(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./node_modules/next/dist/client/image.js":
/*!************************************************!*\
  !*** ./node_modules/next/dist/client/image.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = Image1;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _head = _interopRequireDefault(__webpack_require__(/*! ../shared/lib/head */ "../shared/lib/head"));

var _toBase64 = __webpack_require__(/*! ../shared/lib/to-base-64 */ "../shared/lib/to-base-64");

var _imageConfig = __webpack_require__(/*! ../server/image-config */ "../server/image-config");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};
    var ownKeys = Object.keys(source);

    if (typeof Object.getOwnPropertySymbols === "function") {
      ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) {
        return Object.getOwnPropertyDescriptor(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      _defineProperty(target, key, source[key]);
    });
  }

  return target;
}

function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};

  var target = _objectWithoutPropertiesLoose(source, excluded);

  var key, i;

  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

const loadedImageURLs = new Set();

if (true) {
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['default', defaultLoader], ['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['custom', customLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];

function isStaticRequire(src) {
  return src.default !== undefined;
}

function isStaticImageData(src) {
  return src.src !== undefined;
}

function isStaticImport(src) {
  return typeof src === 'object' && (isStaticRequire(src) || isStaticImageData(src));
}

const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","domains":[]} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout, sizes) {
  if (sizes && (layout === 'fill' || layout === 'responsive')) {
    // Find all the "vw" percent sizes used in the sizes prop
    const viewportWidthRe = /(^|\s)(1?\d?\d)vw/g;
    const percentSizes = [];

    for (let match; match = viewportWidthRe.exec(sizes); match) {
      percentSizes.push(parseInt(match[2]));
    }

    if (percentSizes.length) {
      const smallestRatio = Math.min(...percentSizes) * 0.01;
      return {
        widths: allSizes.filter(s => s >= configDeviceSizes[0] * smallestRatio),
        kind: 'w'
      };
    }

    return {
      widths: allSizes,
      kind: 'w'
    };
  }

  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout, sizes);
  const last = widths.length - 1;
  return {
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', '),
    // It's intended to keep `src` the last attribute because React updates
    // attributes in order. If we keep `src` the first one, Safari will
    // immediately start to fetch `src`, before `sizes` and `srcSet` are even
    // updated by React. That causes multiple unnecessary requests if `srcSet`
    // and `sizes` are defined.
    // This bug cannot be reproduced in Chrome or Firefox.
    src: loader({
      src,
      quality,
      width: widths[last]
    })
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load(_objectSpread({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
} // See https://stackoverflow.com/q/39777833/266535 for why we use this ref
// handler instead of the img's onLoad attribute.


function handleLoading(img, src, layout, placeholder, onLoadingComplete) {
  if (!img) {
    return;
  }

  const handleLoad = () => {
    if (!img.src.startsWith('data:')) {
      const p = 'decode' in img ? img.decode() : Promise.resolve();
      p.catch(() => {}).then(() => {
        if (placeholder === 'blur') {
          img.style.filter = 'none';
          img.style.backgroundSize = 'none';
          img.style.backgroundImage = 'none';
        }

        loadedImageURLs.add(src);

        if (onLoadingComplete) {
          const {
            naturalWidth,
            naturalHeight
          } = img; // Pass back read-only primitive values but not the
          // underlying DOM element because it could be misused.

          onLoadingComplete({
            naturalWidth,
            naturalHeight
          });
        }

        if (true) {
          var ref;

          if ((ref = img.parentElement) === null || ref === void 0 ? void 0 : ref.parentElement) {
            const parent = getComputedStyle(img.parentElement.parentElement);

            if (layout === 'responsive' && parent.display === 'flex') {
              console.warn(`Image with src "${src}" may not render properly as a child of a flex container. Consider wrapping the image with a div to configure the width.`);
            } else if (layout === 'fill' && parent.position !== 'relative') {
              console.warn(`Image with src "${src}" may not render properly with a parent using position:"${parent.position}". Consider changing the parent style to position:"relative" with a width and height.`);
            }
          }
        }
      });
    }
  };

  if (img.complete) {
    // If the real image fails to load, this will still remove the placeholder.
    // This is the desired behavior for now, and will be revisited when error
    // handling is worked on for the image component itself.
    handleLoad();
  } else {
    img.onload = handleLoad;
  }
}

function Image1(_param) {
  var {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    lazyBoundary = '200px',
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    onLoadingComplete,
    loader = defaultImageLoader,
    placeholder = 'empty',
    blurDataURL
  } = _param,
      all = _objectWithoutProperties(_param, ["src", "sizes", "unoptimized", "priority", "loading", "lazyBoundary", "className", "quality", "width", "height", "objectFit", "objectPosition", "onLoadingComplete", "loader", "placeholder", "blurDataURL"]);

  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';

  if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  let staticSrc = '';

  if (isStaticImport(src)) {
    const staticImageData = isStaticRequire(src) ? src.default : src;

    if (!staticImageData.src) {
      throw new Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(staticImageData)}`);
    }

    blurDataURL = blurDataURL || staticImageData.blurDataURL;
    staticSrc = staticImageData.src;

    if (!layout || layout !== 'fill') {
      height = height || staticImageData.height;
      width = width || staticImageData.width;

      if (!staticImageData.height || !staticImageData.width) {
        throw new Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(staticImageData)}`);
      }
    }
  }

  src = typeof src === 'string' ? src : staticSrc;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);
  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src.startsWith('data:') || src.startsWith('blob:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  if (false) {}

  if (true) {
    if (!src) {
      throw new Error(`Image is missing required "src" property. Make sure you pass "src" in props to the \`next/image\` component. Received: ${JSON.stringify({
        width,
        height,
        quality
      })}`);
    }

    if (!VALID_LAYOUT_VALUES.includes(layout)) {
      throw new Error(`Image with src "${src}" has invalid "layout" property. Provided "${layout}" should be one of ${VALID_LAYOUT_VALUES.map(String).join(',')}.`);
    }

    if (typeof widthInt !== 'undefined' && isNaN(widthInt) || typeof heightInt !== 'undefined' && isNaN(heightInt)) {
      throw new Error(`Image with src "${src}" has invalid "width" or "height" property. These should be numeric values.`);
    }

    if (layout === 'fill' && (width || height)) {
      console.warn(`Image with src "${src}" and "layout='fill'" has unused properties assigned. Please remove "width" and "height".`);
    }

    if (!VALID_LOADING_VALUES.includes(loading)) {
      throw new Error(`Image with src "${src}" has invalid "loading" property. Provided "${loading}" should be one of ${VALID_LOADING_VALUES.map(String).join(',')}.`);
    }

    if (priority && loading === 'lazy') {
      throw new Error(`Image with src "${src}" has both "priority" and "loading='lazy'" properties. Only one should be used.`);
    }

    if (placeholder === 'blur') {
      if (layout !== 'fill' && (widthInt || 0) * (heightInt || 0) < 1600) {
        console.warn(`Image with src "${src}" is smaller than 40x40. Consider removing the "placeholder='blur'" property to improve performance.`);
      }

      if (!blurDataURL) {
        const VALID_BLUR_EXT = ['jpeg', 'png', 'webp'] // should match next-image-loader
        ;
        throw new Error(`Image with src "${src}" has "placeholder='blur'" property but is missing the "blurDataURL" property.
          Possible solutions:
            - Add a "blurDataURL" property, the contents should be a small Data URL to represent the image
            - Change the "src" property to a static import with one of the supported file types: ${VALID_BLUR_EXT.join(',')}
            - Remove the "placeholder" property, effectively no blur effect
          Read more: https://nextjs.org/docs/messages/placeholder-blur-data-url`);
      }
    }

    if ('ref' in rest) {
      console.warn(`Image with src "${src}" is using unsupported "ref" property. Consider using the "onLoadingComplete" property instead.`);
    }

    if ('style' in rest) {
      console.warn(`Image with src "${src}" is using unsupported "style" property. Please use the "className" property instead.`);
    }

    const rand = Math.floor(Math.random() * 1000) + 100;

    if (!unoptimized && !loader({
      src,
      width: rand,
      quality: 75
    }).includes(rand.toString())) {
      console.warn(`Image with src "${src}" has a "loader" property that does not implement width. Please implement it or use the "unoptimized" property instead.` + `\nRead more: https://nextjs.org/docs/messages/next-image-missing-loader-width`);
    }
  }

  const [setRef, isIntersected] = (0, _useIntersection).useIntersection({
    rootMargin: lazyBoundary,
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  };
  const blurStyle = placeholder === 'blur' ? {
    filter: 'blur(20px)',
    backgroundSize: objectFit || 'cover',
    backgroundImage: `url("${blurDataURL}")`,
    backgroundPosition: objectPosition || '0% 0%'
  } : {};

  if (layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else {
    // <Image src="i.png" />
    if (true) {
      throw new Error(`Image with src "${src}" must use "width" and "height" properties or "layout='fill'" property.`);
    }
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  let srcString = src;
  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    src: `data:image/svg+xml;base64,${(0, _toBase64).toBase64(sizerSvg)}`
  }) : null) : null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    "data-nimg": layout,
    className: className,
    ref: img => {
      setRef(img);
      handleLoading(img, srcString, layout, placeholder, onLoadingComplete);
    },
    style: _objectSpread({}, imgStyle, blurStyle)
  })), /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, generateImgAttrs({
    src,
    unoptimized,
    layout,
    width: widthInt,
    quality: qualityInt,
    sizes,
    loader
  }), {
    decoding: "async",
    "data-nimg": layout,
    style: imgStyle,
    className: className,
    loading: loading || 'lazy'
  }))), priority ? // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset

  /*#__PURE__*/
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src,
    // @ts-ignore: imagesrcset is not yet in the link element type.
    imagesrcset: imgAttributes.srcSet,
    // @ts-ignore: imagesizes is not yet in the link element type.
    imagesizes: imgAttributes.sizes
  })) : null);
}

function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?auto=format&fit=max&w=300
  const url = new URL(`${root}${normalizeSrc(src)}`);
  const params = url.searchParams;
  params.set('auto', params.get('auto') || 'format');
  params.set('fit', params.get('fit') || 'max');
  params.set('w', params.get('w') || width.toString());

  if (quality) {
    params.set('q', quality.toString());
  }

  return url.href;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function customLoader({
  src
}) {
  throw new Error(`Image with src "${src}" is missing "loader" prop.` + `\nRead more: https://nextjs.org/docs/messages/next-image-missing-loader`);
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (true) {
    const missingValues = []; // these should always be provided but make sure they are

    if (!src) missingValues.push('src');
    if (!width) missingValues.push('width');

    if (missingValues.length > 0) {
      throw new Error(`Next Image Optimization requires ${missingValues.join(', ')} to be provided. Make sure you pass them as props to the \`next/image\` component. Received: ${JSON.stringify({
        src,
        width,
        quality
      })}`);
    }

    if (src.startsWith('//')) {
      throw new Error(`Failed to parse src "${src}" on \`next/image\`, protocol-relative URL (//) must be changed to an absolute URL (http:// or https://)`);
    }

    if (!src.startsWith('/') && configDomains) {
      let parsedSrc;

      try {
        parsedSrc = new URL(src);
      } catch (err) {
        console.error(err);
        throw new Error(`Failed to parse src "${src}" on \`next/image\`, if using relative image it must start with a leading slash "/" or be an absolute URL (http:// or https://)`);
      }

      if ( true && !configDomains.includes(parsedSrc.hostname)) {
        throw new Error(`Invalid src prop (${src}) on \`next/image\`, hostname "${parsedSrc.hostname}" is not configured under images in your \`next.config.js\`\n` + `See more info: https://nextjs.org/docs/messages/next-image-unconfigured-host`);
      }
    }
  }

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "./node_modules/next/dist/client/link.js":
/*!***********************************************!*\
  !*** ./node_modules/next/dist/client/link.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ../shared/lib/router/router */ "./node_modules/next/dist/shared/lib/router/router.js");

var _router1 = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const prefetched = {};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router).isLocalURL(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (true) {
      // rethrow to show invalid URL errors
      throw err;
    }
  });
  const curLocale = options && typeof options.locale !== 'undefined' ? options.locale : router && router.locale; // Join on an invalid URI character

  prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router).isLocalURL(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null && as.indexOf('#') >= 0) {
    scroll = false;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow,
    locale,
    scroll
  });
}

function Link(props) {
  if (true) {
    function createPropError(args) {
      return new Error(`Failed prop type: The prop \`${args.key}\` expects a ${args.expected} in \`<Link>\`, but got \`${args.actual}\` instead.` + ( false ? 0 : ''));
    } // TypeScript trick for type-guarding:


    const requiredPropsGuard = {
      href: true
    };
    const requiredProps = Object.keys(requiredPropsGuard);
    requiredProps.forEach(key => {
      if (key === 'href') {
        if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: props[key] === null ? 'null' : typeof props[key]
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // TypeScript trick for type-guarding:

    const optionalPropsGuard = {
      as: true,
      replace: true,
      scroll: true,
      shallow: true,
      passHref: true,
      prefetch: true,
      locale: true
    };
    const optionalProps = Object.keys(optionalPropsGuard);
    optionalProps.forEach(key => {
      const valType = typeof props[key];

      if (key === 'as') {
        if (props[key] && valType !== 'string' && valType !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: valType
          });
        }
      } else if (key === 'locale') {
        if (props[key] && valType !== 'string') {
          throw createPropError({
            key,
            expected: '`string`',
            actual: valType
          });
        }
      } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'prefetch') {
        if (props[key] != null && valType !== 'boolean') {
          throw createPropError({
            key,
            expected: '`boolean`',
            actual: valType
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // This hook is in a conditional but that is ok because `process.env.NODE_ENV` never changes
    // eslint-disable-next-line react-hooks/rules-of-hooks

    const hasWarned = _react.default.useRef(false);

    if (props.prefetch && !hasWarned.current) {
      hasWarned.current = true;
      console.warn('Next.js auto-prefetches automatically based on viewport. The prefetch attribute is no longer needed. More: https://nextjs.org/docs/messages/prefetch-true-deprecated');
    }
  }

  const p = props.prefetch !== false;
  const router = (0, _router1).useRouter();

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router).resolveHref(router, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router).resolveHref(router, props.as) : resolvedAs || resolvedHref
    };
  }, [router, props.href, props.as]);

  let {
    children,
    replace,
    shallow,
    scroll,
    locale
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  let child;

  if (true) {
    try {
      child = _react.default.Children.only(children);
    } catch (err) {
      throw new Error(`Multiple children were passed to <Link> with \`href\` of \`${props.href}\` but only one child is supported https://nextjs.org/docs/messages/link-multiple-children` + ( false ? 0 : ''));
    }
  } else {}

  const childRef = child && typeof child === 'object' && child.ref;
  const [setIntersectionRef, isVisible] = (0, _useIntersection).useIntersection({
    rootMargin: '200px'
  });

  const setRef = _react.default.useCallback(el => {
    setIntersectionRef(el);

    if (childRef) {
      if (typeof childRef === 'function') childRef(el);else if (typeof childRef === 'object') {
        childRef.current = el;
      }
    }
  }, [childRef, setIntersectionRef]);

  _react.default.useEffect(() => {
    const shouldPrefetch = isVisible && p && (0, _router).isLocalURL(href);
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale;
    const isPrefetched = prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')];

    if (shouldPrefetch && !isPrefetched) {
      prefetch(router, href, as, {
        locale: curLocale
      });
    }
  }, [as, href, isVisible, locale, p, router]);

  const childProps = {
    ref: setRef,
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll, locale);
      }
    }
  };

  childProps.onMouseEnter = e => {
    if (!(0, _router).isLocalURL(href)) return;

    if (child.props && typeof child.props.onMouseEnter === 'function') {
      child.props.onMouseEnter(e);
    }

    prefetch(router, href, as, {
      priority: true
    });
  }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale; // we only render domain locales if we are currently on a domain locale
    // so that locale links are still visitable in development/preview envs

    const localeDomain = router && router.isLocaleDomain && (0, _router).getDomainLocale(as, curLocale, router && router.locales, router && router.domainLocales);
    childProps.href = localeDomain || (0, _router).addBasePath((0, _router).addLocale(as, curLocale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "./node_modules/next/dist/client/normalize-trailing-slash.js":
/*!*******************************************************************!*\
  !*** ./node_modules/next/dist/client/normalize-trailing-slash.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}

const normalizePathTrailingSlash =  false ? 0 : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.requestIdleCallback = exports.cancelIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/route-loader.js":
/*!*******************************************************!*\
  !*** ./node_modules/next/dist/client/route-loader.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.markAssetError = markAssetError;
exports.isAssetError = isAssetError;
exports.getClientBuildManifest = getClientBuildManifest;
exports.createRouteLoader = createRouteLoader;

var _getAssetPathFromRoute = _interopRequireDefault(__webpack_require__(/*! ../shared/lib/router/utils/get-asset-path-from-route */ "../shared/lib/router/utils/get-asset-path-from-route"));

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
} // 3.8s was arbitrarily chosen as it's what https://web.dev/interactive
// considers as "Good" time-to-interactive. We must assume something went
// wrong beyond this point, and then fall-back to a full page transition to
// show the user something of value.


const MS_MAX_IDLE_DELAY = 3800;

function withFuture(key, map, generator) {
  let entry = map.get(key);

  if (entry) {
    if ('future' in entry) {
      return entry.future;
    }

    return Promise.resolve(entry);
  }

  let resolver;
  const prom = new Promise(resolve => {
    resolver = resolve;
  });
  map.set(key, entry = {
    resolve: resolver,
    future: prom
  });
  return generator ? generator().then(value => (resolver(value), value)) : prom;
}

function hasPrefetch(link) {
  try {
    link = document.createElement('link');
    return (// detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || link.relList.supports('prefetch')
    );
  } catch (e) {
    return false;
  }
}

const canPrefetch = hasPrefetch();

function prefetchViaDom(href, as, link) {
  return new Promise((res, rej) => {
    if (document.querySelector(`link[rel="prefetch"][href^="${href}"]`)) {
      return res();
    }

    link = document.createElement('link'); // The order of property assignment here is intentional:

    if (as) link.as = as;
    link.rel = `prefetch`;
    link.crossOrigin = undefined;
    link.onload = res;
    link.onerror = rej; // `href` should always be last:

    link.href = href;
    document.head.appendChild(link);
  });
}

const ASSET_LOAD_ERROR = Symbol('ASSET_LOAD_ERROR');

function markAssetError(err) {
  return Object.defineProperty(err, ASSET_LOAD_ERROR, {});
}

function isAssetError(err) {
  return err && ASSET_LOAD_ERROR in err;
}

function appendScript(src, script) {
  return new Promise((resolve, reject) => {
    script = document.createElement('script'); // The order of property assignment here is intentional.
    // 1. Setup success/failure hooks in case the browser synchronously
    //    executes when `src` is set.

    script.onload = resolve;

    script.onerror = () => reject(markAssetError(new Error(`Failed to load script: ${src}`))); // 2. Configure the cross-origin attribute before setting `src` in case the
    //    browser begins to fetch.


    script.crossOrigin = undefined; // 3. Finally, set the source and inject into the DOM in case the child
    //    must be appended for fetching to start.

    script.src = src;
    document.body.appendChild(script);
  });
} // We wait for pages to be built in dev before we start the route transition
// timeout to prevent an un-necessary hard navigation in development.


let devBuildPromise; // Resolve a promise that times out after given amount of milliseconds.

function resolvePromiseWithTimeout(p, ms, err) {
  return new Promise((resolve, reject) => {
    let cancelled = false;
    p.then(r => {
      // Resolved, cancel the timeout
      cancelled = true;
      resolve(r);
    }).catch(reject); // We wrap these checks separately for better dead-code elimination in
    // production bundles.

    if (true) {
      (devBuildPromise || Promise.resolve()).then(() => {
        (0, _requestIdleCallback).requestIdleCallback(() => setTimeout(() => {
          if (!cancelled) {
            reject(err);
          }
        }, ms));
      });
    }

    if (false) {}
  });
}

function getClientBuildManifest() {
  if (self.__BUILD_MANIFEST) {
    return Promise.resolve(self.__BUILD_MANIFEST);
  }

  const onBuildManifest = new Promise(resolve => {
    // Mandatory because this is not concurrent safe:
    const cb = self.__BUILD_MANIFEST_CB;

    self.__BUILD_MANIFEST_CB = () => {
      resolve(self.__BUILD_MANIFEST);
      cb && cb();
    };
  });
  return resolvePromiseWithTimeout(onBuildManifest, MS_MAX_IDLE_DELAY, markAssetError(new Error('Failed to load client build manifest')));
}

function getFilesForRoute(assetPrefix, route) {
  if (true) {
    return Promise.resolve({
      scripts: [assetPrefix + '/_next/static/chunks/pages' + encodeURI((0, _getAssetPathFromRoute).default(route, '.js'))],
      // Styles are handled by `style-loader` in development:
      css: []
    });
  }

  return getClientBuildManifest().then(manifest => {
    if (!(route in manifest)) {
      throw markAssetError(new Error(`Failed to lookup route: ${route}`));
    }

    const allFiles = manifest[route].map(entry => assetPrefix + '/_next/' + encodeURI(entry));
    return {
      scripts: allFiles.filter(v => v.endsWith('.js')),
      css: allFiles.filter(v => v.endsWith('.css'))
    };
  });
}

function createRouteLoader(assetPrefix) {
  const entrypoints = new Map();
  const loadedScripts = new Map();
  const styleSheets = new Map();
  const routes = new Map();

  function maybeExecuteScript(src) {
    let prom = loadedScripts.get(src);

    if (prom) {
      return prom;
    } // Skip executing script if it's already in the DOM:


    if (document.querySelector(`script[src^="${src}"]`)) {
      return Promise.resolve();
    }

    loadedScripts.set(src, prom = appendScript(src));
    return prom;
  }

  function fetchStyleSheet(href) {
    let prom = styleSheets.get(href);

    if (prom) {
      return prom;
    }

    styleSheets.set(href, prom = fetch(href).then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load stylesheet: ${href}`);
      }

      return res.text().then(text => ({
        href: href,
        content: text
      }));
    }).catch(err => {
      throw markAssetError(err);
    }));
    return prom;
  }

  return {
    whenEntrypoint(route) {
      return withFuture(route, entrypoints);
    },

    onEntrypoint(route, execute) {
      Promise.resolve(execute).then(fn => fn()).then(exports => ({
        component: exports && exports.default || exports,
        exports: exports
      }), err => ({
        error: err
      })).then(input => {
        const old = entrypoints.get(route);
        entrypoints.set(route, input);
        if (old && 'resolve' in old) old.resolve(input);
      });
    },

    loadRoute(route, prefetch) {
      return withFuture(route, routes, () => {
        const routeFilesPromise = getFilesForRoute(assetPrefix, route).then(({
          scripts,
          css
        }) => {
          return Promise.all([entrypoints.has(route) ? [] : Promise.all(scripts.map(maybeExecuteScript)), Promise.all(css.map(fetchStyleSheet))]);
        }).then(res => {
          return this.whenEntrypoint(route).then(entrypoint => ({
            entrypoint,
            styles: res[1]
          }));
        });

        if (true) {
          devBuildPromise = new Promise(resolve => {
            if (routeFilesPromise) {
              return routeFilesPromise.finally(() => {
                resolve();
              });
            }
          });
        }

        return resolvePromiseWithTimeout(routeFilesPromise, MS_MAX_IDLE_DELAY, markAssetError(new Error(`Route did not complete loading: ${route}`))).then(({
          entrypoint,
          styles
        }) => {
          const res = Object.assign({
            styles: styles
          }, entrypoint);
          return 'error' in entrypoint ? entrypoint : res;
        }).catch(err => {
          if (prefetch) {
            // we don't want to cache errors during prefetch
            throw err;
          }

          return {
            error: err
          };
        });
      });
    },

    prefetch(route) {
      // https://github.com/GoogleChromeLabs/quicklink/blob/453a661fa1fa940e2d2e044452398e38c67a98fb/src/index.mjs#L115-L118
      // License: Apache 2.0
      let cn;

      if (cn = navigator.connection) {
        // Don't prefetch if using 2G or if Save-Data is enabled.
        if (cn.saveData || /2g/.test(cn.effectiveType)) return Promise.resolve();
      }

      return getFilesForRoute(assetPrefix, route).then(output => Promise.all(canPrefetch ? output.scripts.map(script => prefetchViaDom(script, 'script')) : [])).then(() => {
        (0, _requestIdleCallback).requestIdleCallback(() => this.loadRoute(route, true).catch(() => {}));
      }).catch( // swallow prefetch errors
      () => {});
    }

  };
}

/***/ }),

/***/ "./node_modules/next/dist/client/router.js":
/*!*************************************************!*\
  !*** ./node_modules/next/dist/client/router.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "Router", ({
  enumerable: true,
  get: function () {
    return _router.default;
  }
}));
Object.defineProperty(exports, "withRouter", ({
  enumerable: true,
  get: function () {
    return _withRouter.default;
  }
}));
exports.useRouter = useRouter;
exports.createRouter = createRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = _interopRequireDefault(__webpack_require__(/*! ../shared/lib/router/router */ "./node_modules/next/dist/shared/lib/router/router.js"));

var _routerContext = __webpack_require__(/*! ../shared/lib/router-context */ "../shared/lib/router-context");

var _withRouter = _interopRequireDefault(__webpack_require__(/*! ./with-router */ "./node_modules/next/dist/client/with-router.js"));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const singletonRouter = {
  router: null,
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale', 'isReady', 'isPreview', 'isLocaleDomain', 'domainLocales'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" on the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
}

var _default = singletonRouter;
exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
}

function createRouter(...args) {
  singletonRouter.router = new _router.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}

function makePublicRouterInstance(router) {
  const _router1 = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router1[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router1[property]) ? [] : {}, _router1[property]) // makes sure query is not stateful
      ;
      continue;
    }

    instance[property] = _router1[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router1[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/client/use-intersection.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/client/use-intersection.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react).useRef();
  const [visible, setVisible] = (0, _react).useState(false);
  const setRef = (0, _react).useCallback(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react).useEffect(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback).requestIdleCallback(() => setVisible(true));
        return () => (0, _requestIdleCallback).cancelIdleCallback(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/client/with-router.js":
/*!******************************************************!*\
  !*** ./node_modules/next/dist/client/with-router.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router).useRouter()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (true) {
    const name = ComposedComponent.displayName || ComposedComponent.name || 'Unknown';
    WithRouterWrapper.displayName = `withRouter(${name})`;
  }

  return WithRouterWrapper;
}

/***/ }),

/***/ "./node_modules/next/dist/shared/lib/router/router.js":
/*!************************************************************!*\
  !*** ./node_modules/next/dist/shared/lib/router/router.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.getDomainLocale = getDomainLocale;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__(/*! ../../../client/normalize-trailing-slash */ "./node_modules/next/dist/client/normalize-trailing-slash.js");

var _routeLoader = __webpack_require__(/*! ../../../client/route-loader */ "./node_modules/next/dist/client/route-loader.js");

var _denormalizePagePath = __webpack_require__(/*! ../../../server/denormalize-page-path */ "../../../server/denormalize-page-path");

var _normalizeLocalePath = __webpack_require__(/*! ../i18n/normalize-locale-path */ "../i18n/normalize-locale-path");

var _mitt = _interopRequireDefault(__webpack_require__(/*! ../mitt */ "../mitt"));

var _utils = __webpack_require__(/*! ../utils */ "../shared/lib/utils");

var _isDynamic = __webpack_require__(/*! ./utils/is-dynamic */ "./utils/is-dynamic");

var _parseRelativeUrl = __webpack_require__(/*! ./utils/parse-relative-url */ "./utils/parse-relative-url");

var _querystring = __webpack_require__(/*! ./utils/querystring */ "./utils/querystring");

var _resolveRewrites = _interopRequireDefault(__webpack_require__(/*! ./utils/resolve-rewrites */ "?5c99"));

var _routeMatcher = __webpack_require__(/*! ./utils/route-matcher */ "./utils/route-matcher");

var _routeRegex = __webpack_require__(/*! ./utils/route-regex */ "./utils/route-regex");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

let detectDomainLocale;

if (false) {}

const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash).normalizePathTrailingSlash(prefix) : `${prefix}${pathNoQueryHash(path) === '/' ? path.substring(1) : path}` : path;
}

function getDomainLocale(path, locale, locales, domainLocales) {
  if (false) {} else {
    return false;
  }
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function pathNoQueryHash(path) {
  const queryIndex = path.indexOf('?');
  const hashIndex = path.indexOf('#');

  if (queryIndex > -1 || hashIndex > -1) {
    path = path.substring(0, queryIndex > -1 ? queryIndex : hashIndex);
  }

  return path;
}

function hasBasePath(path) {
  path = pathNoQueryHash(path);
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  path = path.slice(basePath.length);
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
}

function isLocalURL(url) {
  // prevent a hydration mismatch on href for url with anchor refs
  if (url.startsWith('/') || url.startsWith('#') || url.startsWith('?')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils).getLocationOrigin();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex).getRouteRegex(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher).getRouteMatcher(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && (interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map( // these values should be fully encoded instead of just
    // path delimiter escaped since they are being inserted
    // into the URL and we expect URL encoded segments
    // when parsing dynamic route params
    segment => encodeURIComponent(segment)).join('/') : encodeURIComponent(value)) || '/');
  })) {
    interpolatedRoute = '' // did not satisfy all requirements
    ; // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}

function resolveHref(router, href, resolveAs) {
  // we use a dummy base url for relative urls
  let base;
  let urlAsString = typeof href === 'string' ? href : (0, _utils).formatWithValidation(href); // repeated slashes and backslashes in the URL are considered
  // invalid and will never match a Next.js page/file

  const urlProtoMatch = urlAsString.match(/^[a-zA-Z]{1,}:\/\//);
  const urlAsStringNoProto = urlProtoMatch ? urlAsString.substr(urlProtoMatch[0].length) : urlAsString;
  const urlParts = urlAsStringNoProto.split('?');

  if ((urlParts[0] || '').match(/(\/\/|\\)/)) {
    console.error(`Invalid href passed to next/router: ${urlAsString}, repeated forward-slashes (//) or backslashes \\ are not valid in the href`);
    const normalizedUrl = (0, _utils).normalizeRepeatedSlashes(urlAsStringNoProto);
    urlAsString = (urlProtoMatch ? urlProtoMatch[0] : '') + normalizedUrl;
  } // Return because it cannot be routed by the Next.js router


  if (!isLocalURL(urlAsString)) {
    return resolveAs ? [urlAsString] : urlAsString;
  }

  try {
    base = new URL(urlAsString.startsWith('#') ? router.asPath : router.pathname, 'http://n');
  } catch (_) {
    // fallback to / for invalid asPath values e.g. //
    base = new URL('/', 'http://n');
  }

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash).normalizePathTrailingSlash(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic).isDynamicRoute(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring).searchParamsToUrlQuery(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils).formatWithValidation({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

function stripOrigin(url) {
  const origin = (0, _utils).getLocationOrigin();
  return url.startsWith(origin) ? url.substring(origin.length) : url;
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  let [resolvedHref, resolvedAs] = resolveHref(router, url, true);
  const origin = (0, _utils).getLocationOrigin();
  const hrefHadOrigin = resolvedHref.startsWith(origin);
  const asHadOrigin = resolvedAs && resolvedAs.startsWith(origin);
  resolvedHref = stripOrigin(resolvedHref);
  resolvedAs = resolvedAs ? stripOrigin(resolvedAs) : resolvedAs;
  const preparedUrl = hrefHadOrigin ? resolvedHref : addBasePath(resolvedHref);
  const preparedAs = as ? stripOrigin(resolveHref(router, as)) : resolvedAs || resolvedHref;
  return {
    url: preparedUrl,
    as: asHadOrigin ? preparedAs : addBasePath(preparedAs)
  };
}

function resolveDynamicRoute(pathname, pages) {
  const cleanPathname = (0, _normalizeTrailingSlash).removePathTrailingSlash((0, _denormalizePagePath).denormalizePagePath(pathname));

  if (cleanPathname === '/404' || cleanPathname === '/_error') {
    return pathname;
  } // handle resolving href for dynamic routes


  if (!pages.includes(cleanPathname)) {
    // eslint-disable-next-line array-callback-return
    pages.some(page => {
      if ((0, _isDynamic).isDynamicRoute(page) && (0, _routeRegex).getRouteRegex(page).re.test(cleanPathname)) {
        pathname = page;
        return true;
      }
    });
  }

  return (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname);
}

const manualScrollRestoration =  false && 0;
const SSG_DATA_NOT_FOUND = Symbol('SSG_DATA_NOT_FOUND');

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      if (res.status === 404) {
        return res.json().then(data => {
          if (data.notFound) {
            return {
              notFound: SSG_DATA_NOT_FOUND
            };
          }

          throw new Error(`Failed to load static props`);
        });
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      (0, _routeLoader).markAssetError(err);
    }

    throw err;
  });
}

class Router {
  constructor(pathname1, query1, as1, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component: Component1,
    err: err1,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale,
    domainLocales,
    isPreview
  }) {
    // Static Data Cache
    this.sdc = {}; // In-flight Server Data Requests, for deduping

    this.sdr = {};
    this._idx = 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname: pathname1,
          query: query1
        } = this;
        this.changeState('replaceState', (0, _utils).formatWithValidation({
          pathname: addBasePath(pathname1),
          query: query1
        }), (0, _utils).getURL());
        return;
      }

      if (!state.__N) {
        return;
      }

      let forcedScroll;
      const {
        url,
        as: as1,
        options,
        idx
      } = state;

      if (false) {}

      this._idx = idx;
      const {
        pathname: pathname1
      } = (0, _parseRelativeUrl).parseRelativeUrl(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as1 === this.asPath && pathname1 === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as1, Object.assign({}, options, {
        shallow: options.shallow && this._shallow,
        locale: options.locale || this.defaultLocale
      }), forcedScroll);
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname1); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (pathname1 !== '/_error') {
      this.components[this.route] = {
        Component: Component1,
        initial: true,
        props: initialProps,
        err: err1,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: []
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = pathname1;
    this.query = query1; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    const autoExportDynamic = (0, _isDynamic).isDynamicRoute(pathname1) && self.__NEXT_DATA__.autoExport;

    this.asPath = autoExportDynamic ? pathname1 : as1;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;
    this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || self.__NEXT_DATA__.appGip && !self.__NEXT_DATA__.gsp || !autoExportDynamic && !self.location.search && !false);
    this.isPreview = !!isPreview;
    this.isLocaleDomain = false;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as, options = {}) {
    if (false) {}

    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as, options = {}) {
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options, forcedScroll) {
    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    }

    const shouldResolveHref = url === as || options._h || options._shouldResolveHref; // for static pages with query params in the URL we delay
    // marking the router ready until after the query is updated

    if (options._h) {
      this.isReady = true;
    }

    const prevLocale = this.locale;

    if (false) { var ref; }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    const {
      shallow = false
    } = options;
    const routeProps = {
      shallow
    };

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute, routeProps);
    }

    as = addBasePath(addLocale(hasBasePath(as) ? delBasePath(as) : as, options.locale, this.defaultLocale));
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as;
    let localeChange = prevLocale !== this.locale; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs) && !localeChange) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as, routeProps); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route], null);
      Router.events.emit('hashChangeComplete', as, routeProps);
      return true;
    }

    let parsed = (0, _parseRelativeUrl).parseRelativeUrl(url);
    let {
      pathname: pathname1,
      query: query1
    } = parsed; // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to

    let pages, rewrites;

    try {
      pages = await this.pageLoader.getPageList();
      ({
        __rewrites: rewrites
      } = await (0, _routeLoader).getClientBuildManifest());
    } catch (err1) {
      // If we fail to resolve the page list or client-build manifest, we must
      // do a server-side transition:
      window.location.href = as;
      return false;
    } // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url


    if (!this.urlIsNew(cleanedAs) && !localeChange) {
      method = 'replaceState';
    } // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly


    let resolvedAs = as; // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1

    pathname1 = pathname1 ? (0, _normalizeTrailingSlash).removePathTrailingSlash(delBasePath(pathname1)) : pathname1;

    if (shouldResolveHref && pathname1 !== '/_error') {
      options._shouldResolveHref = true;

      if (false) {} else {
        parsed.pathname = resolveDynamicRoute(pathname1, pages);

        if (parsed.pathname !== pathname1) {
          pathname1 = parsed.pathname;
          parsed.pathname = addBasePath(pathname1);
          url = (0, _utils).formatWithValidation(parsed);
        }
      }
    }

    const route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname1);

    if (!isLocalURL(as)) {
      if (true) {
        throw new Error(`Invalid href: "${url}" and as: "${as}", received relative href and external as` + `\nSee more info: https://nextjs.org/docs/messages/invalid-relative-url-external-as`);
      }

      window.location.href = as;
      return false;
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic).isDynamicRoute(route)) {
      const parsedAs = (0, _parseRelativeUrl).parseRelativeUrl(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex).getRouteRegex(route);
      const routeMatch = (0, _routeMatcher).getRouteMatcher(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query1) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query1[param]);

        if (missingParams.length > 0) {
          if (true) {
            console.warn(`${shouldInterpolate ? `Interpolating href` : `Mismatching \`as\` and \`href\``} failed to manually provide ` + `the params: ${missingParams.join(', ')} in the \`href\`'s \`query\``);
          }

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://nextjs.org/docs/messages/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils).formatWithValidation(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query1, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query1, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as, routeProps);

    try {
      var ref, ref1;
      let routeInfo = await this.getRouteInfo(route, pathname1, query1, as, resolvedAs, routeProps);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props) {
        if (props.pageProps && props.pageProps.__N_REDIRECT) {
          const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
          // client-navigation if it is falling back to hard navigation if
          // it's not

          if (destination.startsWith('/')) {
            const parsedHref = (0, _parseRelativeUrl).parseRelativeUrl(destination);
            parsedHref.pathname = resolveDynamicRoute(parsedHref.pathname, pages);
            const {
              url: newUrl,
              as: newAs
            } = prepareUrlAs(this, destination, destination);
            return this.change(method, newUrl, newAs, options);
          }

          window.location.href = destination;
          return new Promise(() => {});
        }

        this.isPreview = !!props.__N_PREVIEW; // handle SSG data 404

        if (props.notFound === SSG_DATA_NOT_FOUND) {
          let notFoundRoute;

          try {
            await this.fetchComponent('/404');
            notFoundRoute = '/404';
          } catch (_) {
            notFoundRoute = '/_error';
          }

          routeInfo = await this.getRouteInfo(notFoundRoute, notFoundRoute, query1, as, resolvedAs, {
            shallow: false
          });
        }
      }

      Router.events.emit('beforeHistoryChange', as, routeProps);
      this.changeState(method, url, as, options);

      if (true) {
        const appComp = this.components['/_app'].Component;
        window.next.isPrerendered = appComp.getInitialProps === appComp.origGetInitialProps && !routeInfo.Component.getInitialProps;
      }

      if (options._h && pathname1 === '/_error' && ((ref = self.__NEXT_DATA__.props) === null || ref === void 0 ? void 0 : (ref1 = ref.pageProps) === null || ref1 === void 0 ? void 0 : ref1.statusCode) === 500 && (props === null || props === void 0 ? void 0 : props.pageProps)) {
        // ensure statusCode is still correct for static 500 page
        // when updating query information
        props.pageProps.statusCode = 500;
      } // shallow routing is only allowed for same page URL changes.


      const isValidShallowRoute = options.shallow && this.route === route;

      var _scroll;

      const shouldScroll = (_scroll = options.scroll) !== null && _scroll !== void 0 ? _scroll : !isValidShallowRoute;
      const resetScroll = shouldScroll ? {
        x: 0,
        y: 0
      } : null;
      await this.set(route, pathname1, query1, cleanedAs, routeInfo, forcedScroll !== null && forcedScroll !== void 0 ? forcedScroll : resetScroll).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs, routeProps);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as, routeProps);
      return true;
    } catch (err1) {
      if (err1.cancelled) {
        return false;
      }

      throw err1;
    }
  }

  changeState(method, url, as, options = {}) {
    if (true) {
      if (typeof window.history === 'undefined') {
        console.error(`Warning: window.history is not available.`);
        return;
      }

      if (typeof window.history[method] === 'undefined') {
        console.error(`Warning: window.history.${method} is not available`);
        return;
      }
    }

    if (method !== 'pushState' || (0, _utils).getURL() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true,
        idx: this._idx = method !== 'pushState' ? this._idx : this._idx + 1
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, routeProps, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if ((0, _routeLoader).isAssetError(err) || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as, routeProps); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      let Component1;
      let styleSheets;
      let props;

      if (typeof Component1 === 'undefined' || typeof styleSheets === 'undefined') {
        ({
          page: Component1,
          styleSheets
        } = await this.fetchComponent('/_error'));
      }

      const routeInfo = {
        props,
        Component: Component1,
        styleSheets,
        err,
        error: err
      };

      if (!routeInfo.props) {
        try {
          routeInfo.props = await this.getInitialProps(Component1, {
            err,
            pathname,
            query
          });
        } catch (gipErr) {
          console.error('Error in error page `getInitialProps`: ', gipErr);
          routeInfo.props = {};
        }
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, routeProps, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, resolvedAs, routeProps) {
    try {
      const existingRouteInfo = this.components[route];

      if (routeProps.shallow && existingRouteInfo && this.route === route) {
        return existingRouteInfo;
      }

      const cachedRouteInfo = existingRouteInfo && 'initial' in existingRouteInfo ? undefined : existingRouteInfo;
      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component: Component1,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (true) {
        const {
          isValidElementType
        } = __webpack_require__(/*! react-is */ "react-is");

        if (!isValidElementType(Component1)) {
          throw new Error(`The default export is not a React Component in page: "${pathname}"`);
        }
      }

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils).formatWithValidation({
          pathname,
          query
        }), resolvedAs, __N_SSG, this.locale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component1, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as,
        locale: this.locale,
        locales: this.locales,
        defaultLocale: this.defaultLocale
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err2) {
      return this.handleRouteInfoError(err2, pathname, query, as, routeProps);
    }
  }

  set(route, pathname, query, as, data, resetScroll) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data, resetScroll);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value or `#top`
    // To mirror browsers

    if (hash === '' || hash === 'top') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl).parseRelativeUrl(url);
    let {
      pathname: pathname2
    } = parsed;

    if (false) {}

    const pages = await this.pageLoader.getPageList();
    let resolvedAs = asPath;

    if (false) {} else {
      parsed.pathname = resolveDynamicRoute(parsed.pathname, pages);

      if (parsed.pathname !== pathname2) {
        pathname2 = parsed.pathname;
        parsed.pathname = pathname2;
        url = (0, _utils).formatWithValidation(parsed);
      }
    }

    const route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname2); // Prefetch is not supported in development mode because it would trigger on-demand-entries

    if (true) {
      return;
    }

    await Promise.all([this.pageLoader._isSsg(route).then(isSsg => {
      return isSsg ? this._getStaticData(this.pageLoader.getDataHref(url, resolvedAs, true, typeof options.locale !== 'undefined' ? options.locale : this.locale)) : false;
    }), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err2 = new Error('Loading initial props cancelled');
        err2.cancelled = true;
        throw err2;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if (false) {}

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    const {
      href: resourceKey
    } = new URL(dataHref, window.location.href);

    if (this.sdr[resourceKey]) {
      return this.sdr[resourceKey];
    }

    return this.sdr[resourceKey] = fetchNextData(dataHref, this.isSsr).then(data => {
      delete this.sdr[resourceKey];
      return data;
    }).catch(err2 => {
      delete this.sdr[resourceKey];
      throw err2;
    });
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App1
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App1);

    ctx.AppTree = AppTree;
    return (0, _utils).loadGetInitialProps(App1, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as, routeProps) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as, routeProps);
      this.clc();
      this.clc = null;
    }
  }

  notify(data, resetScroll) {
    return this.sub(data, this.components['/_app'].Component, resetScroll);
  }

}

Router.events = (0, _mitt).default();
exports.default = Router;

/***/ }),

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _src_components_LandingPage_Faq__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../src/components/LandingPage/Faq */ "./src/components/LandingPage/Faq.tsx");
/* harmony import */ var _src_components_LandingPage_Hero_Hero__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/components/LandingPage/Hero/Hero */ "./src/components/LandingPage/Hero/Hero.tsx");
/* harmony import */ var _src_components_Shared_NavBar_NavBar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../src/components/Shared/NavBar/NavBar */ "./src/components/Shared/NavBar/NavBar.tsx");
/* harmony import */ var _src_components_LandingPage_WhatDa__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../src/components/LandingPage/WhatDa */ "./src/components/LandingPage/WhatDa.tsx");
/* harmony import */ var _src_components_LandingPage_Community__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../src/components/LandingPage/Community */ "./src/components/LandingPage/Community.tsx");
/* harmony import */ var _src_components_LandingPage_Footer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../src/components/LandingPage/Footer */ "./src/components/LandingPage/Footer.tsx");
/* harmony import */ var _src_components_LandingPage_Roadmap_Roadmap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../src/components/LandingPage/Roadmap/Roadmap */ "./src/components/LandingPage/Roadmap/Roadmap.tsx");
/* harmony import */ var _src_components_LandingPage_Evolution_Evolution__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../src/components/LandingPage/Evolution/Evolution */ "./src/components/LandingPage/Evolution/Evolution.tsx");
/* harmony import */ var _src_components_LandingPage_Eggs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../src/components/LandingPage/Eggs */ "./src/components/LandingPage/Eggs.tsx");
/* harmony import */ var _src_components_LandingPage_BunniesCarousel__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../src/components/LandingPage/BunniesCarousel */ "./src/components/LandingPage/BunniesCarousel.tsx");
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ethersproject/providers */ "@ethersproject/providers");
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_providers__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ethers */ "ethers");
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var web3modal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! web3modal */ "web3modal");
/* harmony import */ var web3modal__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(web3modal__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _walletconnect_web3_provider__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @walletconnect/web3-provider */ "@walletconnect/web3-provider");
/* harmony import */ var _walletconnect_web3_provider__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_walletconnect_web3_provider__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _src_utils_web3lib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../src/utils/web3lib */ "./src/utils/web3lib.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\pages\\index.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





















const LandingWrap = styled_components__WEBPACK_IMPORTED_MODULE_1___default().main.withConfig({
  displayName: "pages__LandingWrap",
  componentId: "sc-ks46ch-0"
})(["overflow:hidden;"]);
const DaBunny_NFT_Address = process.env.NEXT_PUBLIC_DABUNNY_NFTCONTRACT_ADDRESS;
const INFURA_ID = process.env.NEXT_PUBLIC_INFURA_API_KEY_1;

const Home = () => {
  const {
    0: networkName,
    1: setNetworkName
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: provider,
    1: setProvider
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: userBalance,
    1: setUserBalance
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    0: address,
    1: setAddress
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: userData,
    1: setUserData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
    address: '',
    balance: 0,
    network: ''
  });
  const {
    0: message,
    1: setMessage
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const providerOptions = {
    walletconnect: {
      package: (_walletconnect_web3_provider__WEBPACK_IMPORTED_MODULE_16___default()),
      // required
      options: {
        infuraId: INFURA_ID // required

      }
    }
  };
  let assetData = {
    buyerAddress: '',
    normalTokenIds: [],
    rareTokenIds: [],
    totalPricePaid: 0,
    emailId: '',
    subscribeStatus: false,
    purchasedTimeStamp: 0
  }; //It is called when mint button is pressed.

  const onMintToken = async (e, tokenCount, isRarity) => {
    // console.log('Mint token clicked...', tokenCount, rarity);
    // tokenCount = 2;
    let tokenPrice = isRarity ? 0.12 : 0.08; // let tokenPrice = 0.05;

    console.log('onMintToken called ...', tokenCount, tokenPrice); // return;

    console.log('Dabunny address:', DaBunny_NFT_Address);
    console.log('nft address from web3lib:', (0,_src_utils_web3lib__WEBPACK_IMPORTED_MODULE_17__.getNFTAddress)());

    if (provider) {
      let signer = provider.getSigner();
      const accountAddress = await signer.getAddress();
      console.log(accountAddress);
      const nftContract = await (0,_src_utils_web3lib__WEBPACK_IMPORTED_MODULE_17__.getNFTContract)(signer);

      try {
        // let receipt = await tx.wait()
        const price = ethers__WEBPACK_IMPORTED_MODULE_14__.ethers.utils.parseEther((tokenPrice * tokenCount).toString());
        console.log('Price of asset:', price.toString());
        let receipt = await nftContract.mint(tokenCount, isRarity, {
          value: price
        }).then(async tx => {
          return tx.wait().then(receipt => {
            console.log('Receipt:', receipt);
            let tokenIds = [];
            receipt.events.forEach(event => {
              tokenIds.push(Number(event.args[2]));
            }); // let value = receipt.events[0].args[2];
            // let tokenId = value.toNumber();
            // console.log("TokenId minted::", tokenId);

            try {
              if (!isRarity) assetData.normalTokenIds = tokenIds;
              if (isRarity) assetData.rareTokenIds = tokenIds;
              assetData.buyerAddress = userData.address;
              assetData.totalPricePaid = Number(tokenPrice * tokenCount);
              assetData.purchasedTimeStamp = Number(new Date());
              let response = fetch('/api/assets', {
                method: 'POST',
                body: JSON.stringify(assetData)
              });
            } catch (err) {
              console.log('Error while updating data to Backend', err);
            }

            return {
              status: 'Success',
              data: 'TokenId:' + tokenIds.toString(),
              error: ''
            };
          });
        }, error => {
          console.log('ERROR occured1::', error);
          let errMess = error.message.startsWith('MetaMask') ? error.message : error.error.message ? error.error.message : error.message;
          return {
            status: 'Failed',
            data: '',
            error: errMess
          };
        });
        console.log('Fianl Status :: receipt::', receipt);
        if (receipt.status === 'Failed') setMessage(receipt.error);else setMessage(receipt.data);
      } catch (err) {
        console.log('Minting Failed:', err.message);
        setMessage("Minting Failed: " + err.message);
      }
    } else {
      console.log('Please login to wallet');
      alert("Please login to Connect to Wallet");
    }
  }; //It is called when connect wallet button is clicked 


  const onConnectWallet = async () => {
    console.log('Wallet connect clicked...');

    if (!userData.address) {
      let web3Modal = new (web3modal__WEBPACK_IMPORTED_MODULE_15___default())({
        //network: "mainnet", // optional
        cacheProvider: false,
        // optional
        providerOptions // required

      });
      web3Modal.clearCachedProvider();
      let web3provider = await web3Modal.connect();
      console.log('Web3Modal.connect::', web3provider);
      web3provider = new _ethersproject_providers__WEBPACK_IMPORTED_MODULE_13__.Web3Provider(web3provider);
      console.log('web3provider::', web3provider);
      setProvider(web3provider);

      if (web3provider) {
        let networkdata = await web3provider.getNetwork();
        console.log("Network Data::", networkdata);
        console.log('Name:', networkdata.name);

        if (networkdata.name !== "rinkeby") {
          setMessage('Please switch to rinkeby network');
          console.log('Please switch to rinkeby network');
        }

        let signer = web3provider.getSigner();
        console.log('signer:', signer);
        let add = await signer.getAddress();
        console.log('address: ', add);
        let bal = Number(ethers__WEBPACK_IMPORTED_MODULE_14__.ethers.utils.formatEther((await signer.getBalance()).toString()));
        console.log("Accounts:", add);
        console.log("Balance:", bal);
        setNetworkName(networkdata.name);
        setAddress(add);
        setUserBalance(bal);
        setUserData({
          address: add,
          balance: bal,
          network: networkdata.name
        }); // setMessage('Connect successfully');
      }
    } else {
      console.log('User logged out...!!!'); // setMessage('disconnected')

      setUserData({
        address: '',
        balance: 0,
        network: ''
      });
    }
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("title", {
        children: "Home | Dabunny"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 205,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        name: "viewport",
        content: "initial-scale=1.0, width=device-width"
      }, "viewport", false, {
        fileName: _jsxFileName,
        lineNumber: 206,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        name: "description",
        content: "Dabunny curated NFT art"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 207,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        name: "robots",
        content: "index, follow"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 208,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        httpEquiv: "Content-Type",
        content: "text/html;charset=UTF-8"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 209,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        name: "keywords",
        content: "NFT, art, blockchain, digital art, collection, token"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 210,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        property: "og:title",
        content: "Dabunny NFT"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 211,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        property: "og:description",
        content: "Dabunny curated NFT art"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 212,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        property: "og:image",
        content: "../public/img/bunny1.png"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 213,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        property: "og:url",
        content: "https://www.dabunnynft.com/"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 214,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        name: "twitter:card",
        content: "summary_large_image"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 215,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        property: "og:site_name",
        content: "Dabunny NFT"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 216,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("meta", {
        name: "twitter:image:alt",
        content: "Dabunny NFT"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 217,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)("link", {
        rel: "icon",
        href: "/img/favicon.png"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 218,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 204,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(LandingWrap, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(_src_components_Shared_NavBar_NavBar__WEBPACK_IMPORTED_MODULE_5__.default, _objectSpread(_objectSpread({}, userData), {}, {
        onConnectWallet: onConnectWallet
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 222,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(_src_components_LandingPage_Hero_Hero__WEBPACK_IMPORTED_MODULE_4__.default, _objectSpread(_objectSpread({}, userData), {}, {
        provider: provider,
        onMintToken: onMintToken
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 223,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(_src_components_LandingPage_WhatDa__WEBPACK_IMPORTED_MODULE_6__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 226,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(_src_components_LandingPage_BunniesCarousel__WEBPACK_IMPORTED_MODULE_12__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 227,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(_src_components_LandingPage_Evolution_Evolution__WEBPACK_IMPORTED_MODULE_10__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 228,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(_src_components_LandingPage_Eggs__WEBPACK_IMPORTED_MODULE_11__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 229,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(_src_components_LandingPage_Community__WEBPACK_IMPORTED_MODULE_7__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 230,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(_src_components_LandingPage_Roadmap_Roadmap__WEBPACK_IMPORTED_MODULE_9__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 231,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(_src_components_LandingPage_Faq__WEBPACK_IMPORTED_MODULE_3__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 232,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxDEV)(_src_components_LandingPage_Footer__WEBPACK_IMPORTED_MODULE_8__.default, _objectSpread({}, userData), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 233,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 221,
      columnNumber: 7
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

/***/ }),

/***/ "./src/components/LandingPage/BunniesCarousel.tsx":
/*!********************************************************!*\
  !*** ./src/components/LandingPage/BunniesCarousel.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_swipeable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-swipeable */ "react-swipeable");
/* harmony import */ var react_swipeable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_swipeable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\BunniesCarousel.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





 ////////////////////////////////////////////////////////////////////////////////////////Prep Components


let historyItems = [{
  image: `SlideBar_1`
}, {
  image: `SlideBar_2`
}, {
  image: `SlideBar_3`
}, {
  image: `SlideBar_4`
}, {
  image: `SlideBar_5`
}, {
  image: `SlideBar_6`
}, {
  image: `SlideBar_7`
}]; ////////////////////////////////////////////////////////////////////////////////////////////////Styles

const SectionWrap = styled_components__WEBPACK_IMPORTED_MODULE_3___default().section.withConfig({
  displayName: "BunniesCarousel__SectionWrap",
  componentId: "sc-1n6ul4b-0"
})(["background:#acdffb;"]);
const ItemWrap = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "BunniesCarousel__ItemWrap",
  componentId: "sc-1n6ul4b-1"
})(["width:100%;height:100%;position:relative;*{width:calc(100vw/7);@media (max-width:1660px){width:17.5vw;}@media (max-width:768px){width:30vw;}}"]);
const Block = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "BunniesCarousel__Block",
  componentId: "sc-1n6ul4b-2"
})(["position:relative;display:flex;"]);
const Paragraph = styled_components__WEBPACK_IMPORTED_MODULE_3___default().p.withConfig({
  displayName: "BunniesCarousel__Paragraph",
  componentId: "sc-1n6ul4b-3"
})(["display:none;text-align:center;margin-top:48px;font-weight:600;z-index:1;position:relative;padding:0 32px 32px 32px;@media (max-width:970px){display:block;font-size:", ";}@media (max-width:768px){font-size:", ";}@media (max-width:500px){font-size:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.fontSize);

const Item = ({
  image
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(ItemWrap, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_0___default()), {
      src: `/img/${image}.png`,
      alt: "bunny",
      width: 320,
      height: 320
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 83,
    columnNumber: 5
  }, undefined);
}; ////////////////////////////////////////////////////////////////////////////////////////////////Component


const BunniesCarousel = () => {
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    pressHold();
  });

  const pressHold = () => {
    let clicked = false;
    let count, direction, sizeSlider, state, target;
    let item = document.getElementById("bunniesZone");
    let expansionRate = 22.5; // speed for desktop

    item.addEventListener("mousedown", ev => {
      ev.preventDefault();
      item = document.getElementById("bunniesZone");
      target = item.style.transform;
      sizeSlider = (item.children.length - 1) * expansionRate;
      state = parseInt(target.substring(11, target.indexOf(")") - 1));
      clicked = true;
      count = 0;
    });
    item.addEventListener("mousemove", ev => {
      ev.preventDefault();

      if (clicked) {
        direction = ev.movementX < 0 ? -1 : 1;
        count = count + direction / 5;
        item.style.transform = `translateX(${state + count * 2}vw)`.replace("--", "-");
      }
    });
    item.addEventListener("mouseup", ev => {
      const oneElementWidth = item.firstChild.offsetWidth;
      const numberOfElement = item.children.length;
      const nextPosition = (oneElementWidth * numberOfElement / window.innerWidth - 1) * -100;
      const previousPosition = 0;
      ev.preventDefault();
      clicked = false;
      count = 0;

      if (direction === 1) {
        state = previousPosition;
      } else {
        state = nextPosition;
      }

      item.style.transition = `all .5s ease-out`;
      item.style.transform = `translateX(${state}vw)`.replace("--", "-");
      setTimeout(() => {
        item.style.transition = "";
      }, 500);
    });
  };

  const setVariables = () => {
    const expansionRate = 100;
    const element = document.getElementById("bunniesZone");
    const sizeSlider = (element.children.length - 1) * expansionRate;
    const target = element.style.transform;
    const currentPosition = parseInt(target.substring(11, target.indexOf(")") - 1));
    const oneElementWidth = element.firstChild.offsetWidth;
    const numberOfElement = element.children.length;
    const nextPosition = (oneElementWidth * numberOfElement / window.innerWidth - 1) * -100;
    const previousPosition = 0;
    return {
      expansionRate: expansionRate,
      element: element,
      currentPosition: currentPosition,
      nextPosition: nextPosition,
      previousPosition: previousPosition,
      sizeSlider: sizeSlider
    };
  };

  const handlers = (0,react_swipeable__WEBPACK_IMPORTED_MODULE_2__.useSwipeable)({
    onSwiping: ({
      deltaX,
      dir
    }) => {
      if (dir === "Left" || "Right") {
        const {
          currentPosition,
          element
        } = setVariables();
        const speed = 1 * Math.sign(deltaX);
        element.style.transform = `translateX(${currentPosition + speed}vw)`;
      }
    },
    onSwipedLeft: () => {
      const {
        nextPosition,
        element
      } = setVariables();
      element.style.transition = `all .5s ease-out`;
      element.style.transform = `translateX(${nextPosition}vw)`;
      setTimeout(() => {
        element.style.transition = "";
      }, 500);
    },
    onSwipedRight: () => {
      const {
        previousPosition,
        element
      } = setVariables();
      element.style.transition = `all .5s ease-out`;
      element.style.transform = `translateX(${previousPosition}vw)`;
      setTimeout(() => {
        element.style.transition = "";
      }, 500);
    },
    delta: 10,
    preventDefaultTouchmoveEvent: false,
    trackTouch: true
  });
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(SectionWrap, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("div", {
      className: "bunnies",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Block, _objectSpread(_objectSpread({
        id: "bunniesZone",
        style: {
          transform: "translateX(0)"
        }
      }, handlers), {}, {
        children: historyItems.map(element => {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Item, {
            image: element.image
          }, element.image, false, {
            fileName: _jsxFileName,
            lineNumber: 214,
            columnNumber: 15
          }, undefined);
        })
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 207,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 206,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Paragraph, {
      children: "Da Bunny is a tribe of 8,000 programmatically generated NFT bunnies that reside in the Ethereum blockchain. Generation 1 was incubated from a randomized combination of more than 200 unique traits, out of 4,320,000 total possibilities. Each bunny has a unique character and appearance which makes him/her \u201CDa\u201D Bunny...."
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 222,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 205,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BunniesCarousel);

/***/ }),

/***/ "./src/components/LandingPage/Community.tsx":
/*!**************************************************!*\
  !*** ./src/components/LandingPage/Community.tsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Community.tsx";





const Section = styled_components__WEBPACK_IMPORTED_MODULE_2___default().section.withConfig({
  displayName: "Community__Section",
  componentId: "sc-1b1lkww-0"
})(["background-color:#5df2bc;position:relative;padding:20px 0 0 0;@media (max-width:950px){padding-bottom:100px;}@media (max-width:500px){padding-bottom:130px;}"]);
const InnerWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Community__InnerWrap",
  componentId: "sc-1b1lkww-1"
})(["max-width:90rem;margin:0 auto;padding:0 3rem;@media (max-width:1150px){padding:0 20px;}"]);
const TitleTop = styled_components__WEBPACK_IMPORTED_MODULE_2___default().h2.withConfig({
  displayName: "Community__TitleTop",
  componentId: "sc-1b1lkww-2"
})(["font-weight:700;font-size:calc(", " * 1.35);color:#BE6DFF;text-align:center;margin-top:20px;@media (max-width:1660px){font-size:calc(", " * 1.35);}@media (max-width:1440px){font-size:calc(", " * 1.35);}@media (max-width:768px){font-size:calc(", " * 1.35);}@media (max-width:500px){font-size:calc(", " * 1.35);margin-top:12px;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w500.fontSize);
const Title = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(TitleTop).withConfig({
  displayName: "Community__Title",
  componentId: "sc-1b1lkww-3"
})(["font-size:", ";@media (max-width:1660px){font-size:", ";}@media (max-width:1440px){font-size:", ";}@media (max-width:768px){font-size:", ";}@media (max-width:500px){font-size:", ";margin-top:12px;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w500.fontSize);
const Position = styled_components__WEBPACK_IMPORTED_MODULE_2___default().p.withConfig({
  displayName: "Community__Position",
  componentId: "sc-1b1lkww-4"
})(["font-weight:600;font-size:", ";text-align:center;margin-top:.3125rem;@media (max-width:1660px){font-size:", ";}@media (max-width:1440px){font-size:", ";}@media (max-width:768px){font-size:", ";}@media (max-width:500px){font-size:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w500.fontSize);
const ImageWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Community__ImageWrap",
  componentId: "sc-1b1lkww-5"
})(["display:flex;justify-content:space-between;min-width:1110px;max-width:1110px;margin:3.75rem auto 0 auto;@media (max-width:1150px){flex-wrap:wrap;min-width:unset;max-width:600px;}@media (max-width:500px){margin:24px auto 0 auto;}"]);
const ImageBox = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Community__ImageBox",
  componentId: "sc-1b1lkww-6"
})(["width:15.9375rem;height:15.9375rem;@media (max-width:1150px){width:unset;height:unset;}"]);
const BunnyBox = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Community__BunnyBox",
  componentId: "sc-1b1lkww-7"
})(["width:100%;height:100%;display:flex;flex-direction:column;align-items:center;@media (max-width:1150px){width:calc(50% - .5rem);&&:nth-of-type(3),&&:nth-of-type(4){margin-top:32px;}&&:nth-of-type(1),&&:nth-of-type(3){margin-right:.5rem;}&&:nth-of-type(2),&&:nth-of-type(4){margin-left:.5rem;}}"]);
const BubblesImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Community__BubblesImage",
  componentId: "sc-1b1lkww-8"
})(["position:relative;z-index:0;bottom:180px;margin-bottom:-190px;width:100%;@media (max-width:950px){bottom:80px;}@media (max-width:500px){bottom:50px;}img{width:100vw;height:auto;}"]);

const Bunny = ({
  image,
  title,
  position
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BunnyBox, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ImageBox, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        width: 255,
        height: 255,
        src: `/img/${image}`,
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 162,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 161,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Title, {
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 169,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Position, {
      children: position
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 170,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 160,
    columnNumber: 5
  }, undefined);
};

const Community = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Section, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(InnerWrap, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(TitleTop, {
        children: "Da Bunny Community Organizers"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 179,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ImageWrap, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Bunny, {
          image: "Christy.png",
          title: "Da Christy",
          position: "Concept Artist"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 181,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Bunny, {
          image: "David.png",
          title: "Da David",
          position: "Tech & Product"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 182,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Bunny, {
          image: "Canny.png",
          title: "Da Canny",
          position: "Biz & Ops"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 183,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Bunny, {
          image: "Oscar_blue.png",
          title: "Da Oscar",
          position: "Marketing"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 184,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 180,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 178,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BubblesImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        width: 1440,
        height: 504,
        src: "/img/bubbles_red.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 188,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 187,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 177,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Community);

/***/ }),

/***/ "./src/components/LandingPage/Eggs.tsx":
/*!*********************************************!*\
  !*** ./src/components/LandingPage/Eggs.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Shared_CarrotHeader_CarrotHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Shared/CarrotHeader/CarrotHeader */ "./src/components/Shared/CarrotHeader/CarrotHeader.tsx");
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Eggs.tsx";






const Section = styled_components__WEBPACK_IMPORTED_MODULE_2___default().section.withConfig({
  displayName: "Eggs__Section",
  componentId: "sc-l3k9h4-0"
})(["background:#BE6DFF;position:relative;min-height:30rem;padding:150px 32px 200px 32px;@media (max-width:1000px){padding:80px 32px 200px 32px;}@media (max-width:500px){padding:80px 0 200px 16px;}"]);
const HeaderWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Eggs__HeaderWrap",
  componentId: "sc-l3k9h4-1"
})(["max-width:1220px;margin:0 auto;@media (max-width:1000px){display:flex;justify-content:center;padding-right:16px;}"]);
const EggsImages = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Eggs__EggsImages",
  componentId: "sc-l3k9h4-2"
})(["position:relative;z-index:0;top:0;left:0;width:100%;height:", "px;display:flex;align-items:center;justify-content:center;@media (max-width:1300px){top:30px;}@media (max-width:900px){height:", "px;}"], ({
  height
}) => height * 2, ({
  height
}) => height * 3);
const EggsList = styled_components__WEBPACK_IMPORTED_MODULE_2___default().ul.withConfig({
  displayName: "Eggs__EggsList",
  componentId: "sc-l3k9h4-3"
})(["position:relative;max-width:1220px;margin:150px auto 0 auto;border-radius:23px;padding:45px 45px 190px 70px;@media (max-width:500px){padding:26px 32px 120px 40px;}"]);
const Background = styled_components__WEBPACK_IMPORTED_MODULE_2___default().img.withConfig({
  displayName: "Eggs__Background",
  componentId: "sc-l3k9h4-4"
})(["position:absolute;top:0;left:0;width:1220px;height:360px;z-index:0;@media (max-width:1600px){height:370px;}@media (max-width:1300px){width:100%;}@media (max-width:786px){display:none;}"]);
const BackgroundMobile = styled_components__WEBPACK_IMPORTED_MODULE_2___default().img.withConfig({
  displayName: "Eggs__BackgroundMobile",
  componentId: "sc-l3k9h4-5"
})(["display:none;position:absolute;top:0;left:0;width:100%;height:calc(100% - 80px);z-index:0;@media (max-width:786px){display:block;}@media (max-width:500px){display:none;}"]);
const BackgroundMobileSmall = styled_components__WEBPACK_IMPORTED_MODULE_2___default().img.withConfig({
  displayName: "Eggs__BackgroundMobileSmall",
  componentId: "sc-l3k9h4-6"
})(["display:none;position:absolute;top:0;left:0;width:100%;height:calc(100% - 80px);z-index:0;@media (max-width:500px){display:block;}"]);
const TopImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Eggs__TopImage",
  componentId: "sc-l3k9h4-7"
})(["position:absolute;z-index:1;bottom:280px;right:15px;@media (max-width:1660px){bottom:240px;}@media (max-width:1150px){bottom:270px;}@media (max-width:1000px){position:relative;left:50%;right:unset;transform:translateX(-50%);bottom:0;width:400px;height:235px;margin-top:-50px;}@media (max-width:600px){width:280px;height:115px;margin-top:0;}@media (max-width:450px){width:200px;height:40px;margin-top:-20px;}"]);
const ListItem = styled_components__WEBPACK_IMPORTED_MODULE_2___default().li.withConfig({
  displayName: "Eggs__ListItem",
  componentId: "sc-l3k9h4-8"
})(["font-size:", ";font-weight:600;margin-bottom:22px;position:relative;z-index:1;span{color:#BE6DFF;}@media (max-width:1660px){font-size:", ";margin-bottom:12px;}@media (max-width:1440px){font-size:", ";}@media (max-width:768px){font-size:", ";}@media (max-width:500px){font-size:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.fontSize);
const Title = styled_components__WEBPACK_IMPORTED_MODULE_2___default().h3.withConfig({
  displayName: "Eggs__Title",
  componentId: "sc-l3k9h4-9"
})(["font-size:", ";text-align:center;margin-bottom:24px;z-index:1;position:relative;@media (max-width:1660px){font-size:", ";margin-bottom:12px;}@media (max-width:1440px){font-size:", ";}@media (max-width:768px){font-size:", ";}@media (max-width:500px){font-size:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.fontSize);
const Text = styled_components__WEBPACK_IMPORTED_MODULE_2___default().p.withConfig({
  displayName: "Eggs__Text",
  componentId: "sc-l3k9h4-10"
})(["font-size:", ";text-align:center;z-index:1;position:relative;span{font-weight:700;}@media (max-width:1600px){font-size:", ";}@media (max-width:1440px){font-size:", ";}@media (max-width:768px){font-size:16px;line-height:22px;}@media (max-width:600px){font-size:14px;line-height:20px;}@media (max-width:530px){font-size:10px;line-height:12px;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w1660.fontSize);
const BubbleImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Eggs__BubbleImage",
  componentId: "sc-l3k9h4-11"
})(["position:absolute;z-index:0;left:0;bottom:-10px;width:100%;img{width:100vw;height:auto;}"]);
const EggListOuterWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Eggs__EggListOuterWrap",
  componentId: "sc-l3k9h4-12"
})(["position:relative;max-width:1220px;margin:0 auto;"]);
const EggsInfoList = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Eggs__EggsInfoList",
  componentId: "sc-l3k9h4-13"
})(["position:absolute;width:100%;height:100%;display:flex;flex-wrap:wrap;max-width:1000px;justify-content:center;> div:nth-of-type(1){@media (max-width:768px){position:relative;left:-10px;}.text-position-fix{padding:0 15%;top:50px;position:relative;@media (max-width:768px){top:10px;}}.egg-position-fix{top:0;}}> div:nth-of-type(2){@media (max-width:768px){position:relative;left:-10px;}.text-position-fix{padding:0 17.5%;}.egg-position-fix{top:-10px;@media (max-width:1300px){top:0;}}}> div:nth-of-type(3){.text-position-fix{padding:0 12%;top:40px;left:-20px;position:relative;@media (max-width:1440px){padding:0 20%;}}.egg-position-fix{top:25px;}}> div:nth-of-type(4){.text-position-fix{padding:0 15%;padding-top:100px;position:relative;@media (max-width:1440px){left:-15px;}@media (max-width:540px){padding-top:40px;}p{width:90%;margin:0 auto;display:block;}}.egg-position-fix{top:0;}}> div:nth-of-type(5){.text-position-fix{padding:0 10%;position:relative;top:-20px;}.egg-position-fix{top:5px;@media (max-width:1300px){top:0;}}}> div:nth-of-type(6){.text-position-fix{padding:0 10%;position:relative;left:-20px;@media (max-width:1440px){padding:0 15%;}@media (max-width:1200px){top:30px;}}.egg-position-fix{top:40px;@media (max-width:1300px){top:20px;}}}"]);
const EggsInfo = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Eggs__EggsInfo",
  componentId: "sc-l3k9h4-14"
})(["flex-basis:calc(100%/3);display:flex;flex-direction:column;align-items:center;justify-content:center;position:relative;@media (max-width:900px){flex-basis:calc(100%/2);}&&:hover{animation:shake 0.8s cubic-bezier(.37,.08,.20,.91) both;transform:translate3d(0,0,0);perspective:1000px;backface-visibility:hidden;}@keyframes shake{10%,90%{transform:translate3d(-2px,0,0);}20%,80%{transform:translate3d(1px,0,0);}30%,50%,70%{transform:translate3d(-3px,0,0);}40%,60%{transform:translate3d(1px,0,0);}}"]);
const EggImageWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Eggs__EggImageWrap",
  componentId: "sc-l3k9h4-15"
})(["position:absolute;left:0;top:0;width:100%;height:100%;z-index:0;@media (max-width:1300px){display:flex;align-items:center;justify-content:center;}@media (max-width:900px){}"]);

const EggsData = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsInfoList, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsInfo, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("div", {
        className: "text-position-fix",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Title, {
          children: "Rarity.Tools"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 421,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Text, {
          children: "for generative art attributes ranking and rarity lookup dedicated to registered NFT collections only"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 422,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 420,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggImageWrap, {
        className: "egg-position-fix",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          width: 424,
          height: 628,
          src: "/img/all_eggs_01.png",
          alt: ""
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 427,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 426,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 419,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsInfo, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("div", {
        className: "text-position-fix",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Title, {
          children: "Fair Launch"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 437,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Text, {
          children: "0.08 ETH to unlock any Bunny"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 438,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Text, {
          children: "0.12 ETH for more chance to unlock a Super Rare (SRB/SSRB/SB+) Bunny and special exclusive perks"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 439,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 436,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggImageWrap, {
        className: "egg-position-fix",
        id: "firstEgg",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          width: 417,
          height: 628,
          src: "/img/all_eggs_02.png",
          alt: ""
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 442,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 441,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 435,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsInfo, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("div", {
        className: "text-position-fix",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Title, {
          children: "Ownership & Commercial Usage Rights"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 452,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Text, {
          children: "assigned to Da Bunny NFT holders"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 453,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 451,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggImageWrap, {
        className: "egg-position-fix",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          width: 443,
          height: 628,
          src: "/img/all_eggs_03.png",
          alt: ""
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 456,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 455,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 450,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsInfo, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("div", {
        className: "text-position-fix",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Title, {
          children: "Personalized Da Bunny Digital & Physical Merchandise"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 466,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Text, {
          children: ["Exclusive Access for ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("span", {
            children: "all current NFT holders"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 467,
            columnNumber: 38
          }, undefined), " (details to be released on Discord)"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 467,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 465,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggImageWrap, {
        className: "egg-position-fix",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          width: 424,
          height: 627,
          src: "/img/all_eggs_04.png",
          alt: ""
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 470,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 469,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 464,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsInfo, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("div", {
        className: "text-position-fix",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Title, {
          children: "Community Wallet"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 480,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Text, {
          children: "funded by Da Bunny NFT ERC-20 token proceeds to support community events and marketing costs"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 481,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 479,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggImageWrap, {
        className: "egg-position-fix",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          width: 417,
          height: 627,
          src: "/img/all_eggs_05.png",
          alt: ""
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 484,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 483,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 478,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsInfo, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("div", {
        className: "text-position-fix",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Title, {
          children: "Periodic Giveaways"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 494,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Text, {
          children: "to reward Da Bunny NFT holders for being part of the family"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 495,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 493,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggImageWrap, {
        className: "egg-position-fix",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          width: 443,
          height: 627,
          src: "/img/all_eggs_06.png",
          alt: ""
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 498,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 497,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 492,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 418,
    columnNumber: 5
  }, undefined);
};

const EggsHeaderDetails = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggListOuterWrap, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(TopImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        width: 486 / 1.2,
        height: 605 / 1.2,
        src: "/img/Bunny Hole GIF.gif",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 514,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 513,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsList, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Background, {
        alt: "",
        src: "img/rec-background.png"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 522,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(BackgroundMobile, {
        alt: "",
        src: "img/rec-background-mobile.png"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 523,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(BackgroundMobileSmall, {
        alt: "",
        src: "img/rec-background-mobile-small.png"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 524,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(ListItem, {
        children: "Discord-based community for all Da Bunny NFT holders"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 525,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(ListItem, {
        children: ["Members-only access to ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("span", {
          children: "Rabbit Hole"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 529,
          columnNumber: 34
        }, undefined), ", an exclusive clubhouse whose benefits and offerings will unlock with roadmap milestone activations (see below)"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 528,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(ListItem, {
        children: ["We support ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("span", {
          children: "real rabbits"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 533,
          columnNumber: 22
        }, undefined), " globally by donating of 5% of NFT sales net proceeds to the House Rabbit Society"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 532,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 521,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 512,
    columnNumber: 5
  }, undefined);
};

const Eggs = () => {
  const {
    0: listHeight,
    1: setListHeight
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);

  const resizeEventHandle = () => {
    var _document$getElementB;

    const eggImage = (_document$getElementB = document.getElementById('firstEgg')) === null || _document$getElementB === void 0 ? void 0 : _document$getElementB.getElementsByTagName('img')[0];
    const imageHeight = eggImage.offsetHeight;
    setListHeight(imageHeight);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    resizeEventHandle();
    window.addEventListener('resize', resizeEventHandle);
    return () => {
      window.removeEventListener('resize', resizeEventHandle);
    };
  }, []);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Section, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(HeaderWrap, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_Shared_CarrotHeader_CarrotHeader__WEBPACK_IMPORTED_MODULE_3__.default, {
        bgColor: "#ECD6FF",
        padding: "1.5625rem 32px 25px 80px",
        children: "Welcome Down the Rabbit Hole... to Our Community!"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 560,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 559,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsHeaderDetails, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 564,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsImages, {
      height: listHeight,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(EggsData, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 566,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 565,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(BubbleImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        width: 1440,
        height: 436,
        src: "/img/bubbles_green.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 569,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 568,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 558,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Eggs);

/***/ }),

/***/ "./src/components/LandingPage/Evolution/ContentDesktop.tsx":
/*!*****************************************************************!*\
  !*** ./src/components/LandingPage/Evolution/ContentDesktop.tsx ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Evolution\\ContentDesktop.tsx";





const BackInDays = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentDesktop__BackInDays",
  componentId: "sc-rqfrry-0"
})(["width:100%;position:relative;"]);
const ContentImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentDesktop__ContentImage",
  componentId: "sc-rqfrry-1"
})(["position:relative;z-index:0;left:0;top:0;width:100%;height:100%;"]);
const ContentText = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentDesktop__ContentText",
  componentId: "sc-rqfrry-2"
})(["position:absolute;z-index:1;left:0;top:0;width:100%;height:100%;display:flex;flex-direction:column;justify-content:space-around;"]);
const ContentWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentDesktop__ContentWrap",
  componentId: "sc-rqfrry-3"
})(["position:relative;margin-bottom:-100px;@media (max-width:1250px){margin-bottom:-140px;}@media (max-width:1000px){margin-bottom:-110px;}"]);
const BackInDaysText = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentDesktop__BackInDaysText",
  componentId: "sc-rqfrry-4"
})(["font-size:", ";line-height:", ";display:flex;justify-content:flex-end;width:100%;p{max-width:590px;width:60%;@media (max-width:1440px){padding-left:30px;}}@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:1250px){padding:0 0 0 50px;position:relative;top:-50px;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1440.height);
const ThreeBunnies = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentDesktop__ThreeBunnies",
  componentId: "sc-rqfrry-5"
})(["width:100%;position:relative;"]);
const ThreeBunniesText = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentDesktop__ThreeBunniesText",
  componentId: "sc-rqfrry-6"
})(["font-size:", ";line-height:", ";display:flex;justify-content:flex-start;width:100%;position:relative;top:-7rem;p{max-width:590px;width:60%;@media (max-width:1440px){padding-right:30px;}}@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:1250px){padding:0 50px 0 50px;position:relative;top:-120px;}@media (max-width:1150px){top:-80px;}@media (max-width:970px){top:-65px;}@media (max-width:850px){top:-30px;}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w500.height);
const AntMiner = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentDesktop__AntMiner",
  componentId: "sc-rqfrry-7"
})(["width:100%;position:relative;margin:0 auto;"]);
const AntMinerText = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentDesktop__AntMinerText",
  componentId: "sc-rqfrry-8"
})(["font-size:", ";line-height:", ";display:flex;justify-content:flex-end;width:100%;position:relative;top:-12rem;@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}p{max-width:680px;width:60%;@media (max-width:1250px){width:65%;}}"], _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w500.height);

const ContentDesktop = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ContentWrap, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ContentImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        width: 1114,
        height: 1789,
        src: "/img/full-paths.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 182,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 181,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ContentText, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BackInDays, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BackInDaysText, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("p", {
            children: "The origin of Da Bunny tribe is a one-in-a-billion, singular coincidence on earth over the course of evolution..."
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 192,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 191,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 190,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ThreeBunnies, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ThreeBunniesText, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("p", {
            children: "For generations, life couldn't be more boring for a tribe of Lilac Rabbits inhabited on the Easter Island of Chile. These rabbits spent their lifetime at the factory, starved and deprived, mass-producing artificial eggs for a festival celebrated in the post-industrialized human society \u2014 in a meager exchange for only three carrots a day."
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 199,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 198,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 197,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(AntMiner, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(AntMinerText, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("p", {
            children: "The life-changing moment arrived one day when a tribe member found an idled Antminer S19 in the remnants of an abandoned factory havocked by a deadly volcanic erruption. It soon occurred to a rabbit that it can get crypto from the machine."
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 208,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 207,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 206,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 189,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 180,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContentDesktop);

/***/ }),

/***/ "./src/components/LandingPage/Evolution/ContentMobile.tsx":
/*!****************************************************************!*\
  !*** ./src/components/LandingPage/Evolution/ContentMobile.tsx ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Evolution\\ContentMobile.tsx";





const ContentImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentMobile__ContentImage",
  componentId: "sc-12ww3dw-0"
})(["z-index:0;top:0;width:100vw;height:100%;position:relative;"]);
const ContentText = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentMobile__ContentText",
  componentId: "sc-12ww3dw-1"
})(["z-index:1;left:0;top:0;width:100%;height:100%;"]);
const ContentWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentMobile__ContentWrap",
  componentId: "sc-12ww3dw-2"
})(["position:relative;margin-top:90px;"]);
const BlockText = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentMobile__BlockText",
  componentId: "sc-12ww3dw-3"
})(["font-size:", ";line-height:", ";width:100%;@media (max-width:500px){font-size:", ";line-height:", ";}p{text-align:center;padding:0 48px;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w500.height);
const BlockWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "ContentMobile__BlockWrap",
  componentId: "sc-12ww3dw-4"
})(["width:100%;position:relative;margin:0 auto;"]);

const ContentMobile = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ContentWrap, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ContentText, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BlockWrap, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BlockText, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("p", {
            children: "The origin of Da Bunny tribe is a one-in-a-billion, singular coincidence on earth over the course of evolution..."
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 53,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ContentImage, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            width: 769,
            height: 684,
            src: "/img/path_mobile_top.png",
            alt: ""
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 58,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BlockWrap, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BlockText, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("p", {
            children: "For generations, life couldn't be more boring for a tribe of Lilac Rabbits inhabited on the Easter Island of Chile. These rabbits spent their lifetime at the factory, starved and deprived, mass-producing artificial eggs for a festival celebrated in the post-industrialized human society \u2014 in a meager exchange for only three carrots a day."
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 68,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ContentImage, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            width: 769,
            height: 648,
            src: "/img/path_mobile_middle.png",
            alt: ""
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 75,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 74,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BlockWrap, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BlockText, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("p", {
            children: "The life-changing moment arrived one day when a tribe member found an idled Antminer S19 in the remnants of an abandoned factory havocked by a deadly volcanic erruption. It soon occurred to a rabbit that it can get crypto from the machine."
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 85,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ContentImage, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            width: 769,
            height: 708,
            src: "/img/path_mobile_bottom.png",
            alt: ""
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 91,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 90,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 49,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContentMobile);

/***/ }),

/***/ "./src/components/LandingPage/Evolution/Evolution.tsx":
/*!************************************************************!*\
  !*** ./src/components/LandingPage/Evolution/Evolution.tsx ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Shared_CarrotHeader_CarrotHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../Shared/CarrotHeader/CarrotHeader */ "./src/components/Shared/CarrotHeader/CarrotHeader.tsx");
/* harmony import */ var _ContentDesktop__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ContentDesktop */ "./src/components/LandingPage/Evolution/ContentDesktop.tsx");
/* harmony import */ var _ContentMobile__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ContentMobile */ "./src/components/LandingPage/Evolution/ContentMobile.tsx");
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Evolution\\Evolution.tsx";








const Section = styled_components__WEBPACK_IMPORTED_MODULE_2___default().section.withConfig({
  displayName: "Evolution__Section",
  componentId: "sc-1e7ip3a-0"
})(["background-color:#FFD74D;position:relative;overflow:hidden;min-height:30rem;"]);
const BubblesImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Evolution__BubblesImage",
  componentId: "sc-1e7ip3a-1"
})(["position:relative;z-index:0;top:0;width:100%;img{width:100vw;height:auto;}"]);
const HeaderWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Evolution__HeaderWrap",
  componentId: "sc-1e7ip3a-2"
})(["display:flex;justify-content:center;"]);
const InnerWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Evolution__InnerWrap",
  componentId: "sc-1e7ip3a-3"
})(["max-width:1110px;margin:0 auto;@media (max-width:1440px){max-width:950px;}"]);
const BottomText = styled_components__WEBPACK_IMPORTED_MODULE_2___default().p.withConfig({
  displayName: "Evolution__BottomText",
  componentId: "sc-1e7ip3a-4"
})(["font-size:", ";line-height:", ";@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){margin-top:30px;font-size:", ";line-height:", ";}@media (max-width:1250px){padding:50px 48px 10px 48px;}@media (max-width:800px){padding:0 0 10px 0;text-align:center;padding:0 48px;}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w500.height);
const FunnyBunniesImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Evolution__FunnyBunniesImage",
  componentId: "sc-1e7ip3a-5"
})(["max-width:1140px;width:100%;margin:0 auto;margin-top:50px;top:10px;position:relative;@media (max-width:1660px){max-width:1050px;}@media (max-width:800px){margin-top:0;width:110%;left:-5%;}"]);

const Evolution = () => {
  const {
    0: isMobile,
    1: setIsMobile
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const resizeEventHandle = () => {
    if (window.innerWidth < 800) {
      setIsMobile(true);
    } else {
      setIsMobile(false);
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    resizeEventHandle();
    window.addEventListener('resize', resizeEventHandle);
    return () => {
      window.removeEventListener('resize', resizeEventHandle);
    };
  }, []);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Section, {
    id: "rabbit",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(BubblesImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        width: 1440,
        height: 336,
        src: "/img/bubbles_blue_up.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 116,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 115,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(InnerWrap, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(HeaderWrap, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_Shared_CarrotHeader_CarrotHeader__WEBPACK_IMPORTED_MODULE_3__.default, {
          bgColor: "#FFEDAF",
          padding: "1.5625rem 4.0625rem 25px 6.875rem",
          children: "Evolution of Da Bunny"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 125,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 124,
        columnNumber: 9
      }, undefined), isMobile ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_ContentMobile__WEBPACK_IMPORTED_MODULE_5__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 131,
        columnNumber: 11
      }, undefined) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_ContentDesktop__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 133,
        columnNumber: 11
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(BottomText, {
        children: "It soon occurred to another rabbit that crypto trade way more carrots with humans than chocolate eggs. It soon occured to yet another rabbit that carrots are too bland for his taste, and he ordered pizza for the first time. The \u201CAha!\u201D moments continued to cascade and one day, a tribe member decided to take funny portraits of everyone on the island and sell online as NFTs - and this gives rise to Da Bunny!"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 135,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 123,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(FunnyBunniesImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        width: 1440,
        height: 443,
        src: "/img/funny_bunies.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 142,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 141,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 114,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Evolution);

/***/ }),

/***/ "./src/components/LandingPage/Faq.tsx":
/*!********************************************!*\
  !*** ./src/components/LandingPage/Faq.tsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Shared_CarrotHeader_CarrotHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Shared/CarrotHeader/CarrotHeader */ "./src/components/Shared/CarrotHeader/CarrotHeader.tsx");
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Faq.tsx";






const Section = styled_components__WEBPACK_IMPORTED_MODULE_2___default().section.withConfig({
  displayName: "Faq__Section",
  componentId: "sc-8ufbmn-0"
})(["background-color:#39B9FF;position:relative;padding-top:9rem;padding-bottom:25rem;@media (max-width:768px){padding-top:48px;padding-bottom:240px;}"]);
const HeaderWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Faq__HeaderWrap",
  componentId: "sc-8ufbmn-1"
})(["display:flex;justify-content:center;"]);
const InnerLimit = styled_components__WEBPACK_IMPORTED_MODULE_2___default().section.withConfig({
  displayName: "Faq__InnerLimit",
  componentId: "sc-8ufbmn-2"
})(["max-width:90rem;margin:0 auto;"]);
const Paragraph = styled_components__WEBPACK_IMPORTED_MODULE_2___default().p.withConfig({
  displayName: "Faq__Paragraph",
  componentId: "sc-8ufbmn-3"
})(["font-size:", ";@media (max-width:1660px){font-size:", ";}@media (max-width:1440px){font-size:", ";}@media (max-width:768px){font-size:", ";}@media (max-width:500px){font-size:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.fontSize);
const QuestionWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Faq__QuestionWrap",
  componentId: "sc-8ufbmn-4"
})(["margin-top:6.25rem;padding:3.125rem 80px;margin:0 80px;background-color:#BBE7FF;border:3px solid #000000;border-radius:10px;box-shadow:0 8px 0 #000000;@media (max-width:768px){padding:16px;margin:0 16px;box-shadow:0 3.2px 0 0 #000000;}"]);
const TextHeader = styled_components__WEBPACK_IMPORTED_MODULE_2___default().h3.withConfig({
  displayName: "Faq__TextHeader",
  componentId: "sc-8ufbmn-5"
})(["background-color:#FFB9B9;border-radius:8.4375rem;height:4.65rem;padding:1.5rem 40px;box-shadow:16px 16px 0 0 #000000;width:max-content;font-size:", ";margin:3rem 80px 3rem 80px;@media (max-width:1660px){font-size:", ";}@media (max-width:1440px){font-size:", ";}@media (max-width:768px){font-size:", ";margin:24px auto  24px auto;height:38px;padding:10px 30px;box-shadow:6.5px 6.5px 0 0 #000000;}@media (max-width:500px){font-size:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.fontSize);
const TextHeaderFirst = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(TextHeader).withConfig({
  displayName: "Faq__TextHeaderFirst",
  componentId: "sc-8ufbmn-6"
})(["margin:5rem 80px 3rem 80px;@media (max-width:768px){margin:32px auto 48px auto;}"]);
const List = styled_components__WEBPACK_IMPORTED_MODULE_2___default().ul.withConfig({
  displayName: "Faq__List",
  componentId: "sc-8ufbmn-7"
})(["padding-left:40px;@media (max-width:768px){padding-left:16px;}"]);
const ListItem = styled_components__WEBPACK_IMPORTED_MODULE_2___default().li.withConfig({
  displayName: "Faq__ListItem",
  componentId: "sc-8ufbmn-8"
})(["font-family:'Space Grotesk',sans-serif;font-weight:normal;font-size:", ";@media (max-width:1660px){font-size:", ";}@media (max-width:1440px){font-size:", ";}@media (max-width:768px){font-size:", ";}@media (max-width:500px){font-size:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.fontSize);
const BubblesImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Faq__BubblesImage",
  componentId: "sc-8ufbmn-9"
})(["position:absolute;z-index:0;left:0;bottom:-10px;width:100%;img{width:100vw;height:auto;}"]);
const DropDown = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Faq__DropDown",
  componentId: "sc-8ufbmn-10"
})(["overflow:hidden;height:", "px;transition:height .5s ease-out;@media (max-width:1000px){height:", "px;}@media (max-width:768px){height:", "px;}@media (max-width:500px){height:", "px;}@media (max-width:320px){height:", "px;}"], ({
  expanded
}) => expanded ? 758 : 0, ({
  expanded
}) => expanded ? 620 : 0, ({
  expanded
}) => expanded ? 200 : 0, ({
  expanded
}) => expanded ? 260 : 0, ({
  expanded
}) => expanded ? 280 : 0);
const ClickShow = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Faq__ClickShow",
  componentId: "sc-8ufbmn-11"
})(["position:relative;z-index:2;margin:50px 0 0 0;display:flex;align-items:center;justify-content:center;flex-direction:column;width:100%;color:#fff;font-size:", ";font-weight:700;@media (max-width:1660px){font-size:", ";}@media (max-width:1440px){font-size:", ";}@media (max-width:768px){font-size:", ";}@media (max-width:500px){font-size:", ";}svg{margin-top:10px;cursor:pointer;width:30px;height:30px;fill:#fff;transform:rotate(", "deg);transition:transform .2s ease-out;@media (max-width:500px){width:24px;height:24px;margin-top:4px;}}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.fontSize, ({
  expanded
}) => expanded ? 540 : 0);

const Arrow = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 330 330",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("path", {
      d: "M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393\r c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393\r s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 203,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 202,
    columnNumber: 5
  }, undefined);
};

const Faq = () => {
  const {
    0: expanded,
    1: setExpanded
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const toggleShow = () => {
    setExpanded(!expanded);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Section, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(InnerLimit, {
      id: "faq",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(HeaderWrap, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_Shared_CarrotHeader_CarrotHeader__WEBPACK_IMPORTED_MODULE_3__.default, {
          bgColor: "#C6EBFF",
          padding: "1.5625rem 64px 25px 96px",
          children: "Frequently Asked Questions"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 221,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 220,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(TextHeaderFirst, {
        children: "How rare is my Bunny?"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 225,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(QuestionWrap, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Paragraph, {
          children: "\u201CAll bunnies are rare but some are more rare than others.\u201D On the scale of 1-100%:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 227,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(List, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(ListItem, {
            children: "4,000 (50%) are freely roaming Wild Bunnies abundant everywhere on the Island,"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 229,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(ListItem, {
            children: "2,500 (31%) are Rare Bunnies (RB) found in select habitats,"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 230,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(ListItem, {
            children: "1,000 (13%) are Super Rare Bunnies (SRB) hidden in Da Bunny Rabbit Hole,"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 231,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(ListItem, {
            children: "500 (6%) are Super Super Rare Bunnies (SSRB) that travel via secret underground pathways only, and"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 232,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(ListItem, {
            children: ["50 (", '<', "1%) are Superior Bunnies (SB+) equipped only with one-of-a-kind accessories and outfits."]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 233,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 228,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 226,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(TextHeader, {
        children: "What is an NFT?"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 236,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(QuestionWrap, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Paragraph, {
          children: "NFT stands for \u201CNon-fungible token\u201D and is a fancy way of saying it\u2019s a unique, one of a kind digital item that users can buy, own, and trade. Some NFTs main function are to be digital art and look cool, some offer additional utility like exclusive access to websites or participation in an event, think of it like a rare piece of art that can also act as a \u201Cmembers\u201D card."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 238,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 237,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(TextHeader, {
        children: "What is Metamask?"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 244,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(QuestionWrap, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Paragraph, {
          children: "Metamask is a crypto wallet that can store your Ethereum, and is needed to purchase and mint Da Bunny. Having a wallet gives you an Ethereum address (i.e. 0xABCD\u2026.1234), this is where your NFT will be stored. Learn more about Metamask and how easy it is to use over here! (https://metamask.io/)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 246,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 245,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(ClickShow, {
        onClick: toggleShow,
        expanded: expanded,
        children: ["More", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Arrow, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 253,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 251,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(DropDown, {
        expanded: expanded,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(TextHeader, {
          children: "What is OpenSea?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 256,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(QuestionWrap, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Paragraph, {
            children: "OpenSea is a peer-to-peer marketplace for crypto collectibles and non-fungible tokens. It serves as a secondary market for NFTs. Da Bunny NFT Collection can be traded on OpenSea (Da Bunny NFT) (https://opensea.io/)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 258,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 257,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(TextHeader, {
          children: "Have More Questions?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 263,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(QuestionWrap, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Paragraph, {
            children: "Come chat with us on Discord (https://discord.gg/q2MdMthF2z)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 265,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 264,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 255,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 219,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(BubblesImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        width: 1440,
        height: 443,
        src: "/img/bubbles_yellow.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 272,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 271,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 218,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Faq);

/***/ }),

/***/ "./src/components/LandingPage/Footer.tsx":
/*!***********************************************!*\
  !*** ./src/components/LandingPage/Footer.tsx ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var _utils_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../utils/config */ "./src/utils/config.js");
/* harmony import */ var validator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! validator */ "validator");
/* harmony import */ var validator__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(validator__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _links_Links__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../links/Links */ "./src/links/Links.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Footer.tsx";









const Section = styled_components__WEBPACK_IMPORTED_MODULE_3___default().section.withConfig({
  displayName: "Footer__Section",
  componentId: "sc-86jt9a-0"
})(["background-color:#ffd74c;height:44.375rem;position:relative;padding:3.125rem 0 0 0;@media (max-width:1100px){height:unset;padding:0;}@media (max-width:768px){}"]);
const InnerWrap = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Footer__InnerWrap",
  componentId: "sc-86jt9a-1"
})(["padding:0 32px;@media (max-width:768px){position:relative;top:-280px;}"]);
const BunnyImage = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Footer__BunnyImage",
  componentId: "sc-86jt9a-2"
})(["position:absolute;z-index:3;left:-4.6875rem;top:-19.1875rem;width:25.9375rem;@media (max-width:1100px){position:relative;left:-30px;top:80px;}@media (max-width:500px){width:250px;left:-25px;top:55px;}"]);
const LandscapeImage = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Footer__LandscapeImage",
  componentId: "sc-86jt9a-3"
})(["position:absolute;z-index:0;left:0;bottom:0;width:100%;display:flex;justify-content:center;@media (max-width:1110px){bottom:0;}@media (max-width:768px){bottom:0;}"]);
const SmartContractWrap = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Footer__SmartContractWrap",
  componentId: "sc-86jt9a-4"
})(["position:relative;z-index:1;display:flex;justify-content:space-between;max-width:1110px;margin:0 auto;@media (max-width:1100px){flex-direction:column;align-items:center;}"]);
const SmartLeft = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Footer__SmartLeft",
  componentId: "sc-86jt9a-5"
})(["@media (max-width:1100px){order:1;text-align:center;margin-top:60px;}"]);
const TextTop = styled_components__WEBPACK_IMPORTED_MODULE_3___default().p.withConfig({
  displayName: "Footer__TextTop",
  componentId: "sc-86jt9a-6"
})(["font-weight:700;font-size:", ";line-height:", ";@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font40.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font40.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font40.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font40.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font40.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font40.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font40.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font40.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font40.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font40.w500.height);
const TextMiddle = styled_components__WEBPACK_IMPORTED_MODULE_3___default().a.withConfig({
  displayName: "Footer__TextMiddle",
  componentId: "sc-86jt9a-7"
})(["font-weight:bold;font-size:", ";line-height:", ";color:#4A7A72;text-decoration:underline;margin-top:25px;@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.height);
const TokenBottom = styled_components__WEBPACK_IMPORTED_MODULE_3___default().p.withConfig({
  displayName: "Footer__TokenBottom",
  componentId: "sc-86jt9a-8"
})(["font-weight:700;font-size:", ";line-height:", ";margin-top:35px;margin-bottom:14px;word-break:break-all;@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w500.height);
const SmartRight = styled_components__WEBPACK_IMPORTED_MODULE_3___default().a.withConfig({
  displayName: "Footer__SmartRight",
  componentId: "sc-86jt9a-9"
})(["position:relative;padding-top:4.375rem;@media (max-width:1100px){order:0;padding-top:0;}"]);
const TextRight = styled_components__WEBPACK_IMPORTED_MODULE_3___default().p.withConfig({
  displayName: "Footer__TextRight",
  componentId: "sc-86jt9a-10"
})(["width:334.3px;height:135.34px;font-family:Space Grotesk;font-style:normal;font-weight:600;font-size:27.7619px;line-height:35px;display:flex;align-items:center;text-align:center;color:#000000;padding:2rem 20px 20px 20px;text-align:center;background:#E7D7F4;border:3.5px solid #000000;box-shadow:9px 9px 0 #000000;border-radius:12px;height:6rem;@media (max-width:1660px){font-size:27.7619px;}@media (max-width:1440px){font-size:27.7619px;line-height:", ";}@media (max-width:1100px){margin:0 auto;}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";width:200px;height:unset;padding:32px 20px 20px 20px;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w500.height);
const Links = styled_components__WEBPACK_IMPORTED_MODULE_3___default().ul.withConfig({
  displayName: "Footer__Links",
  componentId: "sc-86jt9a-11"
})(["position:relative;z-index:1;margin-top:120px;margin-bottom:30px;display:flex;align-items:center;justify-content:center;"]);
const Item = styled_components__WEBPACK_IMPORTED_MODULE_3___default().li.withConfig({
  displayName: "Footer__Item",
  componentId: "sc-86jt9a-12"
})(["list-style:none;padding:0 3.125rem;font-weight:700;font-size:", ";line-height:", ";@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:1100px){margin:0 auto;}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}a{white-space:nowrap;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font20.w500.height);
const Copyright = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Footer__Copyright",
  componentId: "sc-86jt9a-13"
})(["text-align:center;position:relative;z-index:1;@media (max-width:768px){font-size:14px;}"]);
const EmailSubscribe = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Footer__EmailSubscribe",
  componentId: "sc-86jt9a-14"
})(["text-align:center;position:relative;z-index:1;@media (max-width:768px){font-size:14px;}"]);
const CustomInputText = styled_components__WEBPACK_IMPORTED_MODULE_3___default().input.withConfig({
  displayName: "Footer__CustomInputText",
  componentId: "sc-86jt9a-15"
})(["background:#FFFFFF;border:3px solid #000000;box-sizing:border-box;border-radius:11px;width:471px;height:68px;font-family:Space Grotesk;font-style:normal;font-weight:500;font-size:25px;line-height:32px;color:#B5B5B5;margin-right:15px;padding:0 12px;"]);
const CustomInputBtn = styled_components__WEBPACK_IMPORTED_MODULE_3___default().input.withConfig({
  displayName: "Footer__CustomInputBtn",
  componentId: "sc-86jt9a-16"
})(["background:#96EBBA;border:3px solid #000000;box-sizing:border-box;box-shadow:3px 4px 0px #000000;border-radius:11px;font-family:Space Grotesk;font-style:normal;font-weight:500;font-size:30px;line-height:38px;color:#000000;width:142px;height:68px;padding:0 12px;cursor:pointer;"]);
const Paragraph = styled_components__WEBPACK_IMPORTED_MODULE_3___default().p.withConfig({
  displayName: "Footer__Paragraph",
  componentId: "sc-86jt9a-17"
})(["font-size:20px;line-height:26px;padding-bottom:100px;"]);
const DisplayMessage = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Footer__DisplayMessage",
  componentId: "sc-86jt9a-18"
})(["color:red;text-align:left;position:relative;z-index:1;font-size:14px;@media (max-width:768px){font-size:10px;}"]);
const Loader = styled_components__WEBPACK_IMPORTED_MODULE_3___default().p.withConfig({
  displayName: "Footer__Loader",
  componentId: "sc-86jt9a-19"
})(["color:black;text-align:center;position:relative;z-index:1;font-size:14px;@media (max-width:768px){font-size:10px;}"]);

const Footer = ({
  address,
  balance,
  network
}) => {
  const {
    0: email,
    1: setEmail
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: message,
    1: setMessage
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');

  const onEmailSubscribeHandle = async () => {
    setMessage('');

    if (!validator__WEBPACK_IMPORTED_MODULE_6___default().isEmail(email)) {
      setMessage('Please enter a valid email id');
      return false;
    } else {
      let emailData = {
        emailId: email,
        userAddress: address
      };

      try {
        let response = await fetch('/api/emails', {
          method: 'POST',
          body: JSON.stringify(emailData)
        });
        let data = await response.json();
        console.log('Response from server: ', response, data);
        setMessage(data.message);
      } catch (err) {
        console.log('Error while updating data to Backend', err);
      }
    }

    console.log('Email id is : ', email);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(Section, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(InnerWrap, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(SmartContractWrap, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(SmartLeft, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(TextTop, {
            children: "Verified Smart Contract:"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 370,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(TextMiddle, {
            target: "_blank",
            rel: "noopener",
            href: "https://rinkeby.etherscan.io/address/" + _utils_config__WEBPACK_IMPORTED_MODULE_5__.nftaddress,
            children: "View on Etherscan"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 371,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(TokenBottom, {
            children: _utils_config__WEBPACK_IMPORTED_MODULE_5__.nftaddress ? _utils_config__WEBPACK_IMPORTED_MODULE_5__.nftaddress : '0x...'
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 372,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(EmailSubscribe, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(CustomInputText, {
              type: "text",
              name: "email",
              id: "emailId",
              onChange: e => setEmail(e.target.value)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 374,
              columnNumber: 11
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(CustomInputBtn, {
              type: "button",
              value: "Join",
              onClick: onEmailSubscribeHandle
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 375,
              columnNumber: 11
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(DisplayMessage, {
              children: message
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 376,
              columnNumber: 11
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 373,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 369,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(SmartRight, {
          target: "_blank",
          rel: "noopener",
          href: _links_Links__WEBPACK_IMPORTED_MODULE_7__.DISCORD_LINK,
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(BunnyImage, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
              width: 415,
              height: 483,
              src: "/img/Discord Bunny GIF.gif",
              alt: ""
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 382,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 381,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(TextRight, {
            children: "Join our Discord Channel"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 389,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 380,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 368,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(Links, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(Item, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            href: "https://www.dabunnynft.com/privacy",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("a", {
              children: "Private Policy & Connect Wallet"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 395,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 394,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 393,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 392,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(Copyright, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(Paragraph, {
          children: ["@2021 Da Bunny NFT ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 400,
            columnNumber: 41
          }, undefined), "Produced by MoonLab Co., a Decentalized Autonomous Organization (DAO)"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 400,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 399,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 367,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(LandscapeImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        width: 1439,
        height: 316,
        src: "/img/landscape.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 408,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 407,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 366,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

/***/ }),

/***/ "./src/components/LandingPage/Hero/ConnectButton/ConnectButton.tsx":
/*!*************************************************************************!*\
  !*** ./src/components/LandingPage/Hero/ConnectButton/ConnectButton.tsx ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_Interface__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../utils/Interface */ "./src/utils/Interface.ts");
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Hero\\ConnectButton\\ConnectButton.tsx";





const CtaButton = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ConnectButton__CtaButton",
  componentId: "sc-9ipl48-0"
})(["width:28.4375rem;height:7.5rem;position:relative;top:-14.75rem;display:block;margin:0 auto;@media (max-width:1660px){width:22rem;height:6rem;top:2rem;}@media (max-width:1150px){top:5rem;}@media (max-width:768px){width:14.5rem;height:3.875rem;}"]);
const FirstLayer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ConnectButton__FirstLayer",
  componentId: "sc-9ipl48-1"
})(["background:#FFDC25;position:absolute;z-index:2;top:0;left:0;width:100%;height:100%;border-radius:16px;border:3px solid #000000;"]);
const SecondLayer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ConnectButton__SecondLayer",
  componentId: "sc-9ipl48-2"
})(["background:#4A7A72;position:absolute;z-index:1;top:-.9375rem;left:.9375rem;width:100%;height:100%;border-radius:16px;border:3px solid #000000;@media (max-width:768px){top:-0.3375rem;left:0.3375rem;}"]);
const ButtonText = styled_components__WEBPACK_IMPORTED_MODULE_1___default().p.withConfig({
  displayName: "ConnectButton__ButtonText",
  componentId: "sc-9ipl48-3"
})(["font-size:", ";line-height:", ";position:relative;z-index:2;width:100%;height:100%;font-weight:600;display:flex;align-items:center;justify-content:center;@media (max-width:1600px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font40.w500.height);
const ButtonTextClick = styled_components__WEBPACK_IMPORTED_MODULE_1___default()(ButtonText).withConfig({
  displayName: "ConnectButton__ButtonTextClick",
  componentId: "sc-9ipl48-4"
})(["cursor:pointer;"]);

const LeftCornerSVG = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("svg", {
    width: "50",
    height: "36",
    viewBox: "0 0 50 36",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("path", {
      d: "M5 31.3472V19.0957C5 11.3637 11.268 5.0957 19 5.0957H45",
      stroke: "white",
      strokeWidth: "9",
      strokeLinecap: "round"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 94,
    columnNumber: 5
  }, undefined);
};

const RightCornerSVG = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("svg", {
    width: "92",
    height: "25",
    viewBox: "0 0 92 25",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("path", {
      d: "M87.5 5.23649L87.5 5.59267C87.5 13.3247 81.232 19.5927 73.5 19.5927L4.5 19.5928",
      stroke: "white",
      strokeWidth: "9",
      strokeLinecap: "round"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 103,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 102,
    columnNumber: 5
  }, undefined);
};

const LeftCorner = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ConnectButton__LeftCorner",
  componentId: "sc-9ipl48-5"
})(["position:absolute;z-index:3;left:10px;top:10px;@media (max-width:768px){left:.525rem;top:.325rem;}svg{width:40px;height:1.6875rem;@media (max-width:768px){height:13.5px;width:20px;}}"]);
const RightCorner = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ConnectButton__RightCorner",
  componentId: "sc-9ipl48-6"
})(["position:absolute;z-index:3;right:.3125rem;bottom:10px;@media (max-width:768px){bottom:.125rem;}svg{width:5.1875rem;height:0.9375rem;@media (max-width:768px){width:42px;height:7.5px;}}"]);

const ConnectButton = props => {
  const {
    connectStatus = 0,
    saleStatus = 0,
    setShowMintBox
  } = props;
  console.log(connectStatus, saleStatus);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(CtaButton, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(LeftCorner, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(LeftCornerSVG, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 158,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 157,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(FirstLayer, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 160,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(SecondLayer, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 161,
      columnNumber: 7
    }, undefined), saleStatus === _utils_Interface__WEBPACK_IMPORTED_MODULE_2__.SALE_STATUS.OFFSALE && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ButtonText, {
      children: "TBA"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 162,
      columnNumber: 46
    }, undefined), saleStatus === _utils_Interface__WEBPACK_IMPORTED_MODULE_2__.SALE_STATUS.ONSALE && connectStatus === _utils_Interface__WEBPACK_IMPORTED_MODULE_2__.CONNECT_STATUS.CONNECT && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ButtonTextClick, {
      onClick: () => setShowMintBox(true),
      children: "Connect"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 166,
      columnNumber: 89
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(RightCorner, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(RightCornerSVG, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 170,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 169,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 156,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConnectButton);

/***/ }),

/***/ "./src/components/LandingPage/Hero/Hero.tsx":
/*!**************************************************!*\
  !*** ./src/components/LandingPage/Hero/Hero.tsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ConnectButton_ConnectButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ConnectButton/ConnectButton */ "./src/components/LandingPage/Hero/ConnectButton/ConnectButton.tsx");
/* harmony import */ var _MintButton_MintButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./MintButton/MintButton */ "./src/components/LandingPage/Hero/MintButton/MintButton.tsx");
/* harmony import */ var _utils_Links__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../utils/Links */ "./src/utils/Links.ts");
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Hero\\Hero.tsx";








const Section = styled_components__WEBPACK_IMPORTED_MODULE_1___default().section.withConfig({
  displayName: "Hero__Section",
  componentId: "sc-187th8k-0"
})(["width:100%;text-align:center;margin-bottom:-10px;padding-top:125px;position:relative;height:1056px;@media (max-height:900px) and (min-width:1001px){padding-top:100px;}@media (max-width:1660px){height:630px;}@media (max-width:1000px){height:670px;}@media (max-width:620px){height:620px;}@media (max-width:500px){height:710px;}@media (max-width:400px){height:640px;}"]);
const BannerImage = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "Hero__BannerImage",
  componentId: "sc-187th8k-1"
})(["position:relative;z-index:0;padding:0  24px;height:800px;@media (max-width:1660px){height:390px;}@media (max-width:1000px){height:340px;}@media (max-width:768px){height:335px;}@media (max-width:500px){height:370px;}@media (max-width:400px){height:320px;}"]);
const BunnyImage = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "Hero__BunnyImage",
  componentId: "sc-187th8k-2"
})(["position:absolute;z-index:1;top:320px;left:50%;transform:translateX(-50%);min-width:605px;@media (max-width:1660px){height:calc(605px/1.5);top:250px;}@media (max-width:768px){min-width:400px;}@media (max-width:500px){min-width:320px;top:240px;}@media (max-width:400px){min-width:290px;top:224px;}"]);
const BubbleImage = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "Hero__BubbleImage",
  componentId: "sc-187th8k-3"
})(["position:relative;z-index:0;top:-27vw;width:100%;@media (max-width:1200px){top:-25vw;}@media (max-width:768px){top:-100px;}@media (max-width:500px){top:-25px;}img{width:100vw;height:auto;}"]);
const JoinBoxDesktop = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "Hero__JoinBoxDesktop",
  componentId: "sc-187th8k-4"
})(["position:relative;top:-500px;right:160px;z-index:1;text-align:right;max-width:990px;width:100%;margin:0 auto;@media (max-width:1660px){top:-150px;right:180px;}@media (max-width:1150px){display:none;}svg{width:214px;}"]);
const JoinBoxMobile = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "Hero__JoinBoxMobile",
  componentId: "sc-187th8k-5"
})(["position:relative;z-index:5;text-align:center;top:6rem;max-width:990px;width:100%;margin:0 auto;display:none;@media (max-width:1150px){display:block;}svg{width:214px;@media (max-width:500px){width:166px;}}"]);
const JoinCta = styled_components__WEBPACK_IMPORTED_MODULE_1___default().p.withConfig({
  displayName: "Hero__JoinCta",
  componentId: "sc-187th8k-6"
})(["font-size:", ";@media (max-width:1600px){font-size:", ";}@media (max-width:1440px){font-size:", ";}@media (max-width:768px){font-size:", ";}@media (max-width:500px){font-size:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font20.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_6__.default.font24.w500.fontSize);
const MintBox = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "Hero__MintBox",
  componentId: "sc-187th8k-7"
})(["position:absolute;box-shadow:0px 8px 0px 0px #000000;border-radius:34px;border:4px solid #000000;background:#87EEF4;padding:60px 125px 50px 125px;z-index:5;top:670px;left:50%;transform:translate(-50%,0);@media (max-width:1660px){box-shadow:0px 7px 0px 0px #000000;padding:45px 70px 35px 70px;top:520px;}@media (max-width:768px){box-shadow:0px 4px 0px 0px #000000;padding:15px 50px 20px 50px;border:3px solid #000000;}@media (max-width:400px){top:500px;padding:15px 40px 20px 40px;}"]);
const MintTop = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "Hero__MintTop",
  componentId: "sc-187th8k-8"
})(["display:flex;justify-content:space-between;align-items:center;> div:first-of-type{margin-right:20px;:active{background:#ccc;}@media (max-width:1660px){margin-right:12px;}}> div:last-of-type{margin-left:20px;@media (max-width:1660px){margin-left:12px;}@media (max-width:768px){margin-left:8px;}}> div{background:#FFFFFF;border:4px solid #000000;box-sizing:border-box;border-radius:39.5px;letter-spacing:0.04em;color:#000000;align-items:center;text-align:center;display:flex;font-weight:600;padding:10px 50px;:hover{cursor:pointer;background-color:#ddd;}:focus{background-color:#4A7A72;color:#FFFFFF;}@media (max-width:1200px){padding:8px 35px;}@media (max-width:768px){padding:0 12px;border:3px solid #000000;}p{font-weight:600;font-size:30px;margin-left:12px;@media (max-width:1660px){font-size:22px;}@media (max-width:1200px){font-size:16px;margin-left:8px;}@media (max-width:768px){font-size:14px;margin-left:5px;}}}svg{@media (max-width:1200px){width:18px;}@media (max-width:768px){width:12px;}}"]);
const MintMiddle = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "Hero__MintMiddle",
  componentId: "sc-187th8k-9"
})(["display:flex;background:#D7A6FF;border:4px solid #000000;border-radius:39.5px;justify-content:center;font-size:30px;padding:10px 50px 15px 50px;font-weight:600;@media (max-width:1660px){font-size:22px;padding:8px 35px 12px 35px;}@media (max-width:1200px){font-size:18px;padding:6px 22px 8px 22px;}@media (max-width:768px){font-size:14px;padding:4px 16px 6px 16px;border:3px solid #000000;}p{padding:0 80px;@media (max-width:1660px){padding:0 55px;}@media (max-width:1200px){padding:0 35px;}}div{cursor:pointer;transition:0.3s all;width:30px;}div:hover{cursor:pointer;cursor:pointer;background:#87EEF4;border-radius:10px;}"]);
const Close = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "Hero__Close",
  componentId: "sc-187th8k-10"
})(["cursor:pointer;position:absolute;top:18px;right:18px;z-index:1;font-weight:700;font-size:30px;@media (max-width:1200px){font-size:20px;}@media (max-width:768px){top:12px;right:12px;}"]);
const Rarity = styled_components__WEBPACK_IMPORTED_MODULE_1___default().p.withConfig({
  displayName: "Hero__Rarity",
  componentId: "sc-187th8k-11"
})(["font-weight:600;font-family:'Space Grotesk',sans-serif;text-align:right;font-size:24px;line-height:30px;letter-spacing:0.04em;margin:15px 0 30px 0;@media (max-width:1660px){font-size:18px;line-height:24px;}@media (max-width:1200px){font-size:16px;line-height:20px;margin:10px 0 20px 0;}@media (max-width:768px){font-size:10px;line-height:14px;}"]);
const Limit = styled_components__WEBPACK_IMPORTED_MODULE_1___default().p.withConfig({
  displayName: "Hero__Limit",
  componentId: "sc-187th8k-12"
})(["margin:15px 0 35px 0;font-weight:600;font-family:'Space Grotesk',sans-serif;text-align:center;font-size:24px;line-height:30px;letter-spacing:0.04em;@media (max-width:1660px){font-size:18px;line-height:24px;}@media (max-width:1200px){font-size:16px;line-height:20px;margin:10px 0 20px 0;}@media (max-width:768px){font-size:10px;line-height:14px;}"]);

const Symbol = ({
  children,
  onRarityPriceClicked,
  tabindex
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
    onClick: onRarityPriceClicked,
    tabIndex: Number(tabindex),
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("svg", {
      width: "23",
      height: "37",
      viewBox: "0 0 23 37",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("path", {
        d: "M11.4169 27.7026L0.059082 20.9998L11.41 37.0012L22.7736 20.9998L11.41 27.7026H11.4169ZM11.5857 0L0.23252 18.8434L11.5857 25.5578L22.9436 18.8503L11.5857 0Z",
        fill: "black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 402,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 401,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("p", {
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 404,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 400,
    columnNumber: 9
  }, undefined);
};

const Arrow = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("svg", {
    width: "263",
    height: "17",
    viewBox: "0 0 263 17",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("line", {
      x1: "2",
      y1: "15",
      x2: "261",
      y2: "15",
      stroke: "black",
      strokeWidth: "4",
      strokeLinecap: "round"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 412,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("line", {
      x1: "233.63",
      y1: "2.9601",
      x2: "259.96",
      y2: "14.3697",
      stroke: "black",
      strokeWidth: "4",
      strokeLinecap: "round"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 413,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 411,
    columnNumber: 9
  }, undefined);
};

const Hero = ({
  provider,
  address,
  balance,
  network,
  onMintToken
}) => {
  const {
    0: resizeFactor,
    1: setResizeFactor
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);
  const {
    0: bunnyCount,
    1: setBunnyCount
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);
  const {
    0: showMintBox,
    1: setShowMintBox
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  const {
    0: isRarity,
    1: setIsRarity
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: mintBtnText,
    1: setMintBtnText
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('Mint');

  const onMintToken1 = async e => {
    e.preventDefault();
    console.log('onMintToken1 clicked...', e.target);
    setMintBtnText('Minting...'); // e.target.value = 'Minting...';

    await onMintToken(e, bunnyCount, isRarity); // e.target.value ='Minited Tokens';

    setMintBtnText('Mint');
  };

  const onRarityPriceClicked = e => {
    console.log('Clicked Item: ', e);
    let price = e.currentTarget.innerText;
    console.log('CurrentTarget', e.currentTarget);
    console.log('Price selected:', price);
    if (price === "0.08") setIsRarity(false);else setIsRarity(true);
  };

  const resizeEventHandle = () => {
    const windowWidth = window.innerWidth;

    switch (true) {
      case windowWidth > 1660:
        setResizeFactor(1.5);
        break;

      default:
        setResizeFactor(1.85);
        break;
    }
  };

  const amountChange = amount => {
    switch (amount) {
      case 'increase':
        bunnyCount < 25 && setBunnyCount(bunnyCount + 1);
        break;

      case 'decrease':
        bunnyCount > 1 && setBunnyCount(bunnyCount - 1);
        break;
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    resizeEventHandle();
    window.addEventListener('resize', resizeEventHandle);
    return () => {
      window.removeEventListener('resize', resizeEventHandle);
    };
  }, []);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Section, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(BannerImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        width: 990 / resizeFactor,
        height: 560 / resizeFactor,
        src: "/img/banner.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 490,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 489,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(JoinBoxDesktop, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
        rel: "noreferrer",
        target: "_blank",
        href: _utils_Links__WEBPACK_IMPORTED_MODULE_5__.DISCORD_LINK,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Arrow, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 499,
          columnNumber: 21
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(JoinCta, {
          children: "Join our Discord Channel"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 500,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 498,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 497,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(BunnyImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        width: 605 / resizeFactor,
        height: 605 / resizeFactor,
        src: "/img/Da Bunny Homepage Shuffle.gif",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 504,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 503,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_ConnectButton_ConnectButton__WEBPACK_IMPORTED_MODULE_3__.default, {
      setShowMintBox: setShowMintBox
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 511,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(JoinBoxMobile, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
        rel: "noreferrer",
        target: "_blank",
        href: _utils_Links__WEBPACK_IMPORTED_MODULE_5__.DISCORD_LINK,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Arrow, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 514,
          columnNumber: 21
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(JoinCta, {
          children: "Join our Discord Channel"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 515,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 513,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 512,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(BubbleImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        width: 1440,
        height: 463,
        src: "/img/bubbles.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 519,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 518,
      columnNumber: 13
    }, undefined), showMintBox && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(MintBox, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Close, {
        onClick: () => setShowMintBox(false),
        children: "X"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 528,
        columnNumber: 21
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(MintTop, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Symbol, {
          onRarityPriceClicked: onRarityPriceClicked,
          tabindex: "1",
          children: "0.08"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 530,
          columnNumber: 25
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Symbol, {
          onRarityPriceClicked: onRarityPriceClicked,
          tabindex: "2",
          children: "0.12"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 531,
          columnNumber: 25
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 529,
        columnNumber: 21
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Rarity, {
        children: "(3x Rarity Boost)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 533,
        columnNumber: 21
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(MintMiddle, {
        children: [bunnyCount > 1 && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          onClick: () => amountChange("decrease"),
          children: "-"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 536,
          columnNumber: 29
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("p", {
          children: bunnyCount
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 538,
          columnNumber: 25
        }, undefined), bunnyCount < 25 && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          onClick: () => amountChange("increase"),
          children: "+"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 540,
          columnNumber: 29
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 534,
        columnNumber: 21
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Limit, {
        children: "25 MAX"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 543,
        columnNumber: 21
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_MintButton_MintButton__WEBPACK_IMPORTED_MODULE_4__.default, {
        onMintToken1: onMintToken1,
        mintBtnText: mintBtnText
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 544,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 527,
      columnNumber: 17
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 488,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);

/***/ }),

/***/ "./src/components/LandingPage/Hero/MintButton/MintButton.tsx":
/*!*******************************************************************!*\
  !*** ./src/components/LandingPage/Hero/MintButton/MintButton.tsx ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Hero\\MintButton\\MintButton.tsx";




const CtaButton = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "MintButton__CtaButton",
  componentId: "sc-z0c9gc-0"
})(["width:100%;height:5.5rem;position:relative;display:block;margin:0 auto;cursor:pointer;@media (max-width:768px){height:4rem;}"]);
const FirstLayer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "MintButton__FirstLayer",
  componentId: "sc-z0c9gc-1"
})(["background:#FFDC25;position:absolute;z-index:2;top:0;left:0;width:100%;height:100%;border-radius:16px;border:3px solid #000000;"]);
const SecondLayer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "MintButton__SecondLayer",
  componentId: "sc-z0c9gc-2"
})(["background:#4A7A72;position:absolute;z-index:1;top:-.9375rem;left:.9375rem;width:100%;height:100%;border-radius:16px;border:3px solid #000000;@media (max-width:768px){top:-0.3375rem;left:0.3375rem;}"]);
const ButtonText = styled_components__WEBPACK_IMPORTED_MODULE_1___default().p.withConfig({
  displayName: "MintButton__ButtonText",
  componentId: "sc-z0c9gc-3"
})(["font-size:30px;position:relative;z-index:4;width:100%;height:100%;font-weight:600;display:flex;align-items:center;justify-content:center;@media (max-width:1600px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_2__.default.font40.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_2__.default.font40.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_2__.default.font40.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_2__.default.font40.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_2__.default.font40.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_2__.default.font40.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_2__.default.font40.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_2__.default.font40.w500.height);

const LeftCornerSVG = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("svg", {
    width: "50",
    height: "36",
    viewBox: "0 0 50 36",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("path", {
      d: "M5 31.3472V19.0957C5 11.3637 11.268 5.0957 19 5.0957H45",
      stroke: "white",
      strokeWidth: "9",
      strokeLinecap: "round"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 76,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 75,
    columnNumber: 5
  }, undefined);
};

const RightCornerSVG = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("svg", {
    width: "92",
    height: "25",
    viewBox: "0 0 92 25",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("path", {
      d: "M87.5 5.23649L87.5 5.59267C87.5 13.3247 81.232 19.5927 73.5 19.5927L4.5 19.5928",
      stroke: "white",
      strokeWidth: "9",
      strokeLinecap: "round"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 83,
    columnNumber: 5
  }, undefined);
};

const LeftCorner = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "MintButton__LeftCorner",
  componentId: "sc-z0c9gc-4"
})(["position:absolute;z-index:3;left:10px;top:10px;@media (max-width:768px){left:.525rem;top:.325rem;}svg{width:40px;height:1.6875rem;@media (max-width:768px){height:13.5px;width:20px;}}"]);
const RightCorner = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "MintButton__RightCorner",
  componentId: "sc-z0c9gc-5"
})(["position:absolute;z-index:3;right:.3125rem;bottom:10px;@media (max-width:768px){bottom:.125rem;}svg{width:5.1875rem;height:0.9375rem;@media (max-width:768px){width:42px;height:7.5px;}}"]);

const MintButton = ({
  onMintToken1,
  mintBtnText
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(CtaButton, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(LeftCorner, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(LeftCornerSVG, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 131,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(FirstLayer, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 134,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(SecondLayer, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 135,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(ButtonText, {
      onClick: onMintToken1,
      children: mintBtnText
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 136,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(RightCorner, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(RightCornerSVG, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 140,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 139,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 130,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MintButton);

/***/ }),

/***/ "./src/components/LandingPage/Roadmap/CalendarBoxFour.tsx":
/*!****************************************************************!*\
  !*** ./src/components/LandingPage/Roadmap/CalendarBoxFour.tsx ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CalendarStyle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CalendarStyle */ "./src/components/LandingPage/Roadmap/CalendarStyle.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Roadmap\\CalendarBoxFour.tsx";




const CalendarBoxFour = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.CalendarBox, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.DatesSide, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.DateText, {
        children: "11/2021"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.LineDown, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoSide, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoWrap, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.HeavyInfo, {
          children: "Official Launch"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoList, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoItem, {
            children: "UTC 6PM @DaBunnyNFT.com"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoItem, {
            children: "Supply: 5,000+ (Buy Limit: 20)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 27,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CalendarBoxFour);

/***/ }),

/***/ "./src/components/LandingPage/Roadmap/CalendarBoxOne.tsx":
/*!***************************************************************!*\
  !*** ./src/components/LandingPage/Roadmap/CalendarBoxOne.tsx ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CalendarStyle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CalendarStyle */ "./src/components/LandingPage/Roadmap/CalendarStyle.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Roadmap\\CalendarBoxOne.tsx";




const CalendarBoxOne = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.CalendarBox, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.DatesSide, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.DateText, {
        children: "10/11/2021"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.LineDown, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoSide, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoWrap, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.HeavyInfo, {
          children: "Website Official Launch"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.HeavyInfo, {
          children: "Discord Community Official Launch"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.LightInfo, {
          children: "Discord: https://discord.gg/p3UQjhQ3"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoList, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoItem, {
            children: "@UTC 6PM"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 29,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoItem, {
            children: "Telegram: https://t.me/DaBunnyNFT"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 30,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoItem, {
            children: "Contract Address: TBD"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CalendarBoxOne);

/***/ }),

/***/ "./src/components/LandingPage/Roadmap/CalendarBoxThree.tsx":
/*!*****************************************************************!*\
  !*** ./src/components/LandingPage/Roadmap/CalendarBoxThree.tsx ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CalendarStyle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CalendarStyle */ "./src/components/LandingPage/Roadmap/CalendarStyle.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Roadmap\\CalendarBoxThree.tsx";




const CalendarBoxThree = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.CalendarBox, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.DatesSide, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.DateText, {
        children: "11/2021"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.LineDown, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoSide, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoWrap, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.HeavyInfo, {
          children: "Pre-sale 2"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoList, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoItem, {
            children: "UTC 6PM @DaBunnyNFT.com"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoItem, {
            children: "Supply: 2,000"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 27,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CalendarBoxThree);

/***/ }),

/***/ "./src/components/LandingPage/Roadmap/CalendarBoxTwo.tsx":
/*!***************************************************************!*\
  !*** ./src/components/LandingPage/Roadmap/CalendarBoxTwo.tsx ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CalendarStyle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CalendarStyle */ "./src/components/LandingPage/Roadmap/CalendarStyle.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Roadmap\\CalendarBoxTwo.tsx";




const CalendarBoxTwo = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.CalendarBox, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.DatesSide, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.DateText, {
        children: "11/2021"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.LineDown, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoSide, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoWrap, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.HeavyInfo, {
          children: "Pre-sale 1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoList, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoItem, {
            children: "UTC 6PM @DaBunnyNFT.com"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.InfoItem, {
            children: "Supply: 1,000 "
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 27,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_CalendarStyle__WEBPACK_IMPORTED_MODULE_1__.HeavyInfo, {
          children: "$Da Bunny NFT ERC-20 Token on Uniswap"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CalendarBoxTwo);

/***/ }),

/***/ "./src/components/LandingPage/Roadmap/CalendarStyle.tsx":
/*!**************************************************************!*\
  !*** ./src/components/LandingPage/Roadmap/CalendarStyle.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CalendarBox": () => (/* binding */ CalendarBox),
/* harmony export */   "DatesSide": () => (/* binding */ DatesSide),
/* harmony export */   "DateText": () => (/* binding */ DateText),
/* harmony export */   "LineDown": () => (/* binding */ LineDown),
/* harmony export */   "InfoSide": () => (/* binding */ InfoSide),
/* harmony export */   "InfoWrap": () => (/* binding */ InfoWrap),
/* harmony export */   "HeavyInfo": () => (/* binding */ HeavyInfo),
/* harmony export */   "LightInfo": () => (/* binding */ LightInfo),
/* harmony export */   "InfoList": () => (/* binding */ InfoList),
/* harmony export */   "InfoItem": () => (/* binding */ InfoItem)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/typography */ "./src/styles/typography.ts");


const CalendarBox = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "CalendarStyle__CalendarBox",
  componentId: "sc-i4j0io-0"
})(["display:flex;flex-wrap:wrap;margin-top:4.375rem;margin-bottom:4.0625rem;position:relative;@media (max-width:1100px){display:block;margin-top:6.375rem;}@media (max-width:768px){margin-bottom:96px;margin-top:48px;}"]);
const DatesSide = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "CalendarStyle__DatesSide",
  componentId: "sc-i4j0io-1"
})(["flex-basis:10%;padding-right:4.375rem;display:flex;flex-direction:column;align-items:center;padding-top:30px;@media (max-width:1100px){flex-basis:unset;padding-right:0;flex-direction:unset;align-items:unset;padding-top:0;display:block;border-left:7px dashed #fff;position:absolute;height:calc(100% + 35px);left:0;top:0;}@media (max-width:500px){border-left:4px dashed #fff;}"]);
const DateText = styled_components__WEBPACK_IMPORTED_MODULE_0___default().p.withConfig({
  displayName: "CalendarStyle__DateText",
  componentId: "sc-i4j0io-2"
})(["font-weight:700;font-size:", ";line-height:", ";@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:1100px){position:relative;top:-35px;padding-left:15px;color:#fff;::after{content:\"\";position:absolute;left:-14px;top:14px;width:20px;height:20px;border-radius:50%;background-color:#fff;}}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";::after{left:-10px;top:10px;width:14px;height:14px;}}"], _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w500.height);
const LineDown = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "CalendarStyle__LineDown",
  componentId: "sc-i4j0io-3"
})(["border-right:7px dashed #000000;flex:1;margin-top:1.5rem;@media (max-width:1100px){display:none;}"]);
const InfoSide = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "CalendarStyle__InfoSide",
  componentId: "sc-i4j0io-4"
})(["flex-basis:79%;@media (max-width:1100px){flex-basis:100%;margin-left:48px;}@media (max-width:768px){margin-left:24px;position:relative;top:-1rem;}"]);
const InfoWrap = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "CalendarStyle__InfoWrap",
  componentId: "sc-i4j0io-5"
})(["background:#FFB9B9;border:3px solid #000000;box-shadow:0 8px 00 #000000;border-radius:10px;padding:30px 2.8125rem;@media (max-width:1100px){position:relative;top:30px;}"]);
const HeavyInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h3.withConfig({
  displayName: "CalendarStyle__HeavyInfo",
  componentId: "sc-i4j0io-6"
})(["font-weight:bold;font-size:", ";line-height:", ";@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}&&:not(:first-of-type){margin-top:40px;@media (max-width:500px){margin-top:16px;}}"], _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font40.w500.height);
const LightInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default().p.withConfig({
  displayName: "CalendarStyle__LightInfo",
  componentId: "sc-i4j0io-7"
})(["font-size:", ";line-height:", ";@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";word-break:break-all;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w500.height);
const InfoList = styled_components__WEBPACK_IMPORTED_MODULE_0___default().ul.withConfig({
  displayName: "CalendarStyle__InfoList",
  componentId: "sc-i4j0io-8"
})(["padding:0 40px;@media (max-width:768px){padding:0  24px;}@media (max-width:500px){padding:0 16px;}"]);
const InfoItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default().li.withConfig({
  displayName: "CalendarStyle__InfoItem",
  componentId: "sc-i4j0io-9"
})(["font-size:", ";line-height:", ";word-break:break-all;@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";word-break:break-all;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w500.height);

/***/ }),

/***/ "./src/components/LandingPage/Roadmap/Roadmap.tsx":
/*!********************************************************!*\
  !*** ./src/components/LandingPage/Roadmap/Roadmap.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CalendarBoxOne__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CalendarBoxOne */ "./src/components/LandingPage/Roadmap/CalendarBoxOne.tsx");
/* harmony import */ var _CalendarBoxTwo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CalendarBoxTwo */ "./src/components/LandingPage/Roadmap/CalendarBoxTwo.tsx");
/* harmony import */ var _CalendarBoxFour__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./CalendarBoxFour */ "./src/components/LandingPage/Roadmap/CalendarBoxFour.tsx");
/* harmony import */ var _CalendarBoxThree__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./CalendarBoxThree */ "./src/components/LandingPage/Roadmap/CalendarBoxThree.tsx");
/* harmony import */ var react_waypoint__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-waypoint */ "react-waypoint");
/* harmony import */ var react_waypoint__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_waypoint__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\Roadmap\\Roadmap.tsx";










const Section = styled_components__WEBPACK_IMPORTED_MODULE_2___default().section.withConfig({
  displayName: "Roadmap__Section",
  componentId: "sc-mdetwc-0"
})(["background-color:#FF7272;position:relative;padding:15rem 0 4rem 0;@media (max-width:1440px){padding:20rem 0 4rem 0;}@media (max-width:1000px){padding:25rem 0 4rem 0;}@media (max-width:768px){padding:15rem 0 4rem 0;}@media (max-width:550px){padding-bottom:16px;}@media (max-width:400px){padding:10rem 0 4rem 0;}"]);
const InnerWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Roadmap__InnerWrap",
  componentId: "sc-mdetwc-1"
})(["max-width:1100px;margin:0 auto;position:relative;"]);
const RocketBunny = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Roadmap__RocketBunny",
  componentId: "sc-mdetwc-2"
})(["position:absolute;z-index:1;top:-30rem;height:22.5rem;width:125%;right:", ";transition:right .7s ease-out;@media (max-width:1440px){width:1600px;top:-35rem;right:", ";}@media (max-width:1200px){top:-30rem;width:1320px;right:", ";}@media (max-width:1000px){width:1050x;}@media (max-width:768px){top:-23rem;}@media (max-width:800px){width:880px;}@media (max-width:600px){top:-18rem;width:660px;}@media (max-width:400px){top:-11rem;width:440px;}"], ({
  rocketOnScreen
}) => rocketOnScreen ? '-12.5%' : ' 200vw', ({
  rocketOnScreen
}) => rocketOnScreen ? '-50px' : ' 200vw', ({
  rocketOnScreen
}) => rocketOnScreen ? '0' : ' 200vw');
const BunnyImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Roadmap__BunnyImage",
  componentId: "sc-mdetwc-3"
})(["position:absolute;z-index:1;right:0px;bottom:-310px;width:460px;@media (max-width:1660px){right:-4rem;bottom:-15rem;width:420px;}@media (max-width:1170px){right:50%;transform:translateX(50%);bottom:-13.375rem;width:450px;}@media (max-width:768px){right:50%;transform:translateX(50%);bottom:-13.375rem;width:350px;}@media (max-width:500px){bottom:-6.375rem;width:210px;}"]);
const ActivationsBox = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Roadmap__ActivationsBox",
  componentId: "sc-mdetwc-4"
})(["background-color:#FFF387;box-shadow:24px 1.75rem00 #000000;border:7px solid #000000;border-radius:10px;position:relative;padding-top:5rem;margin:0 80px;margin-bottom:10.9375rem;box-shadow:12px 12px 0px 0px #000000;@media (max-width:1660px){padding-top:40px;}@media (max-width:768px){margin:0 20px;padding-top:40px;}"]);
const VectorWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Roadmap__VectorWrap",
  componentId: "sc-mdetwc-5"
})(["position:absolute;left:50%;top:-7.5rem;height:11.25rem;transform:translateX(-50%);z-index:1;@media (max-width:1000px){top:-8rem;}@media (max-width:768px){top:-7rem;}@media (max-width:500px){top:-56px;}svg{height:8.25rem;@media (max-width:1000px){height:9rem;}@media (max-width:768px){height:128px;}@media (max-width:500px){height:60px;}}"]);
const ActivationTitle = styled_components__WEBPACK_IMPORTED_MODULE_2___default().h3.withConfig({
  displayName: "Roadmap__ActivationTitle",
  componentId: "sc-mdetwc-6"
})(["font-size:", ";line-height:", ";font-weight:700;text-align:center;@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";margin-top:12px;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w500.height);
const ActivationList = styled_components__WEBPACK_IMPORTED_MODULE_2___default().ul.withConfig({
  displayName: "Roadmap__ActivationList",
  componentId: "sc-mdetwc-7"
})(["padding:4rem 80px 8.125rem 80px;height:100%;width:100%;@media (max-width:1660px){padding:3rem 80px 8rem 60px;}@media (max-width:1170px){padding:5.625rem 80px 18rem 80px;}@media (max-width:768px){padding:32px 25px 11rem 25px;list-style:none;}@media (max-width:500px){padding:32px 25px 9.5rem 25px;}"]);
const ActivationItem = styled_components__WEBPACK_IMPORTED_MODULE_2___default().li.withConfig({
  displayName: "Roadmap__ActivationItem",
  componentId: "sc-mdetwc-8"
})(["font-weight:700;font-size:", ";line-height:", ";margin-bottom:18px;color:#000;@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";margin-bottom:7px;}&&:last-of-type{width:70%;@media (max-width:1170px){width:100%;}}span{color:#BE6DFF;margin-right:12px;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font24.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font24.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font24.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font24.w500.height);
const CalendarTitle = styled_components__WEBPACK_IMPORTED_MODULE_2___default().h3.withConfig({
  displayName: "Roadmap__CalendarTitle",
  componentId: "sc-mdetwc-9"
})(["font-weight:700;font-size:", ";line-height:", ";color:#fff;position:relative;z-index:1;white-space:nowrap;@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w500.height);
const CalendarTitleWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Roadmap__CalendarTitleWrap",
  componentId: "sc-mdetwc-10"
})(["position:relative;width:100%;flex:1;margin:10.9375rem 0 4.375rem 0;@media (max-width:1100px){text-align:center;}@media (max-width:500px){margin:80px 0 0 0;}"]);
const CalendarTitleShadow = styled_components__WEBPACK_IMPORTED_MODULE_2___default().h3.withConfig({
  displayName: "Roadmap__CalendarTitleShadow",
  componentId: "sc-mdetwc-11"
})(["position:absolute;top:.25rem;left:.25rem;font-weight:700;font-size:", ";line-height:", ";color:#000;z-index:0;white-space:nowrap;@media (max-width:1660px){font-size:", ";line-height:", ";top:.15rem;left:.15rem;}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:1100px){left:50%;transform:translateX(calc(-50% + .15rem));}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";transform:translateX(calc(-50% + .15rem));}"], _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_8__.default.font40.w500.height);
const CalendarLimit = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "Roadmap__CalendarLimit",
  componentId: "sc-mdetwc-12"
})(["max-width:980px;margin:0 auto;padding:0  24px;"]);

const TopVector = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("svg", {
    width: "417",
    height: "180",
    viewBox: "0 0 417 180",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M0 180H416.606V137.996C416.606 126.036 406.791 116.183 394.822 116.183H237.496V96.2464C251.86 86.6812 261.166 70.7234 261.166 52.3896C261.166 23.3969\r 237.769 0 208.781 0C179.802 0 156.127 23.3969 156.127 52.3896C156.127 70.7234 165.697 86.6764 179.797 96.2464V116.183H21.794C9.82924 116.183 0 126.036 0\r 137.996V180Z",
      fill: "black"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 331,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 330,
    columnNumber: 5
  }, undefined);
};

const content = [{
  percent: '10%',
  text: 'Pay back our team and send Da Bunnies some pizza.'
}, {
  percent: '20%',
  text: 'Airdrop giveaway ERC20 token for top holders & HODL rally event announcement.'
}, {
  percent: '40%',
  text: 'Release 50 special Haunted Bunnies (Halloween edition).'
}, {
  percent: '70%',
  text: 'Announcement of generation 2 and breeding details on Da Bunny NFT Discord.'
}, {
  percent: '80%',
  text: 'Activate our premiere - Da Bunny Radio Channel - on YouTube and Spotify.'
}, {
  percent: '90%',
  text: 'Exclusive member access to Da Bunny limited edition digital merchandise minting. Da Bunny X NIFTI Studios collaboration. Details to be released in Discord.'
}, {
  percent: '100%',
  text: 'We lambo! Announcement of global celebration events & rally on chain. Giveaway for all NFT holders.'
}];

const Roadmap = () => {
  const {
    0: rocketOnScreen,
    1: setRocketOnScreen
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const resizeEventHandle = () => {
    const windowWidth = window.innerWidth;

    switch (true) {
      case windowWidth > 1660:
        /* if (rocketOnScreen) {
          setPositionY(-12.5);
        } else {
          setCalcPosition(-12.5);
        } */
        break;

      default:
        /* if (rocketOnScreen) {
          setPositionY(-25);
        } else {
          setCalcPosition(-25);
        } */
        break;
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    resizeEventHandle();
    window.addEventListener('resize', resizeEventHandle);
    return () => {
      window.removeEventListener('resize', resizeEventHandle);
    };
  }, []);

  const rocketAppears = () => {
    setRocketOnScreen(true);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(Section, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(InnerWrap, {
      id: "roadmap",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(RocketBunny, {
        rocketOnScreen: rocketOnScreen,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(react_waypoint__WEBPACK_IMPORTED_MODULE_7__.Waypoint, {
          onEnter: rocketAppears
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 392,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          width: 2228,
          height: 607,
          src: "/img/rocket_bunny.png",
          alt: ""
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 395,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 391,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(ActivationsBox, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(VectorWrap, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(TopVector, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 404,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 403,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(ActivationTitle, {
          children: "Roadmap Activations"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 406,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(ActivationList, {
          children: content.map((item, index) => {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(ActivationItem, {
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("span", {
                children: [item.percent, " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 411,
                columnNumber: 19
              }, undefined), item.text]
            }, index, true, {
              fileName: _jsxFileName,
              lineNumber: 410,
              columnNumber: 17
            }, undefined);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 407,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(BunnyImage, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            width: 650,
            height: 809,
            src: "/img/bunny4.png",
            alt: ""
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 417,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 416,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 402,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(CalendarLimit, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(CalendarTitleWrap, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(CalendarTitle, {
            children: "Event Calendar"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 427,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(CalendarTitleShadow, {
            children: "Event Calendar"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 430,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 426,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_CalendarBoxOne__WEBPACK_IMPORTED_MODULE_3__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 434,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_CalendarBoxTwo__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 435,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_CalendarBoxThree__WEBPACK_IMPORTED_MODULE_6__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 436,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_CalendarBoxFour__WEBPACK_IMPORTED_MODULE_5__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 437,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 425,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 390,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 389,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Roadmap);

/***/ }),

/***/ "./src/components/LandingPage/WhatDa.tsx":
/*!***********************************************!*\
  !*** ./src/components/LandingPage/WhatDa.tsx ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Shared_CarrotHeader_CarrotHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Shared/CarrotHeader/CarrotHeader */ "./src/components/Shared/CarrotHeader/CarrotHeader.tsx");
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\LandingPage\\WhatDa.tsx";






const Section = styled_components__WEBPACK_IMPORTED_MODULE_2___default().section.withConfig({
  displayName: "WhatDa__Section",
  componentId: "sc-15a1xfy-0"
})(["background-color:#fe60ae;position:relative;"]);
const HeaderWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "WhatDa__HeaderWrapper",
  componentId: "sc-15a1xfy-1"
})(["display:flex;justify-content:center;"]);
const InnerWrap = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "WhatDa__InnerWrap",
  componentId: "sc-15a1xfy-2"
})(["padding-top:10rem;padding-bottom:20.9375rem;max-width:90rem;width:100%;margin:0 auto;position:relative;@media (max-width:970px){padding-bottom:0;padding-top:10rem;}@media (max-width:500px){padding-top:5rem;}"]);
const Paragraph = styled_components__WEBPACK_IMPORTED_MODULE_2___default().p.withConfig({
  displayName: "WhatDa__Paragraph",
  componentId: "sc-15a1xfy-3"
})(["margin-top:80px;font-weight:600;font-size:", ";line-height:", ";padding-left:12.5%;padding-right:35%;z-index:1;position:relative;@media (max-width:1660px){font-size:", ";line-height:", ";}@media (max-width:1440px){font-size:", ";line-height:", ";}@media (max-width:1250px){padding-left:7.5%;padding-right:37.5%;}@media (max-width:970px){display:none;}"], _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_4__.default.font24.w1440.height);
const BunnyImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "WhatDa__BunnyImage",
  componentId: "sc-15a1xfy-4"
})(["position:absolute;z-index:1;right:-100px;bottom:-.525rem;max-width:622px;@media (max-width:1440px){right:0;}@media (max-width:970px){position:relative;left:65%;transform:translateX(-50%);padding-top:35px;}@media (max-width:450px){margin-top:30px;left:50%;padding:0 1rem;}"]);
const BubblesImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "WhatDa__BubblesImage",
  componentId: "sc-15a1xfy-5"
})(["position:absolute;z-index:0;left:0;bottom:-10px;width:100%;img{width:100vw;height:auto;max-height:35rem;}"]);

const WhatDa = () => {
  const {
    0: resizeFactor,
    1: setResizeFactor
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);

  const resizeEventHandle = () => {
    const windowWidth = window.innerWidth;

    switch (true) {
      case windowWidth > 1660:
        setResizeFactor(1.25);
        break;

      case windowWidth > 1200:
        setResizeFactor(1.45);
        break;

      default:
        setResizeFactor(1.55);
        break;
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    resizeEventHandle();
    window.addEventListener('resize', resizeEventHandle);
    return () => {
      window.removeEventListener('resize', resizeEventHandle);
    };
  }, []);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Section, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(InnerWrap, {
      id: "about",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(HeaderWrapper, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_Shared_CarrotHeader_CarrotHeader__WEBPACK_IMPORTED_MODULE_3__.default, {
          bgColor: "#87EEF4",
          padding: "1.5625rem 64px 25px 96px",
          children: "What Da Bunny?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 127,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 126,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Paragraph, {
        children: "Da Bunny is a tribe of 8,000 programmatically generated NFT bunnies that reside in the Ethereum blockchain. Generation 1 was incubated from a randomized combination of more than 200 unique traits, out of 4,320,000 total possibilities. Each bunny has a unique character and appearance which makes him/her \u201CDa\u201D Bunny...."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 131,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(BunnyImage, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          width: 622 / resizeFactor,
          height: 622 / resizeFactor,
          src: "/img/bunny2.png",
          alt: ""
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 137,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 136,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 125,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(BubblesImage, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        width: 1440,
        height: 611,
        src: "/img/bubbles_blue.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 146,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 145,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 124,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WhatDa);

/***/ }),

/***/ "./src/components/Shared/CarrotHeader/CarrotHeader.tsx":
/*!*************************************************************!*\
  !*** ./src/components/Shared/CarrotHeader/CarrotHeader.tsx ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../styles/typography */ "./src/styles/typography.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\Shared\\CarrotHeader\\CarrotHeader.tsx";





const Wrap = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "CarrotHeader__Wrap",
  componentId: "sc-5y9x60-0"
})(["background-color:", ";padding:", ";width:max-content;display:flex;align-items:center;justify-content:center;height:5.625rem;position:relative;border:3px solid #000000;border-radius:10px;box-shadow:0 8px 0 0 #000000;@media (max-width:768px){padding:16px 32px;height:unset;min-width:240px;}"], props => props.bgColor, props => props.padding);
const CarrotWrap = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "CarrotHeader__CarrotWrap",
  componentId: "sc-5y9x60-1"
})(["display:block;position:absolute;left:-1.5625rem;bottom:-0.9375rem;z-index:1;@media (max-width:768px){width:56px;height:74px;bottom:0rem;left:-1rem;}"]);
const Paragraph = styled_components__WEBPACK_IMPORTED_MODULE_1___default().p.withConfig({
  displayName: "CarrotHeader__Paragraph",
  componentId: "sc-5y9x60-2"
})(["display:block;font-size:", ";line-height:", ";font-weight:600;text-align:center;@media (max-width:1600px){font-size:", ";line-height:", ";}@media (max-width:1600px){font-size:", ";line-height:", ";}@media (max-width:768px){font-size:", ";line-height:", ";}@media (max-width:500px){font-size:", ";line-height:", ";}"], _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1920.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1660.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1440.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w1440.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w768.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w768.height, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w500.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_3__.default.font24.w500.height);

const CarrotHeader = ({
  children,
  bgColor,
  padding
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Wrap, {
    bgColor: bgColor,
    padding: padding,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(CarrotWrap, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        width: 124,
        height: 163,
        src: "/img/carrot.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 79,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Paragraph, {
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 78,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CarrotHeader);

/***/ }),

/***/ "./src/components/Shared/ConnectButton/ConnectButton.tsx":
/*!***************************************************************!*\
  !*** ./src/components/Shared/ConnectButton/ConnectButton.tsx ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\Shared\\ConnectButton\\ConnectButton.tsx";



// const Mydiv = styled.div`
//   /* position: absolute; */
//   width: 150px;
//   height: 40px;
//   left: 0px;
//   top: 0px;
//   background: #ffffff;
//   border: 2px solid #000000;
//   box-sizing: border-box;
//   border-radius: 39.5px;
//   padding: 0 13px;
//   display: flex;
//   flex-direction: column;
//   justify-content: center;
//   cursor: pointer;
// `
const Mydiv = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ConnectButton__Mydiv",
  componentId: "sc-ymenqe-0"
})(["display:flex;flex-direction:column;justify-content:center;width:150px;height:40px;left:0px;top:0px;background:#ffffff;border:2px solid #000000;box-sizing:border-box;border-radius:39.5px;cursor:pointer;text-overflow:ellipse;text-align:center;font-size:medium;"]);
const Smallb = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ConnectButton__Smallb",
  componentId: "sc-ymenqe-1"
})(["font-size:small;display:block;height:15px;font-weight:bold;"]);
const Smalls = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ConnectButton__Smalls",
  componentId: "sc-ymenqe-2"
})(["font-size:x-small;"]);

const ConnectButton = props => {
  //{onConnectWallet, address, balance, network}
  const {
    onConnectWallet,
    address,
    balance,
    network
  } = props;
  const Mydiv = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    displayName: "ConnectButton__Mydiv",
    componentId: "sc-ymenqe-3"
  })(["display:flex;flex-direction:column;justify-content:center;font-size:medium;width:150px;height:40px;left:0px;top:0px;background:#FFFFFF;border:2px solid #000000;box-sizing:border-box;border-radius:39.5px;cursor:pointer;text-overflow:ellipse;text-align:center;align-items:center;"]);

  const shortAddress = address => {
    return address.substring(0, 10) + '...' + address.substring(address.length - 4, address.length);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Mydiv, {
    onClick: e => onConnectWallet(e),
    children: address ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Smallb, {
        children: balance ? Number(balance).toFixed(4) + ' ETH' : String(balance) === '0' ? '0 ETH' : ''
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 11
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Smalls, {
        children: address ? shortAddress(address) : 'Connect Wallet'
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 103,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 9
    }, undefined) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
      children: " Connect Wallet "
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 106,
      columnNumber: 9
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 93,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConnectButton);

/***/ }),

/***/ "./src/components/Shared/NavBar/MobileLink.tsx":
/*!*****************************************************!*\
  !*** ./src/components/Shared/NavBar/MobileLink.tsx ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _NavStyle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./NavStyle */ "./src/components/Shared/NavBar/NavStyle.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\Shared\\NavBar\\MobileLink.tsx";





const MobileLink = ({
  href,
  children,
  toggleNavMobile,
  handleClick,
  animationTimeout
}) => {
  const mobileTouch = () => {
    toggleNavMobile();
    setTimeout(() => {
      handleClick(href);
    }, animationTimeout);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_NavStyle__WEBPACK_IMPORTED_MODULE_2__.LinkWrap, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_NavStyle__WEBPACK_IMPORTED_MODULE_2__.CarrotWrap, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        width: 28,
        height: 39,
        layout: "fixed",
        src: "/img/carrot.png",
        alt: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_NavStyle__WEBPACK_IMPORTED_MODULE_2__.MobileLinkText, {
      onClick: mobileTouch,
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MobileLink);

/***/ }),

/***/ "./src/components/Shared/NavBar/NavBar.tsx":
/*!*************************************************!*\
  !*** ./src/components/Shared/NavBar/NavBar.tsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _icons_Icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../icons/Icons */ "./src/icons/Icons.js");
/* harmony import */ var _utils_Links__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../utils/Links */ "./src/utils/Links.ts");
/* harmony import */ var _adjustScroll__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./adjustScroll */ "./src/components/Shared/NavBar/adjustScroll.ts");
/* harmony import */ var _icons_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../icons/icon */ "./src/icons/icon.ts");
/* harmony import */ var _NavStyle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./NavStyle */ "./src/components/Shared/NavBar/NavStyle.ts");
/* harmony import */ var _MobileLink__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./MobileLink */ "./src/components/Shared/NavBar/MobileLink.tsx");
/* harmony import */ var _ConnectButton_ConnectButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../ConnectButton/ConnectButton */ "./src/components/Shared/ConnectButton/ConnectButton.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__);
const _excluded = ["onConnectWallet"];
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\components\\Shared\\NavBar\\NavBar.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const animationTimeout = 400;







const NavBar = props => {
  const {
    0: navMobilePosition,
    1: setNavMobilePosition
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("100%");
  const {
    0: isMobileNavOpen,
    1: setIsMobileNavOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const {
    onConnectWallet
  } = props,
        userData = _objectWithoutProperties(props, _excluded); // console.log(userData);
  //the page has too many itens and this supports the scroll navigation on every click


  const {
    0: positionFix,
    1: setPositionFix
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
    about: 0,
    rabbit: 0,
    roadmap: 0,
    faq: 0
  }); //the support function that adjust every fix due the screen width

  const resizeEventHandle = () => {
    (0,_adjustScroll__WEBPACK_IMPORTED_MODULE_4__.default)(setPositionFix, window.innerWidth);
  }; //only monitors the screen width to adjust every fix


  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    resizeEventHandle();
    window.addEventListener('resize', resizeEventHandle);
    return () => {
      window.removeEventListener('resize', resizeEventHandle);
    };
  }, []); //responsible to show and hide the mobile menu

  const toggleNavMobile = () => {
    setIsMobileNavOpen(!isMobileNavOpen);
    setNavMobilePosition(isMobileNavOpen ? "100%" : "0");
  }; //handles both the mobile and deskop link click


  const handleClick = href => {
    const getHref = document.getElementById(href);
    const valueOfFix = positionFix[href];
    window.scrollBy({
      top: getHref.getBoundingClientRect().top + valueOfFix,
      behavior: 'smooth'
    });
  };

  const DesktopLink = ({
    href,
    children
  }) => {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_NavStyle__WEBPACK_IMPORTED_MODULE_6__.NavLink, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("a", {
        onClick: () => handleClick(href),
        children: children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 74,
      columnNumber: 7
    }, undefined);
  };

  const MobileLinkPrep = ({
    href,
    children
  }) => {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_MobileLink__WEBPACK_IMPORTED_MODULE_7__.default, {
      toggleNavMobile: toggleNavMobile,
      handleClick: handleClick,
      animationTimeout: animationTimeout,
      href: href,
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 82,
      columnNumber: 7
    }, undefined);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_NavStyle__WEBPACK_IMPORTED_MODULE_6__.Nav, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_NavStyle__WEBPACK_IMPORTED_MODULE_6__.Group, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_NavStyle__WEBPACK_IMPORTED_MODULE_6__.Logo, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          width: 217,
          height: 92,
          src: "/img/icon-main.png",
          alt: ""
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 9
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 7
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_NavStyle__WEBPACK_IMPORTED_MODULE_6__.Group, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_icons_icon__WEBPACK_IMPORTED_MODULE_5__.IconLink, {
        href: _utils_Links__WEBPACK_IMPORTED_MODULE_3__.DISCORD_LINK,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_icons_Icons__WEBPACK_IMPORTED_MODULE_2__.Discord, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 112,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 111,
        columnNumber: 7
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_icons_icon__WEBPACK_IMPORTED_MODULE_5__.IconLink, {
        href: _utils_Links__WEBPACK_IMPORTED_MODULE_3__.TWITTER_LINK,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_icons_Icons__WEBPACK_IMPORTED_MODULE_2__.Twitter, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 115,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 114,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_icons_icon__WEBPACK_IMPORTED_MODULE_5__.IconLink, {
        href: _utils_Links__WEBPACK_IMPORTED_MODULE_3__.TELE_LINK,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_icons_Icons__WEBPACK_IMPORTED_MODULE_2__.Telegram, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 118,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 117,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_ConnectButton_ConnectButton__WEBPACK_IMPORTED_MODULE_8__.default, _objectSpread({}, props), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 120,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 110,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 93,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavBar);

/***/ }),

/***/ "./src/components/Shared/NavBar/NavStyle.ts":
/*!**************************************************!*\
  !*** ./src/components/Shared/NavBar/NavStyle.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nav": () => (/* binding */ Nav),
/* harmony export */   "NavLink": () => (/* binding */ NavLink),
/* harmony export */   "Group": () => (/* binding */ Group),
/* harmony export */   "Logo": () => (/* binding */ Logo),
/* harmony export */   "Hamburguer": () => (/* binding */ Hamburguer),
/* harmony export */   "NavMobile": () => (/* binding */ NavMobile),
/* harmony export */   "BubblesImage": () => (/* binding */ BubblesImage),
/* harmony export */   "LinkWrap": () => (/* binding */ LinkWrap),
/* harmony export */   "MobileInner": () => (/* binding */ MobileInner),
/* harmony export */   "CarrotWrap": () => (/* binding */ CarrotWrap),
/* harmony export */   "MobileLinkText": () => (/* binding */ MobileLinkText),
/* harmony export */   "SocLinks": () => (/* binding */ SocLinks)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/typography */ "./src/styles/typography.ts");


const Nav = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "NavStyle__Nav",
  componentId: "sc-1fzi3qc-0"
})(["padding:20px 95px 10px 165px;width:100%;display:flex;align-items:center;position:fixed;justify-content:space-between;z-index:10;top:0;left:0;background-color:#5df2bc;@media (max-height:900px) and (min-width:1001px){padding-top:16px;padding-bottom:16px;}@media (max-width:1300px){padding:35px 48px 35px 48px;}@media (max-width:1000px){padding:15px 48px 15px 48px;}@media (max-width:550px){padding:26px;}"]);
const NavLink = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "NavStyle__NavLink",
  componentId: "sc-1fzi3qc-1"
})(["cursor:pointer;a{white-space:nowrap;text-decoration:none;color:black;justify-content:center;font-weight:600;font-size:", ";font-family:'space grotesk';margin:0 30px;white-space:nowrap;transition:text-shadow 0.3s ease-in-out;@media (max-width:1600px){font-size:", ";}@media (max-width:1440px){font-size:", ";}@media (max-width:1300px){padding:35px 48px 35px 48px;margin:0 16px;}&:hover{text-shadow:0 25px 25px rgba(0,0,0,0.3);}}"], _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1920.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1660.fontSize, _styles_typography__WEBPACK_IMPORTED_MODULE_1__.default.font24.w1440.fontSize);
const Group = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "NavStyle__Group",
  componentId: "sc-1fzi3qc-2"
})(["display:flex;@media (max-width:1000px){}svg{margin:0 10px;}"]);
const Logo = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "NavStyle__Logo",
  componentId: "sc-1fzi3qc-3"
})(["display:block;z-index:1001;@media (max-width:1000px){width:100%;text-align:center;padding-left:20px;}@media (max-height:900px) and (min-width:1001px){width:180px;}@media (max-width:550px){img{width:240px;}}"]);
const Hamburguer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "NavStyle__Hamburguer",
  componentId: "sc-1fzi3qc-4"
})(["display:none;z-index:102;position:relative;top:-15px;span{display:block;margin:0;padding:0;height:8px;transition:transform ", "ms ease-out;svg{height:4px;}}span:nth-child(1){transform:", ";}span:nth-child(2){visibility:", ";}span:nth-child(3){transform:", ";}@media (max-width:1000px){display:block;}"], ({
  animationTimeout
}) => animationTimeout, ({
  isOpen
}) => isOpen ? 'rotate(45deg) translate(12px,0px)' : 'rotate(0)  translate(0, 0)', ({
  isOpen
}) => isOpen ? 'hidden' : 'show', ({
  isOpen
}) => isOpen ? 'rotate(-45deg) translate(-1px,-11px)' : 'rotate(0)  translate(0, 0)');
const NavMobile = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "NavStyle__NavMobile",
  componentId: "sc-1fzi3qc-5"
})(["background-color:#ffd74c;position:fixed;width:100%;height:100%;min-height:100vh;min-width:100vw;left:", ";top:0;transition:all .6s ease-in-out;z-index:101;"], props => props.left);
const BubblesImage = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "NavStyle__BubblesImage",
  componentId: "sc-1fzi3qc-6"
})(["position:absolute;z-index:0;bottom:-8px;width:100%;img{width:100vw;height:auto;}"]);
const LinkWrap = styled_components__WEBPACK_IMPORTED_MODULE_0___default().a.withConfig({
  displayName: "NavStyle__LinkWrap",
  componentId: "sc-1fzi3qc-7"
})(["margin-bottom:70px;display:flex;justify-content:center;align-items:center;position:relative;z-index:1;"]);
const MobileInner = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "NavStyle__MobileInner",
  componentId: "sc-1fzi3qc-8"
})(["position:relative;width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;"]);
const CarrotWrap = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "NavStyle__CarrotWrap",
  componentId: "sc-1fzi3qc-9"
})(["margin-right:10px;"]);
const MobileLinkText = styled_components__WEBPACK_IMPORTED_MODULE_0___default().span.withConfig({
  displayName: "NavStyle__MobileLinkText",
  componentId: "sc-1fzi3qc-10"
})(["font-size:18px;font-weight:600;line-height:23px;"]);
const SocLinks = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "NavStyle__SocLinks",
  componentId: "sc-1fzi3qc-11"
})(["position:fixed;margin:100px 180px 0 0;right:0;"]);

/***/ }),

/***/ "./src/components/Shared/NavBar/adjustScroll.ts":
/*!******************************************************!*\
  !*** ./src/components/Shared/NavBar/adjustScroll.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const adjustScroll = (setPositionFix, width) => {
  if (width >= 1920) {
    setPositionFix({
      about: 120,
      rabbit: 200,
      roadmap: -400,
      faq: 0
    });
    return;
  }

  if (width >= 1600) {
    setPositionFix({
      about: 130,
      rabbit: 100,
      roadmap: -400,
      faq: 0
    });
    return;
  }

  if (width >= 1440) {
    setPositionFix({
      about: 130,
      rabbit: 100,
      roadmap: -400,
      faq: 0
    });
    return;
  }

  if (width >= 1200) {
    setPositionFix({
      about: 120,
      rabbit: 20,
      roadmap: -400,
      faq: 0
    });
    return;
  }

  if (width >= 768) {
    setPositionFix({
      about: -50,
      rabbit: -20,
      roadmap: -400,
      faq: -180
    });
    return;
  }

  if (width >= 500) {
    setPositionFix({
      about: -50,
      rabbit: -20,
      roadmap: -320,
      faq: -160
    });
    return;
  }
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (adjustScroll);

/***/ }),

/***/ "./src/icons/Icons.js":
/*!****************************!*\
  !*** ./src/icons/Icons.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Discord": () => (/* binding */ Discord),
/* harmony export */   "Telegram": () => (/* binding */ Telegram),
/* harmony export */   "Twitter": () => (/* binding */ Twitter),
/* harmony export */   "Medium": () => (/* binding */ Medium)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "E:\\SELF Base\\Usagi\\src\\icons\\Icons.js";


const Discord = props => {
  const {
    width = 60,
    height = 45,
    fill
  } = props;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("svg", {
    height: width,
    width: height,
    viewBox: "-26.25 -50 227.5 300",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "M69.4 83.9c-5.7 0-10.2 5-10.2 11.1s4.6 11.1 10.2 11.1c5.7 0 10.2-5 10.2-11.1.1-6.1-4.5-11.1-10.2-11.1zm36.5 0c-5.7 0-10.2 5-10.2 11.1s4.6 11.1 10.2 11.1c5.7 0 10.2-5 10.2-11.1s-4.5-11.1-10.2-11.1z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 67
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "M154.5 0h-134C9.2 0 0 9.2 0 20.6v135.2c0 11.4 9.2 20.6 20.5 20.6h113.4l-5.3-18.5 12.8 11.9 12.1 11.2 21.5 19V20.6C175 9.2 165.8 0 154.5 0zm-38.6 130.6s-3.6-4.3-6.6-8.1c13.1-3.7 18.1-11.9 18.1-11.9-4.1 2.7-8 4.6-11.5 5.9-5 2.1-9.8 3.5-14.5 4.3-9.6 1.8-18.4 1.3-25.9-.1-5.7-1.1-10.6-2.7-14.7-4.3-2.3-.9-4.8-2-7.3-3.4-.3-.2-.6-.3-.9-.5-.2-.1-.3-.2-.4-.3-1.8-1-2.8-1.7-2.8-1.7s4.8 8 17.5 11.8c-3 3.8-6.7 8.3-6.7 8.3-22.1-.7-30.5-15.2-30.5-15.2 0-32.2 14.4-58.3 14.4-58.3 14.4-10.8 28.1-10.5 28.1-10.5l1 1.2c-18 5.2-26.3 13.1-26.3 13.1s2.2-1.2 5.9-2.9c10.7-4.7 19.2-6 22.7-6.3.6-.1 1.1-.2 1.7-.2 6.1-.8 13-1 20.2-.2 9.5 1.1 19.7 3.9 30.1 9.6 0 0-7.9-7.5-24.9-12.7l1.4-1.6s13.7-.3 28.1 10.5c0 0 14.4 26.1 14.4 58.3 0 0-8.5 14.5-30.6 15.2z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 275
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 1
  }, undefined);
};
const Telegram = props => {
  const {
    width = 60,
    height = 45,
    fill
  } = props;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("svg", {
    height: width,
    width: height,
    viewBox: "-36 -60 312 360",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("defs", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("linearGradient", {
        gradientUnits: "userSpaceOnUse",
        y2: "180",
        y1: "40.008",
        x2: "100.01",
        x1: "160.01",
        id: "a",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("stop", {
          offset: "0",
          "stop-color": "#424d58"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 167
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("stop", {
          offset: "1",
          "stop-color": "#272a2f"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 206
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 68
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 62
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("circle", {
      cx: "120",
      cy: "120",
      r: "120",
      fill: "url(#a)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 269
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      fill: "#fff",
      d: "M49.942 118.96l80.81-33.295c7.977-3.468 35.03-14.566 35.03-14.566s12.486-4.855 11.445 6.936c-.347 4.855-3.12 21.85-5.896 40.23l-8.67 54.45s-.694 7.977-6.6 9.364c-5.906 1.387-15.607-4.855-17.34-6.243-1.387-1.04-26.012-16.647-35.03-24.277-2.428-2.08-5.202-6.243.347-11.098 12.486-11.445 27.4-25.665 36.416-34.682 4.162-4.162 8.324-13.873-9.017-2.08l-48.902 32.948s-5.55 3.468-15.954.347-22.543-7.283-22.543-7.283-8.324-5.202 5.896-10.75z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 319
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 1
  }, undefined);
};
const Twitter = props => {
  const {
    width = 60,
    height = 45,
    fill
  } = props;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("svg", {
    height: width,
    width: height,
    viewBox: "-44.7006 -60.54775 387.4052 363.2865",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      fill: "#none",
      d: "M93.719 242.19c112.46 0 173.96-93.168 173.96-173.96 0-2.646-.054-5.28-.173-7.903a124.338 124.338 0 0030.498-31.66c-10.955 4.87-22.744 8.148-35.11 9.626 12.622-7.57 22.313-19.543 26.885-33.817a122.62 122.62 0 01-38.824 14.841C239.798 7.433 223.915 0 206.326 0c-33.764 0-61.144 27.381-61.144 61.132 0 4.798.537 9.465 1.586 13.941-50.815-2.557-95.874-26.886-126.03-63.88a60.977 60.977 0 00-8.279 30.73c0 21.212 10.794 39.938 27.208 50.893a60.685 60.685 0 01-27.69-7.647c-.009.257-.009.507-.009.781 0 29.61 21.075 54.332 49.051 59.934a61.218 61.218 0 01-16.122 2.152 60.84 60.84 0 01-11.491-1.103c7.784 24.293 30.355 41.971 57.115 42.465-20.926 16.402-47.287 26.171-75.937 26.171-4.929 0-9.798-.28-14.584-.846 27.059 17.344 59.189 27.464 93.722 27.464"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 82
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 1
  }, undefined);
};
const Medium = props => {
  const {
    width = 25,
    height = 25,
    fill
  } = props;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("svg", {
    width: width,
    height: width,
    viewBox: `0 0 ${width} ${height}`,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "M12 0.5C5.37321 0.5 0 5.87321 0 12.5C0 19.1268 5.37321 24.5 12 24.5C18.6268 24.5 24 19.1268 24 12.5C24 5.87321 18.6268 0.5 12\r 0.5ZM18.8571 7.29554L17.7643 8.34286C17.6679 8.41518 17.6223 8.53304 17.6411 8.64821V16.3545C17.6223 16.4723 17.6679 16.5902\r 17.7643 16.6598L18.8357 17.7071V17.9402H13.4571V17.7179L14.5634 16.6438C14.6732 16.5339 14.6732 16.5018 14.6732 16.3384V10.1027L11.5929\r 17.9134H11.1777L7.59375 10.1027V15.3393C7.56161 15.5589 7.63929 15.7813 7.79464 15.9393L9.23571 17.683V17.9161H5.14286V17.683L6.58393\r 15.9393C6.65985 15.8609 6.71636 15.7657 6.74892 15.6615C6.78148 15.5574 6.78919 15.447 6.77143 15.3393V9.28571C6.79018 9.11696 6.72589\r 8.95357 6.59732 8.83839L5.31696 7.29554V7.0625H9.29464L12.3643 13.7991L15.067 7.06786H18.8571V7.29554Z",
      fill: "black"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 28,
    columnNumber: 9
  }, undefined);
};

/***/ }),

/***/ "./src/icons/icon.ts":
/*!***************************!*\
  !*** ./src/icons/icon.ts ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IconLink": () => (/* binding */ IconLink)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const IconLink = styled_components__WEBPACK_IMPORTED_MODULE_0___default().a.withConfig({
  displayName: "icon__IconLink",
  componentId: "sc-169gd2u-0"
})(["cursor:pointer;white-space:nowrap;text-decoration:none;color:black;transition:text-shadow 0.3s ease-in-out;margin-left:20px;@media (max-width:1300px){margin-left:12px;}&:hover{text-shadow:0 25px 25px rgba(0,0,0,0.3);}"]);

/***/ }),

/***/ "./src/links/Links.ts":
/*!****************************!*\
  !*** ./src/links/Links.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DISCORD_LINK": () => (/* binding */ DISCORD_LINK),
/* harmony export */   "TWITTER_LINK": () => (/* binding */ TWITTER_LINK),
/* harmony export */   "TELE_LINK": () => (/* binding */ TELE_LINK),
/* harmony export */   "MEDIUM_LINK": () => (/* binding */ MEDIUM_LINK)
/* harmony export */ });
const DISCORD_LINK = 'https://discord.gg/q2MdMthF2z';
const TWITTER_LINK = "https://twitter.com/DaBunnyNFT";
const TELE_LINK = "https://t.me/DaBunnyNFT";
const MEDIUM_LINK = "https://medium.com/@dabunnynft";

/***/ }),

/***/ "./src/styles/typography.ts":
/*!**********************************!*\
  !*** ./src/styles/typography.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fonts": () => (/* binding */ fonts),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fonts = {
  font40: {
    w1920: {
      fontSize: "22px",
      height: "30px"
    },
    w1660: {
      fontSize: "22px",
      height: "28px"
    },
    w1440: {
      fontSize: "22px",
      height: "28px"
    },
    w768: {
      fontSize: "18px",
      height: "24px"
    },
    w500: {
      fontSize: "16px",
      height: "20px"
    }
  },
  font24: {
    w1920: {
      fontSize: "20px",
      height: "26px"
    },
    w1660: {
      fontSize: "18px",
      height: "24px"
    },
    w1440: {
      fontSize: "18px",
      height: "24px"
    },
    w768: {
      fontSize: "16px",
      height: "20px"
    },
    w500: {
      fontSize: "14px",
      height: "18px"
    }
  },
  font20: {
    w1920: {
      fontSize: "16px",
      height: "20px"
    },
    w1660: {
      fontSize: "16px",
      height: "20px"
    },
    w1440: {
      fontSize: "16px",
      height: "20px"
    },
    w768: {
      fontSize: "16px",
      height: "20px"
    },
    w500: {
      fontSize: "14px",
      height: "18px"
    }
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fonts);

/***/ }),

/***/ "./src/utils/Interface.ts":
/*!********************************!*\
  !*** ./src/utils/Interface.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CONNECT_STATUS": () => (/* binding */ CONNECT_STATUS),
/* harmony export */   "SALE_STATUS": () => (/* binding */ SALE_STATUS)
/* harmony export */ });
let CONNECT_STATUS;

(function (CONNECT_STATUS) {
  CONNECT_STATUS[CONNECT_STATUS["CONNECT"] = 0] = "CONNECT";
  CONNECT_STATUS[CONNECT_STATUS["CONNECTED"] = 1] = "CONNECTED";
  CONNECT_STATUS[CONNECT_STATUS["CONNECTING"] = 2] = "CONNECTING";
})(CONNECT_STATUS || (CONNECT_STATUS = {}));

let SALE_STATUS;

(function (SALE_STATUS) {
  SALE_STATUS[SALE_STATUS["OFFSALE"] = 0] = "OFFSALE";
  SALE_STATUS[SALE_STATUS["ONSALE"] = 1] = "ONSALE";
  SALE_STATUS[SALE_STATUS["SOLDOUT"] = 2] = "SOLDOUT";
})(SALE_STATUS || (SALE_STATUS = {}));

/***/ }),

/***/ "./src/utils/Links.ts":
/*!****************************!*\
  !*** ./src/utils/Links.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DISCORD_LINK": () => (/* binding */ DISCORD_LINK),
/* harmony export */   "TWITTER_LINK": () => (/* binding */ TWITTER_LINK),
/* harmony export */   "TELE_LINK": () => (/* binding */ TELE_LINK),
/* harmony export */   "MEDIUM_LINK": () => (/* binding */ MEDIUM_LINK)
/* harmony export */ });
const DISCORD_LINK = 'https://discord.gg/q2MdMthF2z';
const TWITTER_LINK = "https://twitter.com/DaBunnyNFT";
const TELE_LINK = "https://t.me/DaBunnyNFT";
const MEDIUM_LINK = "https://medium.com/@dabunnynft";

/***/ }),

/***/ "./src/utils/config.js":
/*!*****************************!*\
  !*** ./src/utils/config.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "nftaddress": () => (/* binding */ nftaddress),
/* harmony export */   "serverUrl": () => (/* binding */ serverUrl),
/* harmony export */   "jwtToken": () => (/* binding */ jwtToken)
/* harmony export */ });
// export const nftaddress = "0xa3e116B0bC8689B91E12467368a36A30E8803417";
const nftaddress = "0xB5350E5610360f9daE5b2543DA37D493cB8f82b3";
const serverUrl = "";
const jwtToken = "";

/***/ }),

/***/ "./src/utils/web3lib.js":
/*!******************************!*\
  !*** ./src/utils/web3lib.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getNFTContract": () => (/* binding */ getNFTContract),
/* harmony export */   "getNFTAddress": () => (/* binding */ getNFTAddress)
/* harmony export */ });
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ethers */ "ethers");
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _DaBunny_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DaBunny.json */ "./src/utils/DaBunny.json");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config */ "./src/utils/config.js");
 // import {dabunnynftAbi} from "./dabunny-nft";



const getNFTContract = provider => {
  return new ethers__WEBPACK_IMPORTED_MODULE_0__.ethers.Contract(_config__WEBPACK_IMPORTED_MODULE_2__.nftaddress, _DaBunny_json__WEBPACK_IMPORTED_MODULE_1__.abi, provider);
};
const getNFTAddress = () => {
  return _config__WEBPACK_IMPORTED_MODULE_2__.nftaddress;
};

/***/ }),

/***/ "./node_modules/next/image.js":
/*!************************************!*\
  !*** ./node_modules/next/image.js ***!
  \************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(/*! ./dist/client/image */ "./node_modules/next/dist/client/image.js")


/***/ }),

/***/ "./node_modules/next/link.js":
/*!***********************************!*\
  !*** ./node_modules/next/link.js ***!
  \***********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(/*! ./dist/client/link */ "./node_modules/next/dist/client/link.js")


/***/ }),

/***/ "@ethersproject/providers":
/*!*******************************************!*\
  !*** external "@ethersproject/providers" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ethersproject/providers");

/***/ }),

/***/ "@walletconnect/web3-provider":
/*!***********************************************!*\
  !*** external "@walletconnect/web3-provider" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@walletconnect/web3-provider");

/***/ }),

/***/ "ethers":
/*!*************************!*\
  !*** external "ethers" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("ethers");

/***/ }),

/***/ "../../../server/denormalize-page-path":
/*!************************************************************!*\
  !*** external "next/dist/server/denormalize-page-path.js" ***!
  \************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ "../server/image-config":
/*!***************************************************!*\
  !*** external "next/dist/server/image-config.js" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ "../shared/lib/head":
/*!***********************************************!*\
  !*** external "next/dist/shared/lib/head.js" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ "../i18n/normalize-locale-path":
/*!*********************************************************************!*\
  !*** external "next/dist/shared/lib/i18n/normalize-locale-path.js" ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ "../mitt":
/*!***********************************************!*\
  !*** external "next/dist/shared/lib/mitt.js" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ "../shared/lib/router-context":
/*!*********************************************************!*\
  !*** external "next/dist/shared/lib/router-context.js" ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ "../shared/lib/router/utils/get-asset-path-from-route":
/*!*********************************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/get-asset-path-from-route.js" ***!
  \*********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ "./utils/is-dynamic":
/*!******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/is-dynamic.js" ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ "./utils/parse-relative-url":
/*!**************************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/parse-relative-url.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ "./utils/querystring":
/*!*******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/querystring.js" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ "./utils/route-matcher":
/*!*********************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/route-matcher.js" ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ "./utils/route-regex":
/*!*******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/route-regex.js" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ "../shared/lib/to-base-64":
/*!*****************************************************!*\
  !*** external "next/dist/shared/lib/to-base-64.js" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ "../shared/lib/utils":
/*!************************************************!*\
  !*** external "next/dist/shared/lib/utils.js" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-is":
/*!***************************!*\
  !*** external "react-is" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-is");

/***/ }),

/***/ "react-swipeable":
/*!**********************************!*\
  !*** external "react-swipeable" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-swipeable");

/***/ }),

/***/ "react-waypoint":
/*!*********************************!*\
  !*** external "react-waypoint" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-waypoint");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("styled-components");

/***/ }),

/***/ "validator":
/*!****************************!*\
  !*** external "validator" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("validator");

/***/ }),

/***/ "web3modal":
/*!****************************!*\
  !*** external "web3modal" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("web3modal");

/***/ }),

/***/ "?5c99":
/*!******************************************!*\
  !*** ./utils/resolve-rewrites (ignored) ***!
  \******************************************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ "./src/utils/DaBunny.json":
/*!********************************!*\
  !*** ./src/utils/DaBunny.json ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"_format":"hh-sol-artifact-1","contractName":"RabitsWayNFT","sourceName":"contracts/Dabunny721.sol","abi":[{"inputs":[{"internalType":"address","name":"_daBunny20ContractAddress","type":"address"},{"internalType":"address","name":"_w1","type":"address"},{"internalType":"address","name":"_w2","type":"address"},{"internalType":"address","name":"_w3","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"approved","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"baseExtension","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"bunnyPrice","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getBaseURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"maxMintAllowedOnce","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"maxSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_mintAmount","type":"uint256"},{"internalType":"bool","name":"rarity","type":"bool"}],"name":"mint","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"notRevealedUri","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"rareBunnyPrice","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"revealed","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"bytes","name":"_data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"saleOpen","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_newBaseExtension","type":"string"}],"name":"setBaseExtension","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_newBaseURI","type":"string"}],"name":"setBaseURI","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_price","type":"uint256"}],"name":"setBunnyPrice","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_notRevealedURI","type":"string"}],"name":"setNotRevealedURI","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_price","type":"uint256"}],"name":"setRareBunnyPrice","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"toggleReveal","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"toggleSale","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"index","type":"uint256"}],"name":"tokenByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"uint256","name":"index","type":"uint256"}],"name":"tokenOfOwnerByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_owner","type":"address"}],"name":"tokensOfOwner","outputs":[{"internalType":"uint256[]","name":"","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"withdraw","outputs":[],"stateMutability":"payable","type":"function"}],"linkReferences":{},"deployedLinkReferences":{}}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.tsx"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUFhOztBQUNiQSw4Q0FBNkM7QUFDekNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBRCxlQUFBLEdBQWtCRyxNQUFsQjs7QUFDQSxJQUFJQyxNQUFNLEdBQUdDLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLG9CQUFELENBQVIsQ0FBbkM7O0FBQ0EsSUFBSUMsS0FBSyxHQUFHRixzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyw4Q0FBRCxDQUFSLENBQWxDOztBQUNBLElBQUlFLFNBQVMsR0FBR0YsbUJBQU8sQ0FBQywwREFBRCxDQUF2Qjs7QUFDQSxJQUFJRyxZQUFZLEdBQUdILG1CQUFPLENBQUMsc0RBQUQsQ0FBMUI7O0FBQ0EsSUFBSUksZ0JBQWdCLEdBQUdKLG1CQUFPLENBQUMsK0VBQUQsQ0FBOUI7O0FBQ0EsU0FBU0ssZUFBVCxDQUF5QkMsR0FBekIsRUFBOEJDLEdBQTlCLEVBQW1DWixLQUFuQyxFQUEwQztBQUN0QyxNQUFJWSxHQUFHLElBQUlELEdBQVgsRUFBZ0I7QUFDWmQsSUFBQUEsTUFBTSxDQUFDQyxjQUFQLENBQXNCYSxHQUF0QixFQUEyQkMsR0FBM0IsRUFBZ0M7QUFDNUJaLE1BQUFBLEtBQUssRUFBRUEsS0FEcUI7QUFFNUJhLE1BQUFBLFVBQVUsRUFBRSxJQUZnQjtBQUc1QkMsTUFBQUEsWUFBWSxFQUFFLElBSGM7QUFJNUJDLE1BQUFBLFFBQVEsRUFBRTtBQUprQixLQUFoQztBQU1ILEdBUEQsTUFPTztBQUNISixJQUFBQSxHQUFHLENBQUNDLEdBQUQsQ0FBSCxHQUFXWixLQUFYO0FBQ0g7O0FBQ0QsU0FBT1csR0FBUDtBQUNIOztBQUNELFNBQVNQLHNCQUFULENBQWdDTyxHQUFoQyxFQUFxQztBQUNqQyxTQUFPQSxHQUFHLElBQUlBLEdBQUcsQ0FBQ0ssVUFBWCxHQUF3QkwsR0FBeEIsR0FBOEI7QUFDakNWLElBQUFBLE9BQU8sRUFBRVU7QUFEd0IsR0FBckM7QUFHSDs7QUFDRCxTQUFTTSxhQUFULENBQXVCQyxNQUF2QixFQUErQjtBQUMzQixPQUFJLElBQUlDLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBR0MsU0FBUyxDQUFDQyxNQUE3QixFQUFxQ0YsQ0FBQyxFQUF0QyxFQUF5QztBQUNyQyxRQUFJRyxNQUFNLEdBQUdGLFNBQVMsQ0FBQ0QsQ0FBRCxDQUFULElBQWdCLElBQWhCLEdBQXVCQyxTQUFTLENBQUNELENBQUQsQ0FBaEMsR0FBc0MsRUFBbkQ7QUFFQSxRQUFJSSxPQUFPLEdBQUcxQixNQUFNLENBQUMyQixJQUFQLENBQVlGLE1BQVosQ0FBZDs7QUFDQSxRQUFJLE9BQU96QixNQUFNLENBQUM0QixxQkFBZCxLQUF3QyxVQUE1QyxFQUF3RDtBQUNwREYsTUFBQUEsT0FBTyxHQUFHQSxPQUFPLENBQUNHLE1BQVIsQ0FBZTdCLE1BQU0sQ0FBQzRCLHFCQUFQLENBQTZCSCxNQUE3QixFQUFxQ0ssTUFBckMsQ0FBNEMsVUFBU0MsR0FBVCxFQUFjO0FBQy9FLGVBQU8vQixNQUFNLENBQUNnQyx3QkFBUCxDQUFnQ1AsTUFBaEMsRUFBd0NNLEdBQXhDLEVBQTZDZixVQUFwRDtBQUNILE9BRndCLENBQWYsQ0FBVjtBQUdIOztBQUNEVSxJQUFBQSxPQUFPLENBQUNPLE9BQVIsQ0FBZ0IsVUFBU2xCLEdBQVQsRUFBYztBQUMxQkYsTUFBQUEsZUFBZSxDQUFDUSxNQUFELEVBQVNOLEdBQVQsRUFBY1UsTUFBTSxDQUFDVixHQUFELENBQXBCLENBQWY7QUFDSCxLQUZEO0FBR0g7O0FBQ0QsU0FBT00sTUFBUDtBQUNIOztBQUNELFNBQVNhLHdCQUFULENBQWtDVCxNQUFsQyxFQUEwQ1UsUUFBMUMsRUFBb0Q7QUFDaEQsTUFBSVYsTUFBTSxJQUFJLElBQWQsRUFBb0IsT0FBTyxFQUFQOztBQUVwQixNQUFJSixNQUFNLEdBQUdlLDZCQUE2QixDQUFDWCxNQUFELEVBQVNVLFFBQVQsQ0FBMUM7O0FBQ0EsTUFBSXBCLEdBQUosRUFBU08sQ0FBVDs7QUFDQSxNQUFJdEIsTUFBTSxDQUFDNEIscUJBQVgsRUFBa0M7QUFDOUIsUUFBSVMsZ0JBQWdCLEdBQUdyQyxNQUFNLENBQUM0QixxQkFBUCxDQUE2QkgsTUFBN0IsQ0FBdkI7O0FBQ0EsU0FBSUgsQ0FBQyxHQUFHLENBQVIsRUFBV0EsQ0FBQyxHQUFHZSxnQkFBZ0IsQ0FBQ2IsTUFBaEMsRUFBd0NGLENBQUMsRUFBekMsRUFBNEM7QUFDeENQLE1BQUFBLEdBQUcsR0FBR3NCLGdCQUFnQixDQUFDZixDQUFELENBQXRCO0FBQ0EsVUFBSWEsUUFBUSxDQUFDRyxPQUFULENBQWlCdkIsR0FBakIsS0FBeUIsQ0FBN0IsRUFBZ0M7QUFDaEMsVUFBSSxDQUFDZixNQUFNLENBQUN1QyxTQUFQLENBQWlCQyxvQkFBakIsQ0FBc0NDLElBQXRDLENBQTJDaEIsTUFBM0MsRUFBbURWLEdBQW5ELENBQUwsRUFBOEQ7QUFDOURNLE1BQUFBLE1BQU0sQ0FBQ04sR0FBRCxDQUFOLEdBQWNVLE1BQU0sQ0FBQ1YsR0FBRCxDQUFwQjtBQUNIO0FBQ0o7O0FBQ0QsU0FBT00sTUFBUDtBQUNIOztBQUNELFNBQVNlLDZCQUFULENBQXVDWCxNQUF2QyxFQUErQ1UsUUFBL0MsRUFBeUQ7QUFDckQsTUFBSVYsTUFBTSxJQUFJLElBQWQsRUFBb0IsT0FBTyxFQUFQO0FBRXBCLE1BQUlKLE1BQU0sR0FBRyxFQUFiO0FBRUEsTUFBSXFCLFVBQVUsR0FBRzFDLE1BQU0sQ0FBQzJCLElBQVAsQ0FBWUYsTUFBWixDQUFqQjtBQUNBLE1BQUlWLEdBQUosRUFBU08sQ0FBVDs7QUFDQSxPQUFJQSxDQUFDLEdBQUcsQ0FBUixFQUFXQSxDQUFDLEdBQUdvQixVQUFVLENBQUNsQixNQUExQixFQUFrQ0YsQ0FBQyxFQUFuQyxFQUFzQztBQUNsQ1AsSUFBQUEsR0FBRyxHQUFHMkIsVUFBVSxDQUFDcEIsQ0FBRCxDQUFoQjtBQUNBLFFBQUlhLFFBQVEsQ0FBQ0csT0FBVCxDQUFpQnZCLEdBQWpCLEtBQXlCLENBQTdCLEVBQWdDO0FBQ2hDTSxJQUFBQSxNQUFNLENBQUNOLEdBQUQsQ0FBTixHQUFjVSxNQUFNLENBQUNWLEdBQUQsQ0FBcEI7QUFDSDs7QUFDRCxTQUFPTSxNQUFQO0FBQ0g7O0FBQ0QsTUFBTXNCLGVBQWUsR0FBRyxJQUFJQyxHQUFKLEVBQXhCOztBQUNBLElBQUksTUFBK0I7QUFDL0JDLEVBQUFBLE1BQU0sQ0FBQ0MscUJBQVAsR0FBK0IsSUFBL0I7QUFDSDs7QUFDRCxNQUFNQyxvQkFBb0IsR0FBRyxDQUN6QixNQUR5QixFQUV6QixPQUZ5QixFQUd6QkMsU0FIeUIsQ0FBN0I7QUFLQSxNQUFNQyxPQUFPLEdBQUcsSUFBSUMsR0FBSixDQUFRLENBQ3BCLENBQ0ksU0FESixFQUVJQyxhQUZKLENBRG9CLEVBS3BCLENBQ0ksT0FESixFQUVJQyxXQUZKLENBTG9CLEVBU3BCLENBQ0ksWUFESixFQUVJQyxnQkFGSixDQVRvQixFQWFwQixDQUNJLFFBREosRUFFSUMsWUFGSixDQWJvQixFQWlCcEIsQ0FDSSxRQURKLEVBRUlDLFlBRkosQ0FqQm9CLENBQVIsQ0FBaEI7QUFzQkEsTUFBTUMsbUJBQW1CLEdBQUcsQ0FDeEIsTUFEd0IsRUFFeEIsT0FGd0IsRUFHeEIsV0FId0IsRUFJeEIsWUFKd0IsRUFLeEJSLFNBTHdCLENBQTVCOztBQU9BLFNBQVNTLGVBQVQsQ0FBeUJDLEdBQXpCLEVBQThCO0FBQzFCLFNBQU9BLEdBQUcsQ0FBQ3RELE9BQUosS0FBZ0I0QyxTQUF2QjtBQUNIOztBQUNELFNBQVNXLGlCQUFULENBQTJCRCxHQUEzQixFQUFnQztBQUM1QixTQUFPQSxHQUFHLENBQUNBLEdBQUosS0FBWVYsU0FBbkI7QUFDSDs7QUFDRCxTQUFTWSxjQUFULENBQXdCRixHQUF4QixFQUE2QjtBQUN6QixTQUFPLE9BQU9BLEdBQVAsS0FBZSxRQUFmLEtBQTRCRCxlQUFlLENBQUNDLEdBQUQsQ0FBZixJQUF3QkMsaUJBQWlCLENBQUNELEdBQUQsQ0FBckUsQ0FBUDtBQUNIOztBQUNELE1BQU07QUFBRUcsRUFBQUEsV0FBVyxFQUFFQyxpQkFBZjtBQUFtQ0MsRUFBQUEsVUFBVSxFQUFFQyxnQkFBL0M7QUFBa0VDLEVBQUFBLE1BQU0sRUFBRUMsWUFBMUU7QUFBeUZDLEVBQUFBLElBQUksRUFBRUMsVUFBL0Y7QUFBNEdDLEVBQUFBLE9BQU8sRUFBRUM7QUFBckgsSUFBMElDLHNKQUFBLElBQWlDNUQsWUFBWSxDQUFDK0Qsa0JBQTlMLEVBQ0E7O0FBQ0EsTUFBTUMsUUFBUSxHQUFHLENBQ2IsR0FBR2IsaUJBRFUsRUFFYixHQUFHRSxnQkFGVSxDQUFqQjtBQUlBRixpQkFBaUIsQ0FBQ2MsSUFBbEIsQ0FBdUIsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVFELENBQUMsR0FBR0MsQ0FBbkM7QUFFQUgsUUFBUSxDQUFDQyxJQUFULENBQWMsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVFELENBQUMsR0FBR0MsQ0FBMUI7O0FBRUEsU0FBU0MsU0FBVCxDQUFtQkMsS0FBbkIsRUFBMEJDLE1BQTFCLEVBQWtDQyxLQUFsQyxFQUF5QztBQUNyQyxNQUFJQSxLQUFLLEtBQUtELE1BQU0sS0FBSyxNQUFYLElBQXFCQSxNQUFNLEtBQUssWUFBckMsQ0FBVCxFQUE2RDtBQUN6RDtBQUNBLFVBQU1FLGVBQWUsR0FBRyxvQkFBeEI7QUFDQSxVQUFNQyxZQUFZLEdBQUcsRUFBckI7O0FBQ0EsU0FBSSxJQUFJQyxLQUFSLEVBQWVBLEtBQUssR0FBR0YsZUFBZSxDQUFDRyxJQUFoQixDQUFxQkosS0FBckIsQ0FBdkIsRUFBb0RHLEtBQXBELEVBQTBEO0FBQ3RERCxNQUFBQSxZQUFZLENBQUNHLElBQWIsQ0FBa0JDLFFBQVEsQ0FBQ0gsS0FBSyxDQUFDLENBQUQsQ0FBTixDQUExQjtBQUNIOztBQUNELFFBQUlELFlBQVksQ0FBQzVELE1BQWpCLEVBQXlCO0FBQ3JCLFlBQU1pRSxhQUFhLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEdBQUdQLFlBQVosSUFBNEIsSUFBbEQ7QUFDQSxhQUFPO0FBQ0hRLFFBQUFBLE1BQU0sRUFBRWpCLFFBQVEsQ0FBQzdDLE1BQVQsQ0FBaUIrRCxDQUFELElBQUtBLENBQUMsSUFBSS9CLGlCQUFpQixDQUFDLENBQUQsQ0FBakIsR0FBdUIyQixhQUFqRCxDQURMO0FBR0hLLFFBQUFBLElBQUksRUFBRTtBQUhILE9BQVA7QUFLSDs7QUFDRCxXQUFPO0FBQ0hGLE1BQUFBLE1BQU0sRUFBRWpCLFFBREw7QUFFSG1CLE1BQUFBLElBQUksRUFBRTtBQUZILEtBQVA7QUFJSDs7QUFDRCxNQUFJLE9BQU9kLEtBQVAsS0FBaUIsUUFBakIsSUFBNkJDLE1BQU0sS0FBSyxNQUF4QyxJQUFrREEsTUFBTSxLQUFLLFlBQWpFLEVBQStFO0FBQzNFLFdBQU87QUFDSFcsTUFBQUEsTUFBTSxFQUFFOUIsaUJBREw7QUFFSGdDLE1BQUFBLElBQUksRUFBRTtBQUZILEtBQVA7QUFJSDs7QUFDRCxRQUFNRixNQUFNLEdBQUcsQ0FDWCxHQUFHLElBQUloRCxHQUFKLEVBQVE7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQ0lvQyxLQURKLEVBRUlBLEtBQUssR0FBRztBQUFFO0FBRmQsSUFHRWUsR0FIRixDQUdPQyxDQUFELElBQUtyQixRQUFRLENBQUNzQixJQUFULENBQWVDLENBQUQsSUFBS0EsQ0FBQyxJQUFJRixDQUF4QixLQUNGckIsUUFBUSxDQUFDQSxRQUFRLENBQUNuRCxNQUFULEdBQWtCLENBQW5CLENBSmpCLENBUkcsQ0FEUSxDQUFmO0FBZ0JBLFNBQU87QUFDSG9FLElBQUFBLE1BREc7QUFFSEUsSUFBQUEsSUFBSSxFQUFFO0FBRkgsR0FBUDtBQUlIOztBQUNELFNBQVNLLGdCQUFULENBQTBCO0FBQUV6QyxFQUFBQSxHQUFGO0FBQVEwQyxFQUFBQSxXQUFSO0FBQXNCbkIsRUFBQUEsTUFBdEI7QUFBK0JELEVBQUFBLEtBQS9CO0FBQXVDcUIsRUFBQUEsT0FBdkM7QUFBaURuQixFQUFBQSxLQUFqRDtBQUF5RGpCLEVBQUFBO0FBQXpELENBQTFCLEVBQThGO0FBQzFGLE1BQUltQyxXQUFKLEVBQWlCO0FBQ2IsV0FBTztBQUNIMUMsTUFBQUEsR0FERztBQUVINEMsTUFBQUEsTUFBTSxFQUFFdEQsU0FGTDtBQUdIa0MsTUFBQUEsS0FBSyxFQUFFbEM7QUFISixLQUFQO0FBS0g7O0FBQ0QsUUFBTTtBQUFFNEMsSUFBQUEsTUFBRjtBQUFXRSxJQUFBQTtBQUFYLE1BQXFCZixTQUFTLENBQUNDLEtBQUQsRUFBUUMsTUFBUixFQUFnQkMsS0FBaEIsQ0FBcEM7QUFDQSxRQUFNcUIsSUFBSSxHQUFHWCxNQUFNLENBQUNwRSxNQUFQLEdBQWdCLENBQTdCO0FBQ0EsU0FBTztBQUNIMEQsSUFBQUEsS0FBSyxFQUFFLENBQUNBLEtBQUQsSUFBVVksSUFBSSxLQUFLLEdBQW5CLEdBQXlCLE9BQXpCLEdBQW1DWixLQUR2QztBQUVIb0IsSUFBQUEsTUFBTSxFQUFFVixNQUFNLENBQUNHLEdBQVAsQ0FBVyxDQUFDQyxDQUFELEVBQUkxRSxDQUFKLEtBQVMsR0FBRTJDLE1BQU0sQ0FBQztBQUM3QlAsTUFBQUEsR0FENkI7QUFFN0IyQyxNQUFBQSxPQUY2QjtBQUc3QnJCLE1BQUFBLEtBQUssRUFBRWdCO0FBSHNCLEtBQUQsQ0FJN0IsSUFBR0YsSUFBSSxLQUFLLEdBQVQsR0FBZUUsQ0FBZixHQUFtQjFFLENBQUMsR0FBRyxDQUFFLEdBQUV3RSxJQUFLLEVBSmxDLEVBS05VLElBTE0sQ0FLRCxJQUxDLENBRkw7QUFRSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTlDLElBQUFBLEdBQUcsRUFBRU8sTUFBTSxDQUFDO0FBQ1JQLE1BQUFBLEdBRFE7QUFFUjJDLE1BQUFBLE9BRlE7QUFHUnJCLE1BQUFBLEtBQUssRUFBRVksTUFBTSxDQUFDVyxJQUFEO0FBSEwsS0FBRDtBQWRSLEdBQVA7QUFvQkg7O0FBQ0QsU0FBU0UsTUFBVCxDQUFnQkMsQ0FBaEIsRUFBbUI7QUFDZixNQUFJLE9BQU9BLENBQVAsS0FBYSxRQUFqQixFQUEyQjtBQUN2QixXQUFPQSxDQUFQO0FBQ0g7O0FBQ0QsTUFBSSxPQUFPQSxDQUFQLEtBQWEsUUFBakIsRUFBMkI7QUFDdkIsV0FBT2xCLFFBQVEsQ0FBQ2tCLENBQUQsRUFBSSxFQUFKLENBQWY7QUFDSDs7QUFDRCxTQUFPMUQsU0FBUDtBQUNIOztBQUNELFNBQVMyRCxrQkFBVCxDQUE0QkMsV0FBNUIsRUFBeUM7QUFDckMsUUFBTUMsSUFBSSxHQUFHNUQsT0FBTyxDQUFDNkQsR0FBUixDQUFZNUMsWUFBWixDQUFiOztBQUNBLE1BQUkyQyxJQUFKLEVBQVU7QUFDTixXQUFPQSxJQUFJLENBQUN6RixhQUFhLENBQUM7QUFDdEIyRixNQUFBQSxJQUFJLEVBQUUzQztBQURnQixLQUFELEVBRXRCd0MsV0FGc0IsQ0FBZCxDQUFYO0FBR0g7O0FBQ0QsUUFBTSxJQUFJSSxLQUFKLENBQVcseURBQXdEckcsWUFBWSxDQUFDc0csYUFBYixDQUEyQlQsSUFBM0IsQ0FBZ0MsSUFBaEMsQ0FBc0MsZUFBY3RDLFlBQWEsRUFBcEksQ0FBTjtBQUNILEVBQ0Q7QUFDQTs7O0FBQ0EsU0FBU2dELGFBQVQsQ0FBdUJDLEdBQXZCLEVBQTRCekQsR0FBNUIsRUFBaUN1QixNQUFqQyxFQUF5Q21DLFdBQXpDLEVBQXNEQyxpQkFBdEQsRUFBeUU7QUFDckUsTUFBSSxDQUFDRixHQUFMLEVBQVU7QUFDTjtBQUNIOztBQUNELFFBQU1HLFVBQVUsR0FBRyxNQUFJO0FBQ25CLFFBQUksQ0FBQ0gsR0FBRyxDQUFDekQsR0FBSixDQUFRNkQsVUFBUixDQUFtQixPQUFuQixDQUFMLEVBQWtDO0FBQzlCLFlBQU1yQixDQUFDLEdBQUcsWUFBWWlCLEdBQVosR0FBa0JBLEdBQUcsQ0FBQ0ssTUFBSixFQUFsQixHQUFpQ0MsT0FBTyxDQUFDQyxPQUFSLEVBQTNDO0FBQ0F4QixNQUFBQSxDQUFDLENBQUN5QixLQUFGLENBQVEsTUFBSSxDQUNYLENBREQsRUFDR0MsSUFESCxDQUNRLE1BQUk7QUFDUixZQUFJUixXQUFXLEtBQUssTUFBcEIsRUFBNEI7QUFDeEJELFVBQUFBLEdBQUcsQ0FBQ1UsS0FBSixDQUFVL0YsTUFBVixHQUFtQixNQUFuQjtBQUNBcUYsVUFBQUEsR0FBRyxDQUFDVSxLQUFKLENBQVVDLGNBQVYsR0FBMkIsTUFBM0I7QUFDQVgsVUFBQUEsR0FBRyxDQUFDVSxLQUFKLENBQVVFLGVBQVYsR0FBNEIsTUFBNUI7QUFDSDs7QUFDRHBGLFFBQUFBLGVBQWUsQ0FBQ3FGLEdBQWhCLENBQW9CdEUsR0FBcEI7O0FBQ0EsWUFBSTJELGlCQUFKLEVBQXVCO0FBQ25CLGdCQUFNO0FBQUVZLFlBQUFBLFlBQUY7QUFBaUJDLFlBQUFBO0FBQWpCLGNBQW9DZixHQUExQyxDQURtQixDQUVuQjtBQUNBOztBQUNBRSxVQUFBQSxpQkFBaUIsQ0FBQztBQUNkWSxZQUFBQSxZQURjO0FBRWRDLFlBQUFBO0FBRmMsV0FBRCxDQUFqQjtBQUlIOztBQUNELGtCQUEyQztBQUN2QyxjQUFJQyxHQUFKOztBQUNBLGNBQUksQ0FBQ0EsR0FBRyxHQUFHaEIsR0FBRyxDQUFDaUIsYUFBWCxNQUE4QixJQUE5QixJQUFzQ0QsR0FBRyxLQUFLLEtBQUssQ0FBbkQsR0FBdUQsS0FBSyxDQUE1RCxHQUFnRUEsR0FBRyxDQUFDQyxhQUF4RSxFQUF1RjtBQUNuRixrQkFBTUMsTUFBTSxHQUFHQyxnQkFBZ0IsQ0FBQ25CLEdBQUcsQ0FBQ2lCLGFBQUosQ0FBa0JBLGFBQW5CLENBQS9COztBQUNBLGdCQUFJbkQsTUFBTSxLQUFLLFlBQVgsSUFBMkJvRCxNQUFNLENBQUNFLE9BQVAsS0FBbUIsTUFBbEQsRUFBMEQ7QUFDdERDLGNBQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLG1CQUFrQi9FLEdBQUksMEhBQXBDO0FBQ0gsYUFGRCxNQUVPLElBQUl1QixNQUFNLEtBQUssTUFBWCxJQUFxQm9ELE1BQU0sQ0FBQ0ssUUFBUCxLQUFvQixVQUE3QyxFQUF5RDtBQUM1REYsY0FBQUEsT0FBTyxDQUFDQyxJQUFSLENBQWMsbUJBQWtCL0UsR0FBSSwyREFBMEQyRSxNQUFNLENBQUNLLFFBQVMsdUZBQTlHO0FBQ0g7QUFDSjtBQUNKO0FBQ0osT0E1QkQ7QUE2Qkg7QUFDSixHQWpDRDs7QUFrQ0EsTUFBSXZCLEdBQUcsQ0FBQ3dCLFFBQVIsRUFBa0I7QUFDZDtBQUNBO0FBQ0E7QUFDQXJCLElBQUFBLFVBQVU7QUFDYixHQUxELE1BS087QUFDSEgsSUFBQUEsR0FBRyxDQUFDeUIsTUFBSixHQUFhdEIsVUFBYjtBQUNIO0FBQ0o7O0FBQ0QsU0FBU2pILE1BQVQsQ0FBZ0J3SSxNQUFoQixFQUF3QjtBQUNwQixNQUFJO0FBQUVuRixJQUFBQSxHQUFGO0FBQVF3QixJQUFBQSxLQUFSO0FBQWdCa0IsSUFBQUEsV0FBVyxHQUFFLEtBQTdCO0FBQXFDMEMsSUFBQUEsUUFBUSxHQUFFLEtBQS9DO0FBQXVEQyxJQUFBQSxPQUF2RDtBQUFpRUMsSUFBQUEsWUFBWSxHQUFFLE9BQS9FO0FBQXlGQyxJQUFBQSxTQUF6RjtBQUFxRzVDLElBQUFBLE9BQXJHO0FBQStHckIsSUFBQUEsS0FBL0c7QUFBdUhrRSxJQUFBQSxNQUF2SDtBQUFnSUMsSUFBQUEsU0FBaEk7QUFBNElDLElBQUFBLGNBQTVJO0FBQTZKL0IsSUFBQUEsaUJBQTdKO0FBQWlMcEQsSUFBQUEsTUFBTSxHQUFFMEMsa0JBQXpMO0FBQThNUyxJQUFBQSxXQUFXLEdBQUUsT0FBM047QUFBcU9pQyxJQUFBQTtBQUFyTyxNQUFzUFIsTUFBMVA7QUFBQSxNQUFrUVMsR0FBRyxHQUFHcEgsd0JBQXdCLENBQUMyRyxNQUFELEVBQVMsQ0FBQyxLQUFELEVBQVEsT0FBUixFQUFpQixhQUFqQixFQUFnQyxVQUFoQyxFQUE0QyxTQUE1QyxFQUF1RCxjQUF2RCxFQUF1RSxXQUF2RSxFQUFvRixTQUFwRixFQUErRixPQUEvRixFQUF3RyxRQUF4RyxFQUFrSCxXQUFsSCxFQUErSCxnQkFBL0gsRUFBaUosbUJBQWpKLEVBQXNLLFFBQXRLLEVBQWdMLGFBQWhMLEVBQStMLGFBQS9MLENBQVQsQ0FBaFM7O0FBQ0EsTUFBSVUsSUFBSSxHQUFHRCxHQUFYO0FBQ0EsTUFBSXJFLE1BQU0sR0FBR0MsS0FBSyxHQUFHLFlBQUgsR0FBa0IsV0FBcEM7O0FBQ0EsTUFBSSxZQUFZcUUsSUFBaEIsRUFBc0I7QUFDbEI7QUFDQSxRQUFJQSxJQUFJLENBQUN0RSxNQUFULEVBQWlCQSxNQUFNLEdBQUdzRSxJQUFJLENBQUN0RSxNQUFkLENBRkMsQ0FHbEI7O0FBQ0EsV0FBT3NFLElBQUksQ0FBQyxRQUFELENBQVg7QUFDSDs7QUFDRCxNQUFJQyxTQUFTLEdBQUcsRUFBaEI7O0FBQ0EsTUFBSTVGLGNBQWMsQ0FBQ0YsR0FBRCxDQUFsQixFQUF5QjtBQUNyQixVQUFNK0YsZUFBZSxHQUFHaEcsZUFBZSxDQUFDQyxHQUFELENBQWYsR0FBdUJBLEdBQUcsQ0FBQ3RELE9BQTNCLEdBQXFDc0QsR0FBN0Q7O0FBQ0EsUUFBSSxDQUFDK0YsZUFBZSxDQUFDL0YsR0FBckIsRUFBMEI7QUFDdEIsWUFBTSxJQUFJc0QsS0FBSixDQUFXLDhJQUE2STBDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixlQUFmLENBQWdDLEVBQXhMLENBQU47QUFDSDs7QUFDREosSUFBQUEsV0FBVyxHQUFHQSxXQUFXLElBQUlJLGVBQWUsQ0FBQ0osV0FBN0M7QUFDQUcsSUFBQUEsU0FBUyxHQUFHQyxlQUFlLENBQUMvRixHQUE1Qjs7QUFDQSxRQUFJLENBQUN1QixNQUFELElBQVdBLE1BQU0sS0FBSyxNQUExQixFQUFrQztBQUM5QmlFLE1BQUFBLE1BQU0sR0FBR0EsTUFBTSxJQUFJTyxlQUFlLENBQUNQLE1BQW5DO0FBQ0FsRSxNQUFBQSxLQUFLLEdBQUdBLEtBQUssSUFBSXlFLGVBQWUsQ0FBQ3pFLEtBQWpDOztBQUNBLFVBQUksQ0FBQ3lFLGVBQWUsQ0FBQ1AsTUFBakIsSUFBMkIsQ0FBQ08sZUFBZSxDQUFDekUsS0FBaEQsRUFBdUQ7QUFDbkQsY0FBTSxJQUFJZ0MsS0FBSixDQUFXLDJKQUEwSjBDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixlQUFmLENBQWdDLEVBQXJNLENBQU47QUFDSDtBQUNKO0FBQ0o7O0FBQ0QvRixFQUFBQSxHQUFHLEdBQUcsT0FBT0EsR0FBUCxLQUFlLFFBQWYsR0FBMEJBLEdBQTFCLEdBQWdDOEYsU0FBdEM7QUFDQSxRQUFNSSxRQUFRLEdBQUduRCxNQUFNLENBQUN6QixLQUFELENBQXZCO0FBQ0EsUUFBTTZFLFNBQVMsR0FBR3BELE1BQU0sQ0FBQ3lDLE1BQUQsQ0FBeEI7QUFDQSxRQUFNWSxVQUFVLEdBQUdyRCxNQUFNLENBQUNKLE9BQUQsQ0FBekI7QUFDQSxNQUFJMEQsTUFBTSxHQUFHLENBQUNqQixRQUFELEtBQWNDLE9BQU8sS0FBSyxNQUFaLElBQXNCLE9BQU9BLE9BQVAsS0FBbUIsV0FBdkQsQ0FBYjs7QUFDQSxNQUFJckYsR0FBRyxDQUFDNkQsVUFBSixDQUFlLE9BQWYsS0FBMkI3RCxHQUFHLENBQUM2RCxVQUFKLENBQWUsT0FBZixDQUEvQixFQUF3RDtBQUNwRDtBQUNBbkIsSUFBQUEsV0FBVyxHQUFHLElBQWQ7QUFDQTJELElBQUFBLE1BQU0sR0FBRyxLQUFUO0FBQ0g7O0FBQ0QsTUFBSSxLQUFKLEVBQStELEVBRTlEOztBQUNELFlBQTJDO0FBQ3ZDLFFBQUksQ0FBQ3JHLEdBQUwsRUFBVTtBQUNOLFlBQU0sSUFBSXNELEtBQUosQ0FBVywwSEFBeUgwQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNySjNFLFFBQUFBLEtBRHFKO0FBRXJKa0UsUUFBQUEsTUFGcUo7QUFHcko3QyxRQUFBQTtBQUhxSixPQUFmLENBSXZJLEVBSkcsQ0FBTjtBQUtIOztBQUNELFFBQUksQ0FBQzdDLG1CQUFtQixDQUFDeUcsUUFBcEIsQ0FBNkJoRixNQUE3QixDQUFMLEVBQTJDO0FBQ3ZDLFlBQU0sSUFBSStCLEtBQUosQ0FBVyxtQkFBa0J0RCxHQUFJLDhDQUE2Q3VCLE1BQU8sc0JBQXFCekIsbUJBQW1CLENBQUN1QyxHQUFwQixDQUF3Qm1FLE1BQXhCLEVBQWdDMUQsSUFBaEMsQ0FBcUMsR0FBckMsQ0FBMEMsR0FBcEosQ0FBTjtBQUNIOztBQUNELFFBQUksT0FBT29ELFFBQVAsS0FBb0IsV0FBcEIsSUFBbUNPLEtBQUssQ0FBQ1AsUUFBRCxDQUF4QyxJQUFzRCxPQUFPQyxTQUFQLEtBQXFCLFdBQXJCLElBQW9DTSxLQUFLLENBQUNOLFNBQUQsQ0FBbkcsRUFBZ0g7QUFDNUcsWUFBTSxJQUFJN0MsS0FBSixDQUFXLG1CQUFrQnRELEdBQUksNkVBQWpDLENBQU47QUFDSDs7QUFDRCxRQUFJdUIsTUFBTSxLQUFLLE1BQVgsS0FBc0JELEtBQUssSUFBSWtFLE1BQS9CLENBQUosRUFBNEM7QUFDeENWLE1BQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLG1CQUFrQi9FLEdBQUksMkZBQXBDO0FBQ0g7O0FBQ0QsUUFBSSxDQUFDWCxvQkFBb0IsQ0FBQ2tILFFBQXJCLENBQThCbEIsT0FBOUIsQ0FBTCxFQUE2QztBQUN6QyxZQUFNLElBQUkvQixLQUFKLENBQVcsbUJBQWtCdEQsR0FBSSwrQ0FBOENxRixPQUFRLHNCQUFxQmhHLG9CQUFvQixDQUFDZ0QsR0FBckIsQ0FBeUJtRSxNQUF6QixFQUFpQzFELElBQWpDLENBQXNDLEdBQXRDLENBQTJDLEdBQXZKLENBQU47QUFDSDs7QUFDRCxRQUFJc0MsUUFBUSxJQUFJQyxPQUFPLEtBQUssTUFBNUIsRUFBb0M7QUFDaEMsWUFBTSxJQUFJL0IsS0FBSixDQUFXLG1CQUFrQnRELEdBQUksaUZBQWpDLENBQU47QUFDSDs7QUFDRCxRQUFJMEQsV0FBVyxLQUFLLE1BQXBCLEVBQTRCO0FBQ3hCLFVBQUluQyxNQUFNLEtBQUssTUFBWCxJQUFxQixDQUFDMkUsUUFBUSxJQUFJLENBQWIsS0FBbUJDLFNBQVMsSUFBSSxDQUFoQyxJQUFxQyxJQUE5RCxFQUFvRTtBQUNoRXJCLFFBQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLG1CQUFrQi9FLEdBQUksc0dBQXBDO0FBQ0g7O0FBQ0QsVUFBSSxDQUFDMkYsV0FBTCxFQUFrQjtBQUNkLGNBQU1lLGNBQWMsR0FBRyxDQUNuQixNQURtQixFQUVuQixLQUZtQixFQUduQixNQUhtQixDQUF2QixDQUlFO0FBSkY7QUFNQSxjQUFNLElBQUlwRCxLQUFKLENBQVcsbUJBQWtCdEQsR0FBSTtBQUN2RDtBQUNBO0FBQ0EsbUdBQW1HMEcsY0FBYyxDQUFDNUQsSUFBZixDQUFvQixHQUFwQixDQUF5QjtBQUM1SDtBQUNBLGdGQUxzQixDQUFOO0FBTUg7QUFDSjs7QUFDRCxRQUFJLFNBQVMrQyxJQUFiLEVBQW1CO0FBQ2ZmLE1BQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLG1CQUFrQi9FLEdBQUksaUdBQXBDO0FBQ0g7O0FBQ0QsUUFBSSxXQUFXNkYsSUFBZixFQUFxQjtBQUNqQmYsTUFBQUEsT0FBTyxDQUFDQyxJQUFSLENBQWMsbUJBQWtCL0UsR0FBSSx1RkFBcEM7QUFDSDs7QUFDRCxVQUFNMkcsSUFBSSxHQUFHM0UsSUFBSSxDQUFDNEUsS0FBTCxDQUFXNUUsSUFBSSxDQUFDNkUsTUFBTCxLQUFnQixJQUEzQixJQUFtQyxHQUFoRDs7QUFDQSxRQUFJLENBQUNuRSxXQUFELElBQWdCLENBQUNuQyxNQUFNLENBQUM7QUFDeEJQLE1BQUFBLEdBRHdCO0FBRXhCc0IsTUFBQUEsS0FBSyxFQUFFcUYsSUFGaUI7QUFHeEJoRSxNQUFBQSxPQUFPLEVBQUU7QUFIZSxLQUFELENBQU4sQ0FJbEI0RCxRQUprQixDQUlUSSxJQUFJLENBQUNHLFFBQUwsRUFKUyxDQUFyQixFQUk4QjtBQUMxQmhDLE1BQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLG1CQUFrQi9FLEdBQUkseUhBQXZCLEdBQW1KLCtFQUFoSztBQUNIO0FBQ0o7O0FBQ0QsUUFBTSxDQUFDK0csTUFBRCxFQUFTQyxhQUFULElBQTBCLENBQUMsR0FBRzlKLGdCQUFKLEVBQXNCK0osZUFBdEIsQ0FBc0M7QUFDbEVDLElBQUFBLFVBQVUsRUFBRTVCLFlBRHNEO0FBRWxFNkIsSUFBQUEsUUFBUSxFQUFFLENBQUNkO0FBRnVELEdBQXRDLENBQWhDO0FBSUEsUUFBTWUsU0FBUyxHQUFHLENBQUNmLE1BQUQsSUFBV1csYUFBN0I7QUFDQSxNQUFJSyxZQUFKO0FBQ0EsTUFBSUMsVUFBSjtBQUNBLE1BQUlDLFFBQUo7QUFDQSxNQUFJQyxRQUFRLEdBQUc7QUFDWHhDLElBQUFBLFFBQVEsRUFBRSxVQURDO0FBRVh5QyxJQUFBQSxHQUFHLEVBQUUsQ0FGTTtBQUdYQyxJQUFBQSxJQUFJLEVBQUUsQ0FISztBQUlYQyxJQUFBQSxNQUFNLEVBQUUsQ0FKRztBQUtYQyxJQUFBQSxLQUFLLEVBQUUsQ0FMSTtBQU1YQyxJQUFBQSxTQUFTLEVBQUUsWUFOQTtBQU9YQyxJQUFBQSxPQUFPLEVBQUUsQ0FQRTtBQVFYQyxJQUFBQSxNQUFNLEVBQUUsTUFSRztBQVNYQyxJQUFBQSxNQUFNLEVBQUUsTUFURztBQVVYbkQsSUFBQUEsT0FBTyxFQUFFLE9BVkU7QUFXWHZELElBQUFBLEtBQUssRUFBRSxDQVhJO0FBWVhrRSxJQUFBQSxNQUFNLEVBQUUsQ0FaRztBQWFYeUMsSUFBQUEsUUFBUSxFQUFFLE1BYkM7QUFjWEMsSUFBQUEsUUFBUSxFQUFFLE1BZEM7QUFlWEMsSUFBQUEsU0FBUyxFQUFFLE1BZkE7QUFnQlhDLElBQUFBLFNBQVMsRUFBRSxNQWhCQTtBQWlCWDNDLElBQUFBLFNBakJXO0FBa0JYQyxJQUFBQTtBQWxCVyxHQUFmO0FBb0JBLFFBQU0yQyxTQUFTLEdBQUczRSxXQUFXLEtBQUssTUFBaEIsR0FBeUI7QUFDdkN0RixJQUFBQSxNQUFNLEVBQUUsWUFEK0I7QUFFdkNnRyxJQUFBQSxjQUFjLEVBQUVxQixTQUFTLElBQUksT0FGVTtBQUd2Q3BCLElBQUFBLGVBQWUsRUFBRyxRQUFPc0IsV0FBWSxJQUhFO0FBSXZDMkMsSUFBQUEsa0JBQWtCLEVBQUU1QyxjQUFjLElBQUk7QUFKQyxHQUF6QixHQUtkLEVBTEo7O0FBT0EsTUFBSW5FLE1BQU0sS0FBSyxNQUFmLEVBQXVCO0FBQ25CO0FBQ0E4RixJQUFBQSxZQUFZLEdBQUc7QUFDWHhDLE1BQUFBLE9BQU8sRUFBRSxPQURFO0FBRVgwRCxNQUFBQSxRQUFRLEVBQUUsUUFGQztBQUdYdkQsTUFBQUEsUUFBUSxFQUFFLFVBSEM7QUFJWHlDLE1BQUFBLEdBQUcsRUFBRSxDQUpNO0FBS1hDLE1BQUFBLElBQUksRUFBRSxDQUxLO0FBTVhDLE1BQUFBLE1BQU0sRUFBRSxDQU5HO0FBT1hDLE1BQUFBLEtBQUssRUFBRSxDQVBJO0FBUVhDLE1BQUFBLFNBQVMsRUFBRSxZQVJBO0FBU1hHLE1BQUFBLE1BQU0sRUFBRTtBQVRHLEtBQWY7QUFXSCxHQWJELE1BYU8sSUFBSSxPQUFPOUIsUUFBUCxLQUFvQixXQUFwQixJQUFtQyxPQUFPQyxTQUFQLEtBQXFCLFdBQTVELEVBQXlFO0FBQzVFO0FBQ0EsVUFBTXFDLFFBQVEsR0FBR3JDLFNBQVMsR0FBR0QsUUFBN0I7QUFDQSxVQUFNdUMsVUFBVSxHQUFHaEMsS0FBSyxDQUFDK0IsUUFBRCxDQUFMLEdBQWtCLE1BQWxCLEdBQTRCLEdBQUVBLFFBQVEsR0FBRyxHQUFJLEdBQWhFOztBQUNBLFFBQUlqSCxNQUFNLEtBQUssWUFBZixFQUE2QjtBQUN6QjtBQUNBOEYsTUFBQUEsWUFBWSxHQUFHO0FBQ1h4QyxRQUFBQSxPQUFPLEVBQUUsT0FERTtBQUVYMEQsUUFBQUEsUUFBUSxFQUFFLFFBRkM7QUFHWHZELFFBQUFBLFFBQVEsRUFBRSxVQUhDO0FBSVg2QyxRQUFBQSxTQUFTLEVBQUUsWUFKQTtBQUtYRyxRQUFBQSxNQUFNLEVBQUU7QUFMRyxPQUFmO0FBT0FWLE1BQUFBLFVBQVUsR0FBRztBQUNUekMsUUFBQUEsT0FBTyxFQUFFLE9BREE7QUFFVGdELFFBQUFBLFNBQVMsRUFBRSxZQUZGO0FBR1RZLFFBQUFBO0FBSFMsT0FBYjtBQUtILEtBZEQsTUFjTyxJQUFJbEgsTUFBTSxLQUFLLFdBQWYsRUFBNEI7QUFDL0I7QUFDQThGLE1BQUFBLFlBQVksR0FBRztBQUNYeEMsUUFBQUEsT0FBTyxFQUFFLGNBREU7QUFFWHFELFFBQUFBLFFBQVEsRUFBRSxNQUZDO0FBR1hLLFFBQUFBLFFBQVEsRUFBRSxRQUhDO0FBSVh2RCxRQUFBQSxRQUFRLEVBQUUsVUFKQztBQUtYNkMsUUFBQUEsU0FBUyxFQUFFLFlBTEE7QUFNWEcsUUFBQUEsTUFBTSxFQUFFO0FBTkcsT0FBZjtBQVFBVixNQUFBQSxVQUFVLEdBQUc7QUFDVE8sUUFBQUEsU0FBUyxFQUFFLFlBREY7QUFFVGhELFFBQUFBLE9BQU8sRUFBRSxPQUZBO0FBR1RxRCxRQUFBQSxRQUFRLEVBQUU7QUFIRCxPQUFiO0FBS0FYLE1BQUFBLFFBQVEsR0FBSSxlQUFjckIsUUFBUyxhQUFZQyxTQUFVLHNEQUF6RDtBQUNILEtBaEJNLE1BZ0JBLElBQUk1RSxNQUFNLEtBQUssT0FBZixFQUF3QjtBQUMzQjtBQUNBOEYsTUFBQUEsWUFBWSxHQUFHO0FBQ1hrQixRQUFBQSxRQUFRLEVBQUUsUUFEQztBQUVYVixRQUFBQSxTQUFTLEVBQUUsWUFGQTtBQUdYaEQsUUFBQUEsT0FBTyxFQUFFLGNBSEU7QUFJWEcsUUFBQUEsUUFBUSxFQUFFLFVBSkM7QUFLWDFELFFBQUFBLEtBQUssRUFBRTRFLFFBTEk7QUFNWFYsUUFBQUEsTUFBTSxFQUFFVztBQU5HLE9BQWY7QUFRSDtBQUNKLEdBN0NNLE1BNkNBO0FBQ0g7QUFDQSxjQUEyQztBQUN2QyxZQUFNLElBQUk3QyxLQUFKLENBQVcsbUJBQWtCdEQsR0FBSSx5RUFBakMsQ0FBTjtBQUNIO0FBQ0o7O0FBQ0QsTUFBSTBJLGFBQWEsR0FBRztBQUNoQjFJLElBQUFBLEdBQUcsRUFBRSxnRkFEVztBQUVoQjRDLElBQUFBLE1BQU0sRUFBRXRELFNBRlE7QUFHaEJrQyxJQUFBQSxLQUFLLEVBQUVsQztBQUhTLEdBQXBCOztBQUtBLE1BQUk4SCxTQUFKLEVBQWU7QUFDWHNCLElBQUFBLGFBQWEsR0FBR2pHLGdCQUFnQixDQUFDO0FBQzdCekMsTUFBQUEsR0FENkI7QUFFN0IwQyxNQUFBQSxXQUY2QjtBQUc3Qm5CLE1BQUFBLE1BSDZCO0FBSTdCRCxNQUFBQSxLQUFLLEVBQUU0RSxRQUpzQjtBQUs3QnZELE1BQUFBLE9BQU8sRUFBRXlELFVBTG9CO0FBTTdCNUUsTUFBQUEsS0FONkI7QUFPN0JqQixNQUFBQTtBQVA2QixLQUFELENBQWhDO0FBU0g7O0FBQ0QsTUFBSW9JLFNBQVMsR0FBRzNJLEdBQWhCO0FBQ0EsU0FBTyxhQUFjcEQsTUFBTSxDQUFDRixPQUFQLENBQWVrTSxhQUFmLENBQTZCLEtBQTdCLEVBQW9DO0FBQ3JEekUsSUFBQUEsS0FBSyxFQUFFa0Q7QUFEOEMsR0FBcEMsRUFFbEJDLFVBQVUsR0FBRyxhQUFjMUssTUFBTSxDQUFDRixPQUFQLENBQWVrTSxhQUFmLENBQTZCLEtBQTdCLEVBQW9DO0FBQzlEekUsSUFBQUEsS0FBSyxFQUFFbUQ7QUFEdUQsR0FBcEMsRUFFM0JDLFFBQVEsR0FBRyxhQUFjM0ssTUFBTSxDQUFDRixPQUFQLENBQWVrTSxhQUFmLENBQTZCLEtBQTdCLEVBQW9DO0FBQzVEekUsSUFBQUEsS0FBSyxFQUFFO0FBQ0grRCxNQUFBQSxRQUFRLEVBQUUsTUFEUDtBQUVIckQsTUFBQUEsT0FBTyxFQUFFLE9BRk47QUFHSG1ELE1BQUFBLE1BQU0sRUFBRSxDQUhMO0FBSUhELE1BQUFBLE1BQU0sRUFBRSxNQUpMO0FBS0hELE1BQUFBLE9BQU8sRUFBRTtBQUxOLEtBRHFEO0FBUTVEZSxJQUFBQSxHQUFHLEVBQUUsRUFSdUQ7QUFTNUQsbUJBQWUsSUFUNkM7QUFVNUQ3SSxJQUFBQSxHQUFHLEVBQUcsNkJBQTRCLENBQUMsR0FBR2hELFNBQUosRUFBZThMLFFBQWYsQ0FBd0J2QixRQUF4QixDQUFrQztBQVZSLEdBQXBDLENBQWpCLEdBV04sSUFieUIsQ0FBakIsR0FhQSxJQWZRLEVBZUYsYUFBYzNLLE1BQU0sQ0FBQ0YsT0FBUCxDQUFla00sYUFBZixDQUE2QixLQUE3QixFQUFvQ3RNLE1BQU0sQ0FBQ3lNLE1BQVAsQ0FBYyxFQUFkLEVBQ2xFbEQsSUFEa0UsRUFDNUQ2QyxhQUQ0RCxFQUM3QztBQUNwQk0sSUFBQUEsUUFBUSxFQUFFLE9BRFU7QUFFcEIsaUJBQWF6SCxNQUZPO0FBR3BCZ0UsSUFBQUEsU0FBUyxFQUFFQSxTQUhTO0FBSXBCZCxJQUFBQSxHQUFHLEVBQUdoQixHQUFELElBQU87QUFDUnNELE1BQUFBLE1BQU0sQ0FBQ3RELEdBQUQsQ0FBTjtBQUNBRCxNQUFBQSxhQUFhLENBQUNDLEdBQUQsRUFBTWtGLFNBQU4sRUFBaUJwSCxNQUFqQixFQUF5Qm1DLFdBQXpCLEVBQXNDQyxpQkFBdEMsQ0FBYjtBQUNILEtBUG1CO0FBUXBCUSxJQUFBQSxLQUFLLEVBQUV6RyxhQUFhLENBQUMsRUFBRCxFQUNqQjhKLFFBRGlCLEVBQ1BhLFNBRE87QUFSQSxHQUQ2QyxDQUFwQyxDQWZaLEVBMEJoQixhQUFjekwsTUFBTSxDQUFDRixPQUFQLENBQWVrTSxhQUFmLENBQTZCLFVBQTdCLEVBQXlDLElBQXpDLEVBQStDLGFBQWNoTSxNQUFNLENBQUNGLE9BQVAsQ0FBZWtNLGFBQWYsQ0FBNkIsS0FBN0IsRUFBb0N0TSxNQUFNLENBQUN5TSxNQUFQLENBQWMsRUFBZCxFQUNqSGxELElBRGlILEVBQzNHcEQsZ0JBQWdCLENBQUM7QUFDdEJ6QyxJQUFBQSxHQURzQjtBQUV0QjBDLElBQUFBLFdBRnNCO0FBR3RCbkIsSUFBQUEsTUFIc0I7QUFJdEJELElBQUFBLEtBQUssRUFBRTRFLFFBSmU7QUFLdEJ2RCxJQUFBQSxPQUFPLEVBQUV5RCxVQUxhO0FBTXRCNUUsSUFBQUEsS0FOc0I7QUFPdEJqQixJQUFBQTtBQVBzQixHQUFELENBRDJGLEVBU2hIO0FBQ0F5SSxJQUFBQSxRQUFRLEVBQUUsT0FEVjtBQUVBLGlCQUFhekgsTUFGYjtBQUdBNEMsSUFBQUEsS0FBSyxFQUFFcUQsUUFIUDtBQUlBakMsSUFBQUEsU0FBUyxFQUFFQSxTQUpYO0FBS0FGLElBQUFBLE9BQU8sRUFBRUEsT0FBTyxJQUFJO0FBTHBCLEdBVGdILENBQXBDLENBQTdELENBMUJFLEVBeUNmRCxRQUFRLEdBQUc7QUFDakI7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBY3hJLEVBQUFBLE1BQU0sQ0FBQ0YsT0FBUCxDQUFla00sYUFBZixDQUE2QjdMLEtBQUssQ0FBQ0wsT0FBbkMsRUFBNEMsSUFBNUMsRUFBa0QsYUFBY0UsTUFBTSxDQUFDRixPQUFQLENBQWVrTSxhQUFmLENBQTZCLE1BQTdCLEVBQXFDO0FBQy9HdkwsSUFBQUEsR0FBRyxFQUFFLFlBQVlxTCxhQUFhLENBQUMxSSxHQUExQixHQUFnQzBJLGFBQWEsQ0FBQzlGLE1BQTlDLEdBQXVEOEYsYUFBYSxDQUFDbEgsS0FEcUM7QUFFL0d5SCxJQUFBQSxHQUFHLEVBQUUsU0FGMEc7QUFHL0dDLElBQUFBLEVBQUUsRUFBRSxPQUgyRztBQUkvR0MsSUFBQUEsSUFBSSxFQUFFVCxhQUFhLENBQUM5RixNQUFkLEdBQXVCdEQsU0FBdkIsR0FBbUNvSixhQUFhLENBQUMxSSxHQUp3RDtBQUsvRztBQUNBb0osSUFBQUEsV0FBVyxFQUFFVixhQUFhLENBQUM5RixNQU5vRjtBQU8vRztBQUNBeUcsSUFBQUEsVUFBVSxFQUFFWCxhQUFhLENBQUNsSDtBQVJxRixHQUFyQyxDQUFoRSxDQUxBLEdBY1IsSUF2RGUsQ0FBckI7QUF3REg7O0FBQ0QsU0FBUzhILFlBQVQsQ0FBc0J0SixHQUF0QixFQUEyQjtBQUN2QixTQUFPQSxHQUFHLENBQUMsQ0FBRCxDQUFILEtBQVcsR0FBWCxHQUFpQkEsR0FBRyxDQUFDdUosS0FBSixDQUFVLENBQVYsQ0FBakIsR0FBZ0N2SixHQUF2QztBQUNIOztBQUNELFNBQVNOLFdBQVQsQ0FBcUI7QUFBRTJELEVBQUFBLElBQUY7QUFBU3JELEVBQUFBLEdBQVQ7QUFBZXNCLEVBQUFBLEtBQWY7QUFBdUJxQixFQUFBQTtBQUF2QixDQUFyQixFQUF3RDtBQUNwRDtBQUNBLFFBQU02RyxHQUFHLEdBQUcsSUFBSUMsR0FBSixDQUFTLEdBQUVwRyxJQUFLLEdBQUVpRyxZQUFZLENBQUN0SixHQUFELENBQU0sRUFBcEMsQ0FBWjtBQUNBLFFBQU0wSixNQUFNLEdBQUdGLEdBQUcsQ0FBQ0csWUFBbkI7QUFDQUQsRUFBQUEsTUFBTSxDQUFDRSxHQUFQLENBQVcsTUFBWCxFQUFtQkYsTUFBTSxDQUFDdEcsR0FBUCxDQUFXLE1BQVgsS0FBc0IsUUFBekM7QUFDQXNHLEVBQUFBLE1BQU0sQ0FBQ0UsR0FBUCxDQUFXLEtBQVgsRUFBa0JGLE1BQU0sQ0FBQ3RHLEdBQVAsQ0FBVyxLQUFYLEtBQXFCLEtBQXZDO0FBQ0FzRyxFQUFBQSxNQUFNLENBQUNFLEdBQVAsQ0FBVyxHQUFYLEVBQWdCRixNQUFNLENBQUN0RyxHQUFQLENBQVcsR0FBWCxLQUFtQjlCLEtBQUssQ0FBQ3dGLFFBQU4sRUFBbkM7O0FBQ0EsTUFBSW5FLE9BQUosRUFBYTtBQUNUK0csSUFBQUEsTUFBTSxDQUFDRSxHQUFQLENBQVcsR0FBWCxFQUFnQmpILE9BQU8sQ0FBQ21FLFFBQVIsRUFBaEI7QUFDSDs7QUFDRCxTQUFPMEMsR0FBRyxDQUFDTCxJQUFYO0FBQ0g7O0FBQ0QsU0FBU3ZKLFlBQVQsQ0FBc0I7QUFBRXlELEVBQUFBLElBQUY7QUFBU3JELEVBQUFBLEdBQVQ7QUFBZXNCLEVBQUFBO0FBQWYsQ0FBdEIsRUFBK0M7QUFDM0MsU0FBUSxHQUFFK0IsSUFBSyxHQUFFaUcsWUFBWSxDQUFDdEosR0FBRCxDQUFNLFlBQVdzQixLQUFNLEVBQXBEO0FBQ0g7O0FBQ0QsU0FBUzNCLGdCQUFULENBQTBCO0FBQUUwRCxFQUFBQSxJQUFGO0FBQVNyRCxFQUFBQSxHQUFUO0FBQWVzQixFQUFBQSxLQUFmO0FBQXVCcUIsRUFBQUE7QUFBdkIsQ0FBMUIsRUFBNkQ7QUFDekQ7QUFDQSxRQUFNK0csTUFBTSxHQUFHLENBQ1gsUUFEVyxFQUVYLFNBRlcsRUFHWCxPQUFPcEksS0FISSxFQUlYLFFBQVFxQixPQUFPLElBQUksTUFBbkIsQ0FKVyxDQUFmO0FBTUEsTUFBSWtILFlBQVksR0FBR0gsTUFBTSxDQUFDNUcsSUFBUCxDQUFZLEdBQVosSUFBbUIsR0FBdEM7QUFDQSxTQUFRLEdBQUVPLElBQUssR0FBRXdHLFlBQWEsR0FBRVAsWUFBWSxDQUFDdEosR0FBRCxDQUFNLEVBQWxEO0FBQ0g7O0FBQ0QsU0FBU0gsWUFBVCxDQUFzQjtBQUFFRyxFQUFBQTtBQUFGLENBQXRCLEVBQWdDO0FBQzVCLFFBQU0sSUFBSXNELEtBQUosQ0FBVyxtQkFBa0J0RCxHQUFJLDZCQUF2QixHQUF1RCx5RUFBakUsQ0FBTjtBQUNIOztBQUNELFNBQVNQLGFBQVQsQ0FBdUI7QUFBRTRELEVBQUFBLElBQUY7QUFBU3JELEVBQUFBLEdBQVQ7QUFBZXNCLEVBQUFBLEtBQWY7QUFBdUJxQixFQUFBQTtBQUF2QixDQUF2QixFQUEwRDtBQUN0RCxZQUEyQztBQUN2QyxVQUFNbUgsYUFBYSxHQUFHLEVBQXRCLENBRHVDLENBRXZDOztBQUNBLFFBQUksQ0FBQzlKLEdBQUwsRUFBVThKLGFBQWEsQ0FBQ2pJLElBQWQsQ0FBbUIsS0FBbkI7QUFDVixRQUFJLENBQUNQLEtBQUwsRUFBWXdJLGFBQWEsQ0FBQ2pJLElBQWQsQ0FBbUIsT0FBbkI7O0FBQ1osUUFBSWlJLGFBQWEsQ0FBQ2hNLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFDMUIsWUFBTSxJQUFJd0YsS0FBSixDQUFXLG9DQUFtQ3dHLGFBQWEsQ0FBQ2hILElBQWQsQ0FBbUIsSUFBbkIsQ0FBeUIsZ0dBQStGa0QsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkxqRyxRQUFBQSxHQUR1TDtBQUV2THNCLFFBQUFBLEtBRnVMO0FBR3ZMcUIsUUFBQUE7QUFIdUwsT0FBZixDQUl6SyxFQUpHLENBQU47QUFLSDs7QUFDRCxRQUFJM0MsR0FBRyxDQUFDNkQsVUFBSixDQUFlLElBQWYsQ0FBSixFQUEwQjtBQUN0QixZQUFNLElBQUlQLEtBQUosQ0FBVyx3QkFBdUJ0RCxHQUFJLDBHQUF0QyxDQUFOO0FBQ0g7O0FBQ0QsUUFBSSxDQUFDQSxHQUFHLENBQUM2RCxVQUFKLENBQWUsR0FBZixDQUFELElBQXdCakQsYUFBNUIsRUFBMkM7QUFDdkMsVUFBSW1KLFNBQUo7O0FBQ0EsVUFBSTtBQUNBQSxRQUFBQSxTQUFTLEdBQUcsSUFBSU4sR0FBSixDQUFRekosR0FBUixDQUFaO0FBQ0gsT0FGRCxDQUVFLE9BQU9nSyxHQUFQLEVBQVk7QUFDVmxGLFFBQUFBLE9BQU8sQ0FBQ21GLEtBQVIsQ0FBY0QsR0FBZDtBQUNBLGNBQU0sSUFBSTFHLEtBQUosQ0FBVyx3QkFBdUJ0RCxHQUFJLGlJQUF0QyxDQUFOO0FBQ0g7O0FBQ0QsVUFBSSxTQUFtQyxDQUFDWSxhQUFhLENBQUMyRixRQUFkLENBQXVCd0QsU0FBUyxDQUFDRyxRQUFqQyxDQUF4QyxFQUFvRjtBQUNoRixjQUFNLElBQUk1RyxLQUFKLENBQVcscUJBQW9CdEQsR0FBSSxrQ0FBaUMrSixTQUFTLENBQUNHLFFBQVMsK0RBQTdFLEdBQStJLDhFQUF6SixDQUFOO0FBQ0g7QUFDSjtBQUNKOztBQUNELFNBQVEsR0FBRTdHLElBQUssUUFBTzhHLGtCQUFrQixDQUFDbkssR0FBRCxDQUFNLE1BQUtzQixLQUFNLE1BQUtxQixPQUFPLElBQUksRUFBRyxFQUE1RTtBQUNIOzs7Ozs7Ozs7OztBQ2htQlk7O0FBQ2JyRyw4Q0FBNkM7QUFDekNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBRCxlQUFBLEdBQWtCLEtBQUssQ0FBdkI7O0FBQ0EsSUFBSUksTUFBTSxHQUFHQyxzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyxvQkFBRCxDQUFSLENBQW5DOztBQUNBLElBQUlzTixPQUFPLEdBQUd0TixtQkFBTyxDQUFDLHlGQUFELENBQXJCOztBQUNBLElBQUl1TixRQUFRLEdBQUd2TixtQkFBTyxDQUFDLDJEQUFELENBQXRCOztBQUNBLElBQUlJLGdCQUFnQixHQUFHSixtQkFBTyxDQUFDLCtFQUFELENBQTlCOztBQUNBLFNBQVNELHNCQUFULENBQWdDTyxHQUFoQyxFQUFxQztBQUNqQyxTQUFPQSxHQUFHLElBQUlBLEdBQUcsQ0FBQ0ssVUFBWCxHQUF3QkwsR0FBeEIsR0FBOEI7QUFDakNWLElBQUFBLE9BQU8sRUFBRVU7QUFEd0IsR0FBckM7QUFHSDs7QUFDRCxNQUFNa04sVUFBVSxHQUFHLEVBQW5COztBQUVBLFNBQVNDLFFBQVQsQ0FBa0JDLE1BQWxCLEVBQTBCckIsSUFBMUIsRUFBZ0NELEVBQWhDLEVBQW9DdUIsT0FBcEMsRUFBNkM7QUFDekMsTUFBSSxJQUFKLEVBQThDO0FBQzlDLE1BQUksQ0FBQyxDQUFDLEdBQUdMLE9BQUosRUFBYU0sVUFBYixDQUF3QnZCLElBQXhCLENBQUwsRUFBb0MsT0FGSyxDQUd6QztBQUNBO0FBQ0E7QUFDQTs7QUFDQXFCLEVBQUFBLE1BQU0sQ0FBQ0QsUUFBUCxDQUFnQnBCLElBQWhCLEVBQXNCRCxFQUF0QixFQUEwQnVCLE9BQTFCLEVBQW1DeEcsS0FBbkMsQ0FBMEMrRixHQUFELElBQU87QUFDNUMsY0FBMkM7QUFDdkM7QUFDQSxZQUFNQSxHQUFOO0FBQ0g7QUFDSixHQUxEO0FBTUEsUUFBTVcsU0FBUyxHQUFHRixPQUFPLElBQUksT0FBT0EsT0FBTyxDQUFDRyxNQUFmLEtBQTBCLFdBQXJDLEdBQW1ESCxPQUFPLENBQUNHLE1BQTNELEdBQW9FSixNQUFNLElBQUlBLE1BQU0sQ0FBQ0ksTUFBdkcsQ0FieUMsQ0FjekM7O0FBQ0FOLEVBQUFBLFVBQVUsQ0FBQ25CLElBQUksR0FBRyxHQUFQLEdBQWFELEVBQWIsSUFBbUJ5QixTQUFTLEdBQUcsTUFBTUEsU0FBVCxHQUFxQixFQUFqRCxDQUFELENBQVYsR0FBbUUsSUFBbkU7QUFDSDs7QUFDRCxTQUFTRSxlQUFULENBQXlCQyxLQUF6QixFQUFnQztBQUM1QixRQUFNO0FBQUVuTixJQUFBQTtBQUFGLE1BQWNtTixLQUFLLENBQUNDLGFBQTFCO0FBQ0EsU0FBT3BOLE1BQU0sSUFBSUEsTUFBTSxLQUFLLE9BQXJCLElBQWdDbU4sS0FBSyxDQUFDRSxPQUF0QyxJQUFpREYsS0FBSyxDQUFDRyxPQUF2RCxJQUFrRUgsS0FBSyxDQUFDSSxRQUF4RSxJQUFvRkosS0FBSyxDQUFDSyxNQUExRixJQUFvR0wsS0FBSyxDQUFDTSxXQUFOLElBQXFCTixLQUFLLENBQUNNLFdBQU4sQ0FBa0JDLEtBQWxCLEtBQTRCLENBQTVKO0FBQ0g7O0FBQ0QsU0FBU0MsV0FBVCxDQUFxQkMsQ0FBckIsRUFBd0JmLE1BQXhCLEVBQWdDckIsSUFBaEMsRUFBc0NELEVBQXRDLEVBQTBDc0MsT0FBMUMsRUFBbURDLE9BQW5ELEVBQTREQyxNQUE1RCxFQUFvRWQsTUFBcEUsRUFBNEU7QUFDeEUsUUFBTTtBQUFFZSxJQUFBQTtBQUFGLE1BQWdCSixDQUFDLENBQUNSLGFBQXhCOztBQUNBLE1BQUlZLFFBQVEsS0FBSyxHQUFiLEtBQXFCZCxlQUFlLENBQUNVLENBQUQsQ0FBZixJQUFzQixDQUFDLENBQUMsR0FBR25CLE9BQUosRUFBYU0sVUFBYixDQUF3QnZCLElBQXhCLENBQTVDLENBQUosRUFBZ0Y7QUFDNUU7QUFDQTtBQUNIOztBQUNEb0MsRUFBQUEsQ0FBQyxDQUFDSyxjQUFGLEdBTndFLENBT3hFOztBQUNBLE1BQUlGLE1BQU0sSUFBSSxJQUFWLElBQWtCeEMsRUFBRSxDQUFDdEssT0FBSCxDQUFXLEdBQVgsS0FBbUIsQ0FBekMsRUFBNEM7QUFDeEM4TSxJQUFBQSxNQUFNLEdBQUcsS0FBVDtBQUNILEdBVnVFLENBV3hFOzs7QUFDQWxCLEVBQUFBLE1BQU0sQ0FBQ2dCLE9BQU8sR0FBRyxTQUFILEdBQWUsTUFBdkIsQ0FBTixDQUFxQ3JDLElBQXJDLEVBQTJDRCxFQUEzQyxFQUErQztBQUMzQ3VDLElBQUFBLE9BRDJDO0FBRTNDYixJQUFBQSxNQUYyQztBQUczQ2MsSUFBQUE7QUFIMkMsR0FBL0M7QUFLSDs7QUFDRCxTQUFTRyxJQUFULENBQWNDLEtBQWQsRUFBcUI7QUFDakIsWUFBMkM7QUFDdkMsYUFBU0MsZUFBVCxDQUF5QkMsSUFBekIsRUFBK0I7QUFDM0IsYUFBTyxJQUFJMUksS0FBSixDQUFXLGdDQUErQjBJLElBQUksQ0FBQzNPLEdBQUksZ0JBQWUyTyxJQUFJLENBQUNDLFFBQVMsNkJBQTRCRCxJQUFJLENBQUNFLE1BQU8sYUFBOUcsSUFBOEgsU0FBZ0MsQ0FBaEMsR0FBcUcsRUFBbk8sQ0FBVixDQUFQO0FBQ0gsS0FIc0MsQ0FJdkM7OztBQUNBLFVBQU1DLGtCQUFrQixHQUFHO0FBQ3ZCaEQsTUFBQUEsSUFBSSxFQUFFO0FBRGlCLEtBQTNCO0FBR0EsVUFBTWlELGFBQWEsR0FBRzlQLE1BQU0sQ0FBQzJCLElBQVAsQ0FBWWtPLGtCQUFaLENBQXRCO0FBQ0FDLElBQUFBLGFBQWEsQ0FBQzdOLE9BQWQsQ0FBdUJsQixHQUFELElBQU87QUFDekIsVUFBSUEsR0FBRyxLQUFLLE1BQVosRUFBb0I7QUFDaEIsWUFBSXlPLEtBQUssQ0FBQ3pPLEdBQUQsQ0FBTCxJQUFjLElBQWQsSUFBc0IsT0FBT3lPLEtBQUssQ0FBQ3pPLEdBQUQsQ0FBWixLQUFzQixRQUF0QixJQUFrQyxPQUFPeU8sS0FBSyxDQUFDek8sR0FBRCxDQUFaLEtBQXNCLFFBQWxGLEVBQTRGO0FBQ3hGLGdCQUFNME8sZUFBZSxDQUFDO0FBQ2xCMU8sWUFBQUEsR0FEa0I7QUFFbEI0TyxZQUFBQSxRQUFRLEVBQUUsc0JBRlE7QUFHbEJDLFlBQUFBLE1BQU0sRUFBRUosS0FBSyxDQUFDek8sR0FBRCxDQUFMLEtBQWUsSUFBZixHQUFzQixNQUF0QixHQUErQixPQUFPeU8sS0FBSyxDQUFDek8sR0FBRDtBQUhqQyxXQUFELENBQXJCO0FBS0g7QUFDSixPQVJELE1BUU87QUFDSDtBQUNBO0FBQ0EsY0FBTWdQLENBQUMsR0FBR2hQLEdBQVY7QUFDSDtBQUNKLEtBZEQsRUFUdUMsQ0F3QnZDOztBQUNBLFVBQU1pUCxrQkFBa0IsR0FBRztBQUN2QnBELE1BQUFBLEVBQUUsRUFBRSxJQURtQjtBQUV2QnNDLE1BQUFBLE9BQU8sRUFBRSxJQUZjO0FBR3ZCRSxNQUFBQSxNQUFNLEVBQUUsSUFIZTtBQUl2QkQsTUFBQUEsT0FBTyxFQUFFLElBSmM7QUFLdkJjLE1BQUFBLFFBQVEsRUFBRSxJQUxhO0FBTXZCaEMsTUFBQUEsUUFBUSxFQUFFLElBTmE7QUFPdkJLLE1BQUFBLE1BQU0sRUFBRTtBQVBlLEtBQTNCO0FBU0EsVUFBTTRCLGFBQWEsR0FBR2xRLE1BQU0sQ0FBQzJCLElBQVAsQ0FBWXFPLGtCQUFaLENBQXRCO0FBQ0FFLElBQUFBLGFBQWEsQ0FBQ2pPLE9BQWQsQ0FBdUJsQixHQUFELElBQU87QUFDekIsWUFBTW9QLE9BQU8sR0FBRyxPQUFPWCxLQUFLLENBQUN6TyxHQUFELENBQTVCOztBQUNBLFVBQUlBLEdBQUcsS0FBSyxJQUFaLEVBQWtCO0FBQ2QsWUFBSXlPLEtBQUssQ0FBQ3pPLEdBQUQsQ0FBTCxJQUFjb1AsT0FBTyxLQUFLLFFBQTFCLElBQXNDQSxPQUFPLEtBQUssUUFBdEQsRUFBZ0U7QUFDNUQsZ0JBQU1WLGVBQWUsQ0FBQztBQUNsQjFPLFlBQUFBLEdBRGtCO0FBRWxCNE8sWUFBQUEsUUFBUSxFQUFFLHNCQUZRO0FBR2xCQyxZQUFBQSxNQUFNLEVBQUVPO0FBSFUsV0FBRCxDQUFyQjtBQUtIO0FBQ0osT0FSRCxNQVFPLElBQUlwUCxHQUFHLEtBQUssUUFBWixFQUFzQjtBQUN6QixZQUFJeU8sS0FBSyxDQUFDek8sR0FBRCxDQUFMLElBQWNvUCxPQUFPLEtBQUssUUFBOUIsRUFBd0M7QUFDcEMsZ0JBQU1WLGVBQWUsQ0FBQztBQUNsQjFPLFlBQUFBLEdBRGtCO0FBRWxCNE8sWUFBQUEsUUFBUSxFQUFFLFVBRlE7QUFHbEJDLFlBQUFBLE1BQU0sRUFBRU87QUFIVSxXQUFELENBQXJCO0FBS0g7QUFDSixPQVJNLE1BUUEsSUFBSXBQLEdBQUcsS0FBSyxTQUFSLElBQXFCQSxHQUFHLEtBQUssUUFBN0IsSUFBeUNBLEdBQUcsS0FBSyxTQUFqRCxJQUE4REEsR0FBRyxLQUFLLFVBQXRFLElBQW9GQSxHQUFHLEtBQUssVUFBaEcsRUFBNEc7QUFDL0csWUFBSXlPLEtBQUssQ0FBQ3pPLEdBQUQsQ0FBTCxJQUFjLElBQWQsSUFBc0JvUCxPQUFPLEtBQUssU0FBdEMsRUFBaUQ7QUFDN0MsZ0JBQU1WLGVBQWUsQ0FBQztBQUNsQjFPLFlBQUFBLEdBRGtCO0FBRWxCNE8sWUFBQUEsUUFBUSxFQUFFLFdBRlE7QUFHbEJDLFlBQUFBLE1BQU0sRUFBRU87QUFIVSxXQUFELENBQXJCO0FBS0g7QUFDSixPQVJNLE1BUUE7QUFDSDtBQUNBO0FBQ0EsY0FBTUosQ0FBQyxHQUFHaFAsR0FBVjtBQUNIO0FBQ0osS0EvQkQsRUFuQ3VDLENBbUV2QztBQUNBOztBQUNBLFVBQU1xUCxTQUFTLEdBQUc5UCxNQUFNLENBQUNGLE9BQVAsQ0FBZWlRLE1BQWYsQ0FBc0IsS0FBdEIsQ0FBbEI7O0FBQ0EsUUFBSWIsS0FBSyxDQUFDdkIsUUFBTixJQUFrQixDQUFDbUMsU0FBUyxDQUFDRSxPQUFqQyxFQUEwQztBQUN0Q0YsTUFBQUEsU0FBUyxDQUFDRSxPQUFWLEdBQW9CLElBQXBCO0FBQ0E5SCxNQUFBQSxPQUFPLENBQUNDLElBQVIsQ0FBYSxzS0FBYjtBQUNIO0FBQ0o7O0FBQ0QsUUFBTXZDLENBQUMsR0FBR3NKLEtBQUssQ0FBQ3ZCLFFBQU4sS0FBbUIsS0FBN0I7QUFDQSxRQUFNQyxNQUFNLEdBQUcsQ0FBQyxHQUFHSCxRQUFKLEVBQWN3QyxTQUFkLEVBQWY7O0FBQ0EsUUFBTTtBQUFFMUQsSUFBQUEsSUFBRjtBQUFTRCxJQUFBQTtBQUFULE1BQWlCdE0sTUFBTSxDQUFDRixPQUFQLENBQWVvUSxPQUFmLENBQXVCLE1BQUk7QUFDOUMsVUFBTSxDQUFDQyxZQUFELEVBQWVDLFVBQWYsSUFBNkIsQ0FBQyxHQUFHNUMsT0FBSixFQUFhNkMsV0FBYixDQUF5QnpDLE1BQXpCLEVBQWlDc0IsS0FBSyxDQUFDM0MsSUFBdkMsRUFBNkMsSUFBN0MsQ0FBbkM7QUFDQSxXQUFPO0FBQ0hBLE1BQUFBLElBQUksRUFBRTRELFlBREg7QUFFSDdELE1BQUFBLEVBQUUsRUFBRTRDLEtBQUssQ0FBQzVDLEVBQU4sR0FBVyxDQUFDLEdBQUdrQixPQUFKLEVBQWE2QyxXQUFiLENBQXlCekMsTUFBekIsRUFBaUNzQixLQUFLLENBQUM1QyxFQUF2QyxDQUFYLEdBQXdEOEQsVUFBVSxJQUFJRDtBQUZ2RSxLQUFQO0FBSUgsR0FOc0IsRUFNcEIsQ0FDQ3ZDLE1BREQsRUFFQ3NCLEtBQUssQ0FBQzNDLElBRlAsRUFHQzJDLEtBQUssQ0FBQzVDLEVBSFAsQ0FOb0IsQ0FBdkI7O0FBV0EsTUFBSTtBQUFFZ0UsSUFBQUEsUUFBRjtBQUFhMUIsSUFBQUEsT0FBYjtBQUF1QkMsSUFBQUEsT0FBdkI7QUFBaUNDLElBQUFBLE1BQWpDO0FBQTBDZCxJQUFBQTtBQUExQyxNQUFzRGtCLEtBQTFELENBekZpQixDQTBGakI7O0FBQ0EsTUFBSSxPQUFPb0IsUUFBUCxLQUFvQixRQUF4QixFQUFrQztBQUM5QkEsSUFBQUEsUUFBUSxHQUFHLGFBQWN0USxNQUFNLENBQUNGLE9BQVAsQ0FBZWtNLGFBQWYsQ0FBNkIsR0FBN0IsRUFBa0MsSUFBbEMsRUFBd0NzRSxRQUF4QyxDQUF6QjtBQUNILEdBN0ZnQixDQThGakI7OztBQUNBLE1BQUlDLEtBQUo7O0FBQ0EsWUFBNEM7QUFDeEMsUUFBSTtBQUNBQSxNQUFBQSxLQUFLLEdBQUd2USxNQUFNLENBQUNGLE9BQVAsQ0FBZTBRLFFBQWYsQ0FBd0JDLElBQXhCLENBQTZCSCxRQUE3QixDQUFSO0FBQ0gsS0FGRCxDQUVFLE9BQU9sRCxHQUFQLEVBQVk7QUFDVixZQUFNLElBQUkxRyxLQUFKLENBQVcsOERBQTZEd0ksS0FBSyxDQUFDM0MsSUFBSyw0RkFBekUsSUFBd0ssU0FBZ0MsQ0FBaEMsR0FBc0csRUFBOVEsQ0FBVixDQUFOO0FBQ0g7QUFDSixHQU5ELE1BTU8sRUFFTjs7QUFDRCxRQUFNbUUsUUFBUSxHQUFHSCxLQUFLLElBQUksT0FBT0EsS0FBUCxLQUFpQixRQUExQixJQUFzQ0EsS0FBSyxDQUFDMUksR0FBN0Q7QUFDQSxRQUFNLENBQUM4SSxrQkFBRCxFQUFxQm5HLFNBQXJCLElBQWtDLENBQUMsR0FBR2xLLGdCQUFKLEVBQXNCK0osZUFBdEIsQ0FBc0M7QUFDMUVDLElBQUFBLFVBQVUsRUFBRTtBQUQ4RCxHQUF0QyxDQUF4Qzs7QUFHQSxRQUFNSCxNQUFNLEdBQUduSyxNQUFNLENBQUNGLE9BQVAsQ0FBZThRLFdBQWYsQ0FBNEJDLEVBQUQsSUFBTTtBQUM1Q0YsSUFBQUEsa0JBQWtCLENBQUNFLEVBQUQsQ0FBbEI7O0FBQ0EsUUFBSUgsUUFBSixFQUFjO0FBQ1YsVUFBSSxPQUFPQSxRQUFQLEtBQW9CLFVBQXhCLEVBQW9DQSxRQUFRLENBQUNHLEVBQUQsQ0FBUixDQUFwQyxLQUNLLElBQUksT0FBT0gsUUFBUCxLQUFvQixRQUF4QixFQUFrQztBQUNuQ0EsUUFBQUEsUUFBUSxDQUFDVixPQUFULEdBQW1CYSxFQUFuQjtBQUNIO0FBQ0o7QUFDSixHQVJjLEVBUVosQ0FDQ0gsUUFERCxFQUVDQyxrQkFGRCxDQVJZLENBQWY7O0FBWUEzUSxFQUFBQSxNQUFNLENBQUNGLE9BQVAsQ0FBZWdSLFNBQWYsQ0FBeUIsTUFBSTtBQUN6QixVQUFNQyxjQUFjLEdBQUd2RyxTQUFTLElBQUk1RSxDQUFiLElBQWtCLENBQUMsR0FBRzRILE9BQUosRUFBYU0sVUFBYixDQUF3QnZCLElBQXhCLENBQXpDO0FBQ0EsVUFBTXdCLFNBQVMsR0FBRyxPQUFPQyxNQUFQLEtBQWtCLFdBQWxCLEdBQWdDQSxNQUFoQyxHQUF5Q0osTUFBTSxJQUFJQSxNQUFNLENBQUNJLE1BQTVFO0FBQ0EsVUFBTWdELFlBQVksR0FBR3RELFVBQVUsQ0FBQ25CLElBQUksR0FBRyxHQUFQLEdBQWFELEVBQWIsSUFBbUJ5QixTQUFTLEdBQUcsTUFBTUEsU0FBVCxHQUFxQixFQUFqRCxDQUFELENBQS9COztBQUNBLFFBQUlnRCxjQUFjLElBQUksQ0FBQ0MsWUFBdkIsRUFBcUM7QUFDakNyRCxNQUFBQSxRQUFRLENBQUNDLE1BQUQsRUFBU3JCLElBQVQsRUFBZUQsRUFBZixFQUFtQjtBQUN2QjBCLFFBQUFBLE1BQU0sRUFBRUQ7QUFEZSxPQUFuQixDQUFSO0FBR0g7QUFDSixHQVRELEVBU0csQ0FDQ3pCLEVBREQsRUFFQ0MsSUFGRCxFQUdDL0IsU0FIRCxFQUlDd0QsTUFKRCxFQUtDcEksQ0FMRCxFQU1DZ0ksTUFORCxDQVRIOztBQWlCQSxRQUFNcUQsVUFBVSxHQUFHO0FBQ2ZwSixJQUFBQSxHQUFHLEVBQUVzQyxNQURVO0FBRWYrRyxJQUFBQSxPQUFPLEVBQUd2QyxDQUFELElBQUs7QUFDVixVQUFJNEIsS0FBSyxDQUFDckIsS0FBTixJQUFlLE9BQU9xQixLQUFLLENBQUNyQixLQUFOLENBQVlnQyxPQUFuQixLQUErQixVQUFsRCxFQUE4RDtBQUMxRFgsUUFBQUEsS0FBSyxDQUFDckIsS0FBTixDQUFZZ0MsT0FBWixDQUFvQnZDLENBQXBCO0FBQ0g7O0FBQ0QsVUFBSSxDQUFDQSxDQUFDLENBQUN3QyxnQkFBUCxFQUF5QjtBQUNyQnpDLFFBQUFBLFdBQVcsQ0FBQ0MsQ0FBRCxFQUFJZixNQUFKLEVBQVlyQixJQUFaLEVBQWtCRCxFQUFsQixFQUFzQnNDLE9BQXRCLEVBQStCQyxPQUEvQixFQUF3Q0MsTUFBeEMsRUFBZ0RkLE1BQWhELENBQVg7QUFDSDtBQUNKO0FBVGMsR0FBbkI7O0FBV0FpRCxFQUFBQSxVQUFVLENBQUNHLFlBQVgsR0FBMkJ6QyxDQUFELElBQUs7QUFDM0IsUUFBSSxDQUFDLENBQUMsR0FBR25CLE9BQUosRUFBYU0sVUFBYixDQUF3QnZCLElBQXhCLENBQUwsRUFBb0M7O0FBQ3BDLFFBQUlnRSxLQUFLLENBQUNyQixLQUFOLElBQWUsT0FBT3FCLEtBQUssQ0FBQ3JCLEtBQU4sQ0FBWWtDLFlBQW5CLEtBQW9DLFVBQXZELEVBQW1FO0FBQy9EYixNQUFBQSxLQUFLLENBQUNyQixLQUFOLENBQVlrQyxZQUFaLENBQXlCekMsQ0FBekI7QUFDSDs7QUFDRGhCLElBQUFBLFFBQVEsQ0FBQ0MsTUFBRCxFQUFTckIsSUFBVCxFQUFlRCxFQUFmLEVBQW1CO0FBQ3ZCOUQsTUFBQUEsUUFBUSxFQUFFO0FBRGEsS0FBbkIsQ0FBUjtBQUdILEdBUkQsQ0FySmlCLENBOEpqQjtBQUNBOzs7QUFDQSxNQUFJMEcsS0FBSyxDQUFDUyxRQUFOLElBQWtCWSxLQUFLLENBQUNjLElBQU4sS0FBZSxHQUFmLElBQXNCLEVBQUUsVUFBVWQsS0FBSyxDQUFDckIsS0FBbEIsQ0FBNUMsRUFBc0U7QUFDbEUsVUFBTW5CLFNBQVMsR0FBRyxPQUFPQyxNQUFQLEtBQWtCLFdBQWxCLEdBQWdDQSxNQUFoQyxHQUF5Q0osTUFBTSxJQUFJQSxNQUFNLENBQUNJLE1BQTVFLENBRGtFLENBRWxFO0FBQ0E7O0FBQ0EsVUFBTXNELFlBQVksR0FBRzFELE1BQU0sSUFBSUEsTUFBTSxDQUFDMkQsY0FBakIsSUFBbUMsQ0FBQyxHQUFHL0QsT0FBSixFQUFhZ0UsZUFBYixDQUE2QmxGLEVBQTdCLEVBQWlDeUIsU0FBakMsRUFBNENILE1BQU0sSUFBSUEsTUFBTSxDQUFDNkQsT0FBN0QsRUFBc0U3RCxNQUFNLElBQUlBLE1BQU0sQ0FBQzhELGFBQXZGLENBQXhEO0FBQ0FULElBQUFBLFVBQVUsQ0FBQzFFLElBQVgsR0FBa0IrRSxZQUFZLElBQUksQ0FBQyxHQUFHOUQsT0FBSixFQUFhbUUsV0FBYixDQUF5QixDQUFDLEdBQUduRSxPQUFKLEVBQWFvRSxTQUFiLENBQXVCdEYsRUFBdkIsRUFBMkJ5QixTQUEzQixFQUFzQ0gsTUFBTSxJQUFJQSxNQUFNLENBQUNpRSxhQUF2RCxDQUF6QixDQUFsQztBQUNIOztBQUNELFNBQU8sYUFBYzdSLE1BQU0sQ0FBQ0YsT0FBUCxDQUFlZ1MsWUFBZixDQUE0QnZCLEtBQTVCLEVBQW1DVSxVQUFuQyxDQUFyQjtBQUNIOztBQUNELElBQUljLFFBQVEsR0FBRzlDLElBQWY7QUFDQXJQLGVBQUEsR0FBa0JtUyxRQUFsQjs7Ozs7Ozs7Ozs7QUNqT2E7O0FBQ2JyUyw4Q0FBNkM7QUFDekNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBRCwrQkFBQSxHQUFrQ29TLHVCQUFsQztBQUNBcFMsa0NBQUEsR0FBcUMsS0FBSyxDQUExQzs7QUFDQSxTQUFTb1MsdUJBQVQsQ0FBaUNuTyxJQUFqQyxFQUF1QztBQUNuQyxTQUFPQSxJQUFJLENBQUNxTyxRQUFMLENBQWMsR0FBZCxLQUFzQnJPLElBQUksS0FBSyxHQUEvQixHQUFxQ0EsSUFBSSxDQUFDOEksS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFDLENBQWYsQ0FBckMsR0FBeUQ5SSxJQUFoRTtBQUNIOztBQUNELE1BQU1vTywwQkFBMEIsR0FBR2hPLE1BQUEsR0FBcUNKLENBQXJDLEdBUS9CbU8sdUJBUko7QUFTQXBTLGtDQUFBLEdBQXFDcVMsMEJBQXJDOzs7Ozs7Ozs7OztBQ2xCYTs7QUFDYnZTLDhDQUE2QztBQUN6Q0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0FELDJCQUFBLEdBQThCQSwwQkFBQSxHQUE2QixLQUFLLENBQWhFOztBQUNBLE1BQU15UyxtQkFBbUIsR0FBRyxPQUFPRSxJQUFQLEtBQWdCLFdBQWhCLElBQStCQSxJQUFJLENBQUNGLG1CQUFwQyxJQUEyREUsSUFBSSxDQUFDRixtQkFBTCxDQUF5QkcsSUFBekIsQ0FBOEJDLE1BQTlCLENBQTNELElBQW9HLFVBQVNDLEVBQVQsRUFBYTtBQUN6SSxNQUFJQyxLQUFLLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxFQUFaO0FBQ0EsU0FBT0MsVUFBVSxDQUFDLFlBQVc7QUFDekJKLElBQUFBLEVBQUUsQ0FBQztBQUNDSyxNQUFBQSxVQUFVLEVBQUUsS0FEYjtBQUVDQyxNQUFBQSxhQUFhLEVBQUUsWUFBVztBQUN0QixlQUFPNU4sSUFBSSxDQUFDNk4sR0FBTCxDQUFTLENBQVQsRUFBWSxNQUFNTCxJQUFJLENBQUNDLEdBQUwsS0FBYUYsS0FBbkIsQ0FBWixDQUFQO0FBQ0g7QUFKRixLQUFELENBQUY7QUFNSCxHQVBnQixFQU9kLENBUGMsQ0FBakI7QUFRSCxDQVZEOztBQVdBL1MsMkJBQUEsR0FBOEJ5UyxtQkFBOUI7O0FBQ0EsTUFBTUMsa0JBQWtCLEdBQUcsT0FBT0MsSUFBUCxLQUFnQixXQUFoQixJQUErQkEsSUFBSSxDQUFDRCxrQkFBcEMsSUFBMERDLElBQUksQ0FBQ0Qsa0JBQUwsQ0FBd0JFLElBQXhCLENBQTZCQyxNQUE3QixDQUExRCxJQUFrRyxVQUFTUyxFQUFULEVBQWE7QUFDdEksU0FBT0MsWUFBWSxDQUFDRCxFQUFELENBQW5CO0FBQ0gsQ0FGRDs7QUFHQXRULDBCQUFBLEdBQTZCMFMsa0JBQTdCOzs7Ozs7Ozs7OztBQ3BCYTs7QUFDYjVTLDhDQUE2QztBQUN6Q0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0FELHNCQUFBLEdBQXlCd1QsY0FBekI7QUFDQXhULG9CQUFBLEdBQXVCeVQsWUFBdkI7QUFDQXpULDhCQUFBLEdBQWlDMFQsc0JBQWpDO0FBQ0ExVCx5QkFBQSxHQUE0QjJULGlCQUE1Qjs7QUFDQSxJQUFJQyxzQkFBc0IsR0FBR3ZULHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLGtIQUFELENBQVIsQ0FBbkQ7O0FBQ0EsSUFBSXVULG9CQUFvQixHQUFHdlQsbUJBQU8sQ0FBQyx5RkFBRCxDQUFsQzs7QUFDQSxTQUFTRCxzQkFBVCxDQUFnQ08sR0FBaEMsRUFBcUM7QUFDakMsU0FBT0EsR0FBRyxJQUFJQSxHQUFHLENBQUNLLFVBQVgsR0FBd0JMLEdBQXhCLEdBQThCO0FBQ2pDVixJQUFBQSxPQUFPLEVBQUVVO0FBRHdCLEdBQXJDO0FBR0gsRUFDRDtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTWtULGlCQUFpQixHQUFHLElBQTFCOztBQUNBLFNBQVNDLFVBQVQsQ0FBb0JsVCxHQUFwQixFQUF5QmdGLEdBQXpCLEVBQThCbU8sU0FBOUIsRUFBeUM7QUFDckMsTUFBSUMsS0FBSyxHQUFHcE8sR0FBRyxDQUFDZSxHQUFKLENBQVEvRixHQUFSLENBQVo7O0FBQ0EsTUFBSW9ULEtBQUosRUFBVztBQUNQLFFBQUksWUFBWUEsS0FBaEIsRUFBdUI7QUFDbkIsYUFBT0EsS0FBSyxDQUFDQyxNQUFiO0FBQ0g7O0FBQ0QsV0FBTzNNLE9BQU8sQ0FBQ0MsT0FBUixDQUFnQnlNLEtBQWhCLENBQVA7QUFDSDs7QUFDRCxNQUFJRSxRQUFKO0FBQ0EsUUFBTUMsSUFBSSxHQUFHLElBQUk3TSxPQUFKLENBQWFDLE9BQUQsSUFBVztBQUNoQzJNLElBQUFBLFFBQVEsR0FBRzNNLE9BQVg7QUFDSCxHQUZZLENBQWI7QUFHQTNCLEVBQUFBLEdBQUcsQ0FBQ3VILEdBQUosQ0FBUXZNLEdBQVIsRUFBYW9ULEtBQUssR0FBRztBQUNqQnpNLElBQUFBLE9BQU8sRUFBRTJNLFFBRFE7QUFFakJELElBQUFBLE1BQU0sRUFBRUU7QUFGUyxHQUFyQjtBQUlBLFNBQU9KLFNBQVMsR0FBR0EsU0FBUyxHQUFHdE0sSUFBWixDQUFrQnpILEtBQUQsS0FBVWtVLFFBQVEsQ0FBQ2xVLEtBQUQsQ0FBUixFQUFpQkEsS0FBM0IsQ0FBakIsQ0FBSCxHQUNabVUsSUFESjtBQUVIOztBQUNELFNBQVNDLFdBQVQsQ0FBcUJDLElBQXJCLEVBQTJCO0FBQ3ZCLE1BQUk7QUFDQUEsSUFBQUEsSUFBSSxHQUFHQyxRQUFRLENBQUNuSSxhQUFULENBQXVCLE1BQXZCLENBQVA7QUFDQSxXQUFPO0FBQ1A7QUFDQyxPQUFDLENBQUN5RyxNQUFNLENBQUMyQixvQkFBVCxJQUFpQyxDQUFDLENBQUNELFFBQVEsQ0FBQ0UsWUFBN0MsSUFBOERILElBQUksQ0FBQ0ksT0FBTCxDQUFhQyxRQUFiLENBQXNCLFVBQXRCO0FBRjlEO0FBR0gsR0FMRCxDQUtFLE9BQU81RixDQUFQLEVBQVU7QUFDUixXQUFPLEtBQVA7QUFDSDtBQUNKOztBQUNELE1BQU02RixXQUFXLEdBQUdQLFdBQVcsRUFBL0I7O0FBQ0EsU0FBU1EsY0FBVCxDQUF3QmxJLElBQXhCLEVBQThCRCxFQUE5QixFQUFrQzRILElBQWxDLEVBQXdDO0FBQ3BDLFNBQU8sSUFBSS9NLE9BQUosQ0FBWSxDQUFDdU4sR0FBRCxFQUFNQyxHQUFOLEtBQVk7QUFDM0IsUUFBSVIsUUFBUSxDQUFDUyxhQUFULENBQXdCLCtCQUE4QnJJLElBQUssSUFBM0QsQ0FBSixFQUFxRTtBQUNqRSxhQUFPbUksR0FBRyxFQUFWO0FBQ0g7O0FBQ0RSLElBQUFBLElBQUksR0FBR0MsUUFBUSxDQUFDbkksYUFBVCxDQUF1QixNQUF2QixDQUFQLENBSjJCLENBSzNCOztBQUNBLFFBQUlNLEVBQUosRUFBUTRILElBQUksQ0FBQzVILEVBQUwsR0FBVUEsRUFBVjtBQUNSNEgsSUFBQUEsSUFBSSxDQUFDN0gsR0FBTCxHQUFZLFVBQVo7QUFDQTZILElBQUFBLElBQUksQ0FBQ1csV0FBTCxHQUFtQjVRLFNBQW5CO0FBQ0FpUSxJQUFBQSxJQUFJLENBQUM1TCxNQUFMLEdBQWNvTSxHQUFkO0FBQ0FSLElBQUFBLElBQUksQ0FBQ2EsT0FBTCxHQUFlSixHQUFmLENBVjJCLENBVzNCOztBQUNBVCxJQUFBQSxJQUFJLENBQUMzSCxJQUFMLEdBQVlBLElBQVo7QUFDQTRILElBQUFBLFFBQVEsQ0FBQ2EsSUFBVCxDQUFjQyxXQUFkLENBQTBCZixJQUExQjtBQUNILEdBZE0sQ0FBUDtBQWVIOztBQUNELE1BQU1nQixnQkFBZ0IsR0FBR0MsTUFBTSxDQUFDLGtCQUFELENBQS9COztBQUNBLFNBQVMvQixjQUFULENBQXdCaEcsR0FBeEIsRUFBNkI7QUFDekIsU0FBTzFOLE1BQU0sQ0FBQ0MsY0FBUCxDQUFzQnlOLEdBQXRCLEVBQTJCOEgsZ0JBQTNCLEVBQTZDLEVBQTdDLENBQVA7QUFFSDs7QUFDRCxTQUFTN0IsWUFBVCxDQUFzQmpHLEdBQXRCLEVBQTJCO0FBQ3ZCLFNBQU9BLEdBQUcsSUFBSThILGdCQUFnQixJQUFJOUgsR0FBbEM7QUFDSDs7QUFDRCxTQUFTZ0ksWUFBVCxDQUFzQmhTLEdBQXRCLEVBQTJCaVMsTUFBM0IsRUFBbUM7QUFDL0IsU0FBTyxJQUFJbE8sT0FBSixDQUFZLENBQUNDLE9BQUQsRUFBVWtPLE1BQVYsS0FBbUI7QUFDbENELElBQUFBLE1BQU0sR0FBR2xCLFFBQVEsQ0FBQ25JLGFBQVQsQ0FBdUIsUUFBdkIsQ0FBVCxDQURrQyxDQUVsQztBQUNBO0FBQ0E7O0FBQ0FxSixJQUFBQSxNQUFNLENBQUMvTSxNQUFQLEdBQWdCbEIsT0FBaEI7O0FBQ0FpTyxJQUFBQSxNQUFNLENBQUNOLE9BQVAsR0FBaUIsTUFBSU8sTUFBTSxDQUFDbEMsY0FBYyxDQUFDLElBQUkxTSxLQUFKLENBQVcsMEJBQXlCdEQsR0FBSSxFQUF4QyxDQUFELENBQWYsQ0FBM0IsQ0FOa0MsQ0FRbEM7QUFDQTs7O0FBQ0FpUyxJQUFBQSxNQUFNLENBQUNSLFdBQVAsR0FBcUI1USxTQUFyQixDQVZrQyxDQVdsQztBQUNBOztBQUNBb1IsSUFBQUEsTUFBTSxDQUFDalMsR0FBUCxHQUFhQSxHQUFiO0FBQ0ErUSxJQUFBQSxRQUFRLENBQUNvQixJQUFULENBQWNOLFdBQWQsQ0FBMEJJLE1BQTFCO0FBQ0gsR0FmTSxDQUFQO0FBZ0JILEVBQ0Q7QUFDQTs7O0FBQ0EsSUFBSUcsZUFBSixFQUNBOztBQUNBLFNBQVNDLHlCQUFULENBQW1DN1AsQ0FBbkMsRUFBc0M4UCxFQUF0QyxFQUEwQ3RJLEdBQTFDLEVBQStDO0FBQzNDLFNBQU8sSUFBSWpHLE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVVrTyxNQUFWLEtBQW1CO0FBQ2xDLFFBQUlLLFNBQVMsR0FBRyxLQUFoQjtBQUNBL1AsSUFBQUEsQ0FBQyxDQUFDMEIsSUFBRixDQUFRc08sQ0FBRCxJQUFLO0FBQ1I7QUFDQUQsTUFBQUEsU0FBUyxHQUFHLElBQVo7QUFDQXZPLE1BQUFBLE9BQU8sQ0FBQ3dPLENBQUQsQ0FBUDtBQUNILEtBSkQsRUFJR3ZPLEtBSkgsQ0FJU2lPLE1BSlQsRUFGa0MsQ0FPbEM7QUFDQTs7QUFDQSxjQUE0QztBQUN4QyxPQUFDRSxlQUFlLElBQUlyTyxPQUFPLENBQUNDLE9BQVIsRUFBcEIsRUFBdUNFLElBQXZDLENBQTRDLE1BQUk7QUFDNUMsU0FBQyxHQUFHbU0sb0JBQUosRUFBMEJwQixtQkFBMUIsQ0FBOEMsTUFBSVMsVUFBVSxDQUFDLE1BQUk7QUFDekQsY0FBSSxDQUFDNkMsU0FBTCxFQUFnQjtBQUNaTCxZQUFBQSxNQUFNLENBQUNsSSxHQUFELENBQU47QUFDSDtBQUNKLFNBSnVELEVBSXJEc0ksRUFKcUQsQ0FBNUQ7QUFNSCxPQVBEO0FBUUg7O0FBQ0QsZUFBNEMsRUFPM0M7QUFDSixHQTNCTSxDQUFQO0FBNEJIOztBQUNELFNBQVNwQyxzQkFBVCxHQUFrQztBQUM5QixNQUFJZixJQUFJLENBQUNzRCxnQkFBVCxFQUEyQjtBQUN2QixXQUFPMU8sT0FBTyxDQUFDQyxPQUFSLENBQWdCbUwsSUFBSSxDQUFDc0QsZ0JBQXJCLENBQVA7QUFDSDs7QUFDRCxRQUFNQyxlQUFlLEdBQUcsSUFBSTNPLE9BQUosQ0FBYUMsT0FBRCxJQUFXO0FBQzNDO0FBQ0EsVUFBTXNMLEVBQUUsR0FBR0gsSUFBSSxDQUFDd0QsbUJBQWhCOztBQUNBeEQsSUFBQUEsSUFBSSxDQUFDd0QsbUJBQUwsR0FBMkIsTUFBSTtBQUMzQjNPLE1BQUFBLE9BQU8sQ0FBQ21MLElBQUksQ0FBQ3NELGdCQUFOLENBQVA7QUFDQW5ELE1BQUFBLEVBQUUsSUFBSUEsRUFBRSxFQUFSO0FBQ0gsS0FIRDtBQUlILEdBUHVCLENBQXhCO0FBUUEsU0FBTytDLHlCQUF5QixDQUFDSyxlQUFELEVBQWtCcEMsaUJBQWxCLEVBQXFDTixjQUFjLENBQUMsSUFBSTFNLEtBQUosQ0FBVSxzQ0FBVixDQUFELENBQW5ELENBQWhDO0FBQ0g7O0FBQ0QsU0FBU3NQLGdCQUFULENBQTBCQyxXQUExQixFQUF1Q0MsS0FBdkMsRUFBOEM7QUFDMUMsWUFBNEM7QUFDeEMsV0FBTy9PLE9BQU8sQ0FBQ0MsT0FBUixDQUFnQjtBQUNuQitPLE1BQUFBLE9BQU8sRUFBRSxDQUNMRixXQUFXLEdBQUcsNEJBQWQsR0FBNkNHLFNBQVMsQ0FBQyxDQUFDLEdBQUc1QyxzQkFBSixFQUE0QjFULE9BQTVCLENBQW9Db1csS0FBcEMsRUFBMkMsS0FBM0MsQ0FBRCxDQURqRCxDQURVO0FBSW5CO0FBQ0FHLE1BQUFBLEdBQUcsRUFBRTtBQUxjLEtBQWhCLENBQVA7QUFPSDs7QUFDRCxTQUFPL0Msc0JBQXNCLEdBQUdoTSxJQUF6QixDQUErQmdQLFFBQUQsSUFBWTtBQUM3QyxRQUFJLEVBQUVKLEtBQUssSUFBSUksUUFBWCxDQUFKLEVBQTBCO0FBQ3RCLFlBQU1sRCxjQUFjLENBQUMsSUFBSTFNLEtBQUosQ0FBVywyQkFBMEJ3UCxLQUFNLEVBQTNDLENBQUQsQ0FBcEI7QUFDSDs7QUFDRCxVQUFNSyxRQUFRLEdBQUdELFFBQVEsQ0FBQ0osS0FBRCxDQUFSLENBQWdCelEsR0FBaEIsQ0FBcUJvTyxLQUFELElBQVNvQyxXQUFXLEdBQUcsU0FBZCxHQUEwQkcsU0FBUyxDQUFDdkMsS0FBRCxDQUFoRSxDQUFqQjtBQUVBLFdBQU87QUFDSHNDLE1BQUFBLE9BQU8sRUFBRUksUUFBUSxDQUFDL1UsTUFBVCxDQUFpQmdWLENBQUQsSUFBS0EsQ0FBQyxDQUFDdEUsUUFBRixDQUFXLEtBQVgsQ0FBckIsQ0FETjtBQUdIbUUsTUFBQUEsR0FBRyxFQUFFRSxRQUFRLENBQUMvVSxNQUFULENBQWlCZ1YsQ0FBRCxJQUFLQSxDQUFDLENBQUN0RSxRQUFGLENBQVcsTUFBWCxDQUFyQjtBQUhGLEtBQVA7QUFNSCxHQVpNLENBQVA7QUFhSDs7QUFDRCxTQUFTcUIsaUJBQVQsQ0FBMkIwQyxXQUEzQixFQUF3QztBQUNwQyxRQUFNUSxXQUFXLEdBQUcsSUFBSTdULEdBQUosRUFBcEI7QUFDQSxRQUFNOFQsYUFBYSxHQUFHLElBQUk5VCxHQUFKLEVBQXRCO0FBQ0EsUUFBTStULFdBQVcsR0FBRyxJQUFJL1QsR0FBSixFQUFwQjtBQUNBLFFBQU1nVSxNQUFNLEdBQUcsSUFBSWhVLEdBQUosRUFBZjs7QUFDQSxXQUFTaVUsa0JBQVQsQ0FBNEJ6VCxHQUE1QixFQUFpQztBQUM3QixRQUFJNFEsSUFBSSxHQUFHMEMsYUFBYSxDQUFDbFEsR0FBZCxDQUFrQnBELEdBQWxCLENBQVg7O0FBQ0EsUUFBSTRRLElBQUosRUFBVTtBQUNOLGFBQU9BLElBQVA7QUFDSCxLQUo0QixDQUs3Qjs7O0FBQ0EsUUFBSUcsUUFBUSxDQUFDUyxhQUFULENBQXdCLGdCQUFleFIsR0FBSSxJQUEzQyxDQUFKLEVBQXFEO0FBQ2pELGFBQU8rRCxPQUFPLENBQUNDLE9BQVIsRUFBUDtBQUNIOztBQUNEc1AsSUFBQUEsYUFBYSxDQUFDMUosR0FBZCxDQUFrQjVKLEdBQWxCLEVBQXVCNFEsSUFBSSxHQUFHb0IsWUFBWSxDQUFDaFMsR0FBRCxDQUExQztBQUNBLFdBQU80USxJQUFQO0FBQ0g7O0FBQ0QsV0FBUzhDLGVBQVQsQ0FBeUJ2SyxJQUF6QixFQUErQjtBQUMzQixRQUFJeUgsSUFBSSxHQUFHMkMsV0FBVyxDQUFDblEsR0FBWixDQUFnQitGLElBQWhCLENBQVg7O0FBQ0EsUUFBSXlILElBQUosRUFBVTtBQUNOLGFBQU9BLElBQVA7QUFDSDs7QUFDRDJDLElBQUFBLFdBQVcsQ0FBQzNKLEdBQVosQ0FBZ0JULElBQWhCLEVBQXNCeUgsSUFBSSxHQUFHK0MsS0FBSyxDQUFDeEssSUFBRCxDQUFMLENBQVlqRixJQUFaLENBQWtCb04sR0FBRCxJQUFPO0FBQ2pELFVBQUksQ0FBQ0EsR0FBRyxDQUFDc0MsRUFBVCxFQUFhO0FBQ1QsY0FBTSxJQUFJdFEsS0FBSixDQUFXLDhCQUE2QjZGLElBQUssRUFBN0MsQ0FBTjtBQUNIOztBQUNELGFBQU9tSSxHQUFHLENBQUN1QyxJQUFKLEdBQVczUCxJQUFYLENBQWlCMlAsSUFBRCxLQUFTO0FBQ3hCMUssUUFBQUEsSUFBSSxFQUFFQSxJQURrQjtBQUV4QjJLLFFBQUFBLE9BQU8sRUFBRUQ7QUFGZSxPQUFULENBQWhCLENBQVA7QUFLSCxLQVQ0QixFQVMxQjVQLEtBVDBCLENBU25CK0YsR0FBRCxJQUFPO0FBQ1osWUFBTWdHLGNBQWMsQ0FBQ2hHLEdBQUQsQ0FBcEI7QUFDSCxLQVg0QixDQUE3QjtBQVlBLFdBQU80RyxJQUFQO0FBQ0g7O0FBQ0QsU0FBTztBQUNIbUQsSUFBQUEsY0FBYyxDQUFFakIsS0FBRixFQUFTO0FBQ25CLGFBQU92QyxVQUFVLENBQUN1QyxLQUFELEVBQVFPLFdBQVIsQ0FBakI7QUFDSCxLQUhFOztBQUlIVyxJQUFBQSxZQUFZLENBQUVsQixLQUFGLEVBQVNtQixPQUFULEVBQWtCO0FBQzFCbFEsTUFBQUEsT0FBTyxDQUFDQyxPQUFSLENBQWdCaVEsT0FBaEIsRUFBeUIvUCxJQUF6QixDQUErQmdRLEVBQUQsSUFBTUEsRUFBRSxFQUF0QyxFQUNFaFEsSUFERixDQUNRMUgsT0FBRCxLQUFZO0FBQ1gyWCxRQUFBQSxTQUFTLEVBQUUzWCxPQUFPLElBQUlBLE9BQU8sQ0FBQ0UsT0FBbkIsSUFBOEJGLE9BRDlCO0FBRVhBLFFBQUFBLE9BQU8sRUFBRUE7QUFGRSxPQUFaLENBRFAsRUFLR3dOLEdBQUQsS0FBUTtBQUNGQyxRQUFBQSxLQUFLLEVBQUVEO0FBREwsT0FBUixDQUxGLEVBUUU5RixJQVJGLENBUVFrUSxLQUFELElBQVM7QUFDWixjQUFNQyxHQUFHLEdBQUdoQixXQUFXLENBQUNqUSxHQUFaLENBQWdCMFAsS0FBaEIsQ0FBWjtBQUNBTyxRQUFBQSxXQUFXLENBQUN6SixHQUFaLENBQWdCa0osS0FBaEIsRUFBdUJzQixLQUF2QjtBQUNBLFlBQUlDLEdBQUcsSUFBSSxhQUFhQSxHQUF4QixFQUE2QkEsR0FBRyxDQUFDclEsT0FBSixDQUFZb1EsS0FBWjtBQUNoQyxPQVpEO0FBYUgsS0FsQkU7O0FBbUJIRSxJQUFBQSxTQUFTLENBQUV4QixLQUFGLEVBQVN2SSxRQUFULEVBQW1CO0FBQ3hCLGFBQU9nRyxVQUFVLENBQUN1QyxLQUFELEVBQVFVLE1BQVIsRUFBZ0IsTUFBSTtBQUNqQyxjQUFNZSxpQkFBaUIsR0FBRzNCLGdCQUFnQixDQUFDQyxXQUFELEVBQWNDLEtBQWQsQ0FBaEIsQ0FBcUM1TyxJQUFyQyxDQUEwQyxDQUFDO0FBQUU2TyxVQUFBQSxPQUFGO0FBQVlFLFVBQUFBO0FBQVosU0FBRCxLQUFzQjtBQUN0RixpQkFBT2xQLE9BQU8sQ0FBQzZCLEdBQVIsQ0FBWSxDQUNmeU4sV0FBVyxDQUFDL00sR0FBWixDQUFnQndNLEtBQWhCLElBQXlCLEVBQXpCLEdBQThCL08sT0FBTyxDQUFDNkIsR0FBUixDQUFZbU4sT0FBTyxDQUFDMVEsR0FBUixDQUFZb1Isa0JBQVosQ0FBWixDQURmLEVBRWYxUCxPQUFPLENBQUM2QixHQUFSLENBQVlxTixHQUFHLENBQUM1USxHQUFKLENBQVFxUixlQUFSLENBQVosQ0FGZSxDQUFaLENBQVA7QUFJSCxTQUx5QixFQUt2QnhQLElBTHVCLENBS2pCb04sR0FBRCxJQUFPO0FBQ1gsaUJBQU8sS0FBS3lDLGNBQUwsQ0FBb0JqQixLQUFwQixFQUEyQjVPLElBQTNCLENBQWlDc1EsVUFBRCxLQUFlO0FBQzlDQSxZQUFBQSxVQUQ4QztBQUU5Q0MsWUFBQUEsTUFBTSxFQUFFbkQsR0FBRyxDQUFDLENBQUQ7QUFGbUMsV0FBZixDQUFoQyxDQUFQO0FBS0gsU0FYeUIsQ0FBMUI7O0FBWUEsa0JBQTRDO0FBQ3hDYyxVQUFBQSxlQUFlLEdBQUcsSUFBSXJPLE9BQUosQ0FBYUMsT0FBRCxJQUFXO0FBQ3JDLGdCQUFJdVEsaUJBQUosRUFBdUI7QUFDbkIscUJBQU9BLGlCQUFpQixDQUFDRyxPQUFsQixDQUEwQixNQUFJO0FBQ2pDMVEsZ0JBQUFBLE9BQU87QUFDVixlQUZNLENBQVA7QUFHSDtBQUNKLFdBTmlCLENBQWxCO0FBT0g7O0FBQ0QsZUFBT3FPLHlCQUF5QixDQUFDa0MsaUJBQUQsRUFBb0JqRSxpQkFBcEIsRUFBdUNOLGNBQWMsQ0FBQyxJQUFJMU0sS0FBSixDQUFXLG1DQUFrQ3dQLEtBQU0sRUFBbkQsQ0FBRCxDQUFyRCxDQUF6QixDQUF1STVPLElBQXZJLENBQTRJLENBQUM7QUFBRXNRLFVBQUFBLFVBQUY7QUFBZUMsVUFBQUE7QUFBZixTQUFELEtBQTRCO0FBQzNLLGdCQUFNbkQsR0FBRyxHQUFHaFYsTUFBTSxDQUFDeU0sTUFBUCxDQUFjO0FBQ3RCMEwsWUFBQUEsTUFBTSxFQUFFQTtBQURjLFdBQWQsRUFFVEQsVUFGUyxDQUFaO0FBR0EsaUJBQU8sV0FBV0EsVUFBWCxHQUF3QkEsVUFBeEIsR0FBcUNsRCxHQUE1QztBQUNILFNBTE0sRUFLSnJOLEtBTEksQ0FLRytGLEdBQUQsSUFBTztBQUNaLGNBQUlPLFFBQUosRUFBYztBQUNWO0FBQ0Esa0JBQU1QLEdBQU47QUFDSDs7QUFDRCxpQkFBTztBQUNIQyxZQUFBQSxLQUFLLEVBQUVEO0FBREosV0FBUDtBQUdILFNBYk0sQ0FBUDtBQWNILE9BcENnQixDQUFqQjtBQXFDSCxLQXpERTs7QUEwREhPLElBQUFBLFFBQVEsQ0FBRXVJLEtBQUYsRUFBUztBQUNiO0FBQ0E7QUFDQSxVQUFJNkIsRUFBSjs7QUFDQSxVQUFJQSxFQUFFLEdBQUdDLFNBQVMsQ0FBQ0MsVUFBbkIsRUFBK0I7QUFDM0I7QUFDQSxZQUFJRixFQUFFLENBQUNHLFFBQUgsSUFBZSxLQUFLOUYsSUFBTCxDQUFVMkYsRUFBRSxDQUFDSSxhQUFiLENBQW5CLEVBQWdELE9BQU9oUixPQUFPLENBQUNDLE9BQVIsRUFBUDtBQUNuRDs7QUFDRCxhQUFPNE8sZ0JBQWdCLENBQUNDLFdBQUQsRUFBY0MsS0FBZCxDQUFoQixDQUFxQzVPLElBQXJDLENBQTJDOFEsTUFBRCxJQUFValIsT0FBTyxDQUFDNkIsR0FBUixDQUFZd0wsV0FBVyxHQUFHNEQsTUFBTSxDQUFDakMsT0FBUCxDQUFlMVEsR0FBZixDQUFvQjRQLE1BQUQsSUFBVVosY0FBYyxDQUFDWSxNQUFELEVBQVMsUUFBVCxDQUEzQyxDQUFILEdBQzFFLEVBRG1ELENBQXBELEVBRUwvTixJQUZLLENBRUEsTUFBSTtBQUNQLFNBQUMsR0FBR21NLG9CQUFKLEVBQTBCcEIsbUJBQTFCLENBQThDLE1BQUksS0FBS3FGLFNBQUwsQ0FBZXhCLEtBQWYsRUFBc0IsSUFBdEIsRUFBNEI3TyxLQUE1QixDQUFrQyxNQUFJLENBQ25GLENBRDZDLENBQWxEO0FBR0gsT0FOTSxFQU1KQSxLQU5JLEVBTUU7QUFDVCxZQUFJLENBQ0gsQ0FSTSxDQUFQO0FBU0g7O0FBM0VFLEdBQVA7QUE2RUg7Ozs7Ozs7Ozs7O0FDdFJZOztBQUNiM0gsOENBQTZDO0FBQ3pDRyxFQUFBQSxLQUFLLEVBQUU7QUFEa0MsQ0FBN0M7QUFHQUgsMENBQXlDO0FBQ3JDZ0IsRUFBQUEsVUFBVSxFQUFFLElBRHlCO0FBRXJDOEYsRUFBQUEsR0FBRyxFQUFFLFlBQVc7QUFDWixXQUFPZ0gsT0FBTyxDQUFDMU4sT0FBZjtBQUNIO0FBSm9DLENBQXpDO0FBTUFKLDhDQUE2QztBQUN6Q2dCLEVBQUFBLFVBQVUsRUFBRSxJQUQ2QjtBQUV6QzhGLEVBQUFBLEdBQUcsRUFBRSxZQUFXO0FBQ1osV0FBTzZSLFdBQVcsQ0FBQ3ZZLE9BQW5CO0FBQ0g7QUFKd0MsQ0FBN0M7QUFNQUYsaUJBQUEsR0FBb0JxUSxTQUFwQjtBQUNBclEsb0JBQUEsR0FBdUIwWSxZQUF2QjtBQUNBMVksZ0NBQUEsR0FBbUMyWSx3QkFBbkM7QUFDQTNZLGVBQUEsR0FBa0IsS0FBSyxDQUF2Qjs7QUFDQSxJQUFJSSxNQUFNLEdBQUdDLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLG9CQUFELENBQVIsQ0FBbkM7O0FBQ0EsSUFBSXNOLE9BQU8sR0FBR3ZOLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLHlGQUFELENBQVIsQ0FBcEM7O0FBQ0EsSUFBSXNZLGNBQWMsR0FBR3RZLG1CQUFPLENBQUMsa0VBQUQsQ0FBNUI7O0FBQ0EsSUFBSW1ZLFdBQVcsR0FBR3BZLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLHFFQUFELENBQVIsQ0FBeEM7O0FBQ0EsU0FBU0Qsc0JBQVQsQ0FBZ0NPLEdBQWhDLEVBQXFDO0FBQ2pDLFNBQU9BLEdBQUcsSUFBSUEsR0FBRyxDQUFDSyxVQUFYLEdBQXdCTCxHQUF4QixHQUE4QjtBQUNqQ1YsSUFBQUEsT0FBTyxFQUFFVTtBQUR3QixHQUFyQztBQUdIOztBQUNELE1BQU1pWSxlQUFlLEdBQUc7QUFDcEI3SyxFQUFBQSxNQUFNLEVBQUUsSUFEWTtBQUVwQjhLLEVBQUFBLGNBQWMsRUFBRSxFQUZJOztBQUdwQkMsRUFBQUEsS0FBSyxDQUFFakcsRUFBRixFQUFNO0FBQ1AsUUFBSSxLQUFLOUUsTUFBVCxFQUFpQixPQUFPOEUsRUFBRSxFQUFUOztBQUNqQixlQUFtQyxFQUVsQztBQUNKOztBQVJtQixDQUF4QixFQVVBOztBQUNBLE1BQU1rRyxpQkFBaUIsR0FBRyxDQUN0QixVQURzQixFQUV0QixPQUZzQixFQUd0QixPQUhzQixFQUl0QixRQUpzQixFQUt0QixZQUxzQixFQU10QixZQU5zQixFQU90QixVQVBzQixFQVF0QixRQVJzQixFQVN0QixTQVRzQixFQVV0QixlQVZzQixFQVd0QixTQVhzQixFQVl0QixXQVpzQixFQWF0QixnQkFic0IsRUFjdEIsZUFkc0IsQ0FBMUI7QUFnQkEsTUFBTUMsWUFBWSxHQUFHLENBQ2pCLGtCQURpQixFQUVqQixxQkFGaUIsRUFHakIscUJBSGlCLEVBSWpCLGtCQUppQixFQUtqQixpQkFMaUIsRUFNakIsb0JBTmlCLENBQXJCO0FBUUEsTUFBTUMsZ0JBQWdCLEdBQUcsQ0FDckIsTUFEcUIsRUFFckIsU0FGcUIsRUFHckIsUUFIcUIsRUFJckIsTUFKcUIsRUFLckIsVUFMcUIsRUFNckIsZ0JBTnFCLENBQXpCLEVBUUE7O0FBQ0FwWixNQUFNLENBQUNDLGNBQVAsQ0FBc0I4WSxlQUF0QixFQUF1QyxRQUF2QyxFQUFpRDtBQUM3Q2pTLEVBQUFBLEdBQUcsR0FBSTtBQUNILFdBQU9nSCxPQUFPLENBQUMxTixPQUFSLENBQWdCaVosTUFBdkI7QUFDSDs7QUFINEMsQ0FBakQ7QUFLQUgsaUJBQWlCLENBQUNqWCxPQUFsQixDQUEyQnFYLEtBQUQsSUFBUztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBdFosRUFBQUEsTUFBTSxDQUFDQyxjQUFQLENBQXNCOFksZUFBdEIsRUFBdUNPLEtBQXZDLEVBQThDO0FBQzFDeFMsSUFBQUEsR0FBRyxHQUFJO0FBQ0gsWUFBTW9ILE1BQU0sR0FBR3FMLFNBQVMsRUFBeEI7QUFDQSxhQUFPckwsTUFBTSxDQUFDb0wsS0FBRCxDQUFiO0FBQ0g7O0FBSnlDLEdBQTlDO0FBTUgsQ0FYRDtBQVlBRixnQkFBZ0IsQ0FBQ25YLE9BQWpCLENBQTBCcVgsS0FBRCxJQUFTO0FBQzlCUCxFQUFBQSxlQUFlLENBQUNPLEtBQUQsQ0FBZixHQUF5QixDQUFDLEdBQUc1SixJQUFKLEtBQVc7QUFDaEMsVUFBTXhCLE1BQU0sR0FBR3FMLFNBQVMsRUFBeEI7QUFDQSxXQUFPckwsTUFBTSxDQUFDb0wsS0FBRCxDQUFOLENBQWMsR0FBRzVKLElBQWpCLENBQVA7QUFDSCxHQUhEO0FBSUgsQ0FMRDtBQU1BeUosWUFBWSxDQUFDbFgsT0FBYixDQUFzQnVNLEtBQUQsSUFBUztBQUMxQnVLLEVBQUFBLGVBQWUsQ0FBQ0UsS0FBaEIsQ0FBc0IsTUFBSTtBQUN0Qm5MLElBQUFBLE9BQU8sQ0FBQzFOLE9BQVIsQ0FBZ0JpWixNQUFoQixDQUF1QkcsRUFBdkIsQ0FBMEJoTCxLQUExQixFQUFpQyxDQUFDLEdBQUdrQixJQUFKLEtBQVc7QUFDeEMsWUFBTStKLFVBQVUsR0FBSSxLQUFJakwsS0FBSyxDQUFDa0wsTUFBTixDQUFhLENBQWIsRUFBZ0JDLFdBQWhCLEVBQThCLEdBQUVuTCxLQUFLLENBQUNvTCxTQUFOLENBQWdCLENBQWhCLENBQW1CLEVBQTNFO0FBQ0EsWUFBTUMsZ0JBQWdCLEdBQUdkLGVBQXpCOztBQUNBLFVBQUljLGdCQUFnQixDQUFDSixVQUFELENBQXBCLEVBQWtDO0FBQzlCLFlBQUk7QUFDQUksVUFBQUEsZ0JBQWdCLENBQUNKLFVBQUQsQ0FBaEIsQ0FBNkIsR0FBRy9KLElBQWhDO0FBQ0gsU0FGRCxDQUVFLE9BQU9oQyxHQUFQLEVBQVk7QUFDVmxGLFVBQUFBLE9BQU8sQ0FBQ21GLEtBQVIsQ0FBZSx3Q0FBdUM4TCxVQUFXLEVBQWpFO0FBQ0FqUixVQUFBQSxPQUFPLENBQUNtRixLQUFSLENBQWUsR0FBRUQsR0FBRyxDQUFDb00sT0FBUSxLQUFJcE0sR0FBRyxDQUFDcU0sS0FBTSxFQUEzQztBQUNIO0FBQ0o7QUFDSixLQVhEO0FBWUgsR0FiRDtBQWNILENBZkQ7O0FBZ0JBLFNBQVNSLFNBQVQsR0FBcUI7QUFDakIsTUFBSSxDQUFDUixlQUFlLENBQUM3SyxNQUFyQixFQUE2QjtBQUN6QixVQUFNNEwsT0FBTyxHQUFHLGdDQUFnQyxxRUFBaEQ7QUFDQSxVQUFNLElBQUk5UyxLQUFKLENBQVU4UyxPQUFWLENBQU47QUFDSDs7QUFDRCxTQUFPZixlQUFlLENBQUM3SyxNQUF2QjtBQUNIOztBQUNELElBQUltRSxRQUFRLEdBQUcwRyxlQUFmO0FBQ0E3WSxlQUFBLEdBQWtCbVMsUUFBbEI7O0FBQ0EsU0FBUzlCLFNBQVQsR0FBcUI7QUFDakIsU0FBT2pRLE1BQU0sQ0FBQ0YsT0FBUCxDQUFlNFosVUFBZixDQUEwQmxCLGNBQWMsQ0FBQ21CLGFBQXpDLENBQVA7QUFDSDs7QUFDRCxTQUFTckIsWUFBVCxDQUFzQixHQUFHbEosSUFBekIsRUFBK0I7QUFDM0JxSixFQUFBQSxlQUFlLENBQUM3SyxNQUFoQixHQUF5QixJQUFJSixPQUFPLENBQUMxTixPQUFaLENBQW9CLEdBQUdzUCxJQUF2QixDQUF6QjtBQUNBcUosRUFBQUEsZUFBZSxDQUFDQyxjQUFoQixDQUErQi9XLE9BQS9CLENBQXdDK1EsRUFBRCxJQUFNQSxFQUFFLEVBQS9DO0FBRUErRixFQUFBQSxlQUFlLENBQUNDLGNBQWhCLEdBQWlDLEVBQWpDO0FBQ0EsU0FBT0QsZUFBZSxDQUFDN0ssTUFBdkI7QUFDSDs7QUFDRCxTQUFTMkssd0JBQVQsQ0FBa0MzSyxNQUFsQyxFQUEwQztBQUN0QyxRQUFNSCxRQUFRLEdBQUdHLE1BQWpCO0FBQ0EsUUFBTWdNLFFBQVEsR0FBRyxFQUFqQjs7QUFFQSxPQUFLLE1BQU1DLFFBQVgsSUFBdUJqQixpQkFBdkIsRUFBeUM7QUFDckMsUUFBSSxPQUFPbkwsUUFBUSxDQUFDb00sUUFBRCxDQUFmLEtBQThCLFFBQWxDLEVBQTRDO0FBQ3hDRCxNQUFBQSxRQUFRLENBQUNDLFFBQUQsQ0FBUixHQUFxQm5hLE1BQU0sQ0FBQ3lNLE1BQVAsQ0FBYzJOLEtBQUssQ0FBQ0MsT0FBTixDQUFjdE0sUUFBUSxDQUFDb00sUUFBRCxDQUF0QixJQUFvQyxFQUFwQyxHQUF5QyxFQUF2RCxFQUNsQnBNLFFBQVEsQ0FBQ29NLFFBQUQsQ0FEVSxDQUFyQixDQUN1QjtBQUR2QjtBQUdBO0FBQ0g7O0FBQ0RELElBQUFBLFFBQVEsQ0FBQ0MsUUFBRCxDQUFSLEdBQXFCcE0sUUFBUSxDQUFDb00sUUFBRCxDQUE3QjtBQUNILEdBWnFDLENBYXRDOzs7QUFDQUQsRUFBQUEsUUFBUSxDQUFDYixNQUFULEdBQWtCdkwsT0FBTyxDQUFDMU4sT0FBUixDQUFnQmlaLE1BQWxDO0FBQ0FELEVBQUFBLGdCQUFnQixDQUFDblgsT0FBakIsQ0FBMEJxWCxLQUFELElBQVM7QUFDOUJZLElBQUFBLFFBQVEsQ0FBQ1osS0FBRCxDQUFSLEdBQWtCLENBQUMsR0FBRzVKLElBQUosS0FBVztBQUN6QixhQUFPM0IsUUFBUSxDQUFDdUwsS0FBRCxDQUFSLENBQWdCLEdBQUc1SixJQUFuQixDQUFQO0FBQ0gsS0FGRDtBQUdILEdBSkQ7QUFLQSxTQUFPd0ssUUFBUDtBQUNIOzs7Ozs7Ozs7OztBQ3hKWTs7QUFDYmxhLDhDQUE2QztBQUN6Q0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0FELHVCQUFBLEdBQTBCeUssZUFBMUI7O0FBQ0EsSUFBSXJLLE1BQU0sR0FBR0UsbUJBQU8sQ0FBQyxvQkFBRCxDQUFwQjs7QUFDQSxJQUFJdVQsb0JBQW9CLEdBQUd2VCxtQkFBTyxDQUFDLHlGQUFELENBQWxDOztBQUNBLE1BQU04Wix1QkFBdUIsR0FBRyxPQUFPQyxvQkFBUCxLQUFnQyxXQUFoRTs7QUFDQSxTQUFTNVAsZUFBVCxDQUF5QjtBQUFFQyxFQUFBQSxVQUFGO0FBQWVDLEVBQUFBO0FBQWYsQ0FBekIsRUFBcUQ7QUFDakQsUUFBTTJQLFVBQVUsR0FBRzNQLFFBQVEsSUFBSSxDQUFDeVAsdUJBQWhDO0FBQ0EsUUFBTUcsU0FBUyxHQUFHLENBQUMsR0FBR25hLE1BQUosRUFBWStQLE1BQVosRUFBbEI7QUFDQSxRQUFNLENBQUNxSyxPQUFELEVBQVVDLFVBQVYsSUFBd0IsQ0FBQyxHQUFHcmEsTUFBSixFQUFZc2EsUUFBWixDQUFxQixLQUFyQixDQUE5QjtBQUNBLFFBQU1uUSxNQUFNLEdBQUcsQ0FBQyxHQUFHbkssTUFBSixFQUFZNFEsV0FBWixDQUF5QkMsRUFBRCxJQUFNO0FBQ3pDLFFBQUlzSixTQUFTLENBQUNuSyxPQUFkLEVBQXVCO0FBQ25CbUssTUFBQUEsU0FBUyxDQUFDbkssT0FBVjtBQUNBbUssTUFBQUEsU0FBUyxDQUFDbkssT0FBVixHQUFvQnROLFNBQXBCO0FBQ0g7O0FBQ0QsUUFBSXdYLFVBQVUsSUFBSUUsT0FBbEIsRUFBMkI7O0FBQzNCLFFBQUl2SixFQUFFLElBQUlBLEVBQUUsQ0FBQzBKLE9BQWIsRUFBc0I7QUFDbEJKLE1BQUFBLFNBQVMsQ0FBQ25LLE9BQVYsR0FBb0J3SyxPQUFPLENBQUMzSixFQUFELEVBQU1yRyxTQUFELElBQWFBLFNBQVMsSUFBSTZQLFVBQVUsQ0FBQzdQLFNBQUQsQ0FBekMsRUFDekI7QUFDRUYsUUFBQUE7QUFERixPQUR5QixDQUEzQjtBQUlIO0FBQ0osR0FaYyxFQVlaLENBQ0M0UCxVQURELEVBRUM1UCxVQUZELEVBR0M4UCxPQUhELENBWlksQ0FBZjtBQWlCQSxHQUFDLEdBQUdwYSxNQUFKLEVBQVk4USxTQUFaLENBQXNCLE1BQUk7QUFDdEIsUUFBSSxDQUFDa0osdUJBQUwsRUFBOEI7QUFDMUIsVUFBSSxDQUFDSSxPQUFMLEVBQWM7QUFDVixjQUFNSyxZQUFZLEdBQUcsQ0FBQyxHQUFHaEgsb0JBQUosRUFBMEJwQixtQkFBMUIsQ0FBOEMsTUFBSWdJLFVBQVUsQ0FBQyxJQUFELENBQTVELENBQXJCO0FBRUEsZUFBTyxNQUFJLENBQUMsR0FBRzVHLG9CQUFKLEVBQTBCbkIsa0JBQTFCLENBQTZDbUksWUFBN0MsQ0FBWDtBQUVIO0FBQ0o7QUFDSixHQVRELEVBU0csQ0FDQ0wsT0FERCxDQVRIO0FBWUEsU0FBTyxDQUNIalEsTUFERyxFQUVIaVEsT0FGRyxDQUFQO0FBSUg7O0FBQ0QsU0FBU0ksT0FBVCxDQUFpQkUsT0FBakIsRUFBMEJDLFFBQTFCLEVBQW9DOU0sT0FBcEMsRUFBNkM7QUFDekMsUUFBTTtBQUFFcUYsSUFBQUEsRUFBRjtBQUFPMEgsSUFBQUEsUUFBUDtBQUFrQkMsSUFBQUE7QUFBbEIsTUFBZ0NDLGNBQWMsQ0FBQ2pOLE9BQUQsQ0FBcEQ7QUFDQWdOLEVBQUFBLFFBQVEsQ0FBQzdOLEdBQVQsQ0FBYTBOLE9BQWIsRUFBc0JDLFFBQXRCO0FBQ0FDLEVBQUFBLFFBQVEsQ0FBQ0osT0FBVCxDQUFpQkUsT0FBakI7QUFDQSxTQUFPLFNBQVNQLFNBQVQsR0FBcUI7QUFDeEJVLElBQUFBLFFBQVEsQ0FBQ0UsTUFBVCxDQUFnQkwsT0FBaEI7QUFDQUUsSUFBQUEsUUFBUSxDQUFDVCxTQUFULENBQW1CTyxPQUFuQixFQUZ3QixDQUd4Qjs7QUFDQSxRQUFJRyxRQUFRLENBQUNHLElBQVQsS0FBa0IsQ0FBdEIsRUFBeUI7QUFDckJKLE1BQUFBLFFBQVEsQ0FBQ0ssVUFBVDtBQUNBQyxNQUFBQSxTQUFTLENBQUNILE1BQVYsQ0FBaUI3SCxFQUFqQjtBQUNIO0FBQ0osR0FSRDtBQVNIOztBQUNELE1BQU1nSSxTQUFTLEdBQUcsSUFBSXRZLEdBQUosRUFBbEI7O0FBQ0EsU0FBU2tZLGNBQVQsQ0FBd0JqTixPQUF4QixFQUFpQztBQUM3QixRQUFNcUYsRUFBRSxHQUFHckYsT0FBTyxDQUFDdkQsVUFBUixJQUFzQixFQUFqQztBQUNBLE1BQUlzUCxRQUFRLEdBQUdzQixTQUFTLENBQUMxVSxHQUFWLENBQWMwTSxFQUFkLENBQWY7O0FBQ0EsTUFBSTBHLFFBQUosRUFBYztBQUNWLFdBQU9BLFFBQVA7QUFDSDs7QUFDRCxRQUFNaUIsUUFBUSxHQUFHLElBQUlqWSxHQUFKLEVBQWpCO0FBQ0EsUUFBTWdZLFFBQVEsR0FBRyxJQUFJWCxvQkFBSixDQUEwQmtCLE9BQUQsSUFBVztBQUNqREEsSUFBQUEsT0FBTyxDQUFDeFosT0FBUixDQUFpQmtTLEtBQUQsSUFBUztBQUNyQixZQUFNOEcsUUFBUSxHQUFHRSxRQUFRLENBQUNyVSxHQUFULENBQWFxTixLQUFLLENBQUM5UyxNQUFuQixDQUFqQjtBQUNBLFlBQU15SixTQUFTLEdBQUdxSixLQUFLLENBQUN1SCxjQUFOLElBQXdCdkgsS0FBSyxDQUFDd0gsaUJBQU4sR0FBMEIsQ0FBcEU7O0FBQ0EsVUFBSVYsUUFBUSxJQUFJblEsU0FBaEIsRUFBMkI7QUFDdkJtUSxRQUFBQSxRQUFRLENBQUNuUSxTQUFELENBQVI7QUFDSDtBQUNKLEtBTkQ7QUFPSCxHQVJnQixFQVFkcUQsT0FSYyxDQUFqQjtBQVNBcU4sRUFBQUEsU0FBUyxDQUFDbE8sR0FBVixDQUFja0csRUFBZCxFQUFrQjBHLFFBQVEsR0FBRztBQUN6QjFHLElBQUFBLEVBRHlCO0FBRXpCMEgsSUFBQUEsUUFGeUI7QUFHekJDLElBQUFBO0FBSHlCLEdBQTdCO0FBS0EsU0FBT2pCLFFBQVA7QUFDSDs7Ozs7Ozs7Ozs7QUNuRlk7O0FBQ2JsYSw4Q0FBNkM7QUFDekNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBRCxlQUFBLEdBQWtCMGIsVUFBbEI7O0FBQ0EsSUFBSXRiLE1BQU0sR0FBR0Msc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsb0JBQUQsQ0FBUixDQUFuQzs7QUFDQSxJQUFJc04sT0FBTyxHQUFHdE4sbUJBQU8sQ0FBQywyREFBRCxDQUFyQjs7QUFDQSxTQUFTRCxzQkFBVCxDQUFnQ08sR0FBaEMsRUFBcUM7QUFDakMsU0FBT0EsR0FBRyxJQUFJQSxHQUFHLENBQUNLLFVBQVgsR0FBd0JMLEdBQXhCLEdBQThCO0FBQ2pDVixJQUFBQSxPQUFPLEVBQUVVO0FBRHdCLEdBQXJDO0FBR0g7O0FBQ0QsU0FBUzhhLFVBQVQsQ0FBb0JDLGlCQUFwQixFQUF1QztBQUNuQyxXQUFTQyxpQkFBVCxDQUEyQnRNLEtBQTNCLEVBQWtDO0FBQzlCLFdBQU8sYUFBY2xQLE1BQU0sQ0FBQ0YsT0FBUCxDQUFla00sYUFBZixDQUE2QnVQLGlCQUE3QixFQUFnRDdiLE1BQU0sQ0FBQ3lNLE1BQVAsQ0FBYztBQUMvRXlCLE1BQUFBLE1BQU0sRUFBRSxDQUFDLEdBQUdKLE9BQUosRUFBYXlDLFNBQWI7QUFEdUUsS0FBZCxFQUVsRWYsS0FGa0UsQ0FBaEQsQ0FBckI7QUFHSDs7QUFDRHNNLEVBQUFBLGlCQUFpQixDQUFDQyxlQUFsQixHQUFvQ0YsaUJBQWlCLENBQUNFLGVBQXREO0FBQ0FELEVBQUFBLGlCQUFpQixDQUFDRSxtQkFBbEIsR0FBd0NILGlCQUFpQixDQUFDRyxtQkFBMUQ7O0FBQ0EsWUFBMkM7QUFDdkMsVUFBTUMsSUFBSSxHQUFHSixpQkFBaUIsQ0FBQ0ssV0FBbEIsSUFBaUNMLGlCQUFpQixDQUFDSSxJQUFuRCxJQUEyRCxTQUF4RTtBQUNBSCxJQUFBQSxpQkFBaUIsQ0FBQ0ksV0FBbEIsR0FBaUMsY0FBYUQsSUFBSyxHQUFuRDtBQUNIOztBQUNELFNBQU9ILGlCQUFQO0FBQ0g7Ozs7Ozs7Ozs7O0FDekJZOztBQUNiOWIsOENBQTZDO0FBQ3pDRyxFQUFBQSxLQUFLLEVBQUU7QUFEa0MsQ0FBN0M7QUFHQUQsdUJBQUEsR0FBMEI0UixlQUExQjtBQUNBNVIsaUJBQUEsR0FBb0JnUyxTQUFwQjtBQUNBaFMsaUJBQUEsR0FBb0JpYyxTQUFwQjtBQUNBamMsbUJBQUEsR0FBc0JrYyxXQUF0QjtBQUNBbGMsbUJBQUEsR0FBc0IrUixXQUF0QjtBQUNBL1IsbUJBQUEsR0FBc0JtYyxXQUF0QjtBQUNBbmMsa0JBQUEsR0FBcUJrTyxVQUFyQjtBQUNBbE8scUJBQUEsR0FBd0JvYyxhQUF4QjtBQUNBcGMsbUJBQUEsR0FBc0J5USxXQUF0QjtBQUNBelEsZUFBQSxHQUFrQixLQUFLLENBQXZCOztBQUNBLElBQUlxYyx1QkFBdUIsR0FBRy9iLG1CQUFPLENBQUMsNkdBQUQsQ0FBckM7O0FBQ0EsSUFBSWdjLFlBQVksR0FBR2hjLG1CQUFPLENBQUMscUZBQUQsQ0FBMUI7O0FBQ0EsSUFBSWljLG9CQUFvQixHQUFHamMsbUJBQU8sQ0FBQyxvRkFBRCxDQUFsQzs7QUFDQSxJQUFJa2Msb0JBQW9CLEdBQUdsYyxtQkFBTyxDQUFDLG9FQUFELENBQWxDOztBQUNBLElBQUltYyxLQUFLLEdBQUdwYyxzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyx3QkFBRCxDQUFSLENBQWxDOztBQUNBLElBQUlvYyxNQUFNLEdBQUdwYyxtQkFBTyxDQUFDLHFDQUFELENBQXBCOztBQUNBLElBQUlxYyxVQUFVLEdBQUdyYyxtQkFBTyxDQUFDLDhDQUFELENBQXhCOztBQUNBLElBQUlzYyxpQkFBaUIsR0FBR3RjLG1CQUFPLENBQUMsOERBQUQsQ0FBL0I7O0FBQ0EsSUFBSXVjLFlBQVksR0FBR3ZjLG1CQUFPLENBQUMsZ0RBQUQsQ0FBMUI7O0FBQ0EsSUFBSXdjLGdCQUFnQixHQUFHemMsc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsdUNBQUQsQ0FBUixDQUE3Qzs7QUFDQSxJQUFJeWMsYUFBYSxHQUFHemMsbUJBQU8sQ0FBQyxvREFBRCxDQUEzQjs7QUFDQSxJQUFJMGMsV0FBVyxHQUFHMWMsbUJBQU8sQ0FBQyxnREFBRCxDQUF6Qjs7QUFDQSxTQUFTRCxzQkFBVCxDQUFnQ08sR0FBaEMsRUFBcUM7QUFDakMsU0FBT0EsR0FBRyxJQUFJQSxHQUFHLENBQUNLLFVBQVgsR0FBd0JMLEdBQXhCLEdBQThCO0FBQ2pDVixJQUFBQSxPQUFPLEVBQUVVO0FBRHdCLEdBQXJDO0FBR0g7O0FBQ0QsSUFBSXFjLGtCQUFKOztBQUNBLElBQUk1WSxLQUFKLEVBQXFDLEVBRXBDOztBQUNELE1BQU04WSxRQUFRLEdBQUc5WSxNQUFBLElBQXNDLEVBQXZEOztBQUNBLFNBQVNnWixzQkFBVCxHQUFrQztBQUM5QixTQUFPdmQsTUFBTSxDQUFDeU0sTUFBUCxDQUFjLElBQUl6RixLQUFKLENBQVUsaUJBQVYsQ0FBZCxFQUE0QztBQUMvQ2lQLElBQUFBLFNBQVMsRUFBRTtBQURvQyxHQUE1QyxDQUFQO0FBR0g7O0FBQ0QsU0FBU3VILGFBQVQsQ0FBdUJyWixJQUF2QixFQUE2QnNaLE1BQTdCLEVBQXFDO0FBQ2pDLFNBQU9BLE1BQU0sSUFBSXRaLElBQUksQ0FBQ29ELFVBQUwsQ0FBZ0IsR0FBaEIsQ0FBVixHQUFpQ3BELElBQUksS0FBSyxHQUFULEdBQWUsQ0FBQyxHQUFHb1ksdUJBQUosRUFBNkJoSywwQkFBN0IsQ0FBd0RrTCxNQUF4RCxDQUFmLEdBQWtGLEdBQUVBLE1BQU8sR0FBRUMsZUFBZSxDQUFDdlosSUFBRCxDQUFmLEtBQTBCLEdBQTFCLEdBQWdDQSxJQUFJLENBQUN5VixTQUFMLENBQWUsQ0FBZixDQUFoQyxHQUFvRHpWLElBQUssRUFBdkwsR0FBMkxBLElBQWxNO0FBQ0g7O0FBQ0QsU0FBUzJOLGVBQVQsQ0FBeUIzTixJQUF6QixFQUErQm1LLE1BQS9CLEVBQXVDeUQsT0FBdkMsRUFBZ0RDLGFBQWhELEVBQStEO0FBQzNELE1BQUl6TixLQUFKLEVBQXFDLEVBQXJDLE1BT087QUFDSCxXQUFPLEtBQVA7QUFDSDtBQUNKOztBQUNELFNBQVMyTixTQUFULENBQW1CL04sSUFBbkIsRUFBeUJtSyxNQUF6QixFQUFpQzZELGFBQWpDLEVBQWdEO0FBQzVDLE1BQUk1TixLQUFKLEVBQXFDLEVBS3BDOztBQUNELFNBQU9KLElBQVA7QUFDSDs7QUFDRCxTQUFTZ1ksU0FBVCxDQUFtQmhZLElBQW5CLEVBQXlCbUssTUFBekIsRUFBaUM7QUFDN0IsTUFBSS9KLEtBQUosRUFBcUMsRUFLcEM7O0FBQ0QsU0FBT0osSUFBUDtBQUNIOztBQUNELFNBQVN1WixlQUFULENBQXlCdlosSUFBekIsRUFBK0I7QUFDM0IsUUFBTWthLFVBQVUsR0FBR2xhLElBQUksQ0FBQzdCLE9BQUwsQ0FBYSxHQUFiLENBQW5CO0FBQ0EsUUFBTWdjLFNBQVMsR0FBR25hLElBQUksQ0FBQzdCLE9BQUwsQ0FBYSxHQUFiLENBQWxCOztBQUNBLE1BQUkrYixVQUFVLEdBQUcsQ0FBQyxDQUFkLElBQW1CQyxTQUFTLEdBQUcsQ0FBQyxDQUFwQyxFQUF1QztBQUNuQ25hLElBQUFBLElBQUksR0FBR0EsSUFBSSxDQUFDeVYsU0FBTCxDQUFlLENBQWYsRUFBa0J5RSxVQUFVLEdBQUcsQ0FBQyxDQUFkLEdBQWtCQSxVQUFsQixHQUErQkMsU0FBakQsQ0FBUDtBQUNIOztBQUNELFNBQU9uYSxJQUFQO0FBQ0g7O0FBQ0QsU0FBU2lZLFdBQVQsQ0FBcUJqWSxJQUFyQixFQUEyQjtBQUN2QkEsRUFBQUEsSUFBSSxHQUFHdVosZUFBZSxDQUFDdlosSUFBRCxDQUF0QjtBQUNBLFNBQU9BLElBQUksS0FBS2taLFFBQVQsSUFBcUJsWixJQUFJLENBQUNvRCxVQUFMLENBQWdCOFYsUUFBUSxHQUFHLEdBQTNCLENBQTVCO0FBQ0g7O0FBQ0QsU0FBU3BMLFdBQVQsQ0FBcUI5TixJQUFyQixFQUEyQjtBQUN2QjtBQUNBLFNBQU9xWixhQUFhLENBQUNyWixJQUFELEVBQU9rWixRQUFQLENBQXBCO0FBQ0g7O0FBQ0QsU0FBU2hCLFdBQVQsQ0FBcUJsWSxJQUFyQixFQUEyQjtBQUN2QkEsRUFBQUEsSUFBSSxHQUFHQSxJQUFJLENBQUM4SSxLQUFMLENBQVdvUSxRQUFRLENBQUM3YixNQUFwQixDQUFQO0FBQ0EsTUFBSSxDQUFDMkMsSUFBSSxDQUFDb0QsVUFBTCxDQUFnQixHQUFoQixDQUFMLEVBQTJCcEQsSUFBSSxHQUFJLElBQUdBLElBQUssRUFBaEI7QUFDM0IsU0FBT0EsSUFBUDtBQUNIOztBQUNELFNBQVNpSyxVQUFULENBQW9CbEIsR0FBcEIsRUFBeUI7QUFDckI7QUFDQSxNQUFJQSxHQUFHLENBQUMzRixVQUFKLENBQWUsR0FBZixLQUF1QjJGLEdBQUcsQ0FBQzNGLFVBQUosQ0FBZSxHQUFmLENBQXZCLElBQThDMkYsR0FBRyxDQUFDM0YsVUFBSixDQUFlLEdBQWYsQ0FBbEQsRUFBdUUsT0FBTyxJQUFQOztBQUN2RSxNQUFJO0FBQ0E7QUFDQSxVQUFNZ1gsY0FBYyxHQUFHLENBQUMsR0FBRzNCLE1BQUosRUFBWTRCLGlCQUFaLEVBQXZCO0FBQ0EsVUFBTUMsUUFBUSxHQUFHLElBQUl0UixHQUFKLENBQVFELEdBQVIsRUFBYXFSLGNBQWIsQ0FBakI7QUFDQSxXQUFPRSxRQUFRLENBQUNDLE1BQVQsS0FBb0JILGNBQXBCLElBQXNDbkMsV0FBVyxDQUFDcUMsUUFBUSxDQUFDVCxRQUFWLENBQXhEO0FBQ0gsR0FMRCxDQUtFLE9BQU9qTyxDQUFQLEVBQVU7QUFDUixXQUFPLEtBQVA7QUFDSDtBQUNKOztBQUNELFNBQVN1TSxhQUFULENBQXVCOUYsS0FBdkIsRUFBOEJtSSxVQUE5QixFQUEwQ0MsS0FBMUMsRUFBaUQ7QUFDN0MsTUFBSUMsaUJBQWlCLEdBQUcsRUFBeEI7QUFDQSxRQUFNQyxZQUFZLEdBQUcsQ0FBQyxHQUFHNUIsV0FBSixFQUFpQjZCLGFBQWpCLENBQStCdkksS0FBL0IsQ0FBckI7QUFDQSxRQUFNd0ksYUFBYSxHQUFHRixZQUFZLENBQUNHLE1BQW5DO0FBQ0EsUUFBTUMsY0FBYyxHQUFHO0FBQ3ZCLEdBQUNQLFVBQVUsS0FBS25JLEtBQWYsR0FBdUIsQ0FBQyxHQUFHeUcsYUFBSixFQUFtQmtDLGVBQW5CLENBQW1DTCxZQUFuQyxFQUFpREgsVUFBakQsQ0FBdkIsR0FBc0YsRUFBdkYsS0FBOEY7QUFDOUY7QUFDQUMsRUFBQUEsS0FIQTtBQUlBQyxFQUFBQSxpQkFBaUIsR0FBR3JJLEtBQXBCO0FBQ0EsUUFBTXBKLE1BQU0sR0FBR3BOLE1BQU0sQ0FBQzJCLElBQVAsQ0FBWXFkLGFBQVosQ0FBZjs7QUFDQSxNQUFJLENBQUM1UixNQUFNLENBQUNnUyxLQUFQLENBQWNDLEtBQUQsSUFBUztBQUN2QixRQUFJbGYsS0FBSyxHQUFHK2UsY0FBYyxDQUFDRyxLQUFELENBQWQsSUFBeUIsRUFBckM7QUFDQSxVQUFNO0FBQUVDLE1BQUFBLE1BQUY7QUFBV0MsTUFBQUE7QUFBWCxRQUF5QlAsYUFBYSxDQUFDSyxLQUFELENBQTVDLENBRnVCLENBR3ZCO0FBQ0E7O0FBQ0EsUUFBSUcsUUFBUSxHQUFJLElBQUdGLE1BQU0sR0FBRyxLQUFILEdBQVcsRUFBRyxHQUFFRCxLQUFNLEdBQS9DOztBQUNBLFFBQUlFLFFBQUosRUFBYztBQUNWQyxNQUFBQSxRQUFRLEdBQUksR0FBRSxDQUFDcmYsS0FBRCxHQUFTLEdBQVQsR0FBZSxFQUFHLElBQUdxZixRQUFTLEdBQTVDO0FBQ0g7O0FBQ0QsUUFBSUYsTUFBTSxJQUFJLENBQUNsRixLQUFLLENBQUNDLE9BQU4sQ0FBY2xhLEtBQWQsQ0FBZixFQUFxQ0EsS0FBSyxHQUFHLENBQ3pDQSxLQUR5QyxDQUFSO0FBR3JDLFdBQU8sQ0FBQ29mLFFBQVEsSUFBSUYsS0FBSyxJQUFJSCxjQUF0QixNQUNOTCxpQkFBaUIsR0FBR0EsaUJBQWlCLENBQUMzUCxPQUFsQixDQUEwQnNRLFFBQTFCLEVBQW9DRixNQUFNLEdBQUduZixLQUFLLENBQUM0RixHQUFOLEVBQVU7QUFDNUU7QUFDQTtBQUNBO0FBQ0MwWixJQUFBQSxPQUFELElBQVc1UixrQkFBa0IsQ0FBQzRSLE9BQUQsQ0FKcUMsRUFLaEVqWixJQUxnRSxDQUszRCxHQUwyRCxDQUFILEdBS2pEcUgsa0JBQWtCLENBQUMxTixLQUFELENBTFgsS0FLdUIsR0FOckMsQ0FBUDtBQU9ILEdBbkJJLENBQUwsRUFtQkk7QUFDQTBlLElBQUFBLGlCQUFpQixHQUFHLEVBQXBCLENBQXVCO0FBQXZCLEtBREEsQ0FHSjtBQUNBO0FBQ0M7O0FBQ0QsU0FBTztBQUNIelIsSUFBQUEsTUFERztBQUVIc1MsSUFBQUEsTUFBTSxFQUFFYjtBQUZMLEdBQVA7QUFJSDs7QUFDRCxTQUFTYyxrQkFBVCxDQUE0QmYsS0FBNUIsRUFBbUN4UixNQUFuQyxFQUEyQztBQUN2QyxRQUFNd1MsYUFBYSxHQUFHLEVBQXRCO0FBRUE1ZixFQUFBQSxNQUFNLENBQUMyQixJQUFQLENBQVlpZCxLQUFaLEVBQW1CM2MsT0FBbkIsQ0FBNEJsQixHQUFELElBQU87QUFDOUIsUUFBSSxDQUFDcU0sTUFBTSxDQUFDbkQsUUFBUCxDQUFnQmxKLEdBQWhCLENBQUwsRUFBMkI7QUFDdkI2ZSxNQUFBQSxhQUFhLENBQUM3ZSxHQUFELENBQWIsR0FBcUI2ZCxLQUFLLENBQUM3ZCxHQUFELENBQTFCO0FBQ0g7QUFDSixHQUpEO0FBS0EsU0FBTzZlLGFBQVA7QUFDSDs7QUFDRCxTQUFTalAsV0FBVCxDQUFxQnpDLE1BQXJCLEVBQTZCckIsSUFBN0IsRUFBbUNnVCxTQUFuQyxFQUE4QztBQUMxQztBQUNBLE1BQUlDLElBQUo7QUFDQSxNQUFJQyxXQUFXLEdBQUcsT0FBT2xULElBQVAsS0FBZ0IsUUFBaEIsR0FBMkJBLElBQTNCLEdBQWtDLENBQUMsR0FBRytQLE1BQUosRUFBWW9ELG9CQUFaLENBQWlDblQsSUFBakMsQ0FBcEQsQ0FIMEMsQ0FJMUM7QUFDQTs7QUFDQSxRQUFNb1QsYUFBYSxHQUFHRixXQUFXLENBQUMxYSxLQUFaLENBQWtCLG9CQUFsQixDQUF0QjtBQUNBLFFBQU02YSxrQkFBa0IsR0FBR0QsYUFBYSxHQUFHRixXQUFXLENBQUMzQixNQUFaLENBQW1CNkIsYUFBYSxDQUFDLENBQUQsQ0FBYixDQUFpQnplLE1BQXBDLENBQUgsR0FBaUR1ZSxXQUF6RjtBQUNBLFFBQU1JLFFBQVEsR0FBR0Qsa0JBQWtCLENBQUNFLEtBQW5CLENBQXlCLEdBQXpCLENBQWpCOztBQUNBLE1BQUksQ0FBQ0QsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQWhCLEVBQW9COWEsS0FBcEIsQ0FBMEIsV0FBMUIsQ0FBSixFQUE0QztBQUN4Q21ELElBQUFBLE9BQU8sQ0FBQ21GLEtBQVIsQ0FBZSx1Q0FBc0NvUyxXQUFZLDZFQUFqRTtBQUNBLFVBQU1NLGFBQWEsR0FBRyxDQUFDLEdBQUd6RCxNQUFKLEVBQVkwRCx3QkFBWixDQUFxQ0osa0JBQXJDLENBQXRCO0FBQ0FILElBQUFBLFdBQVcsR0FBRyxDQUFDRSxhQUFhLEdBQUdBLGFBQWEsQ0FBQyxDQUFELENBQWhCLEdBQXNCLEVBQXBDLElBQTBDSSxhQUF4RDtBQUNILEdBYnlDLENBYzFDOzs7QUFDQSxNQUFJLENBQUNqUyxVQUFVLENBQUMyUixXQUFELENBQWYsRUFBOEI7QUFDMUIsV0FBT0YsU0FBUyxHQUFHLENBQ2ZFLFdBRGUsQ0FBSCxHQUVaQSxXQUZKO0FBR0g7O0FBQ0QsTUFBSTtBQUNBRCxJQUFBQSxJQUFJLEdBQUcsSUFBSTNTLEdBQUosQ0FBUTRTLFdBQVcsQ0FBQ3hZLFVBQVosQ0FBdUIsR0FBdkIsSUFBOEIyRyxNQUFNLENBQUNxUyxNQUFyQyxHQUE4Q3JTLE1BQU0sQ0FBQzhQLFFBQTdELEVBQXVFLFVBQXZFLENBQVA7QUFDSCxHQUZELENBRUUsT0FBT2pPLENBQVAsRUFBVTtBQUNSO0FBQ0ErUCxJQUFBQSxJQUFJLEdBQUcsSUFBSTNTLEdBQUosQ0FBUSxHQUFSLEVBQWEsVUFBYixDQUFQO0FBQ0g7O0FBQ0QsTUFBSTtBQUNBLFVBQU1xVCxRQUFRLEdBQUcsSUFBSXJULEdBQUosQ0FBUTRTLFdBQVIsRUFBcUJELElBQXJCLENBQWpCO0FBQ0FVLElBQUFBLFFBQVEsQ0FBQ3hDLFFBQVQsR0FBb0IsQ0FBQyxHQUFHekIsdUJBQUosRUFBNkJoSywwQkFBN0IsQ0FBd0RpTyxRQUFRLENBQUN4QyxRQUFqRSxDQUFwQjtBQUNBLFFBQUl5QyxjQUFjLEdBQUcsRUFBckI7O0FBQ0EsUUFBSSxDQUFDLEdBQUc1RCxVQUFKLEVBQWdCNkQsY0FBaEIsQ0FBK0JGLFFBQVEsQ0FBQ3hDLFFBQXhDLEtBQXFEd0MsUUFBUSxDQUFDblQsWUFBOUQsSUFBOEV3UyxTQUFsRixFQUE2RjtBQUN6RixZQUFNakIsS0FBSyxHQUFHLENBQUMsR0FBRzdCLFlBQUosRUFBa0I0RCxzQkFBbEIsQ0FBeUNILFFBQVEsQ0FBQ25ULFlBQWxELENBQWQ7QUFDQSxZQUFNO0FBQUVxUyxRQUFBQSxNQUFGO0FBQVd0UyxRQUFBQTtBQUFYLFVBQXVCa1AsYUFBYSxDQUFDa0UsUUFBUSxDQUFDeEMsUUFBVixFQUFvQndDLFFBQVEsQ0FBQ3hDLFFBQTdCLEVBQXVDWSxLQUF2QyxDQUExQzs7QUFDQSxVQUFJYyxNQUFKLEVBQVk7QUFDUmUsUUFBQUEsY0FBYyxHQUFHLENBQUMsR0FBRzdELE1BQUosRUFBWW9ELG9CQUFaLENBQWlDO0FBQzlDaEMsVUFBQUEsUUFBUSxFQUFFMEIsTUFEb0M7QUFFOUNrQixVQUFBQSxJQUFJLEVBQUVKLFFBQVEsQ0FBQ0ksSUFGK0I7QUFHOUNoQyxVQUFBQSxLQUFLLEVBQUVlLGtCQUFrQixDQUFDZixLQUFELEVBQVF4UixNQUFSO0FBSHFCLFNBQWpDLENBQWpCO0FBS0g7QUFDSixLQWRELENBZUE7OztBQUNBLFVBQU1xRCxZQUFZLEdBQUcrUCxRQUFRLENBQUM5QixNQUFULEtBQW9Cb0IsSUFBSSxDQUFDcEIsTUFBekIsR0FBa0M4QixRQUFRLENBQUMzVCxJQUFULENBQWNJLEtBQWQsQ0FBb0J1VCxRQUFRLENBQUM5QixNQUFULENBQWdCbGQsTUFBcEMsQ0FBbEMsR0FBZ0ZnZixRQUFRLENBQUMzVCxJQUE5RztBQUNBLFdBQU9nVCxTQUFTLEdBQUcsQ0FDZnBQLFlBRGUsRUFFZmdRLGNBQWMsSUFBSWhRLFlBRkgsQ0FBSCxHQUdaQSxZQUhKO0FBSUgsR0FyQkQsQ0FxQkUsT0FBT1YsQ0FBUCxFQUFVO0FBQ1IsV0FBTzhQLFNBQVMsR0FBRyxDQUNmRSxXQURlLENBQUgsR0FFWkEsV0FGSjtBQUdIO0FBQ0o7O0FBQ0QsU0FBU2MsV0FBVCxDQUFxQjNULEdBQXJCLEVBQTBCO0FBQ3RCLFFBQU13UixNQUFNLEdBQUcsQ0FBQyxHQUFHOUIsTUFBSixFQUFZNEIsaUJBQVosRUFBZjtBQUNBLFNBQU90UixHQUFHLENBQUMzRixVQUFKLENBQWVtWCxNQUFmLElBQXlCeFIsR0FBRyxDQUFDME0sU0FBSixDQUFjOEUsTUFBTSxDQUFDbGQsTUFBckIsQ0FBekIsR0FBd0QwTCxHQUEvRDtBQUNIOztBQUNELFNBQVM0VCxZQUFULENBQXNCNVMsTUFBdEIsRUFBOEJoQixHQUE5QixFQUFtQ04sRUFBbkMsRUFBdUM7QUFDbkM7QUFDQTtBQUNBLE1BQUksQ0FBQzZELFlBQUQsRUFBZUMsVUFBZixJQUE2QkMsV0FBVyxDQUFDekMsTUFBRCxFQUFTaEIsR0FBVCxFQUFjLElBQWQsQ0FBNUM7QUFDQSxRQUFNd1IsTUFBTSxHQUFHLENBQUMsR0FBRzlCLE1BQUosRUFBWTRCLGlCQUFaLEVBQWY7QUFDQSxRQUFNdUMsYUFBYSxHQUFHdFEsWUFBWSxDQUFDbEosVUFBYixDQUF3Qm1YLE1BQXhCLENBQXRCO0FBQ0EsUUFBTXNDLFdBQVcsR0FBR3RRLFVBQVUsSUFBSUEsVUFBVSxDQUFDbkosVUFBWCxDQUFzQm1YLE1BQXRCLENBQWxDO0FBQ0FqTyxFQUFBQSxZQUFZLEdBQUdvUSxXQUFXLENBQUNwUSxZQUFELENBQTFCO0FBQ0FDLEVBQUFBLFVBQVUsR0FBR0EsVUFBVSxHQUFHbVEsV0FBVyxDQUFDblEsVUFBRCxDQUFkLEdBQTZCQSxVQUFwRDtBQUNBLFFBQU11USxXQUFXLEdBQUdGLGFBQWEsR0FBR3RRLFlBQUgsR0FBa0J3QixXQUFXLENBQUN4QixZQUFELENBQTlEO0FBQ0EsUUFBTXlRLFVBQVUsR0FBR3RVLEVBQUUsR0FBR2lVLFdBQVcsQ0FBQ2xRLFdBQVcsQ0FBQ3pDLE1BQUQsRUFBU3RCLEVBQVQsQ0FBWixDQUFkLEdBQTBDOEQsVUFBVSxJQUFJRCxZQUE3RTtBQUNBLFNBQU87QUFDSHZELElBQUFBLEdBQUcsRUFBRStULFdBREY7QUFFSHJVLElBQUFBLEVBQUUsRUFBRW9VLFdBQVcsR0FBR0UsVUFBSCxHQUFnQmpQLFdBQVcsQ0FBQ2lQLFVBQUQ7QUFGdkMsR0FBUDtBQUlIOztBQUNELFNBQVNDLG1CQUFULENBQTZCbkQsUUFBN0IsRUFBdUNvRCxLQUF2QyxFQUE4QztBQUMxQyxRQUFNQyxhQUFhLEdBQUcsQ0FBQyxHQUFHOUUsdUJBQUosRUFBNkJqSyx1QkFBN0IsQ0FBcUQsQ0FBQyxHQUFHbUssb0JBQUosRUFBMEI2RSxtQkFBMUIsQ0FBOEN0RCxRQUE5QyxDQUFyRCxDQUF0Qjs7QUFDQSxNQUFJcUQsYUFBYSxLQUFLLE1BQWxCLElBQTRCQSxhQUFhLEtBQUssU0FBbEQsRUFBNkQ7QUFDekQsV0FBT3JELFFBQVA7QUFDSCxHQUp5QyxDQUsxQzs7O0FBQ0EsTUFBSSxDQUFDb0QsS0FBSyxDQUFDblgsUUFBTixDQUFlb1gsYUFBZixDQUFMLEVBQW9DO0FBQ2hDO0FBQ0FELElBQUFBLEtBQUssQ0FBQ0csSUFBTixDQUFZQyxJQUFELElBQVE7QUFDZixVQUFJLENBQUMsR0FBRzNFLFVBQUosRUFBZ0I2RCxjQUFoQixDQUErQmMsSUFBL0IsS0FBd0MsQ0FBQyxHQUFHdEUsV0FBSixFQUFpQjZCLGFBQWpCLENBQStCeUMsSUFBL0IsRUFBcUNDLEVBQXJDLENBQXdDL08sSUFBeEMsQ0FBNkMyTyxhQUE3QyxDQUE1QyxFQUF5RztBQUNyR3JELFFBQUFBLFFBQVEsR0FBR3dELElBQVg7QUFDQSxlQUFPLElBQVA7QUFDSDtBQUNKLEtBTEQ7QUFNSDs7QUFDRCxTQUFPLENBQUMsR0FBR2pGLHVCQUFKLEVBQTZCakssdUJBQTdCLENBQXFEMEwsUUFBckQsQ0FBUDtBQUNIOztBQUNELE1BQU0wRCx1QkFBdUIsR0FBR25kLE1BQUEsSUFBbUgsQ0FBbko7QUFRQSxNQUFNMGQsa0JBQWtCLEdBQUd4TSxNQUFNLENBQUMsb0JBQUQsQ0FBakM7O0FBQ0EsU0FBU3lNLFVBQVQsQ0FBb0JoVixHQUFwQixFQUF5QmlWLFFBQXpCLEVBQW1DO0FBQy9CLFNBQU85SyxLQUFLLENBQUNuSyxHQUFELEVBQU07QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FrVixJQUFBQSxXQUFXLEVBQUU7QUFaQyxHQUFOLENBQUwsQ0FhSnhhLElBYkksQ0FhRW9OLEdBQUQsSUFBTztBQUNYLFFBQUksQ0FBQ0EsR0FBRyxDQUFDc0MsRUFBVCxFQUFhO0FBQ1QsVUFBSTZLLFFBQVEsR0FBRyxDQUFYLElBQWdCbk4sR0FBRyxDQUFDcU4sTUFBSixJQUFjLEdBQWxDLEVBQXVDO0FBQ25DLGVBQU9ILFVBQVUsQ0FBQ2hWLEdBQUQsRUFBTWlWLFFBQVEsR0FBRyxDQUFqQixDQUFqQjtBQUNIOztBQUNELFVBQUluTixHQUFHLENBQUNxTixNQUFKLEtBQWUsR0FBbkIsRUFBd0I7QUFDcEIsZUFBT3JOLEdBQUcsQ0FBQ3NOLElBQUosR0FBVzFhLElBQVgsQ0FBaUIyYSxJQUFELElBQVE7QUFDM0IsY0FBSUEsSUFBSSxDQUFDQyxRQUFULEVBQW1CO0FBQ2YsbUJBQU87QUFDSEEsY0FBQUEsUUFBUSxFQUFFUDtBQURQLGFBQVA7QUFHSDs7QUFDRCxnQkFBTSxJQUFJamIsS0FBSixDQUFXLDZCQUFYLENBQU47QUFDSCxTQVBNLENBQVA7QUFRSDs7QUFDRCxZQUFNLElBQUlBLEtBQUosQ0FBVyw2QkFBWCxDQUFOO0FBQ0g7O0FBQ0QsV0FBT2dPLEdBQUcsQ0FBQ3NOLElBQUosRUFBUDtBQUNILEdBL0JNLENBQVA7QUFnQ0g7O0FBQ0QsU0FBU0csYUFBVCxDQUF1QkMsUUFBdkIsRUFBaUNDLGNBQWpDLEVBQWlEO0FBQzdDLFNBQU9ULFVBQVUsQ0FBQ1EsUUFBRCxFQUFXQyxjQUFjLEdBQUcsQ0FBSCxHQUFPLENBQWhDLENBQVYsQ0FBNkNoYixLQUE3QyxDQUFvRCtGLEdBQUQsSUFBTztBQUM3RDtBQUNBO0FBQ0E7QUFDQSxRQUFJLENBQUNpVixjQUFMLEVBQXFCO0FBQ2pCLE9BQUMsR0FBR25HLFlBQUosRUFBa0I5SSxjQUFsQixDQUFpQ2hHLEdBQWpDO0FBQ0g7O0FBQ0QsVUFBTUEsR0FBTjtBQUNILEdBUk0sQ0FBUDtBQVNIOztBQUNELE1BQU1rVixNQUFOLENBQWE7QUFDVEMsRUFBQUEsV0FBVyxDQUFDQyxTQUFELEVBQVlDLE1BQVosRUFBb0JDLEdBQXBCLEVBQXlCO0FBQUVDLElBQUFBLFlBQUY7QUFBaUJDLElBQUFBLFVBQWpCO0FBQThCQyxJQUFBQSxHQUE5QjtBQUFvQ0MsSUFBQUEsT0FBcEM7QUFBOENDLElBQUFBLFNBQVMsRUFBRUMsVUFBekQ7QUFBc0U1VixJQUFBQSxHQUFHLEVBQUU2VixJQUEzRTtBQUFrRkMsSUFBQUEsWUFBbEY7QUFBaUdDLElBQUFBLFVBQWpHO0FBQThHblYsSUFBQUEsTUFBOUc7QUFBdUh5RCxJQUFBQSxPQUF2SDtBQUFpSUksSUFBQUEsYUFBakk7QUFBaUpILElBQUFBLGFBQWpKO0FBQWlLMFIsSUFBQUE7QUFBakssR0FBekIsRUFBdU07QUFDOU07QUFDQSxTQUFLQyxHQUFMLEdBQVcsRUFBWCxDQUY4TSxDQUk5TTs7QUFDQSxTQUFLQyxHQUFMLEdBQVcsRUFBWDtBQUVBLFNBQUtDLElBQUwsR0FBWSxDQUFaOztBQUNBLFNBQUtDLFVBQUwsR0FBbUI3VSxDQUFELElBQUs7QUFDbkIsWUFBTThVLEtBQUssR0FBRzlVLENBQUMsQ0FBQzhVLEtBQWhCOztBQUNBLFVBQUksQ0FBQ0EsS0FBTCxFQUFZO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBTTtBQUFFL0YsVUFBQUEsUUFBUSxFQUFFOEUsU0FBWjtBQUF3QmxFLFVBQUFBLEtBQUssRUFBRW1FO0FBQS9CLFlBQTJDLElBQWpEO0FBQ0EsYUFBS2lCLFdBQUwsQ0FBaUIsY0FBakIsRUFBaUMsQ0FBQyxHQUFHcEgsTUFBSixFQUFZb0Qsb0JBQVosQ0FBaUM7QUFDOURoQyxVQUFBQSxRQUFRLEVBQUUvTCxXQUFXLENBQUM2USxTQUFELENBRHlDO0FBRTlEbEUsVUFBQUEsS0FBSyxFQUFFbUU7QUFGdUQsU0FBakMsQ0FBakMsRUFHSSxDQUFDLEdBQUduRyxNQUFKLEVBQVlxSCxNQUFaLEVBSEo7QUFJQTtBQUNIOztBQUNELFVBQUksQ0FBQ0YsS0FBSyxDQUFDRyxHQUFYLEVBQWdCO0FBQ1o7QUFDSDs7QUFDRCxVQUFJQyxZQUFKO0FBQ0EsWUFBTTtBQUFFalgsUUFBQUEsR0FBRjtBQUFRTixRQUFBQSxFQUFFLEVBQUVvVyxHQUFaO0FBQWtCN1UsUUFBQUEsT0FBbEI7QUFBNEJpVyxRQUFBQTtBQUE1QixVQUFxQ0wsS0FBM0M7O0FBQ0EsVUFBSXhmLEtBQUosRUFBMkMsRUF1QjFDOztBQUNELFdBQUtzZixJQUFMLEdBQVlPLEdBQVo7QUFDQSxZQUFNO0FBQUVwRyxRQUFBQSxRQUFRLEVBQUU4RTtBQUFaLFVBQTJCLENBQUMsR0FBR2hHLGlCQUFKLEVBQXVCNEgsZ0JBQXZCLENBQXdDeFgsR0FBeEMsQ0FBakMsQ0FqRG1CLENBa0RuQjtBQUNBOztBQUNBLFVBQUksS0FBS3lYLEtBQUwsSUFBYzNCLEdBQUcsS0FBSyxLQUFLekMsTUFBM0IsSUFBcUN1QyxTQUFTLEtBQUssS0FBSzlFLFFBQTVELEVBQXNFO0FBQ2xFO0FBQ0gsT0F0RGtCLENBdURuQjtBQUNBOzs7QUFDQSxVQUFJLEtBQUs0RyxJQUFMLElBQWEsQ0FBQyxLQUFLQSxJQUFMLENBQVViLEtBQVYsQ0FBbEIsRUFBb0M7QUFDaEM7QUFDSDs7QUFDRCxXQUFLYyxNQUFMLENBQVksY0FBWixFQUE0QjNYLEdBQTVCLEVBQWlDOFYsR0FBakMsRUFBc0NoakIsTUFBTSxDQUFDeU0sTUFBUCxDQUFjLEVBQWQsRUFDbkMwQixPQURtQyxFQUMxQjtBQUNSZ0IsUUFBQUEsT0FBTyxFQUFFaEIsT0FBTyxDQUFDZ0IsT0FBUixJQUFtQixLQUFLMlYsUUFEekI7QUFFUnhXLFFBQUFBLE1BQU0sRUFBRUgsT0FBTyxDQUFDRyxNQUFSLElBQWtCLEtBQUs2RDtBQUZ2QixPQUQwQixDQUF0QyxFQUlJZ1MsWUFKSjtBQUtILEtBakVELENBUjhNLENBMEU5TTs7O0FBQ0EsU0FBSzNOLEtBQUwsR0FBYSxDQUFDLEdBQUcrRix1QkFBSixFQUE2QmpLLHVCQUE3QixDQUFxRHdRLFNBQXJELENBQWIsQ0EzRThNLENBNEU5TTs7QUFDQSxTQUFLaUMsVUFBTCxHQUFrQixFQUFsQixDQTdFOE0sQ0ErRTlNO0FBQ0E7QUFDQTs7QUFDQSxRQUFJakMsU0FBUyxLQUFLLFNBQWxCLEVBQTZCO0FBQ3pCLFdBQUtpQyxVQUFMLENBQWdCLEtBQUt2TyxLQUFyQixJQUE4QjtBQUMxQjZNLFFBQUFBLFNBQVMsRUFBRUMsVUFEZTtBQUUxQjBCLFFBQUFBLE9BQU8sRUFBRSxJQUZpQjtBQUcxQnhWLFFBQUFBLEtBQUssRUFBRXlULFlBSG1CO0FBSTFCdlYsUUFBQUEsR0FBRyxFQUFFNlYsSUFKcUI7QUFLMUIwQixRQUFBQSxPQUFPLEVBQUVoQyxZQUFZLElBQUlBLFlBQVksQ0FBQ2dDLE9BTFo7QUFNMUJDLFFBQUFBLE9BQU8sRUFBRWpDLFlBQVksSUFBSUEsWUFBWSxDQUFDaUM7QUFOWixPQUE5QjtBQVFIOztBQUNELFNBQUtILFVBQUwsQ0FBZ0IsT0FBaEIsSUFBMkI7QUFDdkIxQixNQUFBQSxTQUFTLEVBQUVGLEdBRFk7QUFFdkJsTSxNQUFBQSxXQUFXLEVBQUU7QUFGVSxLQUEzQixDQTVGOE0sQ0FnRzlNO0FBQ0E7O0FBQ0EsU0FBS29DLE1BQUwsR0FBY3VKLE1BQU0sQ0FBQ3ZKLE1BQXJCO0FBQ0EsU0FBSzZKLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EsU0FBS2xGLFFBQUwsR0FBZ0I4RSxTQUFoQjtBQUNBLFNBQUtsRSxLQUFMLEdBQWFtRSxNQUFiLENBckc4TSxDQXNHOU07QUFDQTs7QUFDQSxVQUFNb0MsaUJBQWlCLEdBQUcsQ0FBQyxHQUFHdEksVUFBSixFQUFnQjZELGNBQWhCLENBQStCb0MsU0FBL0IsS0FBNkNqUSxJQUFJLENBQUN1UyxhQUFMLENBQW1CQyxVQUExRjs7QUFDQSxTQUFLOUUsTUFBTCxHQUFjNEUsaUJBQWlCLEdBQUdyQyxTQUFILEdBQWVFLEdBQTlDO0FBQ0EsU0FBSzNGLFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0EsU0FBS2lJLEdBQUwsR0FBVzlCLFlBQVg7QUFDQSxTQUFLK0IsR0FBTCxHQUFXLElBQVg7QUFDQSxTQUFLQyxRQUFMLEdBQWdCcEMsT0FBaEIsQ0E3RzhNLENBOEc5TTtBQUNBOztBQUNBLFNBQUt1QixLQUFMLEdBQWEsSUFBYjtBQUNBLFNBQUtsQixVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLFNBQUtnQyxPQUFMLEdBQWUsQ0FBQyxFQUFFNVMsSUFBSSxDQUFDdVMsYUFBTCxDQUFtQk0sSUFBbkIsSUFBMkI3UyxJQUFJLENBQUN1UyxhQUFMLENBQW1CTyxHQUE5QyxJQUFxRDlTLElBQUksQ0FBQ3VTLGFBQUwsQ0FBbUJRLE1BQW5CLElBQTZCLENBQUMvUyxJQUFJLENBQUN1UyxhQUFMLENBQW1CUyxHQUF0RyxJQUE2RyxDQUFDVixpQkFBRCxJQUFzQixDQUFDdFMsSUFBSSxDQUFDaVQsUUFBTCxDQUFjQyxNQUFyQyxJQUErQyxDQUFDeGhCLEtBQS9KLENBQWhCO0FBQ0EsU0FBS21mLFNBQUwsR0FBaUIsQ0FBQyxDQUFDQSxTQUFuQjtBQUNBLFNBQUs3UixjQUFMLEdBQXNCLEtBQXRCOztBQUNBLFFBQUl0TixLQUFKLEVBQXFDLEVBTXBDOztBQUNELGVBQW1DLEVBdUJsQztBQUNKOztBQUNENmhCLEVBQUFBLE1BQU0sR0FBRztBQUNMclQsSUFBQUEsTUFBTSxDQUFDK1MsUUFBUCxDQUFnQk0sTUFBaEI7QUFDSDtBQUNEO0FBQ0o7QUFDQTs7O0FBQU1DLEVBQUFBLElBQUksR0FBRztBQUNMdFQsSUFBQUEsTUFBTSxDQUFDNk8sT0FBUCxDQUFleUUsSUFBZjtBQUNIO0FBQ0Q7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFBTTlnQixFQUFBQSxJQUFJLENBQUMySCxHQUFELEVBQU1OLEVBQU4sRUFBVXVCLE9BQU8sR0FBRyxFQUFwQixFQUNIO0FBQ0MsUUFBSTVKLEtBQUosRUFBMkMsRUFhMUM7O0FBQ0QsS0FBQztBQUFFMkksTUFBQUEsR0FBRjtBQUFRTixNQUFBQTtBQUFSLFFBQWdCa1UsWUFBWSxDQUFDLElBQUQsRUFBTzVULEdBQVAsRUFBWU4sRUFBWixDQUE3QjtBQUNBLFdBQU8sS0FBS2lZLE1BQUwsQ0FBWSxXQUFaLEVBQXlCM1gsR0FBekIsRUFBOEJOLEVBQTlCLEVBQWtDdUIsT0FBbEMsQ0FBUDtBQUNIO0FBQ0Q7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFBTWUsRUFBQUEsT0FBTyxDQUFDaEMsR0FBRCxFQUFNTixFQUFOLEVBQVV1QixPQUFPLEdBQUcsRUFBcEIsRUFDTjtBQUNDLEtBQUM7QUFBRWpCLE1BQUFBLEdBQUY7QUFBUU4sTUFBQUE7QUFBUixRQUFnQmtVLFlBQVksQ0FBQyxJQUFELEVBQU81VCxHQUFQLEVBQVlOLEVBQVosQ0FBN0I7QUFDQSxXQUFPLEtBQUtpWSxNQUFMLENBQVksY0FBWixFQUE0QjNYLEdBQTVCLEVBQWlDTixFQUFqQyxFQUFxQ3VCLE9BQXJDLENBQVA7QUFDSDs7QUFDVyxRQUFOMFcsTUFBTSxDQUFDeUIsTUFBRCxFQUFTcFosR0FBVCxFQUFjTixFQUFkLEVBQWtCdUIsT0FBbEIsRUFBMkJnVyxZQUEzQixFQUF5QztBQUNqRCxRQUFJLENBQUMvVixVQUFVLENBQUNsQixHQUFELENBQWYsRUFBc0I7QUFDbEI2RixNQUFBQSxNQUFNLENBQUMrUyxRQUFQLENBQWdCalosSUFBaEIsR0FBdUJLLEdBQXZCO0FBQ0EsYUFBTyxLQUFQO0FBQ0g7O0FBQ0QsVUFBTXFaLGlCQUFpQixHQUFHclosR0FBRyxLQUFLTixFQUFSLElBQWN1QixPQUFPLENBQUNxWSxFQUF0QixJQUE0QnJZLE9BQU8sQ0FBQzhYLGtCQUE5RCxDQUxpRCxDQU1qRDtBQUNBOztBQUNBLFFBQUk5WCxPQUFPLENBQUNxWSxFQUFaLEVBQWdCO0FBQ1osV0FBS2YsT0FBTCxHQUFlLElBQWY7QUFDSDs7QUFDRCxVQUFNZ0IsVUFBVSxHQUFHLEtBQUtuWSxNQUF4Qjs7QUFDQSxRQUFJL0osS0FBSixFQUFxQyxZQTZDcEM7O0FBQ0QsUUFBSSxDQUFDNEosT0FBTyxDQUFDcVksRUFBYixFQUFpQjtBQUNiLFdBQUs3QixLQUFMLEdBQWEsS0FBYjtBQUNILEtBNURnRCxDQTZEakQ7OztBQUNBLFFBQUkvSCxNQUFNLENBQUNrSyxFQUFYLEVBQWU7QUFDWEMsTUFBQUEsV0FBVyxDQUFDQyxJQUFaLENBQWlCLGFBQWpCO0FBQ0g7O0FBQ0QsVUFBTTtBQUFFN1gsTUFBQUEsT0FBTyxHQUFFO0FBQVgsUUFBc0JoQixPQUE1QjtBQUNBLFVBQU04WSxVQUFVLEdBQUc7QUFDZjlYLE1BQUFBO0FBRGUsS0FBbkI7O0FBR0EsUUFBSSxLQUFLK1gsY0FBVCxFQUF5QjtBQUNyQixXQUFLQyxrQkFBTCxDQUF3QixLQUFLRCxjQUE3QixFQUE2Q0QsVUFBN0M7QUFDSDs7QUFDRHJhLElBQUFBLEVBQUUsR0FBR3FGLFdBQVcsQ0FBQ0MsU0FBUyxDQUFDa0ssV0FBVyxDQUFDeFAsRUFBRCxDQUFYLEdBQWtCeVAsV0FBVyxDQUFDelAsRUFBRCxDQUE3QixHQUFvQ0EsRUFBckMsRUFBeUN1QixPQUFPLENBQUNHLE1BQWpELEVBQXlELEtBQUs2RCxhQUE5RCxDQUFWLENBQWhCO0FBQ0EsVUFBTWlWLFNBQVMsR0FBR2pMLFNBQVMsQ0FBQ0MsV0FBVyxDQUFDeFAsRUFBRCxDQUFYLEdBQWtCeVAsV0FBVyxDQUFDelAsRUFBRCxDQUE3QixHQUFvQ0EsRUFBckMsRUFBeUMsS0FBSzBCLE1BQTlDLENBQTNCO0FBQ0EsU0FBSzRZLGNBQUwsR0FBc0J0YSxFQUF0QjtBQUNBLFFBQUl5YSxZQUFZLEdBQUdaLFVBQVUsS0FBSyxLQUFLblksTUFBdkMsQ0EzRWlELENBNEVqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFFBQUksQ0FBQ0gsT0FBTyxDQUFDcVksRUFBVCxJQUFlLEtBQUtjLGVBQUwsQ0FBcUJGLFNBQXJCLENBQWYsSUFBa0QsQ0FBQ0MsWUFBdkQsRUFBcUU7QUFDakUsV0FBSzlHLE1BQUwsR0FBYzZHLFNBQWQ7QUFDQXhFLE1BQUFBLE1BQU0sQ0FBQ3ZKLE1BQVAsQ0FBY2tPLElBQWQsQ0FBbUIsaUJBQW5CLEVBQXNDM2EsRUFBdEMsRUFBMENxYSxVQUExQyxFQUZpRSxDQUdqRTs7QUFDQSxXQUFLakQsV0FBTCxDQUFpQnNDLE1BQWpCLEVBQXlCcFosR0FBekIsRUFBOEJOLEVBQTlCLEVBQWtDdUIsT0FBbEM7QUFDQSxXQUFLcVosWUFBTCxDQUFrQkosU0FBbEI7QUFDQSxXQUFLSyxNQUFMLENBQVksS0FBSzFDLFVBQUwsQ0FBZ0IsS0FBS3ZPLEtBQXJCLENBQVosRUFBeUMsSUFBekM7QUFDQW9NLE1BQUFBLE1BQU0sQ0FBQ3ZKLE1BQVAsQ0FBY2tPLElBQWQsQ0FBbUIsb0JBQW5CLEVBQXlDM2EsRUFBekMsRUFBNkNxYSxVQUE3QztBQUNBLGFBQU8sSUFBUDtBQUNIOztBQUNELFFBQUlTLE1BQU0sR0FBRyxDQUFDLEdBQUc1SyxpQkFBSixFQUF1QjRILGdCQUF2QixDQUF3Q3hYLEdBQXhDLENBQWI7QUFDQSxRQUFJO0FBQUU4USxNQUFBQSxRQUFRLEVBQUU4RSxTQUFaO0FBQXdCbEUsTUFBQUEsS0FBSyxFQUFFbUU7QUFBL0IsUUFBMkMyRSxNQUEvQyxDQTVGaUQsQ0E2RmpEO0FBQ0E7QUFDQTs7QUFDQSxRQUFJdEcsS0FBSixFQUFXdUcsUUFBWDs7QUFDQSxRQUFJO0FBQ0F2RyxNQUFBQSxLQUFLLEdBQUcsTUFBTSxLQUFLOEIsVUFBTCxDQUFnQjBFLFdBQWhCLEVBQWQ7QUFDQSxPQUFDO0FBQUVDLFFBQUFBLFVBQVUsRUFBRUY7QUFBZCxVQUE0QixNQUFNLENBQUMsR0FBR25MLFlBQUosRUFBa0I1SSxzQkFBbEIsRUFBbkM7QUFDSCxLQUhELENBR0UsT0FBTzJQLElBQVAsRUFBYTtBQUNYO0FBQ0E7QUFDQXhRLE1BQUFBLE1BQU0sQ0FBQytTLFFBQVAsQ0FBZ0JqWixJQUFoQixHQUF1QkQsRUFBdkI7QUFDQSxhQUFPLEtBQVA7QUFDSCxLQXpHZ0QsQ0EwR2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFFBQUksQ0FBQyxLQUFLa2IsUUFBTCxDQUFjVixTQUFkLENBQUQsSUFBNkIsQ0FBQ0MsWUFBbEMsRUFBZ0Q7QUFDNUNmLE1BQUFBLE1BQU0sR0FBRyxjQUFUO0FBQ0gsS0FqSGdELENBa0hqRDtBQUNBOzs7QUFDQSxRQUFJNVYsVUFBVSxHQUFHOUQsRUFBakIsQ0FwSGlELENBcUhqRDtBQUNBO0FBQ0E7O0FBQ0FrVyxJQUFBQSxTQUFTLEdBQUdBLFNBQVMsR0FBRyxDQUFDLEdBQUd2Ryx1QkFBSixFQUE2QmpLLHVCQUE3QixDQUFxRCtKLFdBQVcsQ0FBQ3lHLFNBQUQsQ0FBaEUsQ0FBSCxHQUFrRkEsU0FBdkc7O0FBQ0EsUUFBSXlELGlCQUFpQixJQUFJekQsU0FBUyxLQUFLLFNBQXZDLEVBQWtEO0FBQzlDM1UsTUFBQUEsT0FBTyxDQUFDOFgsa0JBQVIsR0FBNkIsSUFBN0I7O0FBQ0EsVUFBSTFoQixLQUFKLEVBQTJELEVBQTNELE1BV087QUFDSG1qQixRQUFBQSxNQUFNLENBQUMxSixRQUFQLEdBQWtCbUQsbUJBQW1CLENBQUMyQixTQUFELEVBQVkxQixLQUFaLENBQXJDOztBQUNBLFlBQUlzRyxNQUFNLENBQUMxSixRQUFQLEtBQW9COEUsU0FBeEIsRUFBbUM7QUFDL0JBLFVBQUFBLFNBQVMsR0FBRzRFLE1BQU0sQ0FBQzFKLFFBQW5CO0FBQ0EwSixVQUFBQSxNQUFNLENBQUMxSixRQUFQLEdBQWtCL0wsV0FBVyxDQUFDNlEsU0FBRCxDQUE3QjtBQUNBNVYsVUFBQUEsR0FBRyxHQUFHLENBQUMsR0FBRzBQLE1BQUosRUFBWW9ELG9CQUFaLENBQWlDMEgsTUFBakMsQ0FBTjtBQUNIO0FBQ0o7QUFDSjs7QUFDRCxVQUFNbFIsS0FBSyxHQUFHLENBQUMsR0FBRytGLHVCQUFKLEVBQTZCakssdUJBQTdCLENBQXFEd1EsU0FBckQsQ0FBZDs7QUFDQSxRQUFJLENBQUMxVSxVQUFVLENBQUN4QixFQUFELENBQWYsRUFBcUI7QUFDakIsZ0JBQTJDO0FBQ3ZDLGNBQU0sSUFBSTVGLEtBQUosQ0FBVyxrQkFBaUJrRyxHQUFJLGNBQWFOLEVBQUcsMkNBQXRDLEdBQW9GLG9GQUE5RixDQUFOO0FBQ0g7O0FBQ0RtRyxNQUFBQSxNQUFNLENBQUMrUyxRQUFQLENBQWdCalosSUFBaEIsR0FBdUJELEVBQXZCO0FBQ0EsYUFBTyxLQUFQO0FBQ0g7O0FBQ0Q4RCxJQUFBQSxVQUFVLEdBQUd5TCxTQUFTLENBQUNFLFdBQVcsQ0FBQzNMLFVBQUQsQ0FBWixFQUEwQixLQUFLcEMsTUFBL0IsQ0FBdEI7O0FBQ0EsUUFBSSxDQUFDLEdBQUd1TyxVQUFKLEVBQWdCNkQsY0FBaEIsQ0FBK0JsSyxLQUEvQixDQUFKLEVBQTJDO0FBQ3ZDLFlBQU1rUSxRQUFRLEdBQUcsQ0FBQyxHQUFHNUosaUJBQUosRUFBdUI0SCxnQkFBdkIsQ0FBd0NoVSxVQUF4QyxDQUFqQjtBQUNBLFlBQU1pTyxVQUFVLEdBQUcrSCxRQUFRLENBQUMxSSxRQUE1QjtBQUNBLFlBQU1pSyxVQUFVLEdBQUcsQ0FBQyxHQUFHL0ssV0FBSixFQUFpQjZCLGFBQWpCLENBQStCdkksS0FBL0IsQ0FBbkI7QUFDQSxZQUFNMFIsVUFBVSxHQUFHLENBQUMsR0FBR2pMLGFBQUosRUFBbUJrQyxlQUFuQixDQUFtQzhJLFVBQW5DLEVBQStDdEosVUFBL0MsQ0FBbkI7QUFDQSxZQUFNd0osaUJBQWlCLEdBQUczUixLQUFLLEtBQUttSSxVQUFwQztBQUNBLFlBQU04QixjQUFjLEdBQUcwSCxpQkFBaUIsR0FBRzdMLGFBQWEsQ0FBQzlGLEtBQUQsRUFBUW1JLFVBQVIsRUFBb0JvRSxNQUFwQixDQUFoQixHQUE4QyxFQUF0Rjs7QUFFQSxVQUFJLENBQUNtRixVQUFELElBQWVDLGlCQUFpQixJQUFJLENBQUMxSCxjQUFjLENBQUNmLE1BQXhELEVBQWdFO0FBQzVELGNBQU0wSSxhQUFhLEdBQUdwb0IsTUFBTSxDQUFDMkIsSUFBUCxDQUFZc21CLFVBQVUsQ0FBQ2hKLE1BQXZCLEVBQStCbmQsTUFBL0IsQ0FBdUN1ZCxLQUFELElBQVMsQ0FBQzBELE1BQU0sQ0FBQzFELEtBQUQsQ0FBdEQsQ0FBdEI7O0FBRUEsWUFBSStJLGFBQWEsQ0FBQzVtQixNQUFkLEdBQXVCLENBQTNCLEVBQThCO0FBQzFCLG9CQUEyQztBQUN2Q2dILFlBQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLEdBQUUwZixpQkFBaUIsR0FBSSxvQkFBSixHQUEyQixpQ0FBaUMsOEJBQWhGLEdBQWlILGVBQWNDLGFBQWEsQ0FBQzVoQixJQUFkLENBQW1CLElBQW5CLENBQXlCLDhCQUFySztBQUNIOztBQUNELGdCQUFNLElBQUlRLEtBQUosQ0FBVSxDQUFDbWhCLGlCQUFpQixHQUFJLDBCQUF5QmpiLEdBQUksb0NBQW1Da2IsYUFBYSxDQUFDNWhCLElBQWQsQ0FBbUIsSUFBbkIsQ0FBeUIsaUNBQTdGLEdBQWlJLDhCQUE2Qm1ZLFVBQVcsOENBQTZDbkksS0FBTSxLQUE5TyxJQUF1UCwrQ0FBOEMyUixpQkFBaUIsR0FBRywyQkFBSCxHQUFpQyxzQkFBdUIsRUFBeFgsQ0FBTjtBQUNIO0FBQ0osT0FURCxNQVNPLElBQUlBLGlCQUFKLEVBQXVCO0FBQzFCdmIsUUFBQUEsRUFBRSxHQUFHLENBQUMsR0FBR2dRLE1BQUosRUFBWW9ELG9CQUFaLENBQWlDaGdCLE1BQU0sQ0FBQ3lNLE1BQVAsQ0FBYyxFQUFkLEVBQ25DaWEsUUFEbUMsRUFDekI7QUFDVDFJLFVBQUFBLFFBQVEsRUFBRXlDLGNBQWMsQ0FBQ2YsTUFEaEI7QUFFVGQsVUFBQUEsS0FBSyxFQUFFZSxrQkFBa0IsQ0FBQ29ELE1BQUQsRUFBU3RDLGNBQWMsQ0FBQ3JULE1BQXhCO0FBRmhCLFNBRHlCLENBQWpDLENBQUw7QUFLSCxPQU5NLE1BTUE7QUFDSDtBQUNBcE4sUUFBQUEsTUFBTSxDQUFDeU0sTUFBUCxDQUFjc1csTUFBZCxFQUFzQm1GLFVBQXRCO0FBQ0g7QUFDSjs7QUFDRHRGLElBQUFBLE1BQU0sQ0FBQ3ZKLE1BQVAsQ0FBY2tPLElBQWQsQ0FBbUIsa0JBQW5CLEVBQXVDM2EsRUFBdkMsRUFBMkNxYSxVQUEzQzs7QUFDQSxRQUFJO0FBQ0EsVUFBSTllLEdBQUosRUFBU2tnQixJQUFUO0FBQ0EsVUFBSUMsU0FBUyxHQUFHLE1BQU0sS0FBS0MsWUFBTCxDQUFrQi9SLEtBQWxCLEVBQXlCc00sU0FBekIsRUFBb0NDLE1BQXBDLEVBQTRDblcsRUFBNUMsRUFBZ0Q4RCxVQUFoRCxFQUE0RHVXLFVBQTVELENBQXRCO0FBQ0EsVUFBSTtBQUFFdFosUUFBQUEsS0FBRjtBQUFVNkIsUUFBQUEsS0FBVjtBQUFrQnlWLFFBQUFBLE9BQWxCO0FBQTRCQyxRQUFBQTtBQUE1QixVQUF5Q29ELFNBQTdDLENBSEEsQ0FJQTs7QUFDQSxVQUFJLENBQUNyRCxPQUFPLElBQUlDLE9BQVosS0FBd0IxVixLQUE1QixFQUFtQztBQUMvQixZQUFJQSxLQUFLLENBQUNnWixTQUFOLElBQW1CaFosS0FBSyxDQUFDZ1osU0FBTixDQUFnQkMsWUFBdkMsRUFBcUQ7QUFDakQsZ0JBQU1DLFdBQVcsR0FBR2xaLEtBQUssQ0FBQ2daLFNBQU4sQ0FBZ0JDLFlBQXBDLENBRGlELENBRWpEO0FBQ0E7QUFDQTs7QUFDQSxjQUFJQyxXQUFXLENBQUNuaEIsVUFBWixDQUF1QixHQUF2QixDQUFKLEVBQWlDO0FBQzdCLGtCQUFNb2hCLFVBQVUsR0FBRyxDQUFDLEdBQUc3TCxpQkFBSixFQUF1QjRILGdCQUF2QixDQUF3Q2dFLFdBQXhDLENBQW5CO0FBQ0FDLFlBQUFBLFVBQVUsQ0FBQzNLLFFBQVgsR0FBc0JtRCxtQkFBbUIsQ0FBQ3dILFVBQVUsQ0FBQzNLLFFBQVosRUFBc0JvRCxLQUF0QixDQUF6QztBQUNBLGtCQUFNO0FBQUVsVSxjQUFBQSxHQUFHLEVBQUUwYixNQUFQO0FBQWdCaGMsY0FBQUEsRUFBRSxFQUFFaWM7QUFBcEIsZ0JBQStCL0gsWUFBWSxDQUFDLElBQUQsRUFBTzRILFdBQVAsRUFBb0JBLFdBQXBCLENBQWpEO0FBQ0EsbUJBQU8sS0FBSzdELE1BQUwsQ0FBWXlCLE1BQVosRUFBb0JzQyxNQUFwQixFQUE0QkMsS0FBNUIsRUFBbUMxYSxPQUFuQyxDQUFQO0FBQ0g7O0FBQ0Q0RSxVQUFBQSxNQUFNLENBQUMrUyxRQUFQLENBQWdCalosSUFBaEIsR0FBdUI2YixXQUF2QjtBQUNBLGlCQUFPLElBQUlqaEIsT0FBSixDQUFZLE1BQUksQ0FDdEIsQ0FETSxDQUFQO0FBRUg7O0FBQ0QsYUFBS2ljLFNBQUwsR0FBaUIsQ0FBQyxDQUFDbFUsS0FBSyxDQUFDc1osV0FBekIsQ0FoQitCLENBaUIvQjs7QUFDQSxZQUFJdFosS0FBSyxDQUFDZ1QsUUFBTixLQUFtQlAsa0JBQXZCLEVBQTJDO0FBQ3ZDLGNBQUk4RyxhQUFKOztBQUNBLGNBQUk7QUFDQSxrQkFBTSxLQUFLQyxjQUFMLENBQW9CLE1BQXBCLENBQU47QUFDQUQsWUFBQUEsYUFBYSxHQUFHLE1BQWhCO0FBQ0gsV0FIRCxDQUdFLE9BQU9oWixDQUFQLEVBQVU7QUFDUmdaLFlBQUFBLGFBQWEsR0FBRyxTQUFoQjtBQUNIOztBQUNEVCxVQUFBQSxTQUFTLEdBQUcsTUFBTSxLQUFLQyxZQUFMLENBQWtCUSxhQUFsQixFQUFpQ0EsYUFBakMsRUFBZ0RoRyxNQUFoRCxFQUF3RG5XLEVBQXhELEVBQTREOEQsVUFBNUQsRUFBd0U7QUFDdEZ2QixZQUFBQSxPQUFPLEVBQUU7QUFENkUsV0FBeEUsQ0FBbEI7QUFHSDtBQUNKOztBQUNEeVQsTUFBQUEsTUFBTSxDQUFDdkosTUFBUCxDQUFja08sSUFBZCxDQUFtQixxQkFBbkIsRUFBMEMzYSxFQUExQyxFQUE4Q3FhLFVBQTlDO0FBQ0EsV0FBS2pELFdBQUwsQ0FBaUJzQyxNQUFqQixFQUF5QnBaLEdBQXpCLEVBQThCTixFQUE5QixFQUFrQ3VCLE9BQWxDOztBQUNBLGdCQUEyQztBQUN2QyxjQUFNOGEsT0FBTyxHQUFHLEtBQUtsRSxVQUFMLENBQWdCLE9BQWhCLEVBQXlCMUIsU0FBekM7QUFDQXRRLFFBQUFBLE1BQU0sQ0FBQ21XLElBQVAsQ0FBWUMsYUFBWixHQUE0QkYsT0FBTyxDQUFDbE4sZUFBUixLQUE0QmtOLE9BQU8sQ0FBQ2pOLG1CQUFwQyxJQUEyRCxDQUFDc00sU0FBUyxDQUFDakYsU0FBVixDQUFvQnRILGVBQTVHO0FBQ0g7O0FBQ0QsVUFBSTVOLE9BQU8sQ0FBQ3FZLEVBQVIsSUFBYzFELFNBQVMsS0FBSyxTQUE1QixJQUF5QyxDQUFDLENBQUMzYSxHQUFHLEdBQUcwSyxJQUFJLENBQUN1UyxhQUFMLENBQW1CNVYsS0FBMUIsTUFBcUMsSUFBckMsSUFBNkNySCxHQUFHLEtBQUssS0FBSyxDQUExRCxHQUE4RCxLQUFLLENBQW5FLEdBQXVFLENBQUNrZ0IsSUFBSSxHQUFHbGdCLEdBQUcsQ0FBQ3FnQixTQUFaLE1BQTJCLElBQTNCLElBQW1DSCxJQUFJLEtBQUssS0FBSyxDQUFqRCxHQUFxRCxLQUFLLENBQTFELEdBQThEQSxJQUFJLENBQUNlLFVBQTNJLE1BQTJKLEdBQXBNLEtBQTRNNVosS0FBSyxLQUFLLElBQVYsSUFBa0JBLEtBQUssS0FBSyxLQUFLLENBQWpDLEdBQXFDLEtBQUssQ0FBMUMsR0FBOENBLEtBQUssQ0FBQ2daLFNBQWhRLENBQUosRUFBZ1I7QUFDNVE7QUFDQTtBQUNBaFosUUFBQUEsS0FBSyxDQUFDZ1osU0FBTixDQUFnQlksVUFBaEIsR0FBNkIsR0FBN0I7QUFDSCxPQTlDRCxDQStDQTs7O0FBQ0EsWUFBTUMsbUJBQW1CLEdBQUdsYixPQUFPLENBQUNnQixPQUFSLElBQW1CLEtBQUtxSCxLQUFMLEtBQWVBLEtBQTlEOztBQUNBLFVBQUk4UyxPQUFKOztBQUNBLFlBQU1DLFlBQVksR0FBRyxDQUFDRCxPQUFPLEdBQUduYixPQUFPLENBQUNpQixNQUFuQixNQUErQixJQUEvQixJQUF1Q2thLE9BQU8sS0FBSyxLQUFLLENBQXhELEdBQTREQSxPQUE1RCxHQUFzRSxDQUFDRCxtQkFBNUY7QUFDQSxZQUFNRyxXQUFXLEdBQUdELFlBQVksR0FBRztBQUMvQjdpQixRQUFBQSxDQUFDLEVBQUUsQ0FENEI7QUFFL0I0ZCxRQUFBQSxDQUFDLEVBQUU7QUFGNEIsT0FBSCxHQUc1QixJQUhKO0FBSUEsWUFBTSxLQUFLaFgsR0FBTCxDQUFTa0osS0FBVCxFQUFnQnNNLFNBQWhCLEVBQTJCQyxNQUEzQixFQUFtQ3FFLFNBQW5DLEVBQThDa0IsU0FBOUMsRUFBeURuRSxZQUFZLEtBQUssSUFBakIsSUFBeUJBLFlBQVksS0FBSyxLQUFLLENBQS9DLEdBQW1EQSxZQUFuRCxHQUFrRXFGLFdBQTNILEVBQXdJN2hCLEtBQXhJLENBQStJc0gsQ0FBRCxJQUFLO0FBQ3JKLFlBQUlBLENBQUMsQ0FBQ2dILFNBQU4sRUFBaUJ0SSxLQUFLLEdBQUdBLEtBQUssSUFBSXNCLENBQWpCLENBQWpCLEtBQ0ssTUFBTUEsQ0FBTjtBQUNSLE9BSEssQ0FBTjs7QUFJQSxVQUFJdEIsS0FBSixFQUFXO0FBQ1BpVixRQUFBQSxNQUFNLENBQUN2SixNQUFQLENBQWNrTyxJQUFkLENBQW1CLGtCQUFuQixFQUF1QzVaLEtBQXZDLEVBQThDeVosU0FBOUMsRUFBeURILFVBQXpEO0FBQ0EsY0FBTXRaLEtBQU47QUFDSDs7QUFDRCxVQUFJcEosS0FBSixFQUFxQyxFQUlwQzs7QUFDRHFlLE1BQUFBLE1BQU0sQ0FBQ3ZKLE1BQVAsQ0FBY2tPLElBQWQsQ0FBbUIscUJBQW5CLEVBQTBDM2EsRUFBMUMsRUFBOENxYSxVQUE5QztBQUNBLGFBQU8sSUFBUDtBQUNILEtBdEVELENBc0VFLE9BQU8xRCxJQUFQLEVBQWE7QUFDWCxVQUFJQSxJQUFJLENBQUN0TixTQUFULEVBQW9CO0FBQ2hCLGVBQU8sS0FBUDtBQUNIOztBQUNELFlBQU1zTixJQUFOO0FBQ0g7QUFDSjs7QUFDRFMsRUFBQUEsV0FBVyxDQUFDc0MsTUFBRCxFQUFTcFosR0FBVCxFQUFjTixFQUFkLEVBQWtCdUIsT0FBTyxHQUFHLEVBQTVCLEVBQ1I7QUFDQyxjQUEyQztBQUN2QyxVQUFJLE9BQU80RSxNQUFNLENBQUM2TyxPQUFkLEtBQTBCLFdBQTlCLEVBQTJDO0FBQ3ZDcFosUUFBQUEsT0FBTyxDQUFDbUYsS0FBUixDQUFlLDJDQUFmO0FBQ0E7QUFDSDs7QUFDRCxVQUFJLE9BQU9vRixNQUFNLENBQUM2TyxPQUFQLENBQWUwRSxNQUFmLENBQVAsS0FBa0MsV0FBdEMsRUFBbUQ7QUFDL0M5ZCxRQUFBQSxPQUFPLENBQUNtRixLQUFSLENBQWUsMkJBQTBCMlksTUFBTyxtQkFBaEQ7QUFDQTtBQUNIO0FBQ0o7O0FBQ0QsUUFBSUEsTUFBTSxLQUFLLFdBQVgsSUFBMEIsQ0FBQyxHQUFHMUosTUFBSixFQUFZcUgsTUFBWixPQUF5QnJYLEVBQXZELEVBQTJEO0FBQ3ZELFdBQUtrWSxRQUFMLEdBQWdCM1csT0FBTyxDQUFDZ0IsT0FBeEI7QUFDQTRELE1BQUFBLE1BQU0sQ0FBQzZPLE9BQVAsQ0FBZTBFLE1BQWYsRUFBdUI7QUFDbkJwWixRQUFBQSxHQURtQjtBQUVuQk4sUUFBQUEsRUFGbUI7QUFHbkJ1QixRQUFBQSxPQUhtQjtBQUluQitWLFFBQUFBLEdBQUcsRUFBRSxJQUpjO0FBS25CRSxRQUFBQSxHQUFHLEVBQUUsS0FBS1AsSUFBTCxHQUFZeUMsTUFBTSxLQUFLLFdBQVgsR0FBeUIsS0FBS3pDLElBQTlCLEdBQXFDLEtBQUtBLElBQUwsR0FBWTtBQUwvQyxPQUF2QixFQU1HO0FBQ0g7QUFDQTtBQUNBLFFBVEEsRUFTSWpYLEVBVEo7QUFVSDtBQUNKOztBQUN5QixRQUFwQitjLG9CQUFvQixDQUFDamMsR0FBRCxFQUFNc1EsUUFBTixFQUFnQlksS0FBaEIsRUFBdUJoUyxFQUF2QixFQUEyQnFhLFVBQTNCLEVBQXVDMkMsYUFBdkMsRUFBc0Q7QUFDNUUsUUFBSWxjLEdBQUcsQ0FBQ3VJLFNBQVIsRUFBbUI7QUFDZjtBQUNBLFlBQU12SSxHQUFOO0FBQ0g7O0FBQ0QsUUFBSSxDQUFDLEdBQUc4TyxZQUFKLEVBQWtCN0ksWUFBbEIsQ0FBK0JqRyxHQUEvQixLQUF1Q2tjLGFBQTNDLEVBQTBEO0FBQ3REaEgsTUFBQUEsTUFBTSxDQUFDdkosTUFBUCxDQUFja08sSUFBZCxDQUFtQixrQkFBbkIsRUFBdUM3WixHQUF2QyxFQUE0Q2QsRUFBNUMsRUFBZ0RxYSxVQUFoRCxFQURzRCxDQUV0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBbFUsTUFBQUEsTUFBTSxDQUFDK1MsUUFBUCxDQUFnQmpaLElBQWhCLEdBQXVCRCxFQUF2QixDQVBzRCxDQVF0RDtBQUNBOztBQUNBLFlBQU0yUSxzQkFBc0IsRUFBNUI7QUFDSDs7QUFDRCxRQUFJO0FBQ0EsVUFBSStGLFVBQUo7QUFDQSxVQUFJck0sV0FBSjtBQUNBLFVBQUl6SCxLQUFKOztBQUNBLFVBQUksT0FBTzhULFVBQVAsS0FBc0IsV0FBdEIsSUFBcUMsT0FBT3JNLFdBQVAsS0FBdUIsV0FBaEUsRUFBNkU7QUFDekUsU0FBQztBQUFFdUssVUFBQUEsSUFBSSxFQUFFOEIsVUFBUjtBQUFxQnJNLFVBQUFBO0FBQXJCLFlBQXNDLE1BQU0sS0FBSytSLGNBQUwsQ0FBb0IsU0FBcEIsQ0FBN0M7QUFDSDs7QUFDRCxZQUFNVixTQUFTLEdBQUc7QUFDZDlZLFFBQUFBLEtBRGM7QUFFZDZULFFBQUFBLFNBQVMsRUFBRUMsVUFGRztBQUdkck0sUUFBQUEsV0FIYztBQUlkdkosUUFBQUEsR0FKYztBQUtkQyxRQUFBQSxLQUFLLEVBQUVEO0FBTE8sT0FBbEI7O0FBT0EsVUFBSSxDQUFDNGEsU0FBUyxDQUFDOVksS0FBZixFQUFzQjtBQUNsQixZQUFJO0FBQ0E4WSxVQUFBQSxTQUFTLENBQUM5WSxLQUFWLEdBQWtCLE1BQU0sS0FBS3VNLGVBQUwsQ0FBcUJ1SCxVQUFyQixFQUFpQztBQUNyRDVWLFlBQUFBLEdBRHFEO0FBRXJEc1EsWUFBQUEsUUFGcUQ7QUFHckRZLFlBQUFBO0FBSHFELFdBQWpDLENBQXhCO0FBS0gsU0FORCxDQU1FLE9BQU9pTCxNQUFQLEVBQWU7QUFDYnJoQixVQUFBQSxPQUFPLENBQUNtRixLQUFSLENBQWMseUNBQWQsRUFBeURrYyxNQUF6RDtBQUNBdkIsVUFBQUEsU0FBUyxDQUFDOVksS0FBVixHQUFrQixFQUFsQjtBQUVIO0FBQ0o7O0FBQ0QsYUFBTzhZLFNBQVA7QUFDSCxLQTVCRCxDQTRCRSxPQUFPd0IsWUFBUCxFQUFxQjtBQUNuQixhQUFPLEtBQUtILG9CQUFMLENBQTBCRyxZQUExQixFQUF3QzlMLFFBQXhDLEVBQWtEWSxLQUFsRCxFQUF5RGhTLEVBQXpELEVBQTZEcWEsVUFBN0QsRUFBeUUsSUFBekUsQ0FBUDtBQUNIO0FBQ0o7O0FBQ2lCLFFBQVpzQixZQUFZLENBQUMvUixLQUFELEVBQVF3SCxRQUFSLEVBQWtCWSxLQUFsQixFQUF5QmhTLEVBQXpCLEVBQTZCOEQsVUFBN0IsRUFBeUN1VyxVQUF6QyxFQUFxRDtBQUNuRSxRQUFJO0FBQ0EsWUFBTThDLGlCQUFpQixHQUFHLEtBQUtoRixVQUFMLENBQWdCdk8sS0FBaEIsQ0FBMUI7O0FBQ0EsVUFBSXlRLFVBQVUsQ0FBQzlYLE9BQVgsSUFBc0I0YSxpQkFBdEIsSUFBMkMsS0FBS3ZULEtBQUwsS0FBZUEsS0FBOUQsRUFBcUU7QUFDakUsZUFBT3VULGlCQUFQO0FBQ0g7O0FBQ0QsWUFBTUMsZUFBZSxHQUFHRCxpQkFBaUIsSUFBSSxhQUFhQSxpQkFBbEMsR0FBc0QvbUIsU0FBdEQsR0FBa0UrbUIsaUJBQTFGO0FBQ0EsWUFBTXpCLFNBQVMsR0FBRzBCLGVBQWUsR0FBR0EsZUFBSCxHQUFxQixNQUFNLEtBQUtoQixjQUFMLENBQW9CeFMsS0FBcEIsRUFBMkI1TyxJQUEzQixDQUFpQ29OLEdBQUQsS0FBUTtBQUM1RnFPLFFBQUFBLFNBQVMsRUFBRXJPLEdBQUcsQ0FBQ3dNLElBRDZFO0FBRTVGdkssUUFBQUEsV0FBVyxFQUFFakMsR0FBRyxDQUFDaUMsV0FGMkU7QUFHNUZnTyxRQUFBQSxPQUFPLEVBQUVqUSxHQUFHLENBQUNpVixHQUFKLENBQVFoRixPQUgyRTtBQUk1RkMsUUFBQUEsT0FBTyxFQUFFbFEsR0FBRyxDQUFDaVYsR0FBSixDQUFRL0U7QUFKMkUsT0FBUixDQUFoQyxDQUE1RDtBQU9BLFlBQU07QUFBRTdCLFFBQUFBLFNBQVMsRUFBRUMsVUFBYjtBQUEwQjJCLFFBQUFBLE9BQTFCO0FBQW9DQyxRQUFBQTtBQUFwQyxVQUFpRG9ELFNBQXZEOztBQUNBLGdCQUEyQztBQUN2QyxjQUFNO0FBQUU0QixVQUFBQTtBQUFGLFlBQTBCMXBCLG1CQUFPLENBQUMsMEJBQUQsQ0FBdkM7O0FBQ0EsWUFBSSxDQUFDMHBCLGtCQUFrQixDQUFDNUcsVUFBRCxDQUF2QixFQUFxQztBQUNqQyxnQkFBTSxJQUFJdGMsS0FBSixDQUFXLHlEQUF3RGdYLFFBQVMsR0FBNUUsQ0FBTjtBQUNIO0FBQ0o7O0FBQ0QsVUFBSTBFLFFBQUo7O0FBQ0EsVUFBSXVDLE9BQU8sSUFBSUMsT0FBZixFQUF3QjtBQUNwQnhDLFFBQUFBLFFBQVEsR0FBRyxLQUFLUSxVQUFMLENBQWdCaUgsV0FBaEIsQ0FBNEIsQ0FBQyxHQUFHdk4sTUFBSixFQUFZb0Qsb0JBQVosQ0FBaUM7QUFDcEVoQyxVQUFBQSxRQURvRTtBQUVwRVksVUFBQUE7QUFGb0UsU0FBakMsQ0FBNUIsRUFHUGxPLFVBSE8sRUFHS3VVLE9BSEwsRUFHYyxLQUFLM1csTUFIbkIsQ0FBWDtBQUlIOztBQUNELFlBQU1rQixLQUFLLEdBQUcsTUFBTSxLQUFLNGEsUUFBTCxDQUFjLE1BQUluRixPQUFPLEdBQUcsS0FBS29GLGNBQUwsQ0FBb0IzSCxRQUFwQixDQUFILEdBQW1Dd0MsT0FBTyxHQUFHLEtBQUtvRixjQUFMLENBQW9CNUgsUUFBcEIsQ0FBSCxHQUFtQyxLQUFLM0csZUFBTCxDQUFxQnVILFVBQXJCLEVBQWlDO0FBQ3ZKO0FBQ0l0RixRQUFBQSxRQURKO0FBRUlZLFFBQUFBLEtBRko7QUFHSTJCLFFBQUFBLE1BQU0sRUFBRTNULEVBSFo7QUFJSTBCLFFBQUFBLE1BQU0sRUFBRSxLQUFLQSxNQUpqQjtBQUtJeUQsUUFBQUEsT0FBTyxFQUFFLEtBQUtBLE9BTGxCO0FBTUlJLFFBQUFBLGFBQWEsRUFBRSxLQUFLQTtBQU54QixPQURzSCxDQUF0RyxDQUFwQjtBQVVBbVcsTUFBQUEsU0FBUyxDQUFDOVksS0FBVixHQUFrQkEsS0FBbEI7QUFDQSxXQUFLdVYsVUFBTCxDQUFnQnZPLEtBQWhCLElBQXlCOFIsU0FBekI7QUFDQSxhQUFPQSxTQUFQO0FBQ0gsS0F4Q0QsQ0F3Q0UsT0FBT2lDLElBQVAsRUFBYTtBQUNYLGFBQU8sS0FBS1osb0JBQUwsQ0FBMEJZLElBQTFCLEVBQWdDdk0sUUFBaEMsRUFBMENZLEtBQTFDLEVBQWlEaFMsRUFBakQsRUFBcURxYSxVQUFyRCxDQUFQO0FBQ0g7QUFDSjs7QUFDRDNaLEVBQUFBLEdBQUcsQ0FBQ2tKLEtBQUQsRUFBUXdILFFBQVIsRUFBa0JZLEtBQWxCLEVBQXlCaFMsRUFBekIsRUFBNkIyVixJQUE3QixFQUFtQ2lILFdBQW5DLEVBQWdEO0FBQy9DLFNBQUsvRixVQUFMLEdBQWtCLEtBQWxCO0FBQ0EsU0FBS2pOLEtBQUwsR0FBYUEsS0FBYjtBQUNBLFNBQUt3SCxRQUFMLEdBQWdCQSxRQUFoQjtBQUNBLFNBQUtZLEtBQUwsR0FBYUEsS0FBYjtBQUNBLFNBQUsyQixNQUFMLEdBQWMzVCxFQUFkO0FBQ0EsV0FBTyxLQUFLNmEsTUFBTCxDQUFZbEYsSUFBWixFQUFrQmlILFdBQWxCLENBQVA7QUFDSDtBQUNEO0FBQ0o7QUFDQTtBQUNBOzs7QUFBTWdCLEVBQUFBLGNBQWMsQ0FBQ3hYLEVBQUQsRUFBSztBQUNqQixTQUFLNFIsSUFBTCxHQUFZNVIsRUFBWjtBQUNIOztBQUNEc1UsRUFBQUEsZUFBZSxDQUFDMWEsRUFBRCxFQUFLO0FBQ2hCLFFBQUksQ0FBQyxLQUFLMlQsTUFBVixFQUFrQixPQUFPLEtBQVA7QUFDbEIsVUFBTSxDQUFDa0ssWUFBRCxFQUFlQyxPQUFmLElBQTBCLEtBQUtuSyxNQUFMLENBQVlILEtBQVosQ0FBa0IsR0FBbEIsQ0FBaEM7QUFDQSxVQUFNLENBQUN1SyxZQUFELEVBQWVDLE9BQWYsSUFBMEJoZSxFQUFFLENBQUN3VCxLQUFILENBQVMsR0FBVCxDQUFoQyxDQUhnQixDQUloQjs7QUFDQSxRQUFJd0ssT0FBTyxJQUFJSCxZQUFZLEtBQUtFLFlBQTVCLElBQTRDRCxPQUFPLEtBQUtFLE9BQTVELEVBQXFFO0FBQ2pFLGFBQU8sSUFBUDtBQUNILEtBUGUsQ0FRaEI7OztBQUNBLFFBQUlILFlBQVksS0FBS0UsWUFBckIsRUFBbUM7QUFDL0IsYUFBTyxLQUFQO0FBQ0gsS0FYZSxDQVloQjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsV0FBT0QsT0FBTyxLQUFLRSxPQUFuQjtBQUNIOztBQUNEcEQsRUFBQUEsWUFBWSxDQUFDNWEsRUFBRCxFQUFLO0FBQ2IsVUFBTSxHQUFHZ1UsSUFBSCxJQUFXaFUsRUFBRSxDQUFDd1QsS0FBSCxDQUFTLEdBQVQsQ0FBakIsQ0FEYSxDQUViO0FBQ0E7O0FBQ0EsUUFBSVEsSUFBSSxLQUFLLEVBQVQsSUFBZUEsSUFBSSxLQUFLLEtBQTVCLEVBQW1DO0FBQy9CN04sTUFBQUEsTUFBTSxDQUFDOFgsUUFBUCxDQUFnQixDQUFoQixFQUFtQixDQUFuQjtBQUNBO0FBQ0gsS0FQWSxDQVFiOzs7QUFDQSxVQUFNQyxJQUFJLEdBQUdyVyxRQUFRLENBQUNzVyxjQUFULENBQXdCbkssSUFBeEIsQ0FBYjs7QUFDQSxRQUFJa0ssSUFBSixFQUFVO0FBQ05BLE1BQUFBLElBQUksQ0FBQ0UsY0FBTDtBQUNBO0FBQ0gsS0FiWSxDQWNiO0FBQ0E7OztBQUNBLFVBQU1DLE1BQU0sR0FBR3hXLFFBQVEsQ0FBQ3lXLGlCQUFULENBQTJCdEssSUFBM0IsRUFBaUMsQ0FBakMsQ0FBZjs7QUFDQSxRQUFJcUssTUFBSixFQUFZO0FBQ1JBLE1BQUFBLE1BQU0sQ0FBQ0QsY0FBUDtBQUNIO0FBQ0o7O0FBQ0RsRCxFQUFBQSxRQUFRLENBQUN2SCxNQUFELEVBQVM7QUFDYixXQUFPLEtBQUtBLE1BQUwsS0FBZ0JBLE1BQXZCO0FBQ0g7QUFDRDtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUFvQixRQUFSdFMsUUFBUSxDQUFDZixHQUFELEVBQU1xVCxNQUFNLEdBQUdyVCxHQUFmLEVBQW9CaUIsT0FBTyxHQUFHLEVBQTlCLEVBQ2I7QUFDQyxRQUFJdVosTUFBTSxHQUFHLENBQUMsR0FBRzVLLGlCQUFKLEVBQXVCNEgsZ0JBQXZCLENBQXdDeFgsR0FBeEMsQ0FBYjtBQUNBLFFBQUk7QUFBRThRLE1BQUFBLFFBQVEsRUFBRW1OO0FBQVosUUFBMkJ6RCxNQUEvQjs7QUFDQSxRQUFJbmpCLEtBQUosRUFBcUMsRUFXcEM7O0FBQ0QsVUFBTTZjLEtBQUssR0FBRyxNQUFNLEtBQUs4QixVQUFMLENBQWdCMEUsV0FBaEIsRUFBcEI7QUFDQSxRQUFJbFgsVUFBVSxHQUFHNlAsTUFBakI7O0FBQ0EsUUFBSWhjLEtBQUosRUFBK0QsRUFBL0QsTUFhTztBQUNIbWpCLE1BQUFBLE1BQU0sQ0FBQzFKLFFBQVAsR0FBa0JtRCxtQkFBbUIsQ0FBQ3VHLE1BQU0sQ0FBQzFKLFFBQVIsRUFBa0JvRCxLQUFsQixDQUFyQzs7QUFDQSxVQUFJc0csTUFBTSxDQUFDMUosUUFBUCxLQUFvQm1OLFNBQXhCLEVBQW1DO0FBQy9CQSxRQUFBQSxTQUFTLEdBQUd6RCxNQUFNLENBQUMxSixRQUFuQjtBQUNBMEosUUFBQUEsTUFBTSxDQUFDMUosUUFBUCxHQUFrQm1OLFNBQWxCO0FBQ0FqZSxRQUFBQSxHQUFHLEdBQUcsQ0FBQyxHQUFHMFAsTUFBSixFQUFZb0Qsb0JBQVosQ0FBaUMwSCxNQUFqQyxDQUFOO0FBQ0g7QUFDSjs7QUFDRCxVQUFNbFIsS0FBSyxHQUFHLENBQUMsR0FBRytGLHVCQUFKLEVBQTZCakssdUJBQTdCLENBQXFENlksU0FBckQsQ0FBZCxDQXRDRCxDQXVDQzs7QUFDQSxjQUEyQztBQUN2QztBQUNIOztBQUNELFVBQU0xakIsT0FBTyxDQUFDNkIsR0FBUixDQUFZLENBQ2QsS0FBSzRaLFVBQUwsQ0FBZ0JrSSxNQUFoQixDQUF1QjVVLEtBQXZCLEVBQThCNU8sSUFBOUIsQ0FBb0N5akIsS0FBRCxJQUFTO0FBQ3hDLGFBQU9BLEtBQUssR0FBRyxLQUFLaEIsY0FBTCxDQUFvQixLQUFLbkgsVUFBTCxDQUFnQmlILFdBQWhCLENBQTRCamQsR0FBNUIsRUFBaUN3RCxVQUFqQyxFQUE2QyxJQUE3QyxFQUFtRCxPQUFPdkMsT0FBTyxDQUFDRyxNQUFmLEtBQTBCLFdBQTFCLEdBQXdDSCxPQUFPLENBQUNHLE1BQWhELEdBQXlELEtBQUtBLE1BQWpILENBQXBCLENBQUgsR0FBbUosS0FBL0o7QUFDSCxLQUZELENBRGMsRUFJZCxLQUFLNFUsVUFBTCxDQUFnQi9VLE9BQU8sQ0FBQ3JGLFFBQVIsR0FBbUIsVUFBbkIsR0FBZ0MsVUFBaEQsRUFBNEQwTixLQUE1RCxDQUpjLENBQVosQ0FBTjtBQU1IOztBQUNtQixRQUFkd1MsY0FBYyxDQUFDeFMsS0FBRCxFQUFRO0FBQ3hCLFFBQUlQLFNBQVMsR0FBRyxLQUFoQjs7QUFDQSxVQUFNcVYsTUFBTSxHQUFHLEtBQUsvRixHQUFMLEdBQVcsTUFBSTtBQUMxQnRQLE1BQUFBLFNBQVMsR0FBRyxJQUFaO0FBQ0gsS0FGRDs7QUFHQSxVQUFNc1YsZUFBZSxHQUFHLE1BQU0sS0FBS3JJLFVBQUwsQ0FBZ0JzSSxRQUFoQixDQUF5QmhWLEtBQXpCLENBQTlCOztBQUNBLFFBQUlQLFNBQUosRUFBZTtBQUNYLFlBQU10SSxLQUFLLEdBQUcsSUFBSTNHLEtBQUosQ0FBVyx3Q0FBdUN3UCxLQUFNLEdBQXhELENBQWQ7QUFDQTdJLE1BQUFBLEtBQUssQ0FBQ3NJLFNBQU4sR0FBa0IsSUFBbEI7QUFDQSxZQUFNdEksS0FBTjtBQUNIOztBQUNELFFBQUkyZCxNQUFNLEtBQUssS0FBSy9GLEdBQXBCLEVBQXlCO0FBQ3JCLFdBQUtBLEdBQUwsR0FBVyxJQUFYO0FBQ0g7O0FBQ0QsV0FBT2dHLGVBQVA7QUFDSDs7QUFDRG5CLEVBQUFBLFFBQVEsQ0FBQ3hTLEVBQUQsRUFBSztBQUNULFFBQUkzQixTQUFTLEdBQUcsS0FBaEI7O0FBQ0EsVUFBTXFWLE1BQU0sR0FBRyxNQUFJO0FBQ2ZyVixNQUFBQSxTQUFTLEdBQUcsSUFBWjtBQUNILEtBRkQ7O0FBR0EsU0FBS3NQLEdBQUwsR0FBVytGLE1BQVg7QUFDQSxXQUFPMVQsRUFBRSxHQUFHaFEsSUFBTCxDQUFXMmEsSUFBRCxJQUFRO0FBQ3JCLFVBQUkrSSxNQUFNLEtBQUssS0FBSy9GLEdBQXBCLEVBQXlCO0FBQ3JCLGFBQUtBLEdBQUwsR0FBVyxJQUFYO0FBQ0g7O0FBQ0QsVUFBSXRQLFNBQUosRUFBZTtBQUNYLGNBQU1zVSxJQUFJLEdBQUcsSUFBSXZqQixLQUFKLENBQVUsaUNBQVYsQ0FBYjtBQUNBdWpCLFFBQUFBLElBQUksQ0FBQ3RVLFNBQUwsR0FBaUIsSUFBakI7QUFDQSxjQUFNc1UsSUFBTjtBQUNIOztBQUNELGFBQU9oSSxJQUFQO0FBQ0gsS0FWTSxDQUFQO0FBV0g7O0FBQ0Q4SCxFQUFBQSxjQUFjLENBQUMzSCxRQUFELEVBQVc7QUFDckIsVUFBTTtBQUFFN1YsTUFBQUEsSUFBSSxFQUFFNGU7QUFBUixRQUFzQixJQUFJdGUsR0FBSixDQUFRdVYsUUFBUixFQUFrQjNQLE1BQU0sQ0FBQytTLFFBQVAsQ0FBZ0JqWixJQUFsQyxDQUE1Qjs7QUFDQSxRQUFJLEtBQUosRUFBb0YsRUFFbkY7O0FBQ0QsV0FBTzRWLGFBQWEsQ0FBQ0MsUUFBRCxFQUFXLEtBQUtpQyxLQUFoQixDQUFiLENBQW9DL2MsSUFBcEMsQ0FBMEMyYSxJQUFELElBQVE7QUFDcEQsV0FBS29CLEdBQUwsQ0FBUzhILFFBQVQsSUFBcUJsSixJQUFyQjtBQUNBLGFBQU9BLElBQVA7QUFDSCxLQUhNLENBQVA7QUFJSDs7QUFDRCtILEVBQUFBLGNBQWMsQ0FBQzVILFFBQUQsRUFBVztBQUNyQixVQUFNO0FBQUU3VixNQUFBQSxJQUFJLEVBQUU2ZTtBQUFSLFFBQXlCLElBQUl2ZSxHQUFKLENBQVF1VixRQUFSLEVBQWtCM1AsTUFBTSxDQUFDK1MsUUFBUCxDQUFnQmpaLElBQWxDLENBQS9COztBQUNBLFFBQUksS0FBSytXLEdBQUwsQ0FBUzhILFdBQVQsQ0FBSixFQUEyQjtBQUN2QixhQUFPLEtBQUs5SCxHQUFMLENBQVM4SCxXQUFULENBQVA7QUFDSDs7QUFDRCxXQUFPLEtBQUs5SCxHQUFMLENBQVM4SCxXQUFULElBQXdCakosYUFBYSxDQUFDQyxRQUFELEVBQVcsS0FBS2lDLEtBQWhCLENBQWIsQ0FBb0MvYyxJQUFwQyxDQUEwQzJhLElBQUQsSUFBUTtBQUM1RSxhQUFPLEtBQUtxQixHQUFMLENBQVM4SCxXQUFULENBQVA7QUFDQSxhQUFPbkosSUFBUDtBQUNILEtBSDhCLEVBRzVCNWEsS0FINEIsQ0FHckI0aUIsSUFBRCxJQUFRO0FBQ2IsYUFBTyxLQUFLM0csR0FBTCxDQUFTOEgsV0FBVCxDQUFQO0FBQ0EsWUFBTW5CLElBQU47QUFDSCxLQU44QixDQUEvQjtBQU9IOztBQUNEeE8sRUFBQUEsZUFBZSxDQUFDc0gsU0FBRCxFQUFZc0ksR0FBWixFQUFpQjtBQUM1QixVQUFNO0FBQUV0SSxNQUFBQSxTQUFTLEVBQUV1STtBQUFiLFFBQXVCLEtBQUs3RyxVQUFMLENBQWdCLE9BQWhCLENBQTdCOztBQUNBLFVBQU04RyxPQUFPLEdBQUcsS0FBS3JHLFFBQUwsQ0FBY29HLElBQWQsQ0FBaEI7O0FBQ0FELElBQUFBLEdBQUcsQ0FBQ0UsT0FBSixHQUFjQSxPQUFkO0FBQ0EsV0FBTyxDQUFDLEdBQUdqUCxNQUFKLEVBQVlrUCxtQkFBWixDQUFnQ0YsSUFBaEMsRUFBc0M7QUFDekNDLE1BQUFBLE9BRHlDO0FBRXpDeEksTUFBQUEsU0FGeUM7QUFHekNuVixNQUFBQSxNQUFNLEVBQUUsSUFIaUM7QUFJekN5ZCxNQUFBQTtBQUp5QyxLQUF0QyxDQUFQO0FBTUg7O0FBQ0R4RSxFQUFBQSxrQkFBa0IsQ0FBQ3ZhLEVBQUQsRUFBS3FhLFVBQUwsRUFBaUI7QUFDL0IsUUFBSSxLQUFLMUIsR0FBVCxFQUFjO0FBQ1YzQyxNQUFBQSxNQUFNLENBQUN2SixNQUFQLENBQWNrTyxJQUFkLENBQW1CLGtCQUFuQixFQUF1Q2hLLHNCQUFzQixFQUE3RCxFQUFpRTNRLEVBQWpFLEVBQXFFcWEsVUFBckU7QUFDQSxXQUFLMUIsR0FBTDtBQUNBLFdBQUtBLEdBQUwsR0FBVyxJQUFYO0FBQ0g7QUFDSjs7QUFDRGtDLEVBQUFBLE1BQU0sQ0FBQ2xGLElBQUQsRUFBT2lILFdBQVAsRUFBb0I7QUFDdEIsV0FBTyxLQUFLbEUsR0FBTCxDQUFTL0MsSUFBVCxFQUFlLEtBQUt3QyxVQUFMLENBQWdCLE9BQWhCLEVBQXlCMUIsU0FBeEMsRUFBbURtRyxXQUFuRCxDQUFQO0FBQ0g7O0FBdnZCUTs7QUF5dkJiNUcsTUFBTSxDQUFDdkosTUFBUCxHQUFnQixDQUFDLEdBQUdzRCxLQUFKLEVBQVd2YyxPQUFYLEVBQWhCO0FBQ0FGLGVBQUEsR0FBa0IwaUIsTUFBbEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdmlDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7OztBQUlBLE1BQU1zSyxXQUFXLEdBQUdsQix3RUFBSDtBQUFBO0FBQUE7QUFBQSx3QkFBakI7QUFJQSxNQUFNb0IsbUJBQW1CLEdBQUc3b0IsT0FBTyxDQUFDQyxHQUFSLENBQVk2b0IsdUNBQXhDO0FBQ0EsTUFBTUMsU0FBUyxHQUFHL29CLE9BQU8sQ0FBQ0MsR0FBUixDQUFZK29CLDRCQUE5Qjs7QUFFQSxNQUFNQyxJQUFjLEdBQUcsTUFBTTtBQUMzQixRQUFNO0FBQUEsT0FBQ0MsV0FBRDtBQUFBLE9BQWNDO0FBQWQsTUFBZ0M5UywrQ0FBUSxDQUFDLEVBQUQsQ0FBOUM7QUFDQSxRQUFNO0FBQUEsT0FBQytTLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCaFQsK0NBQVEsRUFBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQ2lULFdBQUQ7QUFBQSxPQUFjQztBQUFkLE1BQWdDbFQsK0NBQVEsQ0FBQyxDQUFELENBQTlDO0FBQ0EsUUFBTTtBQUFBLE9BQUNtVCxPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUF3QnBULCtDQUFRLENBQUMsRUFBRCxDQUF0QztBQUNBLFFBQU07QUFBQSxPQUFDcVQsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJ0VCwrQ0FBUSxDQUFDO0FBQUVtVCxJQUFBQSxPQUFPLEVBQUUsRUFBWDtBQUFlSSxJQUFBQSxPQUFPLEVBQUUsQ0FBeEI7QUFBMkJDLElBQUFBLE9BQU8sRUFBRTtBQUFwQyxHQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUN0VSxPQUFEO0FBQUEsT0FBV3VVO0FBQVgsTUFBeUJ6VCwrQ0FBUSxDQUFDLEVBQUQsQ0FBdkM7QUFFQSxRQUFNMFQsZUFBZSxHQUFHO0FBQ3RCQyxJQUFBQSxhQUFhLEVBQUU7QUFDYkMsTUFBQUEsT0FBTyxFQUFFekIsc0VBREk7QUFDbUI7QUFDaEM1ZSxNQUFBQSxPQUFPLEVBQUU7QUFDUHNnQixRQUFBQSxRQUFRLEVBQUVuQixTQURILENBQ2E7O0FBRGI7QUFGSTtBQURPLEdBQXhCO0FBbUJBLE1BQUlvQixTQUFpQixHQUFHO0FBQ3RCQyxJQUFBQSxZQUFZLEVBQUUsRUFEUTtBQUV0QkMsSUFBQUEsY0FBYyxFQUFFLEVBRk07QUFHdEJDLElBQUFBLFlBQVksRUFBRSxFQUhRO0FBSXRCQyxJQUFBQSxjQUFjLEVBQUUsQ0FKTTtBQUt0QkMsSUFBQUEsT0FBTyxFQUFFLEVBTGE7QUFNdEJDLElBQUFBLGVBQWUsRUFBRSxLQU5LO0FBT3RCQyxJQUFBQSxrQkFBa0IsRUFBRTtBQVBFLEdBQXhCLENBM0IyQixDQXNDM0I7O0FBQ0EsUUFBTUMsV0FBVyxHQUFHLE9BQU9qZ0IsQ0FBUCxFQUFja2dCLFVBQWQsRUFBaUNDLFFBQWpDLEtBQXNEO0FBQ3hFO0FBRUE7QUFDQSxRQUFJQyxVQUFVLEdBQUdELFFBQVEsR0FBRyxJQUFILEdBQVUsSUFBbkMsQ0FKd0UsQ0FLeEU7O0FBQ0E1bUIsSUFBQUEsT0FBTyxDQUFDOG1CLEdBQVIsQ0FBWSx3QkFBWixFQUFzQ0gsVUFBdEMsRUFBa0RFLFVBQWxELEVBTndFLENBT3hFOztBQUVBN21CLElBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVksa0JBQVosRUFBZ0NsQyxtQkFBaEM7QUFDQTVrQixJQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLDJCQUFaLEVBQXlDdEMsa0VBQWEsRUFBdEQ7O0FBQ0EsUUFBR1csUUFBSCxFQUFZO0FBQ1YsVUFBSTRCLE1BQU0sR0FBRzVCLFFBQVEsQ0FBQzZCLFNBQVQsRUFBYjtBQUNBLFlBQU1DLGNBQWMsR0FBRyxNQUFNRixNQUFNLENBQUNHLFVBQVAsRUFBN0I7QUFDQWxuQixNQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZRyxjQUFaO0FBRUEsWUFBTUUsV0FBVyxHQUFHLE1BQU0xQyxtRUFBYyxDQUFDc0MsTUFBRCxDQUF4Qzs7QUFDQSxVQUFJO0FBQ0Y7QUFDQSxjQUFNSyxLQUFLLEdBQUcvQyw0REFBQSxDQUF3QixDQUFDd0MsVUFBVSxHQUFDRixVQUFaLEVBQXdCM2tCLFFBQXhCLEVBQXhCLENBQWQ7QUFDQWhDLFFBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVksaUJBQVosRUFBK0JNLEtBQUssQ0FBQ3BsQixRQUFOLEVBQS9CO0FBQ0EsWUFBSXVsQixPQUFPLEdBQUcsTUFBTUosV0FBVyxDQUFDSyxJQUFaLENBQWlCYixVQUFqQixFQUE2QkMsUUFBN0IsRUFBdUM7QUFBQ2p2QixVQUFBQSxLQUFLLEVBQUV5dkI7QUFBUixTQUF2QyxFQUNuQmhvQixJQURtQixDQUNiLE1BQU9xb0IsRUFBUCxJQUFtQjtBQUN0QixpQkFBT0EsRUFBRSxDQUFDQyxJQUFILEdBQVV0b0IsSUFBVixDQUFnQm1vQixPQUFELElBQWtCO0FBQ3RDdm5CLFlBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVksVUFBWixFQUF3QlMsT0FBeEI7QUFDQSxnQkFBSUksUUFBa0IsR0FBRyxFQUF6QjtBQUNBSixZQUFBQSxPQUFPLENBQUMxVyxNQUFSLENBQWVwWCxPQUFmLENBQXdCdU0sS0FBRCxJQUFnQjtBQUNyQzJoQixjQUFBQSxRQUFRLENBQUM1cUIsSUFBVCxDQUFjNnFCLE1BQU0sQ0FBQzVoQixLQUFLLENBQUNrQixJQUFOLENBQVcsQ0FBWCxDQUFELENBQXBCO0FBQ0QsYUFGRCxFQUhzQyxDQU10QztBQUNBO0FBQ0E7O0FBQ0EsZ0JBQUk7QUFDRixrQkFBRyxDQUFDMGYsUUFBSixFQUNJVixTQUFTLENBQUNFLGNBQVYsR0FBMkJ1QixRQUEzQjtBQUNKLGtCQUFHZixRQUFILEVBQ0lWLFNBQVMsQ0FBQ0csWUFBVixHQUF5QnNCLFFBQXpCO0FBQ0p6QixjQUFBQSxTQUFTLENBQUNDLFlBQVYsR0FBeUJWLFFBQVEsQ0FBQ0YsT0FBbEM7QUFDQVcsY0FBQUEsU0FBUyxDQUFDSSxjQUFWLEdBQTJCc0IsTUFBTSxDQUFDZixVQUFVLEdBQUNGLFVBQVosQ0FBakM7QUFDQVQsY0FBQUEsU0FBUyxDQUFDTyxrQkFBVixHQUErQm1CLE1BQU0sQ0FBQyxJQUFJbGQsSUFBSixFQUFELENBQXJDO0FBRUEsa0JBQUltZCxRQUFRLEdBQUdoWixLQUFLLENBQUMsYUFBRCxFQUFnQjtBQUNoQ2lQLGdCQUFBQSxNQUFNLEVBQUUsTUFEd0I7QUFFaEN6USxnQkFBQUEsSUFBSSxFQUFFbk0sSUFBSSxDQUFDQyxTQUFMLENBQWUra0IsU0FBZjtBQUYwQixlQUFoQixDQUFwQjtBQUlELGFBYkQsQ0FhRSxPQUFPaGhCLEdBQVAsRUFBWTtBQUNabEYsY0FBQUEsT0FBTyxDQUFDOG1CLEdBQVIsQ0FBWSxzQ0FBWixFQUFvRDVoQixHQUFwRDtBQUNEOztBQUVELG1CQUFPO0FBQ0wyVSxjQUFBQSxNQUFNLEVBQUUsU0FESDtBQUVMRSxjQUFBQSxJQUFJLEVBQUUsYUFBWTROLFFBQVEsQ0FBQzNsQixRQUFULEVBRmI7QUFHTG1ELGNBQUFBLEtBQUssRUFBRTtBQUhGLGFBQVA7QUFLRCxXQS9CTSxDQUFQO0FBZ0NILFNBbENtQixFQWtDaEJBLEtBQUQsSUFBZ0I7QUFDakJuRixVQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLGtCQUFaLEVBQWdDM2hCLEtBQWhDO0FBQ0EsY0FBSTJpQixPQUFPLEdBQUczaUIsS0FBSyxDQUFDbU0sT0FBTixDQUFjdlMsVUFBZCxDQUF5QixVQUF6QixJQUF1Q29HLEtBQUssQ0FBQ21NLE9BQTdDLEdBQXNEbk0sS0FBSyxDQUFDQSxLQUFOLENBQVltTSxPQUFaLEdBQXNCbk0sS0FBSyxDQUFDQSxLQUFOLENBQVltTSxPQUFsQyxHQUE0Q25NLEtBQUssQ0FBQ21NLE9BQXRIO0FBQ0EsaUJBQU87QUFDTHVJLFlBQUFBLE1BQU0sRUFBRSxRQURIO0FBRUxFLFlBQUFBLElBQUksRUFBRSxFQUZEO0FBR0w1VSxZQUFBQSxLQUFLLEVBQUUyaUI7QUFIRixXQUFQO0FBS0QsU0ExQ21CLENBQXBCO0FBNENBOW5CLFFBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVksMkJBQVosRUFBeUNTLE9BQXpDO0FBQ0EsWUFBR0EsT0FBTyxDQUFDMU4sTUFBUixLQUFtQixRQUF0QixFQUNFZ00sVUFBVSxDQUFDMEIsT0FBTyxDQUFDcGlCLEtBQVQsQ0FBVixDQURGLEtBRUswZ0IsVUFBVSxDQUFDMEIsT0FBTyxDQUFDeE4sSUFBVCxDQUFWO0FBQ04sT0FwREQsQ0FvREUsT0FBTzdVLEdBQVAsRUFBaUI7QUFDakJsRixRQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLGlCQUFaLEVBQStCNWhCLEdBQUcsQ0FBQ29NLE9BQW5DO0FBQ0F1VSxRQUFBQSxVQUFVLENBQUMscUJBQW9CM2dCLEdBQUcsQ0FBQ29NLE9BQXpCLENBQVY7QUFDRDtBQUNGLEtBOURELE1BK0RJO0FBQ0Z0UixNQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLHdCQUFaO0FBQ0FpQixNQUFBQSxLQUFLLENBQUMsbUNBQUQsQ0FBTDtBQUNEO0FBQ0YsR0E5RUQsQ0F2QzJCLENBdUgzQjs7O0FBQ0EsUUFBTUMsZUFBZSxHQUFHLFlBQVk7QUFFbENob0IsSUFBQUEsT0FBTyxDQUFDOG1CLEdBQVIsQ0FBWSwyQkFBWjs7QUFFQSxRQUFHLENBQUNyQixRQUFRLENBQUNGLE9BQWIsRUFBcUI7QUFDbkIsVUFBSTBDLFNBQVMsR0FBRyxJQUFJM0QsbURBQUosQ0FBYztBQUM1QjtBQUNBNEQsUUFBQUEsYUFBYSxFQUFFLEtBRmE7QUFFTjtBQUN0QnBDLFFBQUFBLGVBSDRCLENBR1g7O0FBSFcsT0FBZCxDQUFoQjtBQUtBbUMsTUFBQUEsU0FBUyxDQUFDRSxtQkFBVjtBQUNBLFVBQUlDLFlBQVksR0FBRyxNQUFNSCxTQUFTLENBQUNJLE9BQVYsRUFBekI7QUFDQXJvQixNQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLHFCQUFaLEVBQW1Dc0IsWUFBbkM7QUFFQUEsTUFBQUEsWUFBWSxHQUFHLElBQUloRSxtRUFBSixDQUFpQmdFLFlBQWpCLENBQWY7QUFDQXBvQixNQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLGdCQUFaLEVBQThCc0IsWUFBOUI7QUFDQWhELE1BQUFBLFdBQVcsQ0FBQ2dELFlBQUQsQ0FBWDs7QUFFQSxVQUFJQSxZQUFKLEVBQWtCO0FBQ2hCLFlBQUlFLFdBQVcsR0FBRyxNQUFNRixZQUFZLENBQUNHLFVBQWIsRUFBeEI7QUFDQXZvQixRQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLGdCQUFaLEVBQThCd0IsV0FBOUI7QUFDQXRvQixRQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLE9BQVosRUFBcUJ3QixXQUFXLENBQUM3VSxJQUFqQzs7QUFDQSxZQUFHNlUsV0FBVyxDQUFDN1UsSUFBWixLQUFxQixTQUF4QixFQUFrQztBQUNoQ29TLFVBQUFBLFVBQVUsQ0FBQyxrQ0FBRCxDQUFWO0FBQ0E3bEIsVUFBQUEsT0FBTyxDQUFDOG1CLEdBQVIsQ0FBWSxrQ0FBWjtBQUNEOztBQUVELFlBQUlDLE1BQU0sR0FBR3FCLFlBQVksQ0FBQ3BCLFNBQWIsRUFBYjtBQUNBaG5CLFFBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVksU0FBWixFQUF1QkMsTUFBdkI7QUFFQSxZQUFJdm5CLEdBQUcsR0FBRyxNQUFNdW5CLE1BQU0sQ0FBQ0csVUFBUCxFQUFoQjtBQUNBbG5CLFFBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVksV0FBWixFQUF5QnRuQixHQUF6QjtBQUNBLFlBQUlncEIsR0FBRyxHQUFHWixNQUFNLENBQUN2RCw2REFBQSxDQUF5QixDQUFDLE1BQU0wQyxNQUFNLENBQUMyQixVQUFQLEVBQVAsRUFBNEIxbUIsUUFBNUIsRUFBekIsQ0FBRCxDQUFoQjtBQUVBaEMsUUFBQUEsT0FBTyxDQUFDOG1CLEdBQVIsQ0FBWSxXQUFaLEVBQXlCdG5CLEdBQXpCO0FBQ0FRLFFBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVksVUFBWixFQUF1QjBCLEdBQXZCO0FBQ0F0RCxRQUFBQSxjQUFjLENBQUNvRCxXQUFXLENBQUM3VSxJQUFiLENBQWQ7QUFDQStSLFFBQUFBLFVBQVUsQ0FBQ2htQixHQUFELENBQVY7QUFDQThsQixRQUFBQSxjQUFjLENBQUNrRCxHQUFELENBQWQ7QUFDQTlDLFFBQUFBLFdBQVcsQ0FBQztBQUFDSCxVQUFBQSxPQUFPLEVBQUUvbEIsR0FBVjtBQUFlbW1CLFVBQUFBLE9BQU8sRUFBRTZDLEdBQXhCO0FBQTZCNUMsVUFBQUEsT0FBTyxFQUFFMEMsV0FBVyxDQUFDN1U7QUFBbEQsU0FBRCxDQUFYLENBckJnQixDQXNCaEI7QUFDRDtBQUNGLEtBdENELE1Bc0NLO0FBQ0h6VCxNQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLHVCQUFaLEVBREcsQ0FFSDs7QUFDQXBCLE1BQUFBLFdBQVcsQ0FBQztBQUFDSCxRQUFBQSxPQUFPLEVBQUUsRUFBVjtBQUFjSSxRQUFBQSxPQUFPLEVBQUUsQ0FBdkI7QUFBMEJDLFFBQUFBLE9BQU8sRUFBRTtBQUFuQyxPQUFELENBQVg7QUFDRDtBQUNGLEdBL0NEOztBQWlEQSxzQkFDRTtBQUFBLDRCQUNFLCtEQUFDLGtEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFNLFlBQUksRUFBQyxVQUFYO0FBQXNCLGVBQU8sRUFBQztBQUE5QixTQUEwRSxVQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGLGVBR0U7QUFBTSxZQUFJLEVBQUMsYUFBWDtBQUF5QixlQUFPLEVBQUM7QUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFIRixlQUlFO0FBQU0sWUFBSSxFQUFDLFFBQVg7QUFBb0IsZUFBTyxFQUFDO0FBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkYsZUFLRTtBQUFNLGlCQUFTLEVBQUMsY0FBaEI7QUFBK0IsZUFBTyxFQUFDO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEYsZUFNRTtBQUFNLFlBQUksRUFBQyxVQUFYO0FBQXNCLGVBQU8sRUFBQztBQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5GLGVBT0U7QUFBTSxnQkFBUSxFQUFDLFVBQWY7QUFBMEIsZUFBTyxFQUFDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUEYsZUFRRTtBQUFNLGdCQUFRLEVBQUMsZ0JBQWY7QUFBZ0MsZUFBTyxFQUFDO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUkYsZUFTRTtBQUFNLGdCQUFRLEVBQUMsVUFBZjtBQUEwQixlQUFPLEVBQUM7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURixlQVVFO0FBQU0sZ0JBQVEsRUFBQyxRQUFmO0FBQXdCLGVBQU8sRUFBQztBQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVZGLGVBV0U7QUFBTSxZQUFJLEVBQUMsY0FBWDtBQUEwQixlQUFPLEVBQUM7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFYRixlQVlFO0FBQU0sZ0JBQVEsRUFBQyxjQUFmO0FBQThCLGVBQU8sRUFBQztBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpGLGVBYUU7QUFBTSxZQUFJLEVBQUMsbUJBQVg7QUFBK0IsZUFBTyxFQUFDO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYkYsZUFjRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQWtCRSwrREFBQyxXQUFEO0FBQUEsOEJBQ0UsK0RBQUMseUVBQUQsa0NBQVlILFFBQVo7QUFBc0IsdUJBQWUsRUFBRXVDO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRSwrREFBQywwRUFBRCxrQ0FBVXZDLFFBQVY7QUFBb0IsZ0JBQVEsRUFBRU4sUUFBOUI7QUFBd0MsbUJBQVcsRUFBRXVCO0FBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkYsZUFLRSwrREFBQyx1RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGLGVBTUUsK0RBQUMsaUZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFORixlQU9FLCtEQUFDLHFGQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUEYsZUFRRSwrREFBQyxzRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJGLGVBU0UsK0RBQUMsMEVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURixlQVVFLCtEQUFDLGdGQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVkYsZUFXRSwrREFBQyxvRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVhGLGVBWUUsK0RBQUMsdUVBQUQsb0JBQVlqQixRQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWxCRjtBQUFBLGtCQURGO0FBbUNELENBNU1EOztBQThNQSxpRUFBZVQsSUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdPQTtBQUNBO0FBQ0E7QUFDQTtDQUVBOzs7QUFFQSxJQUFJOEQsWUFBWSxHQUFHLENBQ2pCO0FBQ0VDLEVBQUFBLEtBQUssRUFBRztBQURWLENBRGlCLEVBSWpCO0FBQ0VBLEVBQUFBLEtBQUssRUFBRztBQURWLENBSmlCLEVBT2pCO0FBQ0VBLEVBQUFBLEtBQUssRUFBRztBQURWLENBUGlCLEVBVWpCO0FBQ0VBLEVBQUFBLEtBQUssRUFBRztBQURWLENBVmlCLEVBYWpCO0FBQ0VBLEVBQUFBLEtBQUssRUFBRztBQURWLENBYmlCLEVBZ0JqQjtBQUNFQSxFQUFBQSxLQUFLLEVBQUc7QUFEVixDQWhCaUIsRUFtQmpCO0FBQ0VBLEVBQUFBLEtBQUssRUFBRztBQURWLENBbkJpQixDQUFuQixFQXlCQTs7QUFFQSxNQUFNQyxXQUFXLEdBQUd4RiwyRUFBSDtBQUFBO0FBQUE7QUFBQSwyQkFBakI7QUFJQSxNQUFNMEYsUUFBUSxHQUFHMUYsdUVBQUg7QUFBQTtBQUFBO0FBQUEscUpBQWQ7QUFnQkEsTUFBTTRGLEtBQUssR0FBRzVGLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHVDQUFYO0FBS0EsTUFBTTZGLFNBQVMsR0FBRzdGLHFFQUFIO0FBQUE7QUFBQTtBQUFBLHNRQVVFcUYsNkVBVkYsRUFhRUEsNEVBYkYsRUFnQklBLDRFQWhCSixDQUFmOztBQW9CQSxNQUFNYyxJQUFJLEdBQUcsQ0FBQztBQUFFWixFQUFBQTtBQUFGLENBQUQsS0FBbUM7QUFDOUMsc0JBQ0UsOERBQUMsUUFBRDtBQUFBLDJCQUNFLDhEQUFDLG1EQUFEO0FBQ0UsU0FBRyxFQUFHLFFBQU9BLEtBQU0sTUFEckI7QUFFRSxTQUFHLEVBQUMsT0FGTjtBQUdFLFdBQUssRUFBRSxHQUhUO0FBSUUsWUFBTSxFQUFFO0FBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQVVELENBWEQsRUFhQTs7O0FBRUEsTUFBTTVFLGVBQWUsR0FBRyxNQUFNO0FBQzVCdmIsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ2RnaEIsSUFBQUEsU0FBUztBQUNWLEdBRlEsQ0FBVDs7QUFJQSxRQUFNQSxTQUFTLEdBQUcsTUFBTTtBQUN0QixRQUFJQyxPQUFPLEdBQUcsS0FBZDtBQUNBLFFBQUlDLEtBQUosRUFBbUJDLFNBQW5CLEVBQXNDQyxVQUF0QyxFQUEwRHpPLEtBQTFELEVBQXlFMWlCLE1BQXpFO0FBQ0EsUUFBSW94QixJQUFJLEdBQUdoZSxRQUFRLENBQUNzVyxjQUFULENBQXdCLGFBQXhCLENBQVg7QUFDQSxRQUFJMkgsYUFBYSxHQUFHLElBQXBCLENBSnNCLENBSUk7O0FBRTFCRCxJQUFBQSxJQUFJLENBQUN2TSxnQkFBTCxDQUFzQixXQUF0QixFQUFvQ3lNLEVBQUQsSUFBZTtBQUNoREEsTUFBQUEsRUFBRSxDQUFDcmpCLGNBQUg7QUFDQW1qQixNQUFBQSxJQUFJLEdBQUdoZSxRQUFRLENBQUNzVyxjQUFULENBQXdCLGFBQXhCLENBQVA7QUFDQTFwQixNQUFBQSxNQUFNLEdBQUdveEIsSUFBSSxDQUFDNXFCLEtBQUwsQ0FBVytxQixTQUFwQjtBQUNBSixNQUFBQSxVQUFVLEdBQUcsQ0FBQ0MsSUFBSSxDQUFDN2hCLFFBQUwsQ0FBY3BQLE1BQWQsR0FBdUIsQ0FBeEIsSUFBNkJreEIsYUFBMUM7QUFDQTNPLE1BQUFBLEtBQUssR0FBR3ZlLFFBQVEsQ0FBQ25FLE1BQU0sQ0FBQ3VZLFNBQVAsQ0FBaUIsRUFBakIsRUFBcUJ2WSxNQUFNLENBQUNpQixPQUFQLENBQWUsR0FBZixJQUFzQixDQUEzQyxDQUFELENBQWhCO0FBQ0ErdkIsTUFBQUEsT0FBTyxHQUFHLElBQVY7QUFDQUMsTUFBQUEsS0FBSyxHQUFHLENBQVI7QUFDRCxLQVJEO0FBVUFHLElBQUFBLElBQUksQ0FBQ3ZNLGdCQUFMLENBQXNCLFdBQXRCLEVBQW9DeU0sRUFBRCxJQUFhO0FBQzlDQSxNQUFBQSxFQUFFLENBQUNyakIsY0FBSDs7QUFDQSxVQUFJK2lCLE9BQUosRUFBYTtBQUNYRSxRQUFBQSxTQUFTLEdBQUdJLEVBQUUsQ0FBQ0UsU0FBSCxHQUFlLENBQWYsR0FBbUIsQ0FBQyxDQUFwQixHQUF3QixDQUFwQztBQUNBUCxRQUFBQSxLQUFLLEdBQUdBLEtBQUssR0FBR0MsU0FBUyxHQUFHLENBQTVCO0FBQ0FFLFFBQUFBLElBQUksQ0FBQzVxQixLQUFMLENBQVcrcUIsU0FBWCxHQUF3QixjQUFhN08sS0FBSyxHQUFHdU8sS0FBSyxHQUFHLENBQUUsS0FBaEMsQ0FBcUNwakIsT0FBckMsQ0FDckIsSUFEcUIsRUFFckIsR0FGcUIsQ0FBdkI7QUFJRDtBQUNGLEtBVkQ7QUFXQXVqQixJQUFBQSxJQUFJLENBQUN2TSxnQkFBTCxDQUFzQixTQUF0QixFQUFrQ3lNLEVBQUQsSUFBZTtBQUM5QyxZQUFNRyxlQUFlLEdBQUdMLElBQUksQ0FBQ00sVUFBTCxDQUFnQkMsV0FBeEM7QUFDQSxZQUFNQyxlQUFlLEdBQUdSLElBQUksQ0FBQzdoQixRQUFMLENBQWNwUCxNQUF0QztBQUNBLFlBQU0weEIsWUFBWSxHQUFHLENBQUNKLGVBQWUsR0FBR0csZUFBbEIsR0FBb0NsZ0IsTUFBTSxDQUFDb2dCLFVBQTNDLEdBQXdELENBQXpELElBQThELENBQUMsR0FBcEY7QUFDQSxZQUFNQyxnQkFBZ0IsR0FBRyxDQUF6QjtBQUVBVCxNQUFBQSxFQUFFLENBQUNyakIsY0FBSDtBQUNBK2lCLE1BQUFBLE9BQU8sR0FBRyxLQUFWO0FBQ0FDLE1BQUFBLEtBQUssR0FBRyxDQUFSOztBQUNBLFVBQUlDLFNBQVMsS0FBSyxDQUFsQixFQUFxQjtBQUNuQnhPLFFBQUFBLEtBQUssR0FBR3FQLGdCQUFSO0FBQ0QsT0FGRCxNQUVPO0FBQ0xyUCxRQUFBQSxLQUFLLEdBQUdtUCxZQUFSO0FBQ0Q7O0FBQ0RULE1BQUFBLElBQUksQ0FBQzVxQixLQUFMLENBQVd3ckIsVUFBWCxHQUF5QixrQkFBekI7QUFDQVosTUFBQUEsSUFBSSxDQUFDNXFCLEtBQUwsQ0FBVytxQixTQUFYLEdBQXdCLGNBQWE3TyxLQUFNLEtBQXBCLENBQXlCN1UsT0FBekIsQ0FBaUMsSUFBakMsRUFBdUMsR0FBdkMsQ0FBdkI7QUFDQWtFLE1BQUFBLFVBQVUsQ0FBQyxNQUFNO0FBQ2ZxZixRQUFBQSxJQUFJLENBQUM1cUIsS0FBTCxDQUFXd3JCLFVBQVgsR0FBd0IsRUFBeEI7QUFDRCxPQUZTLEVBRVAsR0FGTyxDQUFWO0FBR0QsS0FuQkQ7QUFvQkQsR0EvQ0Q7O0FBaURBLFFBQU1DLFlBQVksR0FBRyxNQUFNO0FBQ3pCLFVBQU1aLGFBQWEsR0FBRyxHQUF0QjtBQUNBLFVBQU0xWCxPQUFPLEdBQUd2RyxRQUFRLENBQUNzVyxjQUFULENBQXdCLGFBQXhCLENBQWhCO0FBQ0EsVUFBTXlILFVBQVUsR0FBRyxDQUFDeFgsT0FBTyxDQUFDcEssUUFBUixDQUFpQnBQLE1BQWpCLEdBQTBCLENBQTNCLElBQWdDa3hCLGFBQW5EO0FBQ0EsVUFBTXJ4QixNQUFNLEdBQUcyWixPQUFPLENBQUNuVCxLQUFSLENBQWMrcUIsU0FBN0I7QUFDQSxVQUFNVyxlQUFlLEdBQUcvdEIsUUFBUSxDQUM5Qm5FLE1BQU0sQ0FBQ3VZLFNBQVAsQ0FBaUIsRUFBakIsRUFBcUJ2WSxNQUFNLENBQUNpQixPQUFQLENBQWUsR0FBZixJQUFzQixDQUEzQyxDQUQ4QixDQUFoQztBQUlBLFVBQU13d0IsZUFBZSxHQUFHOVgsT0FBTyxDQUFDK1gsVUFBUixDQUFtQkMsV0FBM0M7QUFDQSxVQUFNQyxlQUFlLEdBQUdqWSxPQUFPLENBQUNwSyxRQUFSLENBQWlCcFAsTUFBekM7QUFFQSxVQUFNMHhCLFlBQVksR0FBRyxDQUFDSixlQUFlLEdBQUdHLGVBQWxCLEdBQW9DbGdCLE1BQU0sQ0FBQ29nQixVQUEzQyxHQUF3RCxDQUF6RCxJQUE4RCxDQUFDLEdBQXBGO0FBQ0EsVUFBTUMsZ0JBQWdCLEdBQUcsQ0FBekI7QUFFQSxXQUFPO0FBQ0xWLE1BQUFBLGFBQWEsRUFBRUEsYUFEVjtBQUVMMVgsTUFBQUEsT0FBTyxFQUFFQSxPQUZKO0FBR0x1WSxNQUFBQSxlQUFlLEVBQUVBLGVBSFo7QUFJTEwsTUFBQUEsWUFBWSxFQUFFQSxZQUpUO0FBS0xFLE1BQUFBLGdCQUFnQixFQUFFQSxnQkFMYjtBQU1MWixNQUFBQSxVQUFVLEVBQUVBO0FBTlAsS0FBUDtBQVFELEdBdkJEOztBQXlCQSxRQUFNZ0IsUUFBUSxHQUFHcEMsNkRBQVksQ0FBQztBQUM1QnFDLElBQUFBLFNBQVMsRUFBRSxDQUFDO0FBQUVDLE1BQUFBLE1BQUY7QUFBVUMsTUFBQUE7QUFBVixLQUFELEtBQXFCO0FBQzlCLFVBQUlBLEdBQUcsS0FBSyxNQUFSLElBQWtCLE9BQXRCLEVBQStCO0FBQzdCLGNBQU07QUFBRUosVUFBQUEsZUFBRjtBQUFtQnZZLFVBQUFBO0FBQW5CLFlBQStCc1ksWUFBWSxFQUFqRDtBQUNBLGNBQU1NLEtBQUssR0FBRyxJQUFJbHVCLElBQUksQ0FBQ211QixJQUFMLENBQVVILE1BQVYsQ0FBbEI7QUFDQTFZLFFBQUFBLE9BQU8sQ0FBQ25ULEtBQVIsQ0FBYytxQixTQUFkLEdBQTJCLGNBQWFXLGVBQWUsR0FBR0ssS0FBTSxLQUFoRTtBQUNEO0FBQ0YsS0FQMkI7QUFRNUJFLElBQUFBLFlBQVksRUFBRSxNQUFNO0FBQ2xCLFlBQU07QUFBRVosUUFBQUEsWUFBRjtBQUFnQmxZLFFBQUFBO0FBQWhCLFVBQTRCc1ksWUFBWSxFQUE5QztBQUNBdFksTUFBQUEsT0FBTyxDQUFDblQsS0FBUixDQUFjd3JCLFVBQWQsR0FBNEIsa0JBQTVCO0FBQ0FyWSxNQUFBQSxPQUFPLENBQUNuVCxLQUFSLENBQWMrcUIsU0FBZCxHQUEyQixjQUFhTSxZQUFhLEtBQXJEO0FBQ0E5ZixNQUFBQSxVQUFVLENBQUMsTUFBTTtBQUNmNEgsUUFBQUEsT0FBTyxDQUFDblQsS0FBUixDQUFjd3JCLFVBQWQsR0FBMkIsRUFBM0I7QUFDRCxPQUZTLEVBRVAsR0FGTyxDQUFWO0FBR0QsS0FmMkI7QUFnQjVCVSxJQUFBQSxhQUFhLEVBQUUsTUFBTTtBQUNuQixZQUFNO0FBQUVYLFFBQUFBLGdCQUFGO0FBQW9CcFksUUFBQUE7QUFBcEIsVUFBZ0NzWSxZQUFZLEVBQWxEO0FBQ0F0WSxNQUFBQSxPQUFPLENBQUNuVCxLQUFSLENBQWN3ckIsVUFBZCxHQUE0QixrQkFBNUI7QUFDQXJZLE1BQUFBLE9BQU8sQ0FBQ25ULEtBQVIsQ0FBYytxQixTQUFkLEdBQTJCLGNBQWFRLGdCQUFpQixLQUF6RDtBQUNBaGdCLE1BQUFBLFVBQVUsQ0FBQyxNQUFNO0FBQ2Y0SCxRQUFBQSxPQUFPLENBQUNuVCxLQUFSLENBQWN3ckIsVUFBZCxHQUEyQixFQUEzQjtBQUNELE9BRlMsRUFFUCxHQUZPLENBQVY7QUFHRCxLQXZCMkI7QUF3QjVCVyxJQUFBQSxLQUFLLEVBQUUsRUF4QnFCO0FBeUI1QkMsSUFBQUEsNEJBQTRCLEVBQUUsS0F6QkY7QUEwQjVCQyxJQUFBQSxVQUFVLEVBQUU7QUExQmdCLEdBQUQsQ0FBN0I7QUE2QkEsc0JBQ0UsOERBQUMsV0FBRDtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLFNBQWY7QUFBQSw2QkFDRSw4REFBQyxLQUFEO0FBQ0UsVUFBRSxFQUFDLGFBREw7QUFFRSxhQUFLLEVBQUU7QUFBRXRCLFVBQUFBLFNBQVMsRUFBRTtBQUFiO0FBRlQsU0FHTVksUUFITjtBQUFBLGtCQUtHbEMsWUFBWSxDQUFDdnJCLEdBQWIsQ0FBa0JpVixPQUFELElBQWE7QUFDN0IsOEJBQ0UsOERBQUMsSUFBRDtBQUVFLGlCQUFLLEVBQUVBLE9BQU8sQ0FBQ3VXO0FBRmpCLGFBQ092VyxPQUFPLENBQUN1VyxLQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREY7QUFNRCxTQVBBO0FBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFpQkUsOERBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUF5QkQsQ0FySUQ7O0FBdUlBLGlFQUFlNUUsZUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RPQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNd0gsT0FBTyxHQUFHbkksMkVBQUg7QUFBQTtBQUFBO0FBQUEsb0tBQWI7QUFjQSxNQUFNb0ksU0FBUyxHQUFHcEksdUVBQUg7QUFBQTtBQUFBO0FBQUEsK0ZBQWY7QUFTQSxNQUFNcUksUUFBUSxHQUFHckksc0VBQUg7QUFBQTtBQUFBO0FBQUEsK1VBRU1xRiw2RUFGTixFQU9RQSw2RUFQUixFQVVRQSw2RUFWUixFQWFRQSw0RUFiUixFQWlCUUEsNEVBakJSLENBQWQ7QUF1QkEsTUFBTXFELEtBQUssR0FBRzFJLHdEQUFNLENBQUNxSSxRQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEsOE1BQ0loRCw2RUFESixFQUdNQSw2RUFITixFQU1NQSw2RUFOTixFQVNNQSw0RUFUTixFQVlNQSw0RUFaTixDQUFYO0FBaUJBLE1BQU1zRCxRQUFRLEdBQUczSSxxRUFBSDtBQUFBO0FBQUE7QUFBQSxvUEFFQ3FGLDZFQUZELEVBTUdBLDZFQU5ILEVBU0dBLDZFQVRILEVBWUdBLDRFQVpILEVBZUdBLDRFQWZILENBQWQ7QUFtQkEsTUFBTXVELFNBQVMsR0FBRzVJLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDRPQUFmO0FBZ0JBLE1BQU02SSxRQUFRLEdBQUc3SSx1RUFBSDtBQUFBO0FBQUE7QUFBQSwrRkFBZDtBQVNBLE1BQU04SSxRQUFRLEdBQUc5SSx1RUFBSDtBQUFBO0FBQUE7QUFBQSw0U0FBZDtBQW9CQSxNQUFNK0ksWUFBWSxHQUFHL0ksdUVBQUg7QUFBQTtBQUFBO0FBQUEsMExBQWxCOztBQXlCQSxNQUFNZ0osS0FBSyxHQUFHLENBQUM7QUFBRXpELEVBQUFBLEtBQUY7QUFBUzBELEVBQUFBLEtBQVQ7QUFBZ0J2c0IsRUFBQUE7QUFBaEIsQ0FBRCxLQUEyQztBQUN2RCxzQkFDRSw4REFBQyxRQUFEO0FBQUEsNEJBQ0UsOERBQUMsUUFBRDtBQUFBLDZCQUNFLDhEQUFDLG1EQUFEO0FBQ0UsYUFBSyxFQUFFLEdBRFQ7QUFFRSxjQUFNLEVBQUUsR0FGVjtBQUdFLFdBQUcsRUFBRyxRQUFPNm9CLEtBQU0sRUFIckI7QUFJRSxXQUFHLEVBQUM7QUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVNFLDhEQUFDLEtBQUQ7QUFBQSxnQkFBUTBEO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFURixlQVVFLDhEQUFDLFFBQUQ7QUFBQSxnQkFBV3ZzQjtBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFjRCxDQWZEOztBQWlCQSxNQUFNNGpCLFNBQVMsR0FBRyxNQUFNO0FBQ3RCLHNCQUNFLDhEQUFDLE9BQUQ7QUFBQSw0QkFDRSw4REFBQyxTQUFEO0FBQUEsOEJBQ0UsOERBQUMsUUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFLDhEQUFDLFNBQUQ7QUFBQSxnQ0FDRSw4REFBQyxLQUFEO0FBQU8sZUFBSyxFQUFDLGFBQWI7QUFBMkIsZUFBSyxFQUFDLFlBQWpDO0FBQThDLGtCQUFRLEVBQUM7QUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFLDhEQUFDLEtBQUQ7QUFBTyxlQUFLLEVBQUMsV0FBYjtBQUF5QixlQUFLLEVBQUMsVUFBL0I7QUFBMEMsa0JBQVEsRUFBQztBQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBR0UsOERBQUMsS0FBRDtBQUFPLGVBQUssRUFBQyxXQUFiO0FBQXlCLGVBQUssRUFBQyxVQUEvQjtBQUEwQyxrQkFBUSxFQUFDO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSEYsZUFJRSw4REFBQyxLQUFEO0FBQU8sZUFBSyxFQUFDLGdCQUFiO0FBQThCLGVBQUssRUFBQyxVQUFwQztBQUErQyxrQkFBUSxFQUFDO0FBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVVFLDhEQUFDLFlBQUQ7QUFBQSw2QkFDRSw4REFBQyxtREFBRDtBQUNFLGFBQUssRUFBRSxJQURUO0FBRUUsY0FBTSxFQUFFLEdBRlY7QUFHRSxXQUFHLEVBQUMsc0JBSE47QUFJRSxXQUFHLEVBQUM7QUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXFCRCxDQXRCRDs7QUF3QkEsaUVBQWVBLFNBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdE1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTTZILE9BQU8sR0FBR25JLDJFQUFIO0FBQUE7QUFBQTtBQUFBLHdNQUFiO0FBYUEsTUFBTW1KLFVBQVUsR0FBR25KLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHlIQUFoQjtBQVdBLE1BQU1vSixVQUFVLEdBQUdwSix1RUFBSDtBQUFBO0FBQUE7QUFBQSw4TUFNSixDQUFDO0FBQUU5aUIsRUFBQUE7QUFBRixDQUFELEtBQWdCQSxNQUFNLEdBQUcsQ0FOckIsRUFnQkYsQ0FBQztBQUFFQSxFQUFBQTtBQUFGLENBQUQsS0FBZ0JBLE1BQU0sR0FBRyxDQWhCdkIsQ0FBaEI7QUFvQkEsTUFBTW1zQixRQUFRLEdBQUdySixzRUFBSDtBQUFBO0FBQUE7QUFBQSwyS0FBZDtBQVlBLE1BQU11SixVQUFVLEdBQUd2Six1RUFBSDtBQUFBO0FBQUE7QUFBQSxnTUFBaEI7QUFtQkEsTUFBTXdKLGdCQUFnQixHQUFHeEosdUVBQUg7QUFBQTtBQUFBO0FBQUEsaUxBQXRCO0FBaUJBLE1BQU15SixxQkFBcUIsR0FBR3pKLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDBJQUEzQjtBQWNBLE1BQU0wSixRQUFRLEdBQUcxSix1RUFBSDtBQUFBO0FBQUE7QUFBQSwrWkFBZDtBQWlDQSxNQUFNMkosUUFBUSxHQUFHM0osc0VBQUg7QUFBQTtBQUFBO0FBQUEsb1NBQ0NxRiw2RUFERCxFQVdHQSw2RUFYSCxFQWVHQSw2RUFmSCxFQWtCR0EsNEVBbEJILEVBcUJLQSw0RUFyQkwsQ0FBZDtBQXlCQSxNQUFNcUQsS0FBSyxHQUFHMUksc0VBQUg7QUFBQTtBQUFBO0FBQUEsa1JBQ0lxRiw2RUFESixFQVFNQSw2RUFSTixFQVlNQSw2RUFaTixFQWVNQSw0RUFmTixFQWtCUUEsNEVBbEJSLENBQVg7QUFzQkEsTUFBTXlFLElBQUksR0FBRzlKLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDhWQUNLcUYsNkVBREwsRUFTT0EsNkVBVFAsRUFhT0EsNkVBYlAsQ0FBVjtBQWdDQSxNQUFNMkUsV0FBVyxHQUFHaEssdUVBQUg7QUFBQTtBQUFBO0FBQUEsZ0dBQWpCO0FBWUEsTUFBTWlLLGdCQUFnQixHQUFHakssdUVBQUg7QUFBQTtBQUFBO0FBQUEseURBQXRCO0FBTUEsTUFBTWtLLFlBQVksR0FBR2xLLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDh1Q0FBbEI7QUFxSEEsTUFBTW1LLFFBQVEsR0FBR25LLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHNmQUFkO0FBc0NBLE1BQU1vSyxZQUFZLEdBQUdwSyx1RUFBSDtBQUFBO0FBQUE7QUFBQSxvTEFBbEI7O0FBa0JBLE1BQU1xSyxRQUFRLEdBQUcsTUFBTTtBQUNyQixzQkFDRSw4REFBQyxZQUFEO0FBQUEsNEJBQ0UsOERBQUMsUUFBRDtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyxtQkFBZjtBQUFBLGdDQUNFLDhEQUFDLEtBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRSw4REFBQyxJQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQU9FLDhEQUFDLFlBQUQ7QUFBYyxpQkFBUyxFQUFDLGtCQUF4QjtBQUFBLCtCQUNFLDhEQUFDLG1EQUFEO0FBQ0UsZUFBSyxFQUFFLEdBRFQ7QUFFRSxnQkFBTSxFQUFFLEdBRlY7QUFHRSxhQUFHLEVBQUMsc0JBSE47QUFJRSxhQUFHLEVBQUM7QUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFpQkUsOERBQUMsUUFBRDtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyxtQkFBZjtBQUFBLGdDQUNFLDhEQUFDLEtBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRSw4REFBQyxJQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBR0UsOERBQUMsSUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFNRSw4REFBQyxZQUFEO0FBQWMsaUJBQVMsRUFBQyxrQkFBeEI7QUFBMkMsVUFBRSxFQUFDLFVBQTlDO0FBQUEsK0JBQ0UsOERBQUMsbURBQUQ7QUFDRSxlQUFLLEVBQUUsR0FEVDtBQUVFLGdCQUFNLEVBQUUsR0FGVjtBQUdFLGFBQUcsRUFBQyxzQkFITjtBQUlFLGFBQUcsRUFBQztBQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFqQkYsZUFnQ0UsOERBQUMsUUFBRDtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyxtQkFBZjtBQUFBLGdDQUNFLDhEQUFDLEtBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRSw4REFBQyxJQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUtFLDhEQUFDLFlBQUQ7QUFBYyxpQkFBUyxFQUFDLGtCQUF4QjtBQUFBLCtCQUNFLDhEQUFDLG1EQUFEO0FBQ0UsZUFBSyxFQUFFLEdBRFQ7QUFFRSxnQkFBTSxFQUFFLEdBRlY7QUFHRSxhQUFHLEVBQUMsc0JBSE47QUFJRSxhQUFHLEVBQUM7QUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaENGLGVBOENFLDhEQUFDLFFBQUQ7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsbUJBQWY7QUFBQSxnQ0FDRSw4REFBQyxLQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUUsOERBQUMsSUFBRDtBQUFBLDJEQUEyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUtFLDhEQUFDLFlBQUQ7QUFBYyxpQkFBUyxFQUFDLGtCQUF4QjtBQUFBLCtCQUNFLDhEQUFDLG1EQUFEO0FBQ0UsZUFBSyxFQUFFLEdBRFQ7QUFFRSxnQkFBTSxFQUFFLEdBRlY7QUFHRSxhQUFHLEVBQUMsc0JBSE47QUFJRSxhQUFHLEVBQUM7QUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOUNGLGVBNERFLDhEQUFDLFFBQUQ7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsbUJBQWY7QUFBQSxnQ0FDRSw4REFBQyxLQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUUsOERBQUMsSUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFLRSw4REFBQyxZQUFEO0FBQWMsaUJBQVMsRUFBQyxrQkFBeEI7QUFBQSwrQkFDRSw4REFBQyxtREFBRDtBQUNFLGVBQUssRUFBRSxHQURUO0FBRUUsZ0JBQU0sRUFBRSxHQUZWO0FBR0UsYUFBRyxFQUFDLHNCQUhOO0FBSUUsYUFBRyxFQUFDO0FBSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTVERixlQTBFRSw4REFBQyxRQUFEO0FBQUEsOEJBQ0U7QUFBSyxpQkFBUyxFQUFDLG1CQUFmO0FBQUEsZ0NBQ0UsOERBQUMsS0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFLDhEQUFDLElBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBS0UsOERBQUMsWUFBRDtBQUFjLGlCQUFTLEVBQUMsa0JBQXhCO0FBQUEsK0JBQ0UsOERBQUMsbURBQUQ7QUFDRSxlQUFLLEVBQUUsR0FEVDtBQUVFLGdCQUFNLEVBQUUsR0FGVjtBQUdFLGFBQUcsRUFBQyxzQkFITjtBQUlFLGFBQUcsRUFBQztBQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUEyRkQsQ0E1RkQ7O0FBOEZBLE1BQU1DLGlCQUFpQixHQUFHLE1BQU07QUFDOUIsc0JBQ0UsOERBQUMsZ0JBQUQ7QUFBQSw0QkFDRSw4REFBQyxRQUFEO0FBQUEsNkJBQ0UsOERBQUMsbURBQUQ7QUFDRSxhQUFLLEVBQUUsTUFBSSxHQURiO0FBRUUsY0FBTSxFQUFFLE1BQUksR0FGZDtBQUdFLFdBQUcsRUFBQyx5QkFITjtBQUlFLFdBQUcsRUFBQztBQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBU0UsOERBQUMsUUFBRDtBQUFBLDhCQUNFLDhEQUFDLFVBQUQ7QUFBWSxXQUFHLEVBQUMsRUFBaEI7QUFBbUIsV0FBRyxFQUFDO0FBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRSw4REFBQyxnQkFBRDtBQUFrQixXQUFHLEVBQUMsRUFBdEI7QUFBeUIsV0FBRyxFQUFDO0FBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkYsZUFHRSw4REFBQyxxQkFBRDtBQUF1QixXQUFHLEVBQUMsRUFBM0I7QUFBOEIsV0FBRyxFQUFDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEYsZUFJRSw4REFBQyxRQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBT0UsOERBQUMsUUFBRDtBQUFBLDJEQUN5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVBGLGVBV0UsOERBQUMsUUFBRDtBQUFBLCtDQUNhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUEyQkQsQ0E1QkQ7O0FBOEJBLE1BQU01SixJQUFJLEdBQUcsTUFBTTtBQUNqQixRQUFNO0FBQUEsT0FBQzZKLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQThCNWIsK0NBQVEsQ0FBQyxDQUFELENBQTVDOztBQUVBLFFBQU02YixpQkFBaUIsR0FBRyxNQUFNO0FBQUE7O0FBQzlCLFVBQU1DLFFBQVEsNEJBQUdqaUIsUUFBUSxDQUFDc1csY0FBVCxDQUF3QixVQUF4QixDQUFILDBEQUFHLHNCQUFxQzRMLG9CQUFyQyxDQUEwRCxLQUExRCxFQUFpRSxDQUFqRSxDQUFqQjtBQUNBLFVBQU1DLFdBQVcsR0FBR0YsUUFBUSxDQUFDRyxZQUE3QjtBQUNBTCxJQUFBQSxhQUFhLENBQUNJLFdBQUQsQ0FBYjtBQUNELEdBSkQ7O0FBTUF4bEIsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ2RxbEIsSUFBQUEsaUJBQWlCO0FBQ2pCMWpCLElBQUFBLE1BQU0sQ0FBQ21ULGdCQUFQLENBQXdCLFFBQXhCLEVBQWtDdVEsaUJBQWxDO0FBQ0EsV0FBTyxNQUFNO0FBQ1gxakIsTUFBQUEsTUFBTSxDQUFDK2pCLG1CQUFQLENBQTJCLFFBQTNCLEVBQXFDTCxpQkFBckM7QUFDRCxLQUZEO0FBR0QsR0FOUSxFQU1OLEVBTk0sQ0FBVDtBQVFBLHNCQUNFLDhEQUFDLE9BQUQ7QUFBQSw0QkFDRSw4REFBQyxVQUFEO0FBQUEsNkJBQ0UsOERBQUMsc0VBQUQ7QUFBYyxlQUFPLEVBQUMsU0FBdEI7QUFBZ0MsZUFBTyxFQUFDLDBCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFNRSw4REFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5GLGVBT0UsOERBQUMsVUFBRDtBQUFZLFlBQU0sRUFBRUYsVUFBcEI7QUFBQSw2QkFDRSw4REFBQyxRQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVBGLGVBVUUsOERBQUMsV0FBRDtBQUFBLDZCQUNFLDhEQUFDLG1EQUFEO0FBQ0UsYUFBSyxFQUFFLElBRFQ7QUFFRSxjQUFNLEVBQUUsR0FGVjtBQUdFLFdBQUcsRUFBQyx3QkFITjtBQUlFLFdBQUcsRUFBQztBQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBcUJELENBdENEOztBQXdDQSxpRUFBZTdKLElBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNua0JBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1xSyxVQUFVLEdBQUcvSyx1RUFBSDtBQUFBO0FBQUE7QUFBQSxxQ0FBaEI7QUFLQSxNQUFNZ0wsWUFBWSxHQUFHaEwsdUVBQUg7QUFBQTtBQUFBO0FBQUEsd0VBQWxCO0FBU0EsTUFBTWlMLFdBQVcsR0FBR2pMLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHdJQUFqQjtBQVlBLE1BQU1rTCxXQUFXLEdBQUdsTCx1RUFBSDtBQUFBO0FBQUE7QUFBQSwrSUFBakI7QUFXQSxNQUFNbUwsY0FBYyxHQUFHbkwsdUVBQUg7QUFBQTtBQUFBO0FBQUEsb1dBQ0xxRiw2RUFESyxFQUVIQSwyRUFGRyxFQWdCSEEsNkVBaEJHLEVBaUJEQSwyRUFqQkMsRUFxQkhBLDZFQXJCRyxFQXNCREEsMkVBdEJDLENBQXBCO0FBZ0NBLE1BQU0rRixZQUFZLEdBQUdwTCx1RUFBSDtBQUFBO0FBQUE7QUFBQSxxQ0FBbEI7QUFLQSxNQUFNcUwsZ0JBQWdCLEdBQUdyTCx1RUFBSDtBQUFBO0FBQUE7QUFBQSx3bUJBQ1BxRiw2RUFETyxFQUVMQSwyRUFGSyxFQWtCTEEsNkVBbEJLLEVBbUJIQSwyRUFuQkcsRUF1QkxBLDZFQXZCSyxFQXdCSEEsMkVBeEJHLEVBOENMQSw0RUE5Q0ssRUErQ0hBLDBFQS9DRyxFQW1ETEEsNEVBbkRLLEVBb0RIQSwwRUFwREcsQ0FBdEI7QUF3REEsTUFBTWlHLFFBQVEsR0FBR3RMLHVFQUFIO0FBQUE7QUFBQTtBQUFBLG1EQUFkO0FBTUEsTUFBTXVMLFlBQVksR0FBR3ZMLHVFQUFIO0FBQUE7QUFBQTtBQUFBLG1hQUNIcUYsNkVBREcsRUFFREEsMkVBRkMsRUFTREEsNkVBVEMsRUFVQ0EsMkVBVkQsRUFjREEsNkVBZEMsRUFlQ0EsMkVBZkQsRUFrQkRBLDRFQWxCQyxFQW1CQ0EsMEVBbkJELEVBc0JEQSw0RUF0QkMsRUF1QkNBLDBFQXZCRCxDQUFsQjs7QUFvQ0EsTUFBTW1HLGNBQWMsR0FBRyxNQUFNO0FBQzNCLHNCQUNFLDhEQUFDLFdBQUQ7QUFBQSw0QkFDRSw4REFBQyxZQUFEO0FBQUEsNkJBQ0UsOERBQUMsbURBQUQ7QUFDRSxhQUFLLEVBQUUsSUFEVDtBQUVFLGNBQU0sRUFBRSxJQUZWO0FBR0UsV0FBRyxFQUFFLHFCQUhQO0FBSUUsV0FBRyxFQUFDO0FBSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFTRSw4REFBQyxXQUFEO0FBQUEsOEJBQ0UsOERBQUMsVUFBRDtBQUFBLCtCQUNFLDhEQUFDLGNBQUQ7QUFBQSxpQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBUUUsOERBQUMsWUFBRDtBQUFBLCtCQUNFLDhEQUFDLGdCQUFEO0FBQUEsaUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSRixlQWlCRSw4REFBQyxRQUFEO0FBQUEsK0JBQ0UsOERBQUMsWUFBRDtBQUFBLGlDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXNDRCxDQXZDRDs7QUF5Q0EsaUVBQWVBLGNBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxTkE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTVIsWUFBWSxHQUFHaEwsdUVBQUg7QUFBQTtBQUFBO0FBQUEsa0VBQWxCO0FBUUEsTUFBTWlMLFdBQVcsR0FBR2pMLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHNEQUFqQjtBQVFBLE1BQU1rTCxXQUFXLEdBQUdsTCx1RUFBSDtBQUFBO0FBQUE7QUFBQSwwQ0FBakI7QUFLQSxNQUFNeUwsU0FBUyxHQUFHekwsdUVBQUg7QUFBQTtBQUFBO0FBQUEsa0pBQ0FxRiw0RUFEQSxFQUVFQSwwRUFGRixFQUtFQSw0RUFMRixFQU1JQSwwRUFOSixDQUFmO0FBY0EsTUFBTXFHLFNBQVMsR0FBRzFMLHVFQUFIO0FBQUE7QUFBQTtBQUFBLG1EQUFmOztBQU1BLE1BQU0yTCxhQUFhLEdBQUcsTUFBTTtBQUMxQixzQkFDRSw4REFBQyxXQUFEO0FBQUEsMkJBQ0UsOERBQUMsV0FBRDtBQUFBLDhCQUNFLDhEQUFDLFNBQUQ7QUFBQSxnQ0FDRSw4REFBQyxTQUFEO0FBQUEsaUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBTUUsOERBQUMsWUFBRDtBQUFBLGlDQUNFLDhEQUFDLG1EQUFEO0FBQ0UsaUJBQUssRUFBRSxHQURUO0FBRUUsa0JBQU0sRUFBRSxHQUZWO0FBR0UsZUFBRyxFQUFFLDBCQUhQO0FBSUUsZUFBRyxFQUFDO0FBSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBZ0JFLDhEQUFDLFNBQUQ7QUFBQSxnQ0FDRSw4REFBQyxTQUFEO0FBQUEsaUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBUUUsOERBQUMsWUFBRDtBQUFBLGlDQUNFLDhEQUFDLG1EQUFEO0FBQ0UsaUJBQUssRUFBRSxHQURUO0FBRUUsa0JBQU0sRUFBRSxHQUZWO0FBR0UsZUFBRyxFQUFFLDZCQUhQO0FBSUUsZUFBRyxFQUFDO0FBSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhCRixlQWlDRSw4REFBQyxTQUFEO0FBQUEsZ0NBQ0UsOERBQUMsU0FBRDtBQUFBLGlDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQU9FLDhEQUFDLFlBQUQ7QUFBQSxpQ0FDRSw4REFBQyxtREFBRDtBQUNFLGlCQUFLLEVBQUUsR0FEVDtBQUVFLGtCQUFNLEVBQUUsR0FGVjtBQUdFLGVBQUcsRUFBRSw2QkFIUDtBQUlFLGVBQUcsRUFBQztBQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBc0RELENBdkREOztBQXlEQSxpRUFBZUEsYUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNeEQsT0FBTyxHQUFHbkksMkVBQUg7QUFBQTtBQUFBO0FBQUEsb0ZBQWI7QUFPQSxNQUFNK0ksWUFBWSxHQUFHL0ksdUVBQUg7QUFBQTtBQUFBO0FBQUEsa0ZBQWxCO0FBV0EsTUFBTW1KLFVBQVUsR0FBR25KLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDRDQUFoQjtBQUtBLE1BQU1vSSxTQUFTLEdBQUdwSSx1RUFBSDtBQUFBO0FBQUE7QUFBQSxrRkFBZjtBQVNBLE1BQU00TCxVQUFVLEdBQUc1TCxxRUFBSDtBQUFBO0FBQUE7QUFBQSx3YUFDRHFGLDZFQURDLEVBRUNBLDJFQUZELEVBS0NBLDZFQUxELEVBTUdBLDJFQU5ILEVBV0NBLDZFQVhELEVBWUdBLDJFQVpILEVBMEJDQSw0RUExQkQsRUEyQkdBLDBFQTNCSCxFQStCQ0EsNEVBL0JELEVBZ0NHQSwwRUFoQ0gsQ0FBaEI7QUFvQ0EsTUFBTXdHLGlCQUFpQixHQUFHN0wsdUVBQUg7QUFBQTtBQUFBO0FBQUEsb01BQXZCOztBQWlCQSxNQUFNUyxTQUFTLEdBQUcsTUFBTTtBQUN0QixRQUFNO0FBQUEsT0FBQ3FMLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCbmQsK0NBQVEsQ0FBQyxLQUFELENBQXhDOztBQUVBLFFBQU02YixpQkFBaUIsR0FBRyxNQUFNO0FBQzlCLFFBQUkxakIsTUFBTSxDQUFDb2dCLFVBQVAsR0FBb0IsR0FBeEIsRUFBNkI7QUFDM0I0RSxNQUFBQSxXQUFXLENBQUMsSUFBRCxDQUFYO0FBQ0QsS0FGRCxNQUVPO0FBQ0xBLE1BQUFBLFdBQVcsQ0FBQyxLQUFELENBQVg7QUFDRDtBQUNGLEdBTkQ7O0FBUUEzbUIsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ2RxbEIsSUFBQUEsaUJBQWlCO0FBQ2pCMWpCLElBQUFBLE1BQU0sQ0FBQ21ULGdCQUFQLENBQXdCLFFBQXhCLEVBQWtDdVEsaUJBQWxDO0FBQ0EsV0FBTyxNQUFNO0FBQ1gxakIsTUFBQUEsTUFBTSxDQUFDK2pCLG1CQUFQLENBQTJCLFFBQTNCLEVBQXFDTCxpQkFBckM7QUFDRCxLQUZEO0FBR0QsR0FOUSxFQU1OLEVBTk0sQ0FBVDtBQVFBLHNCQUNFLDhEQUFDLE9BQUQ7QUFBUyxNQUFFLEVBQUMsUUFBWjtBQUFBLDRCQUNFLDhEQUFDLFlBQUQ7QUFBQSw2QkFDRSw4REFBQyxtREFBRDtBQUNFLGFBQUssRUFBRSxJQURUO0FBRUUsY0FBTSxFQUFFLEdBRlY7QUFHRSxXQUFHLEVBQUMsMEJBSE47QUFJRSxXQUFHLEVBQUM7QUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVNFLDhEQUFDLFNBQUQ7QUFBQSw4QkFDRSw4REFBQyxVQUFEO0FBQUEsK0JBQ0UsOERBQUMsc0VBQUQ7QUFBYyxpQkFBTyxFQUFDLFNBQXRCO0FBQWdDLGlCQUFPLEVBQUMsbUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixFQU1HcUIsUUFBUSxnQkFFUCw4REFBQyxtREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZPLGdCQUlQLDhEQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVkosZUFZRSw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFURixlQTJCRSw4REFBQyxpQkFBRDtBQUFBLDZCQUNFLDhEQUFDLG1EQUFEO0FBQ0UsYUFBSyxFQUFFLElBRFQ7QUFFRSxjQUFNLEVBQUUsR0FGVjtBQUdFLFdBQUcsRUFBQyx1QkFITjtBQUlFLFdBQUcsRUFBQztBQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXNDRCxDQXpERDs7QUEyREEsaUVBQWVyTCxTQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hKQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU0wSCxPQUFPLEdBQUduSSwyRUFBSDtBQUFBO0FBQUE7QUFBQSx5SkFBYjtBQVdBLE1BQU1tSixVQUFVLEdBQUduSix1RUFBSDtBQUFBO0FBQUE7QUFBQSw0Q0FBaEI7QUFLQSxNQUFNZ00sVUFBVSxHQUFHaE0sMkVBQUg7QUFBQTtBQUFBO0FBQUEsc0NBQWhCO0FBS0EsTUFBTTZGLFNBQVMsR0FBRzdGLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDhMQUNBcUYsNkVBREEsRUFJRUEsNkVBSkYsRUFPRUEsNkVBUEYsRUFVRUEsNEVBVkYsRUFhRUEsNEVBYkYsQ0FBZjtBQWlCQSxNQUFNNEcsWUFBWSxHQUFHak0sdUVBQUg7QUFBQTtBQUFBO0FBQUEsbVBBQWxCO0FBZ0JBLE1BQU1rTSxVQUFVLEdBQUdsTSxzRUFBSDtBQUFBO0FBQUE7QUFBQSw2YkFPRHFGLDZFQVBDLEVBV0NBLDZFQVhELEVBY0NBLDZFQWRELEVBaUJDQSw0RUFqQkQsRUF3QkNBLDRFQXhCRCxDQUFoQjtBQTRCQSxNQUFNOEcsZUFBZSxHQUFHbk0sd0RBQU0sQ0FBQ2tNLFVBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSx3RkFBckI7QUFRQSxNQUFNRSxJQUFJLEdBQUdwTSxzRUFBSDtBQUFBO0FBQUE7QUFBQSxzRUFBVjtBQU9BLE1BQU0ySixRQUFRLEdBQUczSixzRUFBSDtBQUFBO0FBQUE7QUFBQSx3UEFHQ3FGLDZFQUhELEVBTUdBLDZFQU5ILEVBU0dBLDZFQVRILEVBWUdBLDRFQVpILEVBZUdBLDRFQWZILENBQWQ7QUFtQkEsTUFBTTBELFlBQVksR0FBRy9JLHVFQUFIO0FBQUE7QUFBQTtBQUFBLGdHQUFsQjtBQVlBLE1BQU1xTSxRQUFRLEdBQUdyTSx1RUFBSDtBQUFBO0FBQUE7QUFBQSx1T0FFRixDQUFDO0FBQUVzTSxFQUFBQTtBQUFGLENBQUQsS0FBa0JBLFFBQVEsR0FBRyxHQUFILEdBQVMsQ0FGakMsRUFNQSxDQUFDO0FBQUVBLEVBQUFBO0FBQUYsQ0FBRCxLQUFrQkEsUUFBUSxHQUFHLEdBQUgsR0FBUyxDQU5uQyxFQVVBLENBQUM7QUFBRUEsRUFBQUE7QUFBRixDQUFELEtBQWtCQSxRQUFRLEdBQUcsR0FBSCxHQUFTLENBVm5DLEVBY0EsQ0FBQztBQUFFQSxFQUFBQTtBQUFGLENBQUQsS0FBa0JBLFFBQVEsR0FBRyxHQUFILEdBQVMsQ0FkbkMsRUFrQkEsQ0FBQztBQUFFQSxFQUFBQTtBQUFGLENBQUQsS0FBa0JBLFFBQVEsR0FBRyxHQUFILEdBQVMsQ0FsQm5DLENBQWQ7QUFzQkEsTUFBTUMsU0FBUyxHQUFHdk0sdUVBQUg7QUFBQTtBQUFBO0FBQUEsZ2lCQVVBcUYsNkVBVkEsRUFjRUEsNkVBZEYsRUFpQkVBLDZFQWpCRixFQW9CRUEsNEVBcEJGLEVBdUJFQSw0RUF2QkYsRUFnQ1MsQ0FBQztBQUFFaUgsRUFBQUE7QUFBRixDQUFELEtBQWtCQSxRQUFRLEdBQUcsR0FBSCxHQUFTLENBaEM1QyxDQUFmOztBQTJDQSxNQUFNRSxLQUFLLEdBQUcsTUFBTTtBQUNsQixzQkFDRTtBQUFLLFNBQUssRUFBQyw0QkFBWDtBQUF3QyxXQUFPLEVBQUMsYUFBaEQ7QUFBQSwyQkFDRTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFPRCxDQVJEOztBQVVBLE1BQU10TSxHQUFHLEdBQUcsTUFBTTtBQUNoQixRQUFNO0FBQUEsT0FBQ29NLFFBQUQ7QUFBQSxPQUFXRztBQUFYLE1BQTBCN2QsK0NBQVEsQ0FBVSxLQUFWLENBQXhDOztBQUVBLFFBQU04ZCxVQUFVLEdBQUcsTUFBTTtBQUN2QkQsSUFBQUEsV0FBVyxDQUFDLENBQUNILFFBQUYsQ0FBWDtBQUNELEdBRkQ7O0FBSUEsc0JBQ0UsOERBQUMsT0FBRDtBQUFBLDRCQUNFLDhEQUFDLFVBQUQ7QUFBWSxRQUFFLEVBQUMsS0FBZjtBQUFBLDhCQUNFLDhEQUFDLFVBQUQ7QUFBQSwrQkFDRSw4REFBQyxzRUFBRDtBQUFjLGlCQUFPLEVBQUMsU0FBdEI7QUFBZ0MsaUJBQU8sRUFBQywwQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBTUUsOERBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFORixlQU9FLDhEQUFDLFlBQUQ7QUFBQSxnQ0FDRSw4REFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUUsOERBQUMsSUFBRDtBQUFBLGtDQUNFLDhEQUFDLFFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRSw4REFBQyxRQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGLGVBR0UsOERBQUMsUUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFIRixlQUlFLDhEQUFDLFFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSkYsZUFLRSw4REFBQyxRQUFEO0FBQUEsK0JBQWUsR0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRixlQWlCRSw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpCRixlQWtCRSw4REFBQyxZQUFEO0FBQUEsK0JBQ0UsOERBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbEJGLGVBeUJFLDhEQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBekJGLGVBMEJFLDhEQUFDLFlBQUQ7QUFBQSwrQkFDRSw4REFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkExQkYsZUFnQ0UsOERBQUMsU0FBRDtBQUFXLGVBQU8sRUFBRUksVUFBcEI7QUFBZ0MsZ0JBQVEsRUFBRUosUUFBMUM7QUFBQSx3Q0FFRSw4REFBQyxLQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhDRixlQW9DRSw4REFBQyxRQUFEO0FBQVUsZ0JBQVEsRUFBRUEsUUFBcEI7QUFBQSxnQ0FDRSw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUUsOERBQUMsWUFBRDtBQUFBLGlDQUNFLDhEQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBUUUsOERBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFSRixlQVNFLDhEQUFDLFlBQUQ7QUFBQSxpQ0FDRSw4REFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQXFERSw4REFBQyxZQUFEO0FBQUEsNkJBQ0UsOERBQUMsbURBQUQ7QUFDRSxhQUFLLEVBQUUsSUFEVDtBQUVFLGNBQU0sRUFBRSxHQUZWO0FBR0UsV0FBRyxFQUFDLHlCQUhOO0FBSUUsV0FBRyxFQUFDO0FBSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBckRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0VELENBdkVEOztBQXlFQSxpRUFBZXBNLEdBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxUkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNaUksT0FBTyxHQUFHbkksMkVBQUg7QUFBQTtBQUFBO0FBQUEsdUtBQWI7QUFjQSxNQUFNb0ksU0FBUyxHQUFHcEksdUVBQUg7QUFBQTtBQUFBO0FBQUEsOEVBQWY7QUFRQSxNQUFNOE0sVUFBVSxHQUFHOU0sdUVBQUg7QUFBQTtBQUFBO0FBQUEsZ05BQWhCO0FBa0JBLE1BQU0rTSxjQUFjLEdBQUcvTSx1RUFBSDtBQUFBO0FBQUE7QUFBQSwwS0FBcEI7QUFnQkEsTUFBTWdOLGlCQUFpQixHQUFHaE4sdUVBQUg7QUFBQTtBQUFBO0FBQUEsa0xBQXZCO0FBY0EsTUFBTWlOLFNBQVMsR0FBR2pOLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDZFQUFmO0FBUUEsTUFBTWtOLE9BQU8sR0FBR2xOLHFFQUFIO0FBQUE7QUFBQTtBQUFBLG1TQUVFcUYsNkVBRkYsRUFHSUEsMkVBSEosRUFLSUEsNkVBTEosRUFNTUEsMkVBTk4sRUFTSUEsNkVBVEosRUFVTUEsMkVBVk4sRUFhSUEsNEVBYkosRUFjTUEsMEVBZE4sRUFpQklBLDRFQWpCSixFQWtCTUEsMEVBbEJOLENBQWI7QUFzQkEsTUFBTThILFVBQVUsR0FBR25OLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDRWQUVEcUYsNkVBRkMsRUFHQ0EsMkVBSEQsRUFRQ0EsNkVBUkQsRUFTR0EsMkVBVEgsRUFZQ0EsNkVBWkQsRUFhR0EsMkVBYkgsRUFnQkNBLDRFQWhCRCxFQWlCR0EsMEVBakJILEVBb0JDQSw0RUFwQkQsRUFxQkdBLDBFQXJCSCxDQUFoQjtBQXlCQSxNQUFNK0gsV0FBVyxHQUFHcE4scUVBQUg7QUFBQTtBQUFBO0FBQUEsMlZBRUZxRiw2RUFGRSxFQUdBQSwyRUFIQSxFQVFBQSw2RUFSQSxFQVNFQSwyRUFURixFQVlBQSw2RUFaQSxFQWFFQSwyRUFiRixFQWdCQUEsNEVBaEJBLEVBaUJFQSwwRUFqQkYsRUFvQkFBLDRFQXBCQSxFQXFCRUEsMEVBckJGLENBQWpCO0FBeUJBLE1BQU1nSSxVQUFVLEdBQUdyTixxRUFBSDtBQUFBO0FBQUE7QUFBQSxnR0FBaEI7QUFTQSxNQUFNc04sU0FBUyxHQUFHdE4scUVBQUg7QUFBQTtBQUFBO0FBQUEsaXFCQXdCSXFGLDJFQXhCSixFQThCRUEsNEVBOUJGLEVBK0JJQSwwRUEvQkosRUFrQ0VBLDRFQWxDRixFQW1DSUEsMEVBbkNKLENBQWY7QUEwQ0EsTUFBTWtJLEtBQUssR0FBR3ZOLHNFQUFIO0FBQUE7QUFBQTtBQUFBLCtIQUFYO0FBVUEsTUFBTW1HLElBQUksR0FBR25HLHNFQUFIO0FBQUE7QUFBQTtBQUFBLHFZQUlLcUYsNkVBSkwsRUFLT0EsMkVBTFAsRUFPT0EsNkVBUFAsRUFRU0EsMkVBUlQsRUFXT0EsNkVBWFAsRUFZU0EsMkVBWlQsRUFrQk9BLDRFQWxCUCxFQW1CU0EsMEVBbkJULEVBc0JPQSw0RUF0QlAsRUF1QlNBLDBFQXZCVCxDQUFWO0FBK0JBLE1BQU1tSSxTQUFTLEdBQUd4Tix1RUFBSDtBQUFBO0FBQUE7QUFBQSwrRkFBZjtBQVFBLE1BQU15TixjQUFjLEdBQUd6Tix1RUFBSDtBQUFBO0FBQUE7QUFBQSwrRkFBcEI7QUFRQSxNQUFNME4sZUFBZSxHQUFHMU4seUVBQUg7QUFBQTtBQUFBO0FBQUEsZ1FBQXJCO0FBZ0JBLE1BQU0yTixjQUFjLEdBQUczTix5RUFBSDtBQUFBO0FBQUE7QUFBQSw0UkFBcEI7QUFpQkEsTUFBTTZGLFNBQVMsR0FBRzdGLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDZEQUFmO0FBTUEsTUFBTTROLGNBQWMsR0FBRzVOLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHNIQUFwQjtBQVVBLE1BQU02TixNQUFNLEdBQUc3TixxRUFBSDtBQUFBO0FBQUE7QUFBQSwwSEFBWjs7QUFnQkEsTUFBTU8sTUFBTSxHQUFHLENBQUM7QUFBQ3dCLEVBQUFBLE9BQUQ7QUFBVUksRUFBQUEsT0FBVjtBQUFtQkMsRUFBQUE7QUFBbkIsQ0FBRCxLQUF3QztBQUVyRCxRQUFNO0FBQUEsT0FBQzBMLEtBQUQ7QUFBQSxPQUFRQztBQUFSLE1BQW9CbmYsK0NBQVEsQ0FBQyxFQUFELENBQWxDO0FBQ0EsUUFBTTtBQUFBLE9BQUNkLE9BQUQ7QUFBQSxPQUFVdVU7QUFBVixNQUF3QnpULCtDQUFRLENBQUMsRUFBRCxDQUF0Qzs7QUFFQSxRQUFNb2Ysc0JBQXNCLEdBQUUsWUFBWTtBQUN4QzNMLElBQUFBLFVBQVUsQ0FBQyxFQUFELENBQVY7O0FBQ0EsUUFBRyxDQUFDdUssd0RBQUEsQ0FBa0JrQixLQUFsQixDQUFKLEVBQTZCO0FBQzNCekwsTUFBQUEsVUFBVSxDQUFDLCtCQUFELENBQVY7QUFDQSxhQUFPLEtBQVA7QUFDRCxLQUhELE1BR087QUFDTCxVQUFJNkwsU0FBUyxHQUFHO0FBQ2RuTCxRQUFBQSxPQUFPLEVBQUUrSyxLQURLO0FBRWRLLFFBQUFBLFdBQVcsRUFBRXBNO0FBRkMsT0FBaEI7O0FBS0EsVUFBSTtBQUNGLFlBQUlzQyxRQUFRLEdBQUcsTUFBTWhaLEtBQUssQ0FBQyxhQUFELEVBQWdCO0FBQ3RDaVAsVUFBQUEsTUFBTSxFQUFFLE1BRDhCO0FBRXRDelEsVUFBQUEsSUFBSSxFQUFFbk0sSUFBSSxDQUFDQyxTQUFMLENBQWV1d0IsU0FBZjtBQUZnQyxTQUFoQixDQUExQjtBQUlBLFlBQUkzWCxJQUFJLEdBQUcsTUFBTThOLFFBQVEsQ0FBQy9OLElBQVQsRUFBakI7QUFDQTlaLFFBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVksd0JBQVosRUFBc0NlLFFBQXRDLEVBQWdEOU4sSUFBaEQ7QUFDQThMLFFBQUFBLFVBQVUsQ0FBQzlMLElBQUksQ0FBQ3pJLE9BQU4sQ0FBVjtBQUVELE9BVEQsQ0FTRSxPQUFPcE0sR0FBUCxFQUFZO0FBQ1psRixRQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLHNDQUFaLEVBQW9ENWhCLEdBQXBEO0FBQ0Q7QUFDRjs7QUFDRGxGLElBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVksZ0JBQVosRUFBOEJ3SyxLQUE5QjtBQUNELEdBekJEOztBQTJCQSxzQkFDRSw4REFBQyxPQUFEO0FBQUEsNEJBQ0UsOERBQUMsU0FBRDtBQUFBLDhCQUNFLDhEQUFDLGlCQUFEO0FBQUEsZ0NBQ0UsOERBQUMsU0FBRDtBQUFBLGtDQUNFLDhEQUFDLE9BQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRSw4REFBQyxVQUFEO0FBQVksa0JBQU0sRUFBQyxRQUFuQjtBQUE0QixlQUFHLEVBQUMsVUFBaEM7QUFBMkMsZ0JBQUksRUFBRSwwQ0FBd0NuQixxREFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkYsZUFHRSw4REFBQyxXQUFEO0FBQUEsc0JBQWNBLHFEQUFVLEdBQUVBLHFEQUFGLEdBQWU7QUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFIRixlQUlFLDhEQUFDLGNBQUQ7QUFBQSxvQ0FDRiw4REFBQyxlQUFEO0FBQWlCLGtCQUFJLEVBQUMsTUFBdEI7QUFBNkIsa0JBQUksRUFBQyxPQUFsQztBQUEwQyxnQkFBRSxFQUFDLFNBQTdDO0FBQXdELHNCQUFRLEVBQUcxcEIsQ0FBRCxJQUFPOHFCLFFBQVEsQ0FBQzlxQixDQUFDLENBQUM1TixNQUFGLENBQVNsQixLQUFWO0FBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREUsZUFFRiw4REFBQyxjQUFEO0FBQWdCLGtCQUFJLEVBQUMsUUFBckI7QUFBOEIsbUJBQUssRUFBQyxNQUFwQztBQUEyQyxxQkFBTyxFQUFFNjVCO0FBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkUsZUFHRiw4REFBQyxjQUFEO0FBQUEsd0JBQWlCbGdCO0FBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQVlFLDhEQUFDLFVBQUQ7QUFBWSxnQkFBTSxFQUFDLFFBQW5CO0FBQTRCLGFBQUcsRUFBQyxVQUFoQztBQUEyQyxjQUFJLEVBQUUrZSxzREFBakQ7QUFBQSxrQ0FDRSw4REFBQyxVQUFEO0FBQUEsbUNBQ0UsOERBQUMsbURBQUQ7QUFDRSxtQkFBSyxFQUFFLEdBRFQ7QUFFRSxvQkFBTSxFQUFFLEdBRlY7QUFHRSxpQkFBRyxFQUFDLDRCQUhOO0FBSUUsaUJBQUcsRUFBQztBQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBU0UsOERBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBeUJFLDhEQUFDLEtBQUQ7QUFBQSwrQkFDRSw4REFBQyxJQUFEO0FBQUEsaUNBQ0UsOERBQUMsa0RBQUQ7QUFBTSxnQkFBSSxFQUFDLG9DQUFYO0FBQUEsbUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBekJGLGVBZ0NFLDhEQUFDLFNBQUQ7QUFBQSwrQkFDRSw4REFBQyxTQUFEO0FBQUEseURBQThCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQXlDRSw4REFBQyxjQUFEO0FBQUEsNkJBQ0UsOERBQUMsbURBQUQ7QUFDRSxhQUFLLEVBQUUsSUFEVDtBQUVFLGNBQU0sRUFBRSxHQUZWO0FBR0UsV0FBRyxFQUFDLG9CQUhOO0FBSUUsV0FBRyxFQUFDO0FBSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBc0RELENBdEZEOztBQXdGQSxpRUFBZXRNLE1BQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BhQTtBQUNBO0FBRUE7QUFDQTs7QUFFQSxNQUFNK04sU0FBUyxHQUFHdE8sdUVBQUg7QUFBQTtBQUFBO0FBQUEsMlBBQWY7QUF3QkEsTUFBTXVPLFVBQVUsR0FBR3ZPLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHVJQUFoQjtBQVlBLE1BQU13TyxXQUFXLEdBQUd4Tyx1RUFBSDtBQUFBO0FBQUE7QUFBQSw4TUFBakI7QUFnQkEsTUFBTXlPLFVBQVUsR0FBR3pPLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDZZQUNEcUYsNkVBREMsRUFFQ0EsMkVBRkQsRUFZQ0EsNkVBWkQsRUFhR0EsMkVBYkgsRUFnQkNBLDZFQWhCRCxFQWlCR0EsMkVBakJILEVBb0JDQSw0RUFwQkQsRUFxQkdBLDBFQXJCSCxFQXdCR0EsNEVBeEJILEVBeUJLQSwwRUF6QkwsQ0FBaEI7QUE2QkEsTUFBTXFKLGVBQWUsR0FBRzFPLHdEQUFNLENBQUN5TyxVQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEsdUJBQXJCOztBQUlBLE1BQU1FLGFBQWEsR0FBRyxNQUFNO0FBQzFCLHNCQUNFO0FBQUssU0FBSyxFQUFDLElBQVg7QUFBZ0IsVUFBTSxFQUFDLElBQXZCO0FBQTRCLFdBQU8sRUFBQyxXQUFwQztBQUFnRCxRQUFJLEVBQUMsTUFBckQ7QUFBNEQsU0FBSyxFQUFDLDRCQUFsRTtBQUFBLDJCQUNFO0FBQU0sT0FBQyxFQUFDLHlEQUFSO0FBQWtFLFlBQU0sRUFBQyxPQUF6RTtBQUFpRixpQkFBVyxFQUFDLEdBQTdGO0FBQWlHLG1CQUFhLEVBQUM7QUFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQUtELENBTkQ7O0FBUUEsTUFBTUMsY0FBYyxHQUFHLE1BQU07QUFDM0Isc0JBQ0U7QUFBSyxTQUFLLEVBQUMsSUFBWDtBQUFnQixVQUFNLEVBQUMsSUFBdkI7QUFBNEIsV0FBTyxFQUFDLFdBQXBDO0FBQWdELFFBQUksRUFBQyxNQUFyRDtBQUE0RCxTQUFLLEVBQUMsNEJBQWxFO0FBQUEsMkJBQ0U7QUFBTSxPQUFDLEVBQUMsaUZBQVI7QUFBMEYsWUFBTSxFQUFDLE9BQWpHO0FBQXlHLGlCQUFXLEVBQUMsR0FBckg7QUFBeUgsbUJBQWEsRUFBQztBQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBTUQsQ0FQRDs7QUFTQSxNQUFNQyxVQUFVLEdBQUc3Tyx1RUFBSDtBQUFBO0FBQUE7QUFBQSw4TEFBaEI7QUFtQkEsTUFBTThPLFdBQVcsR0FBRzlPLHVFQUFIO0FBQUE7QUFBQTtBQUFBLGdNQUFqQjs7QUF3QkEsTUFBTStPLGFBQWEsR0FBSXZyQixLQUFELElBQTBCO0FBQzlDLFFBQU07QUFBRXdyQixJQUFBQSxhQUFhLEdBQUcsQ0FBbEI7QUFBcUJDLElBQUFBLFVBQVUsR0FBRyxDQUFsQztBQUFxQ0MsSUFBQUE7QUFBckMsTUFBd0QxckIsS0FBOUQ7QUFDQWhILEVBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVkwTCxhQUFaLEVBQTJCQyxVQUEzQjtBQUNBLHNCQUNFLDhEQUFDLFNBQUQ7QUFBQSw0QkFDRSw4REFBQyxVQUFEO0FBQUEsNkJBQ0UsOERBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUlFLDhEQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKRixlQUtFLDhEQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRixFQU1HQSxVQUFVLEtBQUtaLGlFQUFmLGlCQUFzQyw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU56QyxFQVVHWSxVQUFVLEtBQUtaLGdFQUFmLElBQXFDVyxhQUFhLEtBQUtaLG9FQUF2RCxpQkFBaUYsOERBQUMsZUFBRDtBQUFpQixhQUFPLEVBQUUsTUFBTWMsY0FBYyxDQUFDLElBQUQsQ0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVnBGLGVBYUUsOERBQUMsV0FBRDtBQUFBLDZCQUNFLDhEQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFtQkQsQ0F0QkQ7O0FBd0JBLGlFQUFlSCxhQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0tBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBLE1BQU01RyxPQUFPLEdBQUduSSwyRUFBSDtBQUFBO0FBQUE7QUFBQSxvWEFBYjtBQTJCQSxNQUFNdVAsV0FBVyxHQUFHdlAsdUVBQUg7QUFBQTtBQUFBO0FBQUEsc1FBQWpCO0FBc0JBLE1BQU04TSxVQUFVLEdBQUc5TSx1RUFBSDtBQUFBO0FBQUE7QUFBQSxnVEFBaEI7QUF3QkEsTUFBTWdLLFdBQVcsR0FBR2hLLHVFQUFIO0FBQUE7QUFBQTtBQUFBLG9NQUFqQjtBQW9CQSxNQUFNd1AsY0FBYyxHQUFHeFAsdUVBQUg7QUFBQTtBQUFBO0FBQUEsZ09BQXBCO0FBcUJBLE1BQU15UCxhQUFhLEdBQUd6UCx1RUFBSDtBQUFBO0FBQUE7QUFBQSxxTkFBbkI7QUFvQkEsTUFBTTBQLE9BQU8sR0FBRzFQLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDhMQUNJcUYsNkVBREosRUFHTUEsNkVBSE4sRUFNTUEsNkVBTk4sRUFTTUEsNEVBVE4sRUFZUUEsNEVBWlIsQ0FBYjtBQWdCQSxNQUFNc0ssT0FBTyxHQUFHM1AsdUVBQUg7QUFBQTtBQUFBO0FBQUEseWVBQWI7QUE4QkEsTUFBTTRQLE9BQU8sR0FBRzVQLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDgrQkFBYjtBQXNGQSxNQUFNNlAsVUFBVSxHQUFHN1AsdUVBQUg7QUFBQTtBQUFBO0FBQUEscW5CQUFoQjtBQW9EQSxNQUFNOFAsS0FBSyxHQUFHOVAsdUVBQUg7QUFBQTtBQUFBO0FBQUEsOExBQVg7QUFtQkEsTUFBTStQLE1BQU0sR0FBRy9QLHFFQUFIO0FBQUE7QUFBQTtBQUFBLGdXQUFaO0FBeUJBLE1BQU1nUSxLQUFLLEdBQUdoUSxxRUFBSDtBQUFBO0FBQUE7QUFBQSxpV0FBWDs7QUEwQkEsTUFBTXZXLE1BQU0sR0FBRyxDQUFDO0FBQUU3RSxFQUFBQSxRQUFGO0FBQVlxckIsRUFBQUEsb0JBQVo7QUFBa0NDLEVBQUFBO0FBQWxDLENBQUQsS0FBeUg7QUFDcEksc0JBQ0k7QUFBTSxXQUFPLEVBQUVELG9CQUFmO0FBQXFDLFlBQVEsRUFBRTdMLE1BQU0sQ0FBQzhMLFFBQUQsQ0FBckQ7QUFBQSw0QkFDSTtBQUFLLFdBQUssRUFBQyxJQUFYO0FBQWdCLFlBQU0sRUFBQyxJQUF2QjtBQUE0QixhQUFPLEVBQUMsV0FBcEM7QUFBZ0QsVUFBSSxFQUFDLE1BQXJEO0FBQTRELFdBQUssRUFBQyw0QkFBbEU7QUFBQSw2QkFDSTtBQUFNLFNBQUMsRUFBQyw2SkFBUjtBQUFzSyxZQUFJLEVBQUM7QUFBM0s7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFJSTtBQUFBLGdCQUFJdHJCO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQVFILENBVEQ7O0FBV0EsTUFBTTRuQixLQUFLLEdBQUcsTUFBTTtBQUNoQixzQkFDSTtBQUFLLFNBQUssRUFBQyxLQUFYO0FBQWlCLFVBQU0sRUFBQyxJQUF4QjtBQUE2QixXQUFPLEVBQUMsWUFBckM7QUFBa0QsUUFBSSxFQUFDLE1BQXZEO0FBQThELFNBQUssRUFBQyw0QkFBcEU7QUFBQSw0QkFDSTtBQUFNLFFBQUUsRUFBQyxHQUFUO0FBQWEsUUFBRSxFQUFDLElBQWhCO0FBQXFCLFFBQUUsRUFBQyxLQUF4QjtBQUE4QixRQUFFLEVBQUMsSUFBakM7QUFBc0MsWUFBTSxFQUFDLE9BQTdDO0FBQXFELGlCQUFXLEVBQUMsR0FBakU7QUFBcUUsbUJBQWEsRUFBQztBQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBRUk7QUFBTSxRQUFFLEVBQUMsUUFBVDtBQUFrQixRQUFFLEVBQUMsUUFBckI7QUFBOEIsUUFBRSxFQUFDLFFBQWpDO0FBQTBDLFFBQUUsRUFBQyxTQUE3QztBQUF1RCxZQUFNLEVBQUMsT0FBOUQ7QUFBc0UsaUJBQVcsRUFBQyxHQUFsRjtBQUFzRixtQkFBYSxFQUFDO0FBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFNSCxDQVBEOztBQWtCQSxNQUFNck0sSUFBSSxHQUFHLENBQUM7QUFBQ3dCLEVBQUFBLFFBQUQ7QUFBV0ksRUFBQUEsT0FBWDtBQUFvQkksRUFBQUEsT0FBcEI7QUFBNkJDLEVBQUFBLE9BQTdCO0FBQXNDYyxFQUFBQTtBQUF0QyxDQUFELEtBQStEO0FBQ3hFLFFBQU07QUFBQSxPQUFDaU4sWUFBRDtBQUFBLE9BQWVDO0FBQWYsTUFBa0N4aEIsK0NBQVEsQ0FBQyxDQUFELENBQWhEO0FBQ0EsUUFBTTtBQUFBLE9BQUN5aEIsVUFBRDtBQUFBLE9BQWFDO0FBQWIsTUFBOEIxaEIsK0NBQVEsQ0FBQyxDQUFELENBQTVDO0FBQ0EsUUFBTTtBQUFBLE9BQUMyaEIsV0FBRDtBQUFBLE9BQWNyQjtBQUFkLE1BQWdDdGdCLCtDQUFRLENBQUMsSUFBRCxDQUE5QztBQUNBLFFBQU07QUFBQSxPQUFDd1UsUUFBRDtBQUFBLE9BQVdvTjtBQUFYLE1BQTBCNWhCLCtDQUFRLENBQUMsS0FBRCxDQUF4QztBQUNBLFFBQU07QUFBQSxPQUFDNmhCLFdBQUQ7QUFBQSxPQUFjQztBQUFkLE1BQWdDOWhCLCtDQUFRLENBQUMsTUFBRCxDQUE5Qzs7QUFFQSxRQUFNK2hCLFlBQVksR0FBRyxNQUFPMXRCLENBQVAsSUFBa0I7QUFDbkNBLElBQUFBLENBQUMsQ0FBQ0ssY0FBRjtBQUNBOUcsSUFBQUEsT0FBTyxDQUFDOG1CLEdBQVIsQ0FBWSx5QkFBWixFQUF1Q3JnQixDQUFDLENBQUM1TixNQUF6QztBQUNBcTdCLElBQUFBLGNBQWMsQ0FBQyxZQUFELENBQWQsQ0FIbUMsQ0FJbkM7O0FBQ0EsVUFBTXhOLFdBQVcsQ0FBQ2pnQixDQUFELEVBQUlvdEIsVUFBSixFQUFnQmpOLFFBQWhCLENBQWpCLENBTG1DLENBTW5DOztBQUNBc04sSUFBQUEsY0FBYyxDQUFDLE1BQUQsQ0FBZDtBQUNILEdBUkQ7O0FBVUEsUUFBTVQsb0JBQW9CLEdBQUlodEIsQ0FBRCxJQUFZO0FBQ3JDekcsSUFBQUEsT0FBTyxDQUFDOG1CLEdBQVIsQ0FBWSxnQkFBWixFQUE4QnJnQixDQUE5QjtBQUVBLFFBQUkyZ0IsS0FBSyxHQUFHM2dCLENBQUMsQ0FBQ1IsYUFBRixDQUFnQm11QixTQUE1QjtBQUNBcDBCLElBQUFBLE9BQU8sQ0FBQzhtQixHQUFSLENBQVksZUFBWixFQUE2QnJnQixDQUFDLENBQUNSLGFBQS9CO0FBQ0FqRyxJQUFBQSxPQUFPLENBQUM4bUIsR0FBUixDQUFZLGlCQUFaLEVBQStCTSxLQUEvQjtBQUVBLFFBQUlBLEtBQUssS0FBSyxNQUFkLEVBQXNCNE0sV0FBVyxDQUFDLEtBQUQsQ0FBWCxDQUF0QixLQUNLQSxXQUFXLENBQUMsSUFBRCxDQUFYO0FBRVIsR0FWRDs7QUFZQSxRQUFNL0YsaUJBQWlCLEdBQUcsTUFBTTtBQUM1QixVQUFNb0csV0FBVyxHQUFHOXBCLE1BQU0sQ0FBQ29nQixVQUEzQjs7QUFDQSxZQUFRLElBQVI7QUFDSSxXQUFLMEosV0FBVyxHQUFHLElBQW5CO0FBQ0lULFFBQUFBLGVBQWUsQ0FBQyxHQUFELENBQWY7QUFDQTs7QUFDSjtBQUNJQSxRQUFBQSxlQUFlLENBQUMsSUFBRCxDQUFmO0FBQ0E7QUFOUjtBQVFILEdBVkQ7O0FBWUEsUUFBTVUsWUFBWSxHQUFJQyxNQUFELElBQW9CO0FBQ3JDLFlBQVFBLE1BQVI7QUFDSSxXQUFLLFVBQUw7QUFDSVYsUUFBQUEsVUFBVSxHQUFHLEVBQWIsSUFBbUJDLGFBQWEsQ0FBQ0QsVUFBVSxHQUFHLENBQWQsQ0FBaEM7QUFDQTs7QUFDSixXQUFLLFVBQUw7QUFDSUEsUUFBQUEsVUFBVSxHQUFHLENBQWIsSUFBa0JDLGFBQWEsQ0FBQ0QsVUFBVSxHQUFHLENBQWQsQ0FBL0I7QUFDQTtBQU5SO0FBUUgsR0FURDs7QUFXQWpyQixFQUFBQSxnREFBUyxDQUFDLE1BQU07QUFDWnFsQixJQUFBQSxpQkFBaUI7QUFDakIxakIsSUFBQUEsTUFBTSxDQUFDbVQsZ0JBQVAsQ0FBd0IsUUFBeEIsRUFBa0N1USxpQkFBbEM7QUFDQSxXQUFPLE1BQU07QUFDVDFqQixNQUFBQSxNQUFNLENBQUMrakIsbUJBQVAsQ0FBMkIsUUFBM0IsRUFBcUNMLGlCQUFyQztBQUNILEtBRkQ7QUFHSCxHQU5RLEVBTU4sRUFOTSxDQUFUO0FBUUEsc0JBQ0ksOERBQUMsT0FBRDtBQUFBLDRCQUNJLDhEQUFDLFdBQUQ7QUFBQSw2QkFDSSw4REFBQyxtREFBRDtBQUNJLGFBQUssRUFBRSxNQUFNMEYsWUFEakI7QUFFSSxjQUFNLEVBQUUsTUFBTUEsWUFGbEI7QUFHSSxXQUFHLEVBQUMsaUJBSFI7QUFJSSxXQUFHLEVBQUM7QUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQVNJLDhEQUFDLGNBQUQ7QUFBQSw2QkFDSTtBQUFHLFdBQUcsRUFBQyxZQUFQO0FBQW9CLGNBQU0sRUFBQyxRQUEzQjtBQUFvQyxZQUFJLEVBQUV0RCxzREFBMUM7QUFBQSxnQ0FDSSw4REFBQyxLQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFFSSw4REFBQyxPQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVEosZUFlSSw4REFBQyxVQUFEO0FBQUEsNkJBQ0ksOERBQUMsbURBQUQ7QUFDSSxhQUFLLEVBQUUsTUFBTXNELFlBRGpCO0FBRUksY0FBTSxFQUFFLE1BQU1BLFlBRmxCO0FBR0ksV0FBRyxFQUFDLG9DQUhSO0FBSUksV0FBRyxFQUFDO0FBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZkosZUF1QkksOERBQUMsaUVBQUQ7QUFBZSxvQkFBYyxFQUFFakI7QUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF2QkosZUF3QkksOERBQUMsYUFBRDtBQUFBLDZCQUNJO0FBQUcsV0FBRyxFQUFDLFlBQVA7QUFBb0IsY0FBTSxFQUFDLFFBQTNCO0FBQW9DLFlBQUksRUFBRXJDLHNEQUExQztBQUFBLGdDQUNJLDhEQUFDLEtBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQUVJLDhEQUFDLE9BQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF4QkosZUE4QkksOERBQUMsV0FBRDtBQUFBLDZCQUNJLDhEQUFDLG1EQUFEO0FBQ0ksYUFBSyxFQUFFLElBRFg7QUFFSSxjQUFNLEVBQUUsR0FGWjtBQUdJLFdBQUcsRUFBQyxrQkFIUjtBQUlJLFdBQUcsRUFBQztBQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTlCSixFQXNDSzBELFdBQVcsaUJBQ1IsOERBQUMsT0FBRDtBQUFBLDhCQUNJLDhEQUFDLEtBQUQ7QUFBTyxlQUFPLEVBQUUsTUFBTXJCLGNBQWMsQ0FBQyxLQUFELENBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUksOERBQUMsT0FBRDtBQUFBLGdDQUNJLDhEQUFDLE1BQUQ7QUFBUSw4QkFBb0IsRUFBRWUsb0JBQTlCO0FBQW9ELGtCQUFRLEVBQUMsR0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFFSSw4REFBQyxNQUFEO0FBQVEsOEJBQW9CLEVBQUVBLG9CQUE5QjtBQUFvRCxrQkFBUSxFQUFDLEdBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSixlQU1JLDhEQUFDLE1BQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTkosZUFPSSw4REFBQyxVQUFEO0FBQUEsbUJBQ0tJLFVBQVUsR0FBRyxDQUFiLGlCQUNHO0FBQUssaUJBQU8sRUFBRSxNQUFNUyxZQUFZLENBQUMsVUFBRCxDQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGUixlQUlJO0FBQUEsb0JBQUlUO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKSixFQUtLQSxVQUFVLEdBQUcsRUFBYixpQkFDRztBQUFLLGlCQUFPLEVBQUUsTUFBTVMsWUFBWSxDQUFDLFVBQUQsQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVBKLGVBZ0JJLDhEQUFDLEtBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaEJKLGVBaUJJLDhEQUFDLDJEQUFEO0FBQVksb0JBQVksRUFBRUgsWUFBMUI7QUFBd0MsbUJBQVcsRUFBRUY7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXZDUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQThESCxDQTFIRDs7QUE0SEEsaUVBQWV0USxJQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RpQkE7QUFDQTtBQUNBOztBQUVBLE1BQU1tTyxTQUFTLEdBQUd0Tyx1RUFBSDtBQUFBO0FBQUE7QUFBQSxvSUFBZjtBQVlBLE1BQU11TyxVQUFVLEdBQUd2Tyx1RUFBSDtBQUFBO0FBQUE7QUFBQSx1SUFBaEI7QUFZQSxNQUFNd08sV0FBVyxHQUFHeE8sdUVBQUg7QUFBQTtBQUFBO0FBQUEsOE1BQWpCO0FBZ0JBLE1BQU15TyxVQUFVLEdBQUd6TyxxRUFBSDtBQUFBO0FBQUE7QUFBQSw0WEFXQ3FGLDZFQVhELEVBWUdBLDJFQVpILEVBZUNBLDZFQWZELEVBZ0JHQSwyRUFoQkgsRUFtQkNBLDRFQW5CRCxFQW9CR0EsMEVBcEJILEVBdUJHQSw0RUF2QkgsRUF3QktBLDBFQXhCTCxDQUFoQjs7QUE0QkEsTUFBTXNKLGFBQWEsR0FBRyxNQUFNO0FBQzFCLHNCQUNFO0FBQUssU0FBSyxFQUFDLElBQVg7QUFBZ0IsVUFBTSxFQUFDLElBQXZCO0FBQTRCLFdBQU8sRUFBQyxXQUFwQztBQUFnRCxRQUFJLEVBQUMsTUFBckQ7QUFBNEQsU0FBSyxFQUFDLDRCQUFsRTtBQUFBLDJCQUNFO0FBQU0sT0FBQyxFQUFDLHlEQUFSO0FBQWtFLFlBQU0sRUFBQyxPQUF6RTtBQUFpRixpQkFBVyxFQUFDLEdBQTdGO0FBQWlHLG1CQUFhLEVBQUM7QUFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQUtELENBTkQ7O0FBUUEsTUFBTUMsY0FBYyxHQUFHLE1BQU07QUFDM0Isc0JBQ0U7QUFBSyxTQUFLLEVBQUMsSUFBWDtBQUFnQixVQUFNLEVBQUMsSUFBdkI7QUFBNEIsV0FBTyxFQUFDLFdBQXBDO0FBQWdELFFBQUksRUFBQyxNQUFyRDtBQUE0RCxTQUFLLEVBQUMsNEJBQWxFO0FBQUEsMkJBQ0U7QUFBTSxPQUFDLEVBQUMsaUZBQVI7QUFBMEYsWUFBTSxFQUFDLE9BQWpHO0FBQXlHLGlCQUFXLEVBQUMsR0FBckg7QUFBeUgsbUJBQWEsRUFBQztBQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBTUQsQ0FQRDs7QUFTQSxNQUFNQyxVQUFVLEdBQUc3Tyx1RUFBSDtBQUFBO0FBQUE7QUFBQSw4TEFBaEI7QUFtQkEsTUFBTThPLFdBQVcsR0FBRzlPLHVFQUFIO0FBQUE7QUFBQTtBQUFBLGdNQUFqQjs7QUFrQkEsTUFBTXNQLFVBQVUsR0FBRyxDQUFDO0FBQUNxQixFQUFBQSxZQUFEO0FBQWVGLEVBQUFBO0FBQWYsQ0FBRCxLQUF1QztBQUV4RCxzQkFDRSw4REFBQyxTQUFEO0FBQUEsNEJBQ0UsOERBQUMsVUFBRDtBQUFBLDZCQUNFLDhEQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFJRSw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkYsZUFLRSw4REFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEYsZUFNRSw4REFBQyxVQUFEO0FBQVksYUFBTyxFQUFFRSxZQUFyQjtBQUFBLGdCQUNHRjtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTkYsZUFTRSw4REFBQyxXQUFEO0FBQUEsNkJBQ0UsOERBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWVELENBakJEOztBQW1CQSxpRUFBZW5CLFVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pKQTtBQUVBOzs7QUFZQSxNQUFNbUMsZUFBZSxHQUFHLE1BQU07QUFDNUIsc0JBQ0UsOERBQUMsdURBQUQ7QUFBQSw0QkFDRSw4REFBQyxxREFBRDtBQUFBLDhCQUNFLDhEQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUUsOERBQUMsb0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFLRSw4REFBQyxvREFBRDtBQUFBLDZCQUNFLDhEQUFDLG9EQUFEO0FBQUEsZ0NBQ0UsOERBQUMscURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRSw4REFBQyxvREFBRDtBQUFBLGtDQUNFLDhEQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUUsOERBQUMsb0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFpQkQsQ0FsQkQ7O0FBb0JBLGlFQUFlQSxlQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQ0E7QUFFQTs7O0FBYUEsTUFBTUUsY0FBYyxHQUFHLE1BQU07QUFDM0Isc0JBQ0UsOERBQUMsdURBQUQ7QUFBQSw0QkFDRSw4REFBQyxxREFBRDtBQUFBLDhCQUNFLDhEQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUUsOERBQUMsb0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFLRSw4REFBQyxvREFBRDtBQUFBLDZCQUNFLDhEQUFDLG9EQUFEO0FBQUEsZ0NBQ0UsOERBQUMscURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRSw4REFBQyxxREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRixlQUdFLDhEQUFDLHFEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUhGLGVBSUUsOERBQUMsb0RBQUQ7QUFBQSxrQ0FDRSw4REFBQyxvREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFLDhEQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGLGVBR0UsOERBQUMsb0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFvQkQsQ0FyQkQ7O0FBdUJBLGlFQUFlQSxjQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Q0E7QUFFQTs7O0FBWUEsTUFBTUMsZ0JBQWdCLEdBQUcsTUFBTTtBQUM3QixzQkFDRSw4REFBQyx1REFBRDtBQUFBLDRCQUNFLDhEQUFDLHFEQUFEO0FBQUEsOEJBQ0UsOERBQUMsb0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRSw4REFBQyxvREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUtFLDhEQUFDLG9EQUFEO0FBQUEsNkJBQ0UsOERBQUMsb0RBQUQ7QUFBQSxnQ0FDRSw4REFBQyxxREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFLDhEQUFDLG9EQUFEO0FBQUEsa0NBQ0UsOERBQUMsb0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRSw4REFBQyxvREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWlCRCxDQWxCRDs7QUFvQkEsaUVBQWVBLGdCQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQ0E7QUFFQTs7O0FBWUEsTUFBTUMsY0FBYyxHQUFHLE1BQU07QUFDM0Isc0JBQ0UsOERBQUMsdURBQUQ7QUFBQSw0QkFDRSw4REFBQyxxREFBRDtBQUFBLDhCQUNFLDhEQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUUsOERBQUMsb0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFLRSw4REFBQyxvREFBRDtBQUFBLDZCQUNFLDhEQUFDLG9EQUFEO0FBQUEsZ0NBQ0UsOERBQUMscURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRSw4REFBQyxvREFBRDtBQUFBLGtDQUNFLDhEQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUUsOERBQUMsb0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBT0UsOERBQUMscURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQW1CRCxDQXBCRDs7QUFzQkEsaUVBQWVBLGNBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BDQTtBQUNBO0FBRU8sTUFBTWIsV0FBVyxHQUFHaFIsdUVBQUg7QUFBQTtBQUFBO0FBQUEsNE5BQWpCO0FBZ0JBLE1BQU1pUixTQUFTLEdBQUdqUix1RUFBSDtBQUFBO0FBQUE7QUFBQSw4WEFBZjtBQTJCQSxNQUFNa1IsUUFBUSxHQUFHbFIscUVBQUg7QUFBQTtBQUFBO0FBQUEsc2lCQUVOcUYsNkVBRk0sRUFHSkEsMkVBSEksRUFLSkEsNkVBTEksRUFNRkEsMkVBTkUsRUFTSkEsNkVBVEksRUFVRkEsMkVBVkUsRUE2QkpBLDRFQTdCSSxFQThCRkEsMEVBOUJFLEVBaUNKQSw0RUFqQ0ksRUFrQ0ZBLDBFQWxDRSxDQUFkO0FBNENBLE1BQU04TCxRQUFRLEdBQUduUix1RUFBSDtBQUFBO0FBQUE7QUFBQSx5R0FBZDtBQVNBLE1BQU1vUixRQUFRLEdBQUdwUix1RUFBSDtBQUFBO0FBQUE7QUFBQSwwSkFBZDtBQWNBLE1BQU1xUixRQUFRLEdBQUdyUix1RUFBSDtBQUFBO0FBQUE7QUFBQSxnTEFBZDtBQVlBLE1BQU1zUixTQUFTLEdBQUd0UixzRUFBSDtBQUFBO0FBQUE7QUFBQSxzWEFFUHFGLDZFQUZPLEVBR0xBLDJFQUhLLEVBS0xBLDZFQUxLLEVBTUhBLDJFQU5HLEVBU0xBLDZFQVRLLEVBVUhBLDJFQVZHLEVBYUxBLDRFQWJLLEVBY0hBLDBFQWRHLEVBaUJMQSw0RUFqQkssRUFrQkhBLDBFQWxCRyxDQUFmO0FBNEJBLE1BQU1xTSxTQUFTLEdBQUcxUixxRUFBSDtBQUFBO0FBQUE7QUFBQSx3U0FDUHFGLDZFQURPLEVBRUxBLDJFQUZLLEVBS0xBLDZFQUxLLEVBTUhBLDJFQU5HLEVBU0xBLDZFQVRLLEVBVUhBLDJFQVZHLEVBYUxBLDRFQWJLLEVBY0hBLDBFQWRHLEVBaUJMQSw0RUFqQkssRUFrQkhBLDBFQWxCRyxDQUFmO0FBdUJBLE1BQU1rTSxRQUFRLEdBQUd2UixzRUFBSDtBQUFBO0FBQUE7QUFBQSwwR0FBZDtBQVVBLE1BQU13UixRQUFRLEdBQUd4UixzRUFBSDtBQUFBO0FBQUE7QUFBQSw2VEFDTnFGLDZFQURNLEVBRUpBLDJFQUZJLEVBS0pBLDZFQUxJLEVBTUZBLDJFQU5FLEVBU0pBLDZFQVRJLEVBVUZBLDJFQVZFLEVBYUpBLDRFQWJJLEVBY0ZBLDBFQWRFLEVBaUJKQSw0RUFqQkksRUFrQkZBLDBFQWxCRSxDQUFkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUxQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNOEMsT0FBTyxHQUFHbkksMkVBQUg7QUFBQTtBQUFBO0FBQUEsOFRBQWI7QUEwQkEsTUFBTW9JLFNBQVMsR0FBR3BJLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHlEQUFmO0FBTUEsTUFBTStSLFdBQVcsR0FBRy9SLHVFQUFIO0FBQUE7QUFBQTtBQUFBLG1jQU1OLENBQUM7QUFBRWdTLEVBQUFBO0FBQUYsQ0FBRCxLQUF3QkEsY0FBYyxHQUFHLFFBQUgsR0FBYyxRQU45QyxFQVlKLENBQUM7QUFBRUEsRUFBQUE7QUFBRixDQUFELEtBQXdCQSxjQUFjLEdBQUcsT0FBSCxHQUFhLFFBWi9DLEVBa0JKLENBQUM7QUFBRUEsRUFBQUE7QUFBRixDQUFELEtBQXdCQSxjQUFjLEdBQUcsR0FBSCxHQUFTLFFBbEIzQyxDQUFqQjtBQTRDQSxNQUFNbEYsVUFBVSxHQUFHOU0sdUVBQUg7QUFBQTtBQUFBO0FBQUEseVhBQWhCO0FBNkJBLE1BQU1pUyxjQUFjLEdBQUdqUyx1RUFBSDtBQUFBO0FBQUE7QUFBQSxtVUFBcEI7QUFvQkEsTUFBTWtTLFVBQVUsR0FBR2xTLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHlWQUFoQjtBQThCQSxNQUFNbVMsZUFBZSxHQUFHblMsc0VBQUg7QUFBQTtBQUFBO0FBQUEscVVBQ05xRiw2RUFETSxFQUVKQSwyRUFGSSxFQU1KQSw2RUFOSSxFQU9GQSwyRUFQRSxFQVVKQSw2RUFWSSxFQVdGQSwyRUFYRSxFQWNKQSw0RUFkSSxFQWVGQSwwRUFmRSxFQWtCSkEsNEVBbEJJLEVBbUJGQSwwRUFuQkUsQ0FBckI7QUF3QkEsTUFBTStNLGNBQWMsR0FBR3BTLHNFQUFIO0FBQUE7QUFBQTtBQUFBLGlUQUFwQjtBQW1CQSxNQUFNcVMsY0FBYyxHQUFHclMsc0VBQUg7QUFBQTtBQUFBO0FBQUEsMGJBRUxxRiw2RUFGSyxFQUdIQSwyRUFIRyxFQVFIQSw2RUFSRyxFQVNEQSwyRUFUQyxFQVlIQSw2RUFaRyxFQWFEQSwyRUFiQyxFQWdCSEEsNEVBaEJHLEVBaUJEQSwwRUFqQkMsRUFvQkhBLDRFQXBCRyxFQXFCREEsMEVBckJDLENBQXBCO0FBc0NBLE1BQU1pTixhQUFhLEdBQUd0UyxzRUFBSDtBQUFBO0FBQUE7QUFBQSw2VkFFSnFGLDZFQUZJLEVBR0ZBLDJFQUhFLEVBU0ZBLDZFQVRFLEVBVUFBLDJFQVZBLEVBYUZBLDZFQWJFLEVBY0FBLDJFQWRBLEVBaUJGQSw0RUFqQkUsRUFrQkFBLDBFQWxCQSxFQXFCRkEsNEVBckJFLEVBc0JBQSwwRUF0QkEsQ0FBbkI7QUEwQkEsTUFBTWtOLGlCQUFpQixHQUFHdlMsdUVBQUg7QUFBQTtBQUFBO0FBQUEsb0tBQXZCO0FBYUEsTUFBTXdTLG1CQUFtQixHQUFHeFMsc0VBQUg7QUFBQTtBQUFBO0FBQUEsbWdCQUtWcUYsNkVBTFUsRUFNUkEsMkVBTlEsRUFZUkEsNkVBWlEsRUFhTkEsMkVBYk0sRUFrQlJBLDZFQWxCUSxFQW1CTkEsMkVBbkJNLEVBMEJSQSw0RUExQlEsRUEyQk5BLDBFQTNCTSxFQThCUkEsNEVBOUJRLEVBK0JOQSwwRUEvQk0sQ0FBekI7QUFvQ0EsTUFBTW9OLGFBQWEsR0FBR3pTLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHNEQUFuQjs7QUFNQSxNQUFNMFMsU0FBUyxHQUFHLE1BQU07QUFDdEIsc0JBQ0U7QUFBSyxTQUFLLEVBQUMsS0FBWDtBQUFpQixVQUFNLEVBQUMsS0FBeEI7QUFBOEIsV0FBTyxFQUFDLGFBQXRDO0FBQW9ELFFBQUksRUFBQyxNQUF6RDtBQUFnRSxTQUFLLEVBQUMsNEJBQXRFO0FBQUEsMkJBQ0U7QUFDRSxjQUFRLEVBQUMsU0FEWDtBQUVFLGNBQVEsRUFBQyxTQUZYO0FBR0UsT0FBQyxFQUFDLGlVQUhKO0FBTUUsVUFBSSxFQUFDO0FBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQVdELENBWkQ7O0FBY0EsTUFBTWxuQixPQUFPLEdBQUcsQ0FDZDtBQUFFbW5CLEVBQUFBLE9BQU8sRUFBRSxLQUFYO0FBQWtCcG5CLEVBQUFBLElBQUksRUFBRTtBQUF4QixDQURjLEVBRWQ7QUFBRW9uQixFQUFBQSxPQUFPLEVBQUUsS0FBWDtBQUFrQnBuQixFQUFBQSxJQUFJLEVBQUU7QUFBeEIsQ0FGYyxFQUdkO0FBQUVvbkIsRUFBQUEsT0FBTyxFQUFFLEtBQVg7QUFBa0JwbkIsRUFBQUEsSUFBSSxFQUFFO0FBQXhCLENBSGMsRUFJZDtBQUFFb25CLEVBQUFBLE9BQU8sRUFBRSxLQUFYO0FBQWtCcG5CLEVBQUFBLElBQUksRUFBRTtBQUF4QixDQUpjLEVBS2Q7QUFBRW9uQixFQUFBQSxPQUFPLEVBQUUsS0FBWDtBQUFrQnBuQixFQUFBQSxJQUFJLEVBQUU7QUFBeEIsQ0FMYyxFQU1kO0FBQUVvbkIsRUFBQUEsT0FBTyxFQUFFLEtBQVg7QUFBa0JwbkIsRUFBQUEsSUFBSSxFQUFFO0FBQXhCLENBTmMsRUFPZDtBQUFFb25CLEVBQUFBLE9BQU8sRUFBRSxNQUFYO0FBQW1CcG5CLEVBQUFBLElBQUksRUFBRTtBQUF6QixDQVBjLENBQWhCOztBQVVBLE1BQU1pVixPQUFPLEdBQUcsTUFBTTtBQUNwQixRQUFNO0FBQUEsT0FBQ3dSLGNBQUQ7QUFBQSxPQUFpQlk7QUFBakIsTUFBc0Noa0IsK0NBQVEsQ0FBQyxLQUFELENBQXBEOztBQUVBLFFBQU02YixpQkFBaUIsR0FBRyxNQUFNO0FBQzlCLFVBQU1vRyxXQUFXLEdBQUc5cEIsTUFBTSxDQUFDb2dCLFVBQTNCOztBQUNBLFlBQVEsSUFBUjtBQUNFLFdBQUswSixXQUFXLEdBQUcsSUFBbkI7QUFFRTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7O0FBQ0Y7QUFDRTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFmSjtBQWlCRCxHQW5CRDs7QUFxQkF6ckIsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ2RxbEIsSUFBQUEsaUJBQWlCO0FBQ2pCMWpCLElBQUFBLE1BQU0sQ0FBQ21ULGdCQUFQLENBQXdCLFFBQXhCLEVBQWtDdVEsaUJBQWxDO0FBQ0EsV0FBTyxNQUFNO0FBQ1gxakIsTUFBQUEsTUFBTSxDQUFDK2pCLG1CQUFQLENBQTJCLFFBQTNCLEVBQXFDTCxpQkFBckM7QUFDRCxLQUZEO0FBR0QsR0FOUSxFQU1OLEVBTk0sQ0FBVDs7QUFRQSxRQUFNb0ksYUFBYSxHQUFHLE1BQU07QUFDMUJELElBQUFBLGlCQUFpQixDQUFDLElBQUQsQ0FBakI7QUFDRCxHQUZEOztBQUlBLHNCQUNFLDhEQUFDLE9BQUQ7QUFBQSwyQkFDRSw4REFBQyxTQUFEO0FBQVcsUUFBRSxFQUFDLFNBQWQ7QUFBQSw4QkFDRSw4REFBQyxXQUFEO0FBQWEsc0JBQWMsRUFBRVosY0FBN0I7QUFBQSxnQ0FDRSw4REFBQyxvREFBRDtBQUNFLGlCQUFPLEVBQUVhO0FBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUlFLDhEQUFDLG1EQUFEO0FBQ0UsZUFBSyxFQUFFLElBRFQ7QUFFRSxnQkFBTSxFQUFFLEdBRlY7QUFHRSxhQUFHLEVBQUMsdUJBSE47QUFJRSxhQUFHLEVBQUM7QUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQVlFLDhEQUFDLGNBQUQ7QUFBQSxnQ0FDRSw4REFBQyxVQUFEO0FBQUEsaUNBQ0UsOERBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUlFLDhEQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkYsZUFLRSw4REFBQyxjQUFEO0FBQUEsb0JBQ0dybkIsT0FBTyxDQUFDelIsR0FBUixDQUFZLENBQUMwc0IsSUFBRCxFQUFPcU0sS0FBUCxLQUFpQjtBQUM1QixnQ0FDRSw4REFBQyxjQUFEO0FBQUEsc0NBQ0U7QUFBQSwyQkFBT3JNLElBQUksQ0FBQ2tNLE9BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLEVBQytCbE0sSUFBSSxDQUFDbGIsSUFEcEM7QUFBQSxlQUFxQnVuQixLQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGO0FBS0QsV0FOQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTEYsZUFjRSw4REFBQyxVQUFEO0FBQUEsaUNBQ0UsOERBQUMsbURBQUQ7QUFDRSxpQkFBSyxFQUFFLEdBRFQ7QUFFRSxrQkFBTSxFQUFFLEdBRlY7QUFHRSxlQUFHLEVBQUMsaUJBSE47QUFJRSxlQUFHLEVBQUM7QUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWkYsZUFtQ0UsOERBQUMsYUFBRDtBQUFBLGdDQUNFLDhEQUFDLGlCQUFEO0FBQUEsa0NBQ0UsOERBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUlFLDhEQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQVNFLDhEQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVEYsZUFVRSw4REFBQyxvREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZGLGVBV0UsOERBQUMsc0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFYRixlQVlFLDhEQUFDLHFEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFzREQsQ0ExRkQ7O0FBNEZBLGlFQUFldFMsT0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNMkgsT0FBTyxHQUFHbkksMkVBQUg7QUFBQTtBQUFBO0FBQUEsbURBQWI7QUFLQSxNQUFNK1MsYUFBYSxHQUFHL1MsdUVBQUg7QUFBQTtBQUFBO0FBQUEsNENBQW5CO0FBS0EsTUFBTW9JLFNBQVMsR0FBR3BJLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHVOQUFmO0FBZ0JBLE1BQU02RixTQUFTLEdBQUc3RixxRUFBSDtBQUFBO0FBQUE7QUFBQSx3V0FHQXFGLDZFQUhBLEVBSUVBLDJFQUpGLEVBVUVBLDZFQVZGLEVBV0lBLDJFQVhKLEVBY0VBLDZFQWRGLEVBZUlBLDJFQWZKLENBQWY7QUEwQkEsTUFBTXlILFVBQVUsR0FBRzlNLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHVSQUFoQjtBQXdCQSxNQUFNK0ksWUFBWSxHQUFHL0ksdUVBQUg7QUFBQTtBQUFBO0FBQUEsaUhBQWxCOztBQWFBLE1BQU1LLE1BQU0sR0FBRyxNQUFNO0FBRW5CLFFBQU07QUFBQSxPQUFDOFAsWUFBRDtBQUFBLE9BQWVDO0FBQWYsTUFBa0N4aEIsK0NBQVEsQ0FBQyxDQUFELENBQWhEOztBQUVBLFFBQU02YixpQkFBaUIsR0FBRyxNQUFNO0FBQzlCLFVBQU1vRyxXQUFXLEdBQUc5cEIsTUFBTSxDQUFDb2dCLFVBQTNCOztBQUNBLFlBQVEsSUFBUjtBQUNFLFdBQUswSixXQUFXLEdBQUcsSUFBbkI7QUFDRVQsUUFBQUEsZUFBZSxDQUFDLElBQUQsQ0FBZjtBQUNBOztBQUNGLFdBQUtTLFdBQVcsR0FBRyxJQUFuQjtBQUNFVCxRQUFBQSxlQUFlLENBQUMsSUFBRCxDQUFmO0FBQ0E7O0FBQ0Y7QUFDRUEsUUFBQUEsZUFBZSxDQUFDLElBQUQsQ0FBZjtBQUNBO0FBVEo7QUFXRCxHQWJEOztBQWVBaHJCLEVBQUFBLGdEQUFTLENBQUMsTUFBTTtBQUNkcWxCLElBQUFBLGlCQUFpQjtBQUNqQjFqQixJQUFBQSxNQUFNLENBQUNtVCxnQkFBUCxDQUF3QixRQUF4QixFQUFrQ3VRLGlCQUFsQztBQUNBLFdBQU8sTUFBTTtBQUNYMWpCLE1BQUFBLE1BQU0sQ0FBQytqQixtQkFBUCxDQUEyQixRQUEzQixFQUFxQ0wsaUJBQXJDO0FBQ0QsS0FGRDtBQUdELEdBTlEsRUFNTixFQU5NLENBQVQ7QUFRQSxzQkFDRSw4REFBQyxPQUFEO0FBQUEsNEJBQ0UsOERBQUMsU0FBRDtBQUFXLFFBQUUsRUFBQyxPQUFkO0FBQUEsOEJBQ0UsOERBQUMsYUFBRDtBQUFBLCtCQUNFLDhEQUFDLHNFQUFEO0FBQWMsaUJBQU8sRUFBQyxTQUF0QjtBQUFnQyxpQkFBTyxFQUFDLDBCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFNRSw4REFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5GLGVBV0UsOERBQUMsVUFBRDtBQUFBLCtCQUNFLDhEQUFDLG1EQUFEO0FBQ0UsZUFBSyxFQUFFLE1BQU0wRixZQURmO0FBRUUsZ0JBQU0sRUFBRSxNQUFNQSxZQUZoQjtBQUdFLGFBQUcsRUFBQyxpQkFITjtBQUlFLGFBQUcsRUFBQztBQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQXFCRSw4REFBQyxZQUFEO0FBQUEsNkJBQ0UsOERBQUMsbURBQUQ7QUFDRSxhQUFLLEVBQUUsSUFEVDtBQUVFLGNBQU0sRUFBRSxHQUZWO0FBR0UsV0FBRyxFQUFDLHVCQUhOO0FBSUUsV0FBRyxFQUFDO0FBSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0NELENBM0REOztBQTZEQSxpRUFBZTlQLE1BQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1SkE7QUFDQTtBQUNBO0FBQ0E7O0FBUUEsTUFBTTJTLElBQUksR0FBR2hULHVFQUFIO0FBQUE7QUFBQTtBQUFBLHlTQUNZeGMsS0FBSyxJQUFJQSxLQUFLLENBQUN5dkIsT0FEM0IsRUFFR3p2QixLQUFLLElBQUlBLEtBQUssQ0FBQ2hFLE9BRmxCLENBQVY7QUFvQkEsTUFBTTB6QixVQUFVLEdBQUdsVCx1RUFBSDtBQUFBO0FBQUE7QUFBQSw0SkFBaEI7QUFlQSxNQUFNNkYsU0FBUyxHQUFHN0YscUVBQUg7QUFBQTtBQUFBO0FBQUEsbVVBRUFxRiw2RUFGQSxFQUdFQSwyRUFIRixFQVFFQSw2RUFSRixFQVNJQSwyRUFUSixFQWFFQSw2RUFiRixFQWNJQSwyRUFkSixFQWtCRUEsNEVBbEJGLEVBbUJJQSwwRUFuQkosRUF1QkVBLDRFQXZCRixFQXdCSUEsMEVBeEJKLENBQWY7O0FBNkJBLE1BQU02RCxZQUFZLEdBQUcsQ0FBQztBQUFFdGtCLEVBQUFBLFFBQUY7QUFBWXF1QixFQUFBQSxPQUFaO0FBQXFCenpCLEVBQUFBO0FBQXJCLENBQUQsS0FBZ0Q7QUFDbkUsc0JBQ0UsOERBQUMsSUFBRDtBQUFNLFdBQU8sRUFBRXl6QixPQUFmO0FBQXdCLFdBQU8sRUFBRXp6QixPQUFqQztBQUFBLDRCQUNFLDhEQUFDLFVBQUQ7QUFBQSw2QkFDRSw4REFBQyxtREFBRDtBQUNFLGFBQUssRUFBRSxHQURUO0FBRUUsY0FBTSxFQUFFLEdBRlY7QUFHRSxXQUFHLEVBQUMsaUJBSE47QUFJRSxXQUFHLEVBQUM7QUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVNFLDhEQUFDLFNBQUQ7QUFBQSxnQkFDR29GO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWVELENBaEJEOztBQWtCQSxpRUFBZXNrQixZQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0ZBO0FBQ0E7O0FBVUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxNQUFNaUssS0FBSyxHQUFHblQsdUVBQUg7QUFBQTtBQUFBO0FBQUEsMFFBQVg7QUFtQkEsTUFBTW9ULE1BQU0sR0FBR3BULHVFQUFIO0FBQUE7QUFBQTtBQUFBLG1FQUFaO0FBTUEsTUFBTXFULE1BQU0sR0FBR3JULHVFQUFIO0FBQUE7QUFBQTtBQUFBLDBCQUFaOztBQUlBLE1BQU0rTyxhQUE4QixHQUFJdnJCLEtBQUQsSUFBVztBQUNoRDtBQUNBLFFBQU07QUFBQ2doQixJQUFBQSxlQUFEO0FBQWtCekMsSUFBQUEsT0FBbEI7QUFBMkJJLElBQUFBLE9BQTNCO0FBQW9DQyxJQUFBQTtBQUFwQyxNQUErQzVlLEtBQXJEO0FBRUEsUUFBTTJ2QixLQUFLLEdBQUduVCx1RUFBSDtBQUFBO0FBQUE7QUFBQSwrUkFBWDs7QUFzQkEsUUFBTXNULFlBQVksR0FBSXZSLE9BQUQsSUFBcUI7QUFDeEMsV0FDRUEsT0FBTyxDQUFDblUsU0FBUixDQUFrQixDQUFsQixFQUFxQixFQUFyQixJQUNBLEtBREEsR0FFQW1VLE9BQU8sQ0FBQ25VLFNBQVIsQ0FBa0JtVSxPQUFPLENBQUN2c0IsTUFBUixHQUFpQixDQUFuQyxFQUFzQ3VzQixPQUFPLENBQUN2c0IsTUFBOUMsQ0FIRjtBQUtELEdBTkQ7O0FBUUEsc0JBQ0UsOERBQUMsS0FBRDtBQUFPLFdBQU8sRUFBR3lOLENBQUQsSUFBT3VoQixlQUFlLENBQUN2aEIsQ0FBRCxDQUF0QztBQUFBLGNBQ0c4ZSxPQUFPLGdCQUNOO0FBQUEsOEJBQ0UsOERBQUMsTUFBRDtBQUFBLGtCQUNHSSxPQUFPLEdBQ0ppQyxNQUFNLENBQUNqQyxPQUFELENBQU4sQ0FBZ0JvUixPQUFoQixDQUF3QixDQUF4QixJQUE2QixNQUR6QixHQUVKcjFCLE1BQU0sQ0FBQ2lrQixPQUFELENBQU4sS0FBb0IsR0FBcEIsR0FDQSxPQURBLEdBRUE7QUFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBUUUsOERBQUMsTUFBRDtBQUFBLGtCQUFTSixPQUFPLEdBQUd1UixZQUFZLENBQUN2UixPQUFELENBQWYsR0FBMkI7QUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRE0sZ0JBWU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFrQkQsQ0FwREQ7O0FBc0RBLGlFQUFlZ04sYUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvR0E7QUFDQTtBQUdBOzs7QUFNQSxNQUFNMkUsVUFBVSxHQUFHLENBQUM7QUFBRTd5QixFQUFBQSxJQUFGO0FBQVErRCxFQUFBQSxRQUFSO0FBQWtCK3VCLEVBQUFBLGVBQWxCO0FBQW1DQyxFQUFBQSxXQUFuQztBQUFnREMsRUFBQUE7QUFBaEQsQ0FBRCxLQUF3RjtBQUN6RyxRQUFNQyxXQUFXLEdBQUcsTUFBTTtBQUN4QkgsSUFBQUEsZUFBZTtBQUNmdnNCLElBQUFBLFVBQVUsQ0FBQyxNQUFNO0FBQ2Z3c0IsTUFBQUEsV0FBVyxDQUFDL3lCLElBQUQsQ0FBWDtBQUNELEtBRlMsRUFFUGd6QixnQkFGTyxDQUFWO0FBR0QsR0FMRDs7QUFPQSxzQkFDRSw4REFBQywrQ0FBRDtBQUFBLDRCQUNFLDhEQUFDLGlEQUFEO0FBQUEsNkJBQ0UsOERBQUMsbURBQUQ7QUFDRSxhQUFLLEVBQUUsRUFEVDtBQUVFLGNBQU0sRUFBRSxFQUZWO0FBR0UsY0FBTSxFQUFDLE9BSFQ7QUFJRSxXQUFHLEVBQUMsaUJBSk47QUFLRSxXQUFHLEVBQUM7QUFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVVFLDhEQUFDLHFEQUFEO0FBQWdCLGFBQU8sRUFBRUMsV0FBekI7QUFBQSxnQkFDR2x2QjtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFnQkQsQ0F4QkQ7O0FBMEJBLGlFQUFlOHVCLFVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUcsZ0JBQWdCLEdBQUcsR0FBekI7QUFFQTtBQUNBO0FBRUE7QUFhQTtBQUNBOzs7QUFJQSxNQUFNelQsTUFBTSxHQUFJNWMsS0FBRCxJQUFnQjtBQUM3QixRQUFNO0FBQUEsT0FBQ2t4QixpQkFBRDtBQUFBLE9BQW9CQztBQUFwQixNQUE0Qy9sQiwrQ0FBUSxDQUFDLE1BQUQsQ0FBMUQ7QUFDQSxRQUFNO0FBQUEsT0FBQ2dtQixlQUFEO0FBQUEsT0FBa0JDO0FBQWxCLE1BQXdDam1CLCtDQUFRLENBQUMsS0FBRCxDQUF0RDs7QUFDQSxRQUFNO0FBQUM0VixJQUFBQTtBQUFELE1BQWtDaGhCLEtBQXhDO0FBQUEsUUFBMkJ5ZSxRQUEzQiw0QkFBd0N6ZSxLQUF4QyxhQUg2QixDQUk3QjtBQUVBOzs7QUFDQSxRQUFNO0FBQUEsT0FBQ3N4QixXQUFEO0FBQUEsT0FBY0M7QUFBZCxNQUFnQ25tQiwrQ0FBUSxDQUFDO0FBQzdDb21CLElBQUFBLEtBQUssRUFBRSxDQURzQztBQUU3Q0MsSUFBQUEsTUFBTSxFQUFFLENBRnFDO0FBRzdDQyxJQUFBQSxPQUFPLEVBQUUsQ0FIb0M7QUFJN0NDLElBQUFBLEdBQUcsRUFBRTtBQUp3QyxHQUFELENBQTlDLENBUDZCLENBYzdCOztBQUNBLFFBQU0xSyxpQkFBaUIsR0FBRyxNQUFNO0FBQzlCMkosSUFBQUEsc0RBQVksQ0FBQ1csY0FBRCxFQUFpQmh1QixNQUFNLENBQUNvZ0IsVUFBeEIsQ0FBWjtBQUNELEdBRkQsQ0FmNkIsQ0FtQjdCOzs7QUFDQS9oQixFQUFBQSxnREFBUyxDQUFDLE1BQU07QUFDZHFsQixJQUFBQSxpQkFBaUI7QUFDakIxakIsSUFBQUEsTUFBTSxDQUFDbVQsZ0JBQVAsQ0FBd0IsUUFBeEIsRUFBa0N1USxpQkFBbEM7QUFDQSxXQUFPLE1BQU07QUFDWDFqQixNQUFBQSxNQUFNLENBQUMrakIsbUJBQVAsQ0FBMkIsUUFBM0IsRUFBcUNMLGlCQUFyQztBQUNELEtBRkQ7QUFHRCxHQU5RLEVBTU4sRUFOTSxDQUFULENBcEI2QixDQTRCN0I7O0FBQ0EsUUFBTWtKLGVBQWUsR0FBRyxNQUFNO0FBQzVCa0IsSUFBQUEsa0JBQWtCLENBQUMsQ0FBQ0QsZUFBRixDQUFsQjtBQUNBRCxJQUFBQSxvQkFBb0IsQ0FBQ0MsZUFBZSxHQUFHLE1BQUgsR0FBWSxHQUE1QixDQUFwQjtBQUNELEdBSEQsQ0E3QjZCLENBa0M3Qjs7O0FBQ0EsUUFBTWhCLFdBQVcsR0FBSS95QixJQUFELElBQW9CO0FBQ3RDLFVBQU11MEIsT0FBTyxHQUFHM3NCLFFBQVEsQ0FBQ3NXLGNBQVQsQ0FBd0JsZSxJQUF4QixDQUFoQjtBQUNBLFVBQU13MEIsVUFBVSxHQUFHUCxXQUFXLENBQUNqMEIsSUFBRCxDQUE5QjtBQUNBa0csSUFBQUEsTUFBTSxDQUFDdXVCLFFBQVAsQ0FBZ0I7QUFDZG4yQixNQUFBQSxHQUFHLEVBQUVpMkIsT0FBTyxDQUFDRyxxQkFBUixHQUFnQ3AyQixHQUFoQyxHQUFzQ2syQixVQUQ3QjtBQUVkRyxNQUFBQSxRQUFRLEVBQUU7QUFGSSxLQUFoQjtBQUlELEdBUEQ7O0FBU0EsUUFBTUMsV0FBVyxHQUFHLENBQUM7QUFBRTUwQixJQUFBQSxJQUFGO0FBQVErRCxJQUFBQTtBQUFSLEdBQUQsS0FBeUM7QUFDM0Qsd0JBQ0UsOERBQUMsOENBQUQ7QUFBQSw2QkFDRTtBQUFHLGVBQU8sRUFBRSxNQUFNZ3ZCLFdBQVcsQ0FBQy95QixJQUFELENBQTdCO0FBQUEsa0JBQXNDK0Q7QUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREY7QUFLRCxHQU5EOztBQVFBLFFBQU04d0IsY0FBYyxHQUFHLENBQUM7QUFBRTcwQixJQUFBQSxJQUFGO0FBQVErRCxJQUFBQTtBQUFSLEdBQUQsS0FBZ0U7QUFDckYsd0JBQ0UsOERBQUMsZ0RBQUQ7QUFDRSxxQkFBZSxFQUFFK3VCLGVBRG5CO0FBRUUsaUJBQVcsRUFBRUMsV0FGZjtBQUdFLHNCQUFnQixFQUFFQyxnQkFIcEI7QUFJRSxVQUFJLEVBQUVoekIsSUFKUjtBQUFBLGdCQUtJK0Q7QUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBU0QsR0FWRDs7QUFZQSxzQkFDRSw4REFBQywwQ0FBRDtBQUFBLDRCQUVFLDhEQUFDLDRDQUFEO0FBQUEsNkJBQ0EsOERBQUMsMkNBQUQ7QUFBQSwrQkFDRSw4REFBQyxtREFBRDtBQUNFLGVBQUssRUFBRSxHQURUO0FBRUUsZ0JBQU0sRUFBRSxFQUZWO0FBR0UsYUFBRyxFQUFDLG9CQUhOO0FBSUUsYUFBRyxFQUFDO0FBSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGLGVBaUJFLDhEQUFDLDRDQUFEO0FBQUEsOEJBQ0EsOERBQUMsaURBQUQ7QUFBVSxZQUFJLEVBQUVpb0Isc0RBQWhCO0FBQUEsK0JBQ0ksOERBQUMsaURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREEsZUFJRSw4REFBQyxpREFBRDtBQUFVLFlBQUksRUFBRXFILHNEQUFoQjtBQUFBLCtCQUNFLDhEQUFDLGlEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBT0UsOERBQUMsaURBQUQ7QUFBVSxZQUFJLEVBQUVDLG1EQUFoQjtBQUFBLCtCQUNFLDhEQUFDLGtEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVBGLGVBVUUsOERBQUMsaUVBQUQsb0JBQW1CM3dCLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXFERCxDQXJIRDs7QUF1SEEsaUVBQWU0YyxNQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xKQTtBQUNBO0FBRU8sTUFBTWtVLEdBQUcsR0FBR3RVLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDBaQUFUO0FBMEJBLE1BQU11VSxPQUFPLEdBQUd2VSx1RUFBSDtBQUFBO0FBQUE7QUFBQSxvYkFRSHFGLDZFQVJHLEVBY0RBLDZFQWRDLEVBaUJEQSw2RUFqQkMsQ0FBYjtBQThCQSxNQUFNbVAsS0FBSyxHQUFHeFUsdUVBQUg7QUFBQTtBQUFBO0FBQUEsbUVBQVg7QUFVQSxNQUFNeVUsSUFBSSxHQUFHelUsdUVBQUg7QUFBQTtBQUFBO0FBQUEsc05BQVY7QUFrQkEsTUFBTTJWLFVBQVUsR0FBRzNWLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHFUQVdLLENBQUM7QUFBRTZULEVBQUFBO0FBQUYsQ0FBRCxLQUEwQkEsZ0JBWC9CLEVBa0JOLENBQUM7QUFBRStCLEVBQUFBO0FBQUYsQ0FBRCxLQUFnQkEsTUFBTSxHQUFHLG1DQUFILEdBQXlDLDRCQWxCekQsRUFzQkwsQ0FBQztBQUFFQSxFQUFBQTtBQUFGLENBQUQsS0FBZ0JBLE1BQU0sR0FBRyxRQUFILEdBQWMsTUF0Qi9CLEVBMEJOLENBQUM7QUFBRUEsRUFBQUE7QUFBRixDQUFELEtBQWdCQSxNQUFNLEdBQUcsc0NBQUgsR0FBNEMsNEJBMUI1RCxDQUFoQjtBQWtDQSxNQUFNQyxTQUFTLEdBQUc3Vix1RUFBSDtBQUFBO0FBQUE7QUFBQSxvS0FPWnhjLEtBQUssSUFBSUEsS0FBSyxDQUFDcEUsSUFQSCxDQUFmO0FBYUEsTUFBTTJwQixZQUFZLEdBQUcvSSx1RUFBSDtBQUFBO0FBQUE7QUFBQSx3RkFBbEI7QUFXQSxNQUFNd1QsUUFBUSxHQUFHeFQscUVBQUg7QUFBQTtBQUFBO0FBQUEsOEdBQWQ7QUFTQSxNQUFNOFYsV0FBVyxHQUFHOVYsdUVBQUg7QUFBQTtBQUFBO0FBQUEsMkdBQWpCO0FBU0EsTUFBTWtULFVBQVUsR0FBR2xULHVFQUFIO0FBQUE7QUFBQTtBQUFBLDBCQUFoQjtBQUlBLE1BQU15VCxjQUFjLEdBQUd6VCx3RUFBSDtBQUFBO0FBQUE7QUFBQSx3REFBcEI7QUFNQSxNQUFNZ1csUUFBUSxHQUFHaFcsdUVBQUg7QUFBQTtBQUFBO0FBQUEsc0RBQWQ7Ozs7Ozs7Ozs7Ozs7OztBQzdLUCxNQUFNb1UsWUFBWSxHQUFHLENBQUNXLGNBQUQsRUFBc0IvN0IsS0FBdEIsS0FBd0M7QUFDM0QsTUFBSUEsS0FBSyxJQUFJLElBQWIsRUFBbUI7QUFDakIrN0IsSUFBQUEsY0FBYyxDQUFDO0FBQ2JDLE1BQUFBLEtBQUssRUFBRSxHQURNO0FBRWJDLE1BQUFBLE1BQU0sRUFBRSxHQUZLO0FBR2JDLE1BQUFBLE9BQU8sRUFBRSxDQUFDLEdBSEc7QUFJYkMsTUFBQUEsR0FBRyxFQUFFO0FBSlEsS0FBRCxDQUFkO0FBTUE7QUFDRDs7QUFDRCxNQUFJbjhCLEtBQUssSUFBSSxJQUFiLEVBQW1CO0FBQ2pCKzdCLElBQUFBLGNBQWMsQ0FBQztBQUNiQyxNQUFBQSxLQUFLLEVBQUUsR0FETTtBQUViQyxNQUFBQSxNQUFNLEVBQUUsR0FGSztBQUdiQyxNQUFBQSxPQUFPLEVBQUUsQ0FBQyxHQUhHO0FBSWJDLE1BQUFBLEdBQUcsRUFBRTtBQUpRLEtBQUQsQ0FBZDtBQU1BO0FBQ0Q7O0FBQ0QsTUFBSW44QixLQUFLLElBQUksSUFBYixFQUFtQjtBQUNqQis3QixJQUFBQSxjQUFjLENBQUM7QUFDYkMsTUFBQUEsS0FBSyxFQUFFLEdBRE07QUFFYkMsTUFBQUEsTUFBTSxFQUFFLEdBRks7QUFHYkMsTUFBQUEsT0FBTyxFQUFFLENBQUMsR0FIRztBQUliQyxNQUFBQSxHQUFHLEVBQUU7QUFKUSxLQUFELENBQWQ7QUFNQTtBQUNEOztBQUNELE1BQUluOEIsS0FBSyxJQUFJLElBQWIsRUFBbUI7QUFDakIrN0IsSUFBQUEsY0FBYyxDQUFDO0FBQ2JDLE1BQUFBLEtBQUssRUFBRSxHQURNO0FBRWJDLE1BQUFBLE1BQU0sRUFBRSxFQUZLO0FBR2JDLE1BQUFBLE9BQU8sRUFBRSxDQUFDLEdBSEc7QUFJYkMsTUFBQUEsR0FBRyxFQUFFO0FBSlEsS0FBRCxDQUFkO0FBTUE7QUFDRDs7QUFDRCxNQUFJbjhCLEtBQUssSUFBSSxHQUFiLEVBQWtCO0FBQ2hCKzdCLElBQUFBLGNBQWMsQ0FBQztBQUNiQyxNQUFBQSxLQUFLLEVBQUUsQ0FBQyxFQURLO0FBRWJDLE1BQUFBLE1BQU0sRUFBRSxDQUFDLEVBRkk7QUFHYkMsTUFBQUEsT0FBTyxFQUFFLENBQUMsR0FIRztBQUliQyxNQUFBQSxHQUFHLEVBQUUsQ0FBQztBQUpPLEtBQUQsQ0FBZDtBQU1BO0FBQ0Q7O0FBQ0QsTUFBSW44QixLQUFLLElBQUksR0FBYixFQUFrQjtBQUNoQis3QixJQUFBQSxjQUFjLENBQUM7QUFDYkMsTUFBQUEsS0FBSyxFQUFFLENBQUMsRUFESztBQUViQyxNQUFBQSxNQUFNLEVBQUUsQ0FBQyxFQUZJO0FBR2JDLE1BQUFBLE9BQU8sRUFBRSxDQUFDLEdBSEc7QUFJYkMsTUFBQUEsR0FBRyxFQUFFLENBQUM7QUFKTyxLQUFELENBQWQ7QUFNQTtBQUNEO0FBQ0YsQ0F2REQ7O0FBeURBLGlFQUFlZixZQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pEQTs7QUFFTyxNQUFNTCxPQUFPLEdBQUl2d0IsS0FBRCxJQUFXO0FBQzlCLFFBQU07QUFBRXhLLElBQUFBLEtBQUssR0FBRyxFQUFWO0FBQWNrRSxJQUFBQSxNQUFNLEdBQUcsRUFBdkI7QUFBMkIrNEIsSUFBQUE7QUFBM0IsTUFBb0N6eUIsS0FBMUM7QUFDQSxzQkFDSjtBQUFLLFVBQU0sRUFBRXhLLEtBQWI7QUFBb0IsU0FBSyxFQUFFa0UsTUFBM0I7QUFBbUMsV0FBTyxFQUFDLHNCQUEzQztBQUFBLDRCQUFrRTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWxFLGVBQWtSO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREk7QUFHSCxDQUxNO0FBT0EsTUFBTSsyQixRQUFRLEdBQUl6d0IsS0FBRCxJQUFXO0FBQy9CLFFBQU07QUFBR3hLLElBQUFBLEtBQUssR0FBRyxFQUFYO0FBQWVrRSxJQUFBQSxNQUFNLEdBQUcsRUFBeEI7QUFBNEIrNEIsSUFBQUE7QUFBNUIsTUFBcUN6eUIsS0FBM0M7QUFDQSxzQkFDSjtBQUFLLFVBQU0sRUFBRXhLLEtBQWI7QUFBb0IsU0FBSyxFQUFFa0UsTUFBM0I7QUFBbUMsV0FBTyxFQUFDLGlCQUEzQztBQUFBLDRCQUE2RDtBQUFBLDZCQUFNO0FBQWdCLHFCQUFhLEVBQUMsZ0JBQTlCO0FBQStDLFVBQUUsRUFBQyxLQUFsRDtBQUF3RCxVQUFFLEVBQUMsUUFBM0Q7QUFBb0UsVUFBRSxFQUFDLFFBQXZFO0FBQWdGLFVBQUUsRUFBQyxRQUFuRjtBQUE0RixVQUFFLEVBQUMsR0FBL0Y7QUFBQSxnQ0FBbUc7QUFBTSxnQkFBTSxFQUFDLEdBQWI7QUFBaUIsd0JBQVc7QUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbkcsZUFBMEk7QUFBTSxnQkFBTSxFQUFDLEdBQWI7QUFBaUIsd0JBQVc7QUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBN0QsZUFBNFE7QUFBUSxRQUFFLEVBQUMsS0FBWDtBQUFpQixRQUFFLEVBQUMsS0FBcEI7QUFBMEIsT0FBQyxFQUFDLEtBQTVCO0FBQWtDLFVBQUksRUFBQztBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE1USxlQUE4VDtBQUFNLFVBQUksRUFBQyxNQUFYO0FBQWtCLE9BQUMsRUFBQztBQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE5VDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESTtBQUdILENBTE07QUFPQSxNQUFNODJCLE9BQU8sR0FBSXh3QixLQUFELElBQVc7QUFDOUIsUUFBTTtBQUFHeEssSUFBQUEsS0FBSyxHQUFHLEVBQVg7QUFBZWtFLElBQUFBLE1BQU0sR0FBRyxFQUF4QjtBQUE0Qis0QixJQUFBQTtBQUE1QixNQUFxQ3p5QixLQUEzQztBQUNBLHNCQUNKO0FBQUssVUFBTSxFQUFFeEssS0FBYjtBQUFvQixTQUFLLEVBQUVrRSxNQUEzQjtBQUFrQyxXQUFPLEVBQUMsc0NBQTFDO0FBQUEsMkJBQWlGO0FBQU0sVUFBSSxFQUFDLE9BQVg7QUFBbUIsT0FBQyxFQUFDO0FBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURJO0FBSUgsQ0FOTTtBQVFBLE1BQU1nNUIsTUFBTSxHQUFJMXlCLEtBQUQsSUFBVztBQUM3QixRQUFNO0FBQUV4SyxJQUFBQSxLQUFLLEdBQUcsRUFBVjtBQUFja0UsSUFBQUEsTUFBTSxHQUFHLEVBQXZCO0FBQTJCKzRCLElBQUFBO0FBQTNCLE1BQW9DenlCLEtBQTFDO0FBQ0Esc0JBQ0k7QUFBSyxTQUFLLEVBQUV4SyxLQUFaO0FBQW1CLFVBQU0sRUFBRUEsS0FBM0I7QUFBa0MsV0FBTyxFQUFHLE9BQU1BLEtBQU0sSUFBR2tFLE1BQU8sRUFBbEU7QUFBcUUsUUFBSSxFQUFDLE1BQTFFO0FBQWlGLFNBQUssRUFBQyw0QkFBdkY7QUFBQSwyQkFDSTtBQUNJLE9BQUMsRUFBQyxrd0JBRE47QUFPSSxVQUFJLEVBQUM7QUFQVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBYUgsQ0FmTTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4QlA7QUFHTyxNQUFNbTNCLFFBQVEsR0FBR3JVLHFFQUFIO0FBQUE7QUFBQTtBQUFBLGlPQUFkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIQSxNQUFNNk0sWUFBWSxHQUFHLCtCQUFyQjtBQUNBLE1BQU1xSCxZQUFZLEdBQUcsZ0NBQXJCO0FBQ0EsTUFBTUMsU0FBUyxHQUFHLHlCQUFsQjtBQUNBLE1BQU1nQyxXQUFXLEdBQUcsZ0NBQXBCOzs7Ozs7Ozs7Ozs7Ozs7O0FDSEEsTUFBTTlRLEtBQUssR0FBRztBQUNuQmtELEVBQUFBLE1BQU0sRUFBRTtBQUNOQyxJQUFBQSxLQUFLLEVBQUU7QUFDTHhDLE1BQUFBLFFBQVEsRUFBRSxNQURMO0FBRUw5b0IsTUFBQUEsTUFBTSxFQUFFO0FBRkgsS0FERDtBQUtOdXJCLElBQUFBLEtBQUssRUFBRTtBQUNMekMsTUFBQUEsUUFBUSxFQUFFLE1BREw7QUFFTDlvQixNQUFBQSxNQUFNLEVBQUU7QUFGSCxLQUxEO0FBU042b0IsSUFBQUEsS0FBSyxFQUFFO0FBQ0xDLE1BQUFBLFFBQVEsRUFBRSxNQURMO0FBRUw5b0IsTUFBQUEsTUFBTSxFQUFFO0FBRkgsS0FURDtBQWFOK29CLElBQUFBLElBQUksRUFBRTtBQUNKRCxNQUFBQSxRQUFRLEVBQUUsTUFETjtBQUVKOW9CLE1BQUFBLE1BQU0sRUFBRTtBQUZKLEtBYkE7QUFpQk5ncEIsSUFBQUEsSUFBSSxFQUFFO0FBQ0pGLE1BQUFBLFFBQVEsRUFBRSxNQUROO0FBRUo5b0IsTUFBQUEsTUFBTSxFQUFFO0FBRko7QUFqQkEsR0FEVztBQXVCbkI0b0IsRUFBQUEsTUFBTSxFQUFFO0FBQ04wQyxJQUFBQSxLQUFLLEVBQUU7QUFDTHhDLE1BQUFBLFFBQVEsRUFBRSxNQURMO0FBRUw5b0IsTUFBQUEsTUFBTSxFQUFFO0FBRkgsS0FERDtBQUtOdXJCLElBQUFBLEtBQUssRUFBRTtBQUNMekMsTUFBQUEsUUFBUSxFQUFFLE1BREw7QUFFTDlvQixNQUFBQSxNQUFNLEVBQUU7QUFGSCxLQUxEO0FBU042b0IsSUFBQUEsS0FBSyxFQUFFO0FBQ0xDLE1BQUFBLFFBQVEsRUFBRSxNQURMO0FBRUw5b0IsTUFBQUEsTUFBTSxFQUFFO0FBRkgsS0FURDtBQWFOK29CLElBQUFBLElBQUksRUFBRTtBQUNKRCxNQUFBQSxRQUFRLEVBQUUsTUFETjtBQUVKOW9CLE1BQUFBLE1BQU0sRUFBRTtBQUZKLEtBYkE7QUFpQk5ncEIsSUFBQUEsSUFBSSxFQUFFO0FBQ0pGLE1BQUFBLFFBQVEsRUFBRSxNQUROO0FBRUo5b0IsTUFBQUEsTUFBTSxFQUFFO0FBRko7QUFqQkEsR0F2Qlc7QUE2Q25CNnNCLEVBQUFBLE1BQU0sRUFBRTtBQUNOdkIsSUFBQUEsS0FBSyxFQUFFO0FBQ0x4QyxNQUFBQSxRQUFRLEVBQUUsTUFETDtBQUVMOW9CLE1BQUFBLE1BQU0sRUFBRTtBQUZILEtBREQ7QUFLTnVyQixJQUFBQSxLQUFLLEVBQUU7QUFDTHpDLE1BQUFBLFFBQVEsRUFBRSxNQURMO0FBRUw5b0IsTUFBQUEsTUFBTSxFQUFFO0FBRkgsS0FMRDtBQVNONm9CLElBQUFBLEtBQUssRUFBRTtBQUNMQyxNQUFBQSxRQUFRLEVBQUUsTUFETDtBQUVMOW9CLE1BQUFBLE1BQU0sRUFBRTtBQUZILEtBVEQ7QUFhTitvQixJQUFBQSxJQUFJLEVBQUU7QUFDSkQsTUFBQUEsUUFBUSxFQUFFLE1BRE47QUFFSjlvQixNQUFBQSxNQUFNLEVBQUU7QUFGSixLQWJBO0FBaUJOZ3BCLElBQUFBLElBQUksRUFBRTtBQUNKRixNQUFBQSxRQUFRLEVBQUUsTUFETjtBQUVKOW9CLE1BQUFBLE1BQU0sRUFBRTtBQUZKO0FBakJBO0FBN0NXLENBQWQ7QUFxRVAsaUVBQWVtb0IsS0FBZjs7Ozs7Ozs7Ozs7Ozs7OztBQ3JFTyxJQUFLK0ksY0FBWjs7V0FBWUE7QUFBQUEsRUFBQUEsZUFBQUE7QUFBQUEsRUFBQUEsZUFBQUE7QUFBQUEsRUFBQUEsZUFBQUE7R0FBQUEsbUJBQUFBOztBQU1MLElBQUtDLFdBQVo7O1dBQVlBO0FBQUFBLEVBQUFBLFlBQUFBO0FBQUFBLEVBQUFBLFlBQUFBO0FBQUFBLEVBQUFBLFlBQUFBO0dBQUFBLGdCQUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTkwsTUFBTXhCLFlBQVksR0FBRywrQkFBckI7QUFDQSxNQUFNcUgsWUFBWSxHQUFHLGdDQUFyQjtBQUNBLE1BQU1DLFNBQVMsR0FBRyx5QkFBbEI7QUFDQSxNQUFNZ0MsV0FBVyxHQUFHLGdDQUFwQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIUDtBQUNPLE1BQU14SixVQUFVLEdBQUcsNENBQW5CO0FBQ0EsTUFBTXlKLFNBQVMsR0FBRyxFQUFsQjtBQUNBLE1BQU1DLFFBQVEsR0FBRSxFQUFoQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0NGUDs7QUFDQTtBQUVBO0FBRU8sTUFBTXBWLGNBQWMsR0FBSVUsUUFBRCxJQUFjO0FBQzFDLFNBQU8sSUFBSWQsbURBQUosQ0FBb0I4TCwrQ0FBcEIsRUFBZ0MySiw4Q0FBaEMsRUFBZ0QzVSxRQUFoRCxDQUFQO0FBQ0QsQ0FGTTtBQUlBLE1BQU1YLGFBQWEsR0FBRyxNQUFNO0FBQ2pDLFNBQU8yTCwrQ0FBUDtBQUNELENBRk07Ozs7Ozs7Ozs7QUNWUCwyR0FBK0M7Ozs7Ozs7Ozs7O0FDQS9DLHlHQUE4Qzs7Ozs7Ozs7Ozs7O0FDQTlDOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly91c2FnaS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L2ltYWdlLmpzIiwid2VicGFjazovL3VzYWdpLy4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvbGluay5qcyIsIndlYnBhY2s6Ly91c2FnaS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L25vcm1hbGl6ZS10cmFpbGluZy1zbGFzaC5qcyIsIndlYnBhY2s6Ly91c2FnaS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3JlcXVlc3QtaWRsZS1jYWxsYmFjay5qcyIsIndlYnBhY2s6Ly91c2FnaS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3JvdXRlLWxvYWRlci5qcyIsIndlYnBhY2s6Ly91c2FnaS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3JvdXRlci5qcyIsIndlYnBhY2s6Ly91c2FnaS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3VzZS1pbnRlcnNlY3Rpb24uanMiLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC93aXRoLXJvdXRlci5qcyIsIndlYnBhY2s6Ly91c2FnaS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvcm91dGVyLmpzIiwid2VicGFjazovL3VzYWdpLy4vcGFnZXMvaW5kZXgudHN4Iiwid2VicGFjazovL3VzYWdpLy4vc3JjL2NvbXBvbmVudHMvTGFuZGluZ1BhZ2UvQnVubmllc0Nhcm91c2VsLnRzeCIsIndlYnBhY2s6Ly91c2FnaS8uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL0NvbW11bml0eS50c3giLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9zcmMvY29tcG9uZW50cy9MYW5kaW5nUGFnZS9FZ2dzLnRzeCIsIndlYnBhY2s6Ly91c2FnaS8uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL0V2b2x1dGlvbi9Db250ZW50RGVza3RvcC50c3giLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9zcmMvY29tcG9uZW50cy9MYW5kaW5nUGFnZS9Fdm9sdXRpb24vQ29udGVudE1vYmlsZS50c3giLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9zcmMvY29tcG9uZW50cy9MYW5kaW5nUGFnZS9Fdm9sdXRpb24vRXZvbHV0aW9uLnRzeCIsIndlYnBhY2s6Ly91c2FnaS8uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL0ZhcS50c3giLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9zcmMvY29tcG9uZW50cy9MYW5kaW5nUGFnZS9Gb290ZXIudHN4Iiwid2VicGFjazovL3VzYWdpLy4vc3JjL2NvbXBvbmVudHMvTGFuZGluZ1BhZ2UvSGVyby9Db25uZWN0QnV0dG9uL0Nvbm5lY3RCdXR0b24udHN4Iiwid2VicGFjazovL3VzYWdpLy4vc3JjL2NvbXBvbmVudHMvTGFuZGluZ1BhZ2UvSGVyby9IZXJvLnRzeCIsIndlYnBhY2s6Ly91c2FnaS8uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL0hlcm8vTWludEJ1dHRvbi9NaW50QnV0dG9uLnRzeCIsIndlYnBhY2s6Ly91c2FnaS8uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL1JvYWRtYXAvQ2FsZW5kYXJCb3hGb3VyLnRzeCIsIndlYnBhY2s6Ly91c2FnaS8uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL1JvYWRtYXAvQ2FsZW5kYXJCb3hPbmUudHN4Iiwid2VicGFjazovL3VzYWdpLy4vc3JjL2NvbXBvbmVudHMvTGFuZGluZ1BhZ2UvUm9hZG1hcC9DYWxlbmRhckJveFRocmVlLnRzeCIsIndlYnBhY2s6Ly91c2FnaS8uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL1JvYWRtYXAvQ2FsZW5kYXJCb3hUd28udHN4Iiwid2VicGFjazovL3VzYWdpLy4vc3JjL2NvbXBvbmVudHMvTGFuZGluZ1BhZ2UvUm9hZG1hcC9DYWxlbmRhclN0eWxlLnRzeCIsIndlYnBhY2s6Ly91c2FnaS8uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL1JvYWRtYXAvUm9hZG1hcC50c3giLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9zcmMvY29tcG9uZW50cy9MYW5kaW5nUGFnZS9XaGF0RGEudHN4Iiwid2VicGFjazovL3VzYWdpLy4vc3JjL2NvbXBvbmVudHMvU2hhcmVkL0NhcnJvdEhlYWRlci9DYXJyb3RIZWFkZXIudHN4Iiwid2VicGFjazovL3VzYWdpLy4vc3JjL2NvbXBvbmVudHMvU2hhcmVkL0Nvbm5lY3RCdXR0b24vQ29ubmVjdEJ1dHRvbi50c3giLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9zcmMvY29tcG9uZW50cy9TaGFyZWQvTmF2QmFyL01vYmlsZUxpbmsudHN4Iiwid2VicGFjazovL3VzYWdpLy4vc3JjL2NvbXBvbmVudHMvU2hhcmVkL05hdkJhci9OYXZCYXIudHN4Iiwid2VicGFjazovL3VzYWdpLy4vc3JjL2NvbXBvbmVudHMvU2hhcmVkL05hdkJhci9OYXZTdHlsZS50cyIsIndlYnBhY2s6Ly91c2FnaS8uL3NyYy9jb21wb25lbnRzL1NoYXJlZC9OYXZCYXIvYWRqdXN0U2Nyb2xsLnRzIiwid2VicGFjazovL3VzYWdpLy4vc3JjL2ljb25zL0ljb25zLmpzIiwid2VicGFjazovL3VzYWdpLy4vc3JjL2ljb25zL2ljb24udHMiLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9zcmMvbGlua3MvTGlua3MudHMiLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9zcmMvc3R5bGVzL3R5cG9ncmFwaHkudHMiLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9zcmMvdXRpbHMvSW50ZXJmYWNlLnRzIiwid2VicGFjazovL3VzYWdpLy4vc3JjL3V0aWxzL0xpbmtzLnRzIiwid2VicGFjazovL3VzYWdpLy4vc3JjL3V0aWxzL2NvbmZpZy5qcyIsIndlYnBhY2s6Ly91c2FnaS8uL3NyYy91dGlscy93ZWIzbGliLmpzIiwid2VicGFjazovL3VzYWdpLy4vbm9kZV9tb2R1bGVzL25leHQvaW1hZ2UuanMiLCJ3ZWJwYWNrOi8vdXNhZ2kvLi9ub2RlX21vZHVsZXMvbmV4dC9saW5rLmpzIiwid2VicGFjazovL3VzYWdpL2V4dGVybmFsIFwiQGV0aGVyc3Byb2plY3QvcHJvdmlkZXJzXCIiLCJ3ZWJwYWNrOi8vdXNhZ2kvZXh0ZXJuYWwgXCJAd2FsbGV0Y29ubmVjdC93ZWIzLXByb3ZpZGVyXCIiLCJ3ZWJwYWNrOi8vdXNhZ2kvZXh0ZXJuYWwgXCJldGhlcnNcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcIm5leHQvZGlzdC9zZXJ2ZXIvZGVub3JtYWxpemUtcGFnZS1wYXRoLmpzXCIiLCJ3ZWJwYWNrOi8vdXNhZ2kvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2VydmVyL2ltYWdlLWNvbmZpZy5qc1wiIiwid2VicGFjazovL3VzYWdpL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvaGVhZC5qc1wiIiwid2VicGFjazovL3VzYWdpL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvaTE4bi9ub3JtYWxpemUtbG9jYWxlLXBhdGguanNcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL21pdHQuanNcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci1jb250ZXh0LmpzXCIiLCJ3ZWJwYWNrOi8vdXNhZ2kvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvZ2V0LWFzc2V0LXBhdGgtZnJvbS1yb3V0ZS5qc1wiIiwid2VicGFjazovL3VzYWdpL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL2lzLWR5bmFtaWMuanNcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9wYXJzZS1yZWxhdGl2ZS11cmwuanNcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9xdWVyeXN0cmluZy5qc1wiIiwid2VicGFjazovL3VzYWdpL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3JvdXRlLW1hdGNoZXIuanNcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9yb3V0ZS1yZWdleC5qc1wiIiwid2VicGFjazovL3VzYWdpL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvdG8tYmFzZS02NC5qc1wiIiwid2VicGFjazovL3VzYWdpL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvdXRpbHMuanNcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovL3VzYWdpL2V4dGVybmFsIFwicmVhY3RcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcInJlYWN0LWlzXCIiLCJ3ZWJwYWNrOi8vdXNhZ2kvZXh0ZXJuYWwgXCJyZWFjdC1zd2lwZWFibGVcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcInJlYWN0LXdheXBvaW50XCIiLCJ3ZWJwYWNrOi8vdXNhZ2kvZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcInN0eWxlZC1jb21wb25lbnRzXCIiLCJ3ZWJwYWNrOi8vdXNhZ2kvZXh0ZXJuYWwgXCJ2YWxpZGF0b3JcIiIsIndlYnBhY2s6Ly91c2FnaS9leHRlcm5hbCBcIndlYjNtb2RhbFwiIiwid2VicGFjazovL3VzYWdpL2lnbm9yZWR8RTpcXFNFTEYgQmFzZVxcVXNhZ2lcXG5vZGVfbW9kdWxlc1xcbmV4dFxcZGlzdFxcc2hhcmVkXFxsaWJcXHJvdXRlcnwuL3V0aWxzL3Jlc29sdmUtcmV3cml0ZXMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLmRlZmF1bHQgPSBJbWFnZTE7XG52YXIgX3JlYWN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwicmVhY3RcIikpO1xudmFyIF9oZWFkID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vc2hhcmVkL2xpYi9oZWFkXCIpKTtcbnZhciBfdG9CYXNlNjQgPSByZXF1aXJlKFwiLi4vc2hhcmVkL2xpYi90by1iYXNlLTY0XCIpO1xudmFyIF9pbWFnZUNvbmZpZyA9IHJlcXVpcmUoXCIuLi9zZXJ2ZXIvaW1hZ2UtY29uZmlnXCIpO1xudmFyIF91c2VJbnRlcnNlY3Rpb24gPSByZXF1aXJlKFwiLi91c2UtaW50ZXJzZWN0aW9uXCIpO1xuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KG9iaiwga2V5LCB2YWx1ZSkge1xuICAgIGlmIChrZXkgaW4gb2JqKSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwge1xuICAgICAgICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHdyaXRhYmxlOiB0cnVlXG4gICAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIG9ialtrZXldID0gdmFsdWU7XG4gICAgfVxuICAgIHJldHVybiBvYmo7XG59XG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICAgIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgICAgIGRlZmF1bHQ6IG9ialxuICAgIH07XG59XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKHRhcmdldCkge1xuICAgIGZvcih2YXIgaSA9IDE7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspe1xuICAgICAgICB2YXIgc291cmNlID0gYXJndW1lbnRzW2ldICE9IG51bGwgPyBhcmd1bWVudHNbaV0gOiB7XG4gICAgICAgIH07XG4gICAgICAgIHZhciBvd25LZXlzID0gT2JqZWN0LmtleXMoc291cmNlKTtcbiAgICAgICAgaWYgKHR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgIG93bktleXMgPSBvd25LZXlzLmNvbmNhdChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHNvdXJjZSkuZmlsdGVyKGZ1bmN0aW9uKHN5bSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHNvdXJjZSwgc3ltKS5lbnVtZXJhYmxlO1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9XG4gICAgICAgIG93bktleXMuZm9yRWFjaChmdW5jdGlvbihrZXkpIHtcbiAgICAgICAgICAgIF9kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgc291cmNlW2tleV0pO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHRhcmdldDtcbn1cbmZ1bmN0aW9uIF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhzb3VyY2UsIGV4Y2x1ZGVkKSB7XG4gICAgaWYgKHNvdXJjZSA9PSBudWxsKSByZXR1cm4ge1xuICAgIH07XG4gICAgdmFyIHRhcmdldCA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlKHNvdXJjZSwgZXhjbHVkZWQpO1xuICAgIHZhciBrZXksIGk7XG4gICAgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHtcbiAgICAgICAgdmFyIHNvdXJjZVN5bWJvbEtleXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHNvdXJjZSk7XG4gICAgICAgIGZvcihpID0gMDsgaSA8IHNvdXJjZVN5bWJvbEtleXMubGVuZ3RoOyBpKyspe1xuICAgICAgICAgICAga2V5ID0gc291cmNlU3ltYm9sS2V5c1tpXTtcbiAgICAgICAgICAgIGlmIChleGNsdWRlZC5pbmRleE9mKGtleSkgPj0gMCkgY29udGludWU7XG4gICAgICAgICAgICBpZiAoIU9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChzb3VyY2UsIGtleSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdGFyZ2V0O1xufVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCkge1xuICAgIGlmIChzb3VyY2UgPT0gbnVsbCkgcmV0dXJuIHtcbiAgICB9O1xuICAgIHZhciB0YXJnZXQgPSB7XG4gICAgfTtcbiAgICB2YXIgc291cmNlS2V5cyA9IE9iamVjdC5rZXlzKHNvdXJjZSk7XG4gICAgdmFyIGtleSwgaTtcbiAgICBmb3IoaSA9IDA7IGkgPCBzb3VyY2VLZXlzLmxlbmd0aDsgaSsrKXtcbiAgICAgICAga2V5ID0gc291cmNlS2V5c1tpXTtcbiAgICAgICAgaWYgKGV4Y2x1ZGVkLmluZGV4T2Yoa2V5KSA+PSAwKSBjb250aW51ZTtcbiAgICAgICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgICB9XG4gICAgcmV0dXJuIHRhcmdldDtcbn1cbmNvbnN0IGxvYWRlZEltYWdlVVJMcyA9IG5ldyBTZXQoKTtcbmlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykge1xuICAgIGdsb2JhbC5fX05FWFRfSU1BR0VfSU1QT1JURUQgPSB0cnVlO1xufVxuY29uc3QgVkFMSURfTE9BRElOR19WQUxVRVMgPSBbXG4gICAgJ2xhenknLFxuICAgICdlYWdlcicsXG4gICAgdW5kZWZpbmVkXG5dO1xuY29uc3QgbG9hZGVycyA9IG5ldyBNYXAoW1xuICAgIFtcbiAgICAgICAgJ2RlZmF1bHQnLFxuICAgICAgICBkZWZhdWx0TG9hZGVyXG4gICAgXSxcbiAgICBbXG4gICAgICAgICdpbWdpeCcsXG4gICAgICAgIGltZ2l4TG9hZGVyXG4gICAgXSxcbiAgICBbXG4gICAgICAgICdjbG91ZGluYXJ5JyxcbiAgICAgICAgY2xvdWRpbmFyeUxvYWRlclxuICAgIF0sXG4gICAgW1xuICAgICAgICAnYWthbWFpJyxcbiAgICAgICAgYWthbWFpTG9hZGVyXG4gICAgXSxcbiAgICBbXG4gICAgICAgICdjdXN0b20nLFxuICAgICAgICBjdXN0b21Mb2FkZXJcbiAgICBdLCBcbl0pO1xuY29uc3QgVkFMSURfTEFZT1VUX1ZBTFVFUyA9IFtcbiAgICAnZmlsbCcsXG4gICAgJ2ZpeGVkJyxcbiAgICAnaW50cmluc2ljJyxcbiAgICAncmVzcG9uc2l2ZScsXG4gICAgdW5kZWZpbmVkLCBcbl07XG5mdW5jdGlvbiBpc1N0YXRpY1JlcXVpcmUoc3JjKSB7XG4gICAgcmV0dXJuIHNyYy5kZWZhdWx0ICE9PSB1bmRlZmluZWQ7XG59XG5mdW5jdGlvbiBpc1N0YXRpY0ltYWdlRGF0YShzcmMpIHtcbiAgICByZXR1cm4gc3JjLnNyYyAhPT0gdW5kZWZpbmVkO1xufVxuZnVuY3Rpb24gaXNTdGF0aWNJbXBvcnQoc3JjKSB7XG4gICAgcmV0dXJuIHR5cGVvZiBzcmMgPT09ICdvYmplY3QnICYmIChpc1N0YXRpY1JlcXVpcmUoc3JjKSB8fCBpc1N0YXRpY0ltYWdlRGF0YShzcmMpKTtcbn1cbmNvbnN0IHsgZGV2aWNlU2l6ZXM6IGNvbmZpZ0RldmljZVNpemVzICwgaW1hZ2VTaXplczogY29uZmlnSW1hZ2VTaXplcyAsIGxvYWRlcjogY29uZmlnTG9hZGVyICwgcGF0aDogY29uZmlnUGF0aCAsIGRvbWFpbnM6IGNvbmZpZ0RvbWFpbnMgLCAgfSA9IHByb2Nlc3MuZW52Ll9fTkVYVF9JTUFHRV9PUFRTIHx8IF9pbWFnZUNvbmZpZy5pbWFnZUNvbmZpZ0RlZmF1bHQ7XG4vLyBzb3J0IHNtYWxsZXN0IHRvIGxhcmdlc3RcbmNvbnN0IGFsbFNpemVzID0gW1xuICAgIC4uLmNvbmZpZ0RldmljZVNpemVzLFxuICAgIC4uLmNvbmZpZ0ltYWdlU2l6ZXNcbl07XG5jb25maWdEZXZpY2VTaXplcy5zb3J0KChhLCBiKT0+YSAtIGJcbik7XG5hbGxTaXplcy5zb3J0KChhLCBiKT0+YSAtIGJcbik7XG5mdW5jdGlvbiBnZXRXaWR0aHMod2lkdGgsIGxheW91dCwgc2l6ZXMpIHtcbiAgICBpZiAoc2l6ZXMgJiYgKGxheW91dCA9PT0gJ2ZpbGwnIHx8IGxheW91dCA9PT0gJ3Jlc3BvbnNpdmUnKSkge1xuICAgICAgICAvLyBGaW5kIGFsbCB0aGUgXCJ2d1wiIHBlcmNlbnQgc2l6ZXMgdXNlZCBpbiB0aGUgc2l6ZXMgcHJvcFxuICAgICAgICBjb25zdCB2aWV3cG9ydFdpZHRoUmUgPSAvKF58XFxzKSgxP1xcZD9cXGQpdncvZztcbiAgICAgICAgY29uc3QgcGVyY2VudFNpemVzID0gW107XG4gICAgICAgIGZvcihsZXQgbWF0Y2g7IG1hdGNoID0gdmlld3BvcnRXaWR0aFJlLmV4ZWMoc2l6ZXMpOyBtYXRjaCl7XG4gICAgICAgICAgICBwZXJjZW50U2l6ZXMucHVzaChwYXJzZUludChtYXRjaFsyXSkpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwZXJjZW50U2l6ZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICBjb25zdCBzbWFsbGVzdFJhdGlvID0gTWF0aC5taW4oLi4ucGVyY2VudFNpemVzKSAqIDAuMDE7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHdpZHRoczogYWxsU2l6ZXMuZmlsdGVyKChzKT0+cyA+PSBjb25maWdEZXZpY2VTaXplc1swXSAqIHNtYWxsZXN0UmF0aW9cbiAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgIGtpbmQ6ICd3J1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgd2lkdGhzOiBhbGxTaXplcyxcbiAgICAgICAgICAgIGtpbmQ6ICd3J1xuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHdpZHRoICE9PSAnbnVtYmVyJyB8fCBsYXlvdXQgPT09ICdmaWxsJyB8fCBsYXlvdXQgPT09ICdyZXNwb25zaXZlJykge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgd2lkdGhzOiBjb25maWdEZXZpY2VTaXplcyxcbiAgICAgICAgICAgIGtpbmQ6ICd3J1xuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdCB3aWR0aHMgPSBbXG4gICAgICAgIC4uLm5ldyBTZXQoLy8gPiBUaGlzIG1lYW5zIHRoYXQgbW9zdCBPTEVEIHNjcmVlbnMgdGhhdCBzYXkgdGhleSBhcmUgM3ggcmVzb2x1dGlvbixcbiAgICAgICAgLy8gPiBhcmUgYWN0dWFsbHkgM3ggaW4gdGhlIGdyZWVuIGNvbG9yLCBidXQgb25seSAxLjV4IGluIHRoZSByZWQgYW5kXG4gICAgICAgIC8vID4gYmx1ZSBjb2xvcnMuIFNob3dpbmcgYSAzeCByZXNvbHV0aW9uIGltYWdlIGluIHRoZSBhcHAgdnMgYSAyeFxuICAgICAgICAvLyA+IHJlc29sdXRpb24gaW1hZ2Ugd2lsbCBiZSB2aXN1YWxseSB0aGUgc2FtZSwgdGhvdWdoIHRoZSAzeCBpbWFnZVxuICAgICAgICAvLyA+IHRha2VzIHNpZ25pZmljYW50bHkgbW9yZSBkYXRhLiBFdmVuIHRydWUgM3ggcmVzb2x1dGlvbiBzY3JlZW5zIGFyZVxuICAgICAgICAvLyA+IHdhc3RlZnVsIGFzIHRoZSBodW1hbiBleWUgY2Fubm90IHNlZSB0aGF0IGxldmVsIG9mIGRldGFpbCB3aXRob3V0XG4gICAgICAgIC8vID4gc29tZXRoaW5nIGxpa2UgYSBtYWduaWZ5aW5nIGdsYXNzLlxuICAgICAgICAvLyBodHRwczovL2Jsb2cudHdpdHRlci5jb20vZW5naW5lZXJpbmcvZW5fdXMvdG9waWNzL2luZnJhc3RydWN0dXJlLzIwMTkvY2FwcGluZy1pbWFnZS1maWRlbGl0eS1vbi11bHRyYS1oaWdoLXJlc29sdXRpb24tZGV2aWNlcy5odG1sXG4gICAgICAgIFtcbiAgICAgICAgICAgIHdpZHRoLFxuICAgICAgICAgICAgd2lkdGggKiAyIC8qLCB3aWR0aCAqIDMqLyBcbiAgICAgICAgXS5tYXAoKHcpPT5hbGxTaXplcy5maW5kKChwKT0+cCA+PSB3XG4gICAgICAgICAgICApIHx8IGFsbFNpemVzW2FsbFNpemVzLmxlbmd0aCAtIDFdXG4gICAgICAgICkpLCBcbiAgICBdO1xuICAgIHJldHVybiB7XG4gICAgICAgIHdpZHRocyxcbiAgICAgICAga2luZDogJ3gnXG4gICAgfTtcbn1cbmZ1bmN0aW9uIGdlbmVyYXRlSW1nQXR0cnMoeyBzcmMgLCB1bm9wdGltaXplZCAsIGxheW91dCAsIHdpZHRoICwgcXVhbGl0eSAsIHNpemVzICwgbG9hZGVyICB9KSB7XG4gICAgaWYgKHVub3B0aW1pemVkKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzcmMsXG4gICAgICAgICAgICBzcmNTZXQ6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIHNpemVzOiB1bmRlZmluZWRcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgeyB3aWR0aHMgLCBraW5kICB9ID0gZ2V0V2lkdGhzKHdpZHRoLCBsYXlvdXQsIHNpemVzKTtcbiAgICBjb25zdCBsYXN0ID0gd2lkdGhzLmxlbmd0aCAtIDE7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgc2l6ZXM6ICFzaXplcyAmJiBraW5kID09PSAndycgPyAnMTAwdncnIDogc2l6ZXMsXG4gICAgICAgIHNyY1NldDogd2lkdGhzLm1hcCgodywgaSk9PmAke2xvYWRlcih7XG4gICAgICAgICAgICAgICAgc3JjLFxuICAgICAgICAgICAgICAgIHF1YWxpdHksXG4gICAgICAgICAgICAgICAgd2lkdGg6IHdcbiAgICAgICAgICAgIH0pfSAke2tpbmQgPT09ICd3JyA/IHcgOiBpICsgMX0ke2tpbmR9YFxuICAgICAgICApLmpvaW4oJywgJyksXG4gICAgICAgIC8vIEl0J3MgaW50ZW5kZWQgdG8ga2VlcCBgc3JjYCB0aGUgbGFzdCBhdHRyaWJ1dGUgYmVjYXVzZSBSZWFjdCB1cGRhdGVzXG4gICAgICAgIC8vIGF0dHJpYnV0ZXMgaW4gb3JkZXIuIElmIHdlIGtlZXAgYHNyY2AgdGhlIGZpcnN0IG9uZSwgU2FmYXJpIHdpbGxcbiAgICAgICAgLy8gaW1tZWRpYXRlbHkgc3RhcnQgdG8gZmV0Y2ggYHNyY2AsIGJlZm9yZSBgc2l6ZXNgIGFuZCBgc3JjU2V0YCBhcmUgZXZlblxuICAgICAgICAvLyB1cGRhdGVkIGJ5IFJlYWN0LiBUaGF0IGNhdXNlcyBtdWx0aXBsZSB1bm5lY2Vzc2FyeSByZXF1ZXN0cyBpZiBgc3JjU2V0YFxuICAgICAgICAvLyBhbmQgYHNpemVzYCBhcmUgZGVmaW5lZC5cbiAgICAgICAgLy8gVGhpcyBidWcgY2Fubm90IGJlIHJlcHJvZHVjZWQgaW4gQ2hyb21lIG9yIEZpcmVmb3guXG4gICAgICAgIHNyYzogbG9hZGVyKHtcbiAgICAgICAgICAgIHNyYyxcbiAgICAgICAgICAgIHF1YWxpdHksXG4gICAgICAgICAgICB3aWR0aDogd2lkdGhzW2xhc3RdXG4gICAgICAgIH0pXG4gICAgfTtcbn1cbmZ1bmN0aW9uIGdldEludCh4KSB7XG4gICAgaWYgKHR5cGVvZiB4ID09PSAnbnVtYmVyJykge1xuICAgICAgICByZXR1cm4geDtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiB4ID09PSAnc3RyaW5nJykge1xuICAgICAgICByZXR1cm4gcGFyc2VJbnQoeCwgMTApO1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufVxuZnVuY3Rpb24gZGVmYXVsdEltYWdlTG9hZGVyKGxvYWRlclByb3BzKSB7XG4gICAgY29uc3QgbG9hZCA9IGxvYWRlcnMuZ2V0KGNvbmZpZ0xvYWRlcik7XG4gICAgaWYgKGxvYWQpIHtcbiAgICAgICAgcmV0dXJuIGxvYWQoX29iamVjdFNwcmVhZCh7XG4gICAgICAgICAgICByb290OiBjb25maWdQYXRoXG4gICAgICAgIH0sIGxvYWRlclByb3BzKSk7XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBcImxvYWRlclwiIGZvdW5kIGluIFwibmV4dC5jb25maWcuanNcIi4gRXhwZWN0ZWQ6ICR7X2ltYWdlQ29uZmlnLlZBTElEX0xPQURFUlMuam9pbignLCAnKX0uIFJlY2VpdmVkOiAke2NvbmZpZ0xvYWRlcn1gKTtcbn1cbi8vIFNlZSBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3EvMzk3Nzc4MzMvMjY2NTM1IGZvciB3aHkgd2UgdXNlIHRoaXMgcmVmXG4vLyBoYW5kbGVyIGluc3RlYWQgb2YgdGhlIGltZydzIG9uTG9hZCBhdHRyaWJ1dGUuXG5mdW5jdGlvbiBoYW5kbGVMb2FkaW5nKGltZywgc3JjLCBsYXlvdXQsIHBsYWNlaG9sZGVyLCBvbkxvYWRpbmdDb21wbGV0ZSkge1xuICAgIGlmICghaW1nKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaGFuZGxlTG9hZCA9ICgpPT57XG4gICAgICAgIGlmICghaW1nLnNyYy5zdGFydHNXaXRoKCdkYXRhOicpKSB7XG4gICAgICAgICAgICBjb25zdCBwID0gJ2RlY29kZScgaW4gaW1nID8gaW1nLmRlY29kZSgpIDogUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgICAgICAgICBwLmNhdGNoKCgpPT57XG4gICAgICAgICAgICB9KS50aGVuKCgpPT57XG4gICAgICAgICAgICAgICAgaWYgKHBsYWNlaG9sZGVyID09PSAnYmx1cicpIHtcbiAgICAgICAgICAgICAgICAgICAgaW1nLnN0eWxlLmZpbHRlciA9ICdub25lJztcbiAgICAgICAgICAgICAgICAgICAgaW1nLnN0eWxlLmJhY2tncm91bmRTaXplID0gJ25vbmUnO1xuICAgICAgICAgICAgICAgICAgICBpbWcuc3R5bGUuYmFja2dyb3VuZEltYWdlID0gJ25vbmUnO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBsb2FkZWRJbWFnZVVSTHMuYWRkKHNyYyk7XG4gICAgICAgICAgICAgICAgaWYgKG9uTG9hZGluZ0NvbXBsZXRlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHsgbmF0dXJhbFdpZHRoICwgbmF0dXJhbEhlaWdodCAgfSA9IGltZztcbiAgICAgICAgICAgICAgICAgICAgLy8gUGFzcyBiYWNrIHJlYWQtb25seSBwcmltaXRpdmUgdmFsdWVzIGJ1dCBub3QgdGhlXG4gICAgICAgICAgICAgICAgICAgIC8vIHVuZGVybHlpbmcgRE9NIGVsZW1lbnQgYmVjYXVzZSBpdCBjb3VsZCBiZSBtaXN1c2VkLlxuICAgICAgICAgICAgICAgICAgICBvbkxvYWRpbmdDb21wbGV0ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYXR1cmFsV2lkdGgsXG4gICAgICAgICAgICAgICAgICAgICAgICBuYXR1cmFsSGVpZ2h0XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgcmVmO1xuICAgICAgICAgICAgICAgICAgICBpZiAoKHJlZiA9IGltZy5wYXJlbnRFbGVtZW50KSA9PT0gbnVsbCB8fCByZWYgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlZi5wYXJlbnRFbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJlbnQgPSBnZXRDb21wdXRlZFN0eWxlKGltZy5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGxheW91dCA9PT0gJ3Jlc3BvbnNpdmUnICYmIHBhcmVudC5kaXNwbGF5ID09PSAnZmxleCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgbWF5IG5vdCByZW5kZXIgcHJvcGVybHkgYXMgYSBjaGlsZCBvZiBhIGZsZXggY29udGFpbmVyLiBDb25zaWRlciB3cmFwcGluZyB0aGUgaW1hZ2Ugd2l0aCBhIGRpdiB0byBjb25maWd1cmUgdGhlIHdpZHRoLmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChsYXlvdXQgPT09ICdmaWxsJyAmJiBwYXJlbnQucG9zaXRpb24gIT09ICdyZWxhdGl2ZScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgbWF5IG5vdCByZW5kZXIgcHJvcGVybHkgd2l0aCBhIHBhcmVudCB1c2luZyBwb3NpdGlvbjpcIiR7cGFyZW50LnBvc2l0aW9ufVwiLiBDb25zaWRlciBjaGFuZ2luZyB0aGUgcGFyZW50IHN0eWxlIHRvIHBvc2l0aW9uOlwicmVsYXRpdmVcIiB3aXRoIGEgd2lkdGggYW5kIGhlaWdodC5gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBpZiAoaW1nLmNvbXBsZXRlKSB7XG4gICAgICAgIC8vIElmIHRoZSByZWFsIGltYWdlIGZhaWxzIHRvIGxvYWQsIHRoaXMgd2lsbCBzdGlsbCByZW1vdmUgdGhlIHBsYWNlaG9sZGVyLlxuICAgICAgICAvLyBUaGlzIGlzIHRoZSBkZXNpcmVkIGJlaGF2aW9yIGZvciBub3csIGFuZCB3aWxsIGJlIHJldmlzaXRlZCB3aGVuIGVycm9yXG4gICAgICAgIC8vIGhhbmRsaW5nIGlzIHdvcmtlZCBvbiBmb3IgdGhlIGltYWdlIGNvbXBvbmVudCBpdHNlbGYuXG4gICAgICAgIGhhbmRsZUxvYWQoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBpbWcub25sb2FkID0gaGFuZGxlTG9hZDtcbiAgICB9XG59XG5mdW5jdGlvbiBJbWFnZTEoX3BhcmFtKSB7XG4gICAgdmFyIHsgc3JjICwgc2l6ZXMgLCB1bm9wdGltaXplZCA9ZmFsc2UgLCBwcmlvcml0eSA9ZmFsc2UgLCBsb2FkaW5nICwgbGF6eUJvdW5kYXJ5ID0nMjAwcHgnICwgY2xhc3NOYW1lICwgcXVhbGl0eSAsIHdpZHRoICwgaGVpZ2h0ICwgb2JqZWN0Rml0ICwgb2JqZWN0UG9zaXRpb24gLCBvbkxvYWRpbmdDb21wbGV0ZSAsIGxvYWRlciA9ZGVmYXVsdEltYWdlTG9hZGVyICwgcGxhY2Vob2xkZXIgPSdlbXB0eScgLCBibHVyRGF0YVVSTCAgfSA9IF9wYXJhbSwgYWxsID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzKF9wYXJhbSwgW1wic3JjXCIsIFwic2l6ZXNcIiwgXCJ1bm9wdGltaXplZFwiLCBcInByaW9yaXR5XCIsIFwibG9hZGluZ1wiLCBcImxhenlCb3VuZGFyeVwiLCBcImNsYXNzTmFtZVwiLCBcInF1YWxpdHlcIiwgXCJ3aWR0aFwiLCBcImhlaWdodFwiLCBcIm9iamVjdEZpdFwiLCBcIm9iamVjdFBvc2l0aW9uXCIsIFwib25Mb2FkaW5nQ29tcGxldGVcIiwgXCJsb2FkZXJcIiwgXCJwbGFjZWhvbGRlclwiLCBcImJsdXJEYXRhVVJMXCJdKTtcbiAgICBsZXQgcmVzdCA9IGFsbDtcbiAgICBsZXQgbGF5b3V0ID0gc2l6ZXMgPyAncmVzcG9uc2l2ZScgOiAnaW50cmluc2ljJztcbiAgICBpZiAoJ2xheW91dCcgaW4gcmVzdCkge1xuICAgICAgICAvLyBPdmVycmlkZSBkZWZhdWx0IGxheW91dCBpZiB0aGUgdXNlciBzcGVjaWZpZWQgb25lOlxuICAgICAgICBpZiAocmVzdC5sYXlvdXQpIGxheW91dCA9IHJlc3QubGF5b3V0O1xuICAgICAgICAvLyBSZW1vdmUgcHJvcGVydHkgc28gaXQncyBub3Qgc3ByZWFkIGludG8gaW1hZ2U6XG4gICAgICAgIGRlbGV0ZSByZXN0WydsYXlvdXQnXTtcbiAgICB9XG4gICAgbGV0IHN0YXRpY1NyYyA9ICcnO1xuICAgIGlmIChpc1N0YXRpY0ltcG9ydChzcmMpKSB7XG4gICAgICAgIGNvbnN0IHN0YXRpY0ltYWdlRGF0YSA9IGlzU3RhdGljUmVxdWlyZShzcmMpID8gc3JjLmRlZmF1bHQgOiBzcmM7XG4gICAgICAgIGlmICghc3RhdGljSW1hZ2VEYXRhLnNyYykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBBbiBvYmplY3Qgc2hvdWxkIG9ubHkgYmUgcGFzc2VkIHRvIHRoZSBpbWFnZSBjb21wb25lbnQgc3JjIHBhcmFtZXRlciBpZiBpdCBjb21lcyBmcm9tIGEgc3RhdGljIGltYWdlIGltcG9ydC4gSXQgbXVzdCBpbmNsdWRlIHNyYy4gUmVjZWl2ZWQgJHtKU09OLnN0cmluZ2lmeShzdGF0aWNJbWFnZURhdGEpfWApO1xuICAgICAgICB9XG4gICAgICAgIGJsdXJEYXRhVVJMID0gYmx1ckRhdGFVUkwgfHwgc3RhdGljSW1hZ2VEYXRhLmJsdXJEYXRhVVJMO1xuICAgICAgICBzdGF0aWNTcmMgPSBzdGF0aWNJbWFnZURhdGEuc3JjO1xuICAgICAgICBpZiAoIWxheW91dCB8fCBsYXlvdXQgIT09ICdmaWxsJykge1xuICAgICAgICAgICAgaGVpZ2h0ID0gaGVpZ2h0IHx8IHN0YXRpY0ltYWdlRGF0YS5oZWlnaHQ7XG4gICAgICAgICAgICB3aWR0aCA9IHdpZHRoIHx8IHN0YXRpY0ltYWdlRGF0YS53aWR0aDtcbiAgICAgICAgICAgIGlmICghc3RhdGljSW1hZ2VEYXRhLmhlaWdodCB8fCAhc3RhdGljSW1hZ2VEYXRhLndpZHRoKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBBbiBvYmplY3Qgc2hvdWxkIG9ubHkgYmUgcGFzc2VkIHRvIHRoZSBpbWFnZSBjb21wb25lbnQgc3JjIHBhcmFtZXRlciBpZiBpdCBjb21lcyBmcm9tIGEgc3RhdGljIGltYWdlIGltcG9ydC4gSXQgbXVzdCBpbmNsdWRlIGhlaWdodCBhbmQgd2lkdGguIFJlY2VpdmVkICR7SlNPTi5zdHJpbmdpZnkoc3RhdGljSW1hZ2VEYXRhKX1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBzcmMgPSB0eXBlb2Ygc3JjID09PSAnc3RyaW5nJyA/IHNyYyA6IHN0YXRpY1NyYztcbiAgICBjb25zdCB3aWR0aEludCA9IGdldEludCh3aWR0aCk7XG4gICAgY29uc3QgaGVpZ2h0SW50ID0gZ2V0SW50KGhlaWdodCk7XG4gICAgY29uc3QgcXVhbGl0eUludCA9IGdldEludChxdWFsaXR5KTtcbiAgICBsZXQgaXNMYXp5ID0gIXByaW9yaXR5ICYmIChsb2FkaW5nID09PSAnbGF6eScgfHwgdHlwZW9mIGxvYWRpbmcgPT09ICd1bmRlZmluZWQnKTtcbiAgICBpZiAoc3JjLnN0YXJ0c1dpdGgoJ2RhdGE6JykgfHwgc3JjLnN0YXJ0c1dpdGgoJ2Jsb2I6JykpIHtcbiAgICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSFRUUC9CYXNpY3Nfb2ZfSFRUUC9EYXRhX1VSSXNcbiAgICAgICAgdW5vcHRpbWl6ZWQgPSB0cnVlO1xuICAgICAgICBpc0xhenkgPSBmYWxzZTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIGxvYWRlZEltYWdlVVJMcy5oYXMoc3JjKSkge1xuICAgICAgICBpc0xhenkgPSBmYWxzZTtcbiAgICB9XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgaWYgKCFzcmMpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW1hZ2UgaXMgbWlzc2luZyByZXF1aXJlZCBcInNyY1wiIHByb3BlcnR5LiBNYWtlIHN1cmUgeW91IHBhc3MgXCJzcmNcIiBpbiBwcm9wcyB0byB0aGUgXFxgbmV4dC9pbWFnZVxcYCBjb21wb25lbnQuIFJlY2VpdmVkOiAke0pTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICB3aWR0aCxcbiAgICAgICAgICAgICAgICBoZWlnaHQsXG4gICAgICAgICAgICAgICAgcXVhbGl0eVxuICAgICAgICAgICAgfSl9YCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFWQUxJRF9MQVlPVVRfVkFMVUVTLmluY2x1ZGVzKGxheW91dCkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgaW52YWxpZCBcImxheW91dFwiIHByb3BlcnR5LiBQcm92aWRlZCBcIiR7bGF5b3V0fVwiIHNob3VsZCBiZSBvbmUgb2YgJHtWQUxJRF9MQVlPVVRfVkFMVUVTLm1hcChTdHJpbmcpLmpvaW4oJywnKX0uYCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiB3aWR0aEludCAhPT0gJ3VuZGVmaW5lZCcgJiYgaXNOYU4od2lkdGhJbnQpIHx8IHR5cGVvZiBoZWlnaHRJbnQgIT09ICd1bmRlZmluZWQnICYmIGlzTmFOKGhlaWdodEludCkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgaW52YWxpZCBcIndpZHRoXCIgb3IgXCJoZWlnaHRcIiBwcm9wZXJ0eS4gVGhlc2Ugc2hvdWxkIGJlIG51bWVyaWMgdmFsdWVzLmApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChsYXlvdXQgPT09ICdmaWxsJyAmJiAod2lkdGggfHwgaGVpZ2h0KSkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGFuZCBcImxheW91dD0nZmlsbCdcIiBoYXMgdW51c2VkIHByb3BlcnRpZXMgYXNzaWduZWQuIFBsZWFzZSByZW1vdmUgXCJ3aWR0aFwiIGFuZCBcImhlaWdodFwiLmApO1xuICAgICAgICB9XG4gICAgICAgIGlmICghVkFMSURfTE9BRElOR19WQUxVRVMuaW5jbHVkZXMobG9hZGluZykpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgaW52YWxpZCBcImxvYWRpbmdcIiBwcm9wZXJ0eS4gUHJvdmlkZWQgXCIke2xvYWRpbmd9XCIgc2hvdWxkIGJlIG9uZSBvZiAke1ZBTElEX0xPQURJTkdfVkFMVUVTLm1hcChTdHJpbmcpLmpvaW4oJywnKX0uYCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHByaW9yaXR5ICYmIGxvYWRpbmcgPT09ICdsYXp5Jykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBib3RoIFwicHJpb3JpdHlcIiBhbmQgXCJsb2FkaW5nPSdsYXp5J1wiIHByb3BlcnRpZXMuIE9ubHkgb25lIHNob3VsZCBiZSB1c2VkLmApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwbGFjZWhvbGRlciA9PT0gJ2JsdXInKSB7XG4gICAgICAgICAgICBpZiAobGF5b3V0ICE9PSAnZmlsbCcgJiYgKHdpZHRoSW50IHx8IDApICogKGhlaWdodEludCB8fCAwKSA8IDE2MDApIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaXMgc21hbGxlciB0aGFuIDQweDQwLiBDb25zaWRlciByZW1vdmluZyB0aGUgXCJwbGFjZWhvbGRlcj0nYmx1cidcIiBwcm9wZXJ0eSB0byBpbXByb3ZlIHBlcmZvcm1hbmNlLmApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFibHVyRGF0YVVSTCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IFZBTElEX0JMVVJfRVhUID0gW1xuICAgICAgICAgICAgICAgICAgICAnanBlZycsXG4gICAgICAgICAgICAgICAgICAgICdwbmcnLFxuICAgICAgICAgICAgICAgICAgICAnd2VicCdcbiAgICAgICAgICAgICAgICBdIC8vIHNob3VsZCBtYXRjaCBuZXh0LWltYWdlLWxvYWRlclxuICAgICAgICAgICAgICAgIDtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaGFzIFwicGxhY2Vob2xkZXI9J2JsdXInXCIgcHJvcGVydHkgYnV0IGlzIG1pc3NpbmcgdGhlIFwiYmx1ckRhdGFVUkxcIiBwcm9wZXJ0eS5cbiAgICAgICAgICBQb3NzaWJsZSBzb2x1dGlvbnM6XG4gICAgICAgICAgICAtIEFkZCBhIFwiYmx1ckRhdGFVUkxcIiBwcm9wZXJ0eSwgdGhlIGNvbnRlbnRzIHNob3VsZCBiZSBhIHNtYWxsIERhdGEgVVJMIHRvIHJlcHJlc2VudCB0aGUgaW1hZ2VcbiAgICAgICAgICAgIC0gQ2hhbmdlIHRoZSBcInNyY1wiIHByb3BlcnR5IHRvIGEgc3RhdGljIGltcG9ydCB3aXRoIG9uZSBvZiB0aGUgc3VwcG9ydGVkIGZpbGUgdHlwZXM6ICR7VkFMSURfQkxVUl9FWFQuam9pbignLCcpfVxuICAgICAgICAgICAgLSBSZW1vdmUgdGhlIFwicGxhY2Vob2xkZXJcIiBwcm9wZXJ0eSwgZWZmZWN0aXZlbHkgbm8gYmx1ciBlZmZlY3RcbiAgICAgICAgICBSZWFkIG1vcmU6IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL3BsYWNlaG9sZGVyLWJsdXItZGF0YS11cmxgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoJ3JlZicgaW4gcmVzdCkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGlzIHVzaW5nIHVuc3VwcG9ydGVkIFwicmVmXCIgcHJvcGVydHkuIENvbnNpZGVyIHVzaW5nIHRoZSBcIm9uTG9hZGluZ0NvbXBsZXRlXCIgcHJvcGVydHkgaW5zdGVhZC5gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoJ3N0eWxlJyBpbiByZXN0KSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaXMgdXNpbmcgdW5zdXBwb3J0ZWQgXCJzdHlsZVwiIHByb3BlcnR5LiBQbGVhc2UgdXNlIHRoZSBcImNsYXNzTmFtZVwiIHByb3BlcnR5IGluc3RlYWQuYCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmFuZCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMDApICsgMTAwO1xuICAgICAgICBpZiAoIXVub3B0aW1pemVkICYmICFsb2FkZXIoe1xuICAgICAgICAgICAgc3JjLFxuICAgICAgICAgICAgd2lkdGg6IHJhbmQsXG4gICAgICAgICAgICBxdWFsaXR5OiA3NVxuICAgICAgICB9KS5pbmNsdWRlcyhyYW5kLnRvU3RyaW5nKCkpKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaGFzIGEgXCJsb2FkZXJcIiBwcm9wZXJ0eSB0aGF0IGRvZXMgbm90IGltcGxlbWVudCB3aWR0aC4gUGxlYXNlIGltcGxlbWVudCBpdCBvciB1c2UgdGhlIFwidW5vcHRpbWl6ZWRcIiBwcm9wZXJ0eSBpbnN0ZWFkLmAgKyBgXFxuUmVhZCBtb3JlOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9uZXh0LWltYWdlLW1pc3NpbmctbG9hZGVyLXdpZHRoYCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgW3NldFJlZiwgaXNJbnRlcnNlY3RlZF0gPSAoMCwgX3VzZUludGVyc2VjdGlvbikudXNlSW50ZXJzZWN0aW9uKHtcbiAgICAgICAgcm9vdE1hcmdpbjogbGF6eUJvdW5kYXJ5LFxuICAgICAgICBkaXNhYmxlZDogIWlzTGF6eVxuICAgIH0pO1xuICAgIGNvbnN0IGlzVmlzaWJsZSA9ICFpc0xhenkgfHwgaXNJbnRlcnNlY3RlZDtcbiAgICBsZXQgd3JhcHBlclN0eWxlO1xuICAgIGxldCBzaXplclN0eWxlO1xuICAgIGxldCBzaXplclN2ZztcbiAgICBsZXQgaW1nU3R5bGUgPSB7XG4gICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgICAgICB0b3A6IDAsXG4gICAgICAgIGxlZnQ6IDAsXG4gICAgICAgIGJvdHRvbTogMCxcbiAgICAgICAgcmlnaHQ6IDAsXG4gICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICBwYWRkaW5nOiAwLFxuICAgICAgICBib3JkZXI6ICdub25lJyxcbiAgICAgICAgbWFyZ2luOiAnYXV0bycsXG4gICAgICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgICAgIHdpZHRoOiAwLFxuICAgICAgICBoZWlnaHQ6IDAsXG4gICAgICAgIG1pbldpZHRoOiAnMTAwJScsXG4gICAgICAgIG1heFdpZHRoOiAnMTAwJScsXG4gICAgICAgIG1pbkhlaWdodDogJzEwMCUnLFxuICAgICAgICBtYXhIZWlnaHQ6ICcxMDAlJyxcbiAgICAgICAgb2JqZWN0Rml0LFxuICAgICAgICBvYmplY3RQb3NpdGlvblxuICAgIH07XG4gICAgY29uc3QgYmx1clN0eWxlID0gcGxhY2Vob2xkZXIgPT09ICdibHVyJyA/IHtcbiAgICAgICAgZmlsdGVyOiAnYmx1cigyMHB4KScsXG4gICAgICAgIGJhY2tncm91bmRTaXplOiBvYmplY3RGaXQgfHwgJ2NvdmVyJyxcbiAgICAgICAgYmFja2dyb3VuZEltYWdlOiBgdXJsKFwiJHtibHVyRGF0YVVSTH1cIilgLFxuICAgICAgICBiYWNrZ3JvdW5kUG9zaXRpb246IG9iamVjdFBvc2l0aW9uIHx8ICcwJSAwJSdcbiAgICB9IDoge1xuICAgIH07XG4gICAgaWYgKGxheW91dCA9PT0gJ2ZpbGwnKSB7XG4gICAgICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIGxheW91dD1cImZpbGxcIiAvPlxuICAgICAgICB3cmFwcGVyU3R5bGUgPSB7XG4gICAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgICAgICB0b3A6IDAsXG4gICAgICAgICAgICBsZWZ0OiAwLFxuICAgICAgICAgICAgYm90dG9tOiAwLFxuICAgICAgICAgICAgcmlnaHQ6IDAsXG4gICAgICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgICAgIG1hcmdpbjogMFxuICAgICAgICB9O1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHdpZHRoSW50ICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgaGVpZ2h0SW50ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiB3aWR0aD1cIjEwMFwiIGhlaWdodD1cIjEwMFwiIC8+XG4gICAgICAgIGNvbnN0IHF1b3RpZW50ID0gaGVpZ2h0SW50IC8gd2lkdGhJbnQ7XG4gICAgICAgIGNvbnN0IHBhZGRpbmdUb3AgPSBpc05hTihxdW90aWVudCkgPyAnMTAwJScgOiBgJHtxdW90aWVudCAqIDEwMH0lYDtcbiAgICAgICAgaWYgKGxheW91dCA9PT0gJ3Jlc3BvbnNpdmUnKSB7XG4gICAgICAgICAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiB3aWR0aD1cIjEwMFwiIGhlaWdodD1cIjEwMFwiIGxheW91dD1cInJlc3BvbnNpdmVcIiAvPlxuICAgICAgICAgICAgd3JhcHBlclN0eWxlID0ge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgICAgICAgICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICAgICAgICAgIG1hcmdpbjogMFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHNpemVyU3R5bGUgPSB7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgICAgICAgICBwYWRkaW5nVG9wXG4gICAgICAgICAgICB9O1xuICAgICAgICB9IGVsc2UgaWYgKGxheW91dCA9PT0gJ2ludHJpbnNpYycpIHtcbiAgICAgICAgICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgbGF5b3V0PVwiaW50cmluc2ljXCIgLz5cbiAgICAgICAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyxcbiAgICAgICAgICAgICAgICBtYXhXaWR0aDogJzEwMCUnLFxuICAgICAgICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICAgICAgICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgICAgICAgICBtYXJnaW46IDBcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBzaXplclN0eWxlID0ge1xuICAgICAgICAgICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgICAgICAgICAgICAgbWF4V2lkdGg6ICcxMDAlJ1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHNpemVyU3ZnID0gYDxzdmcgd2lkdGg9XCIke3dpZHRoSW50fVwiIGhlaWdodD1cIiR7aGVpZ2h0SW50fVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2ZXJzaW9uPVwiMS4xXCIvPmA7XG4gICAgICAgIH0gZWxzZSBpZiAobGF5b3V0ID09PSAnZml4ZWQnKSB7XG4gICAgICAgICAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiB3aWR0aD1cIjEwMFwiIGhlaWdodD1cIjEwMFwiIGxheW91dD1cImZpeGVkXCIgLz5cbiAgICAgICAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgICAgICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gICAgICAgICAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgICAgICAgICAgZGlzcGxheTogJ2lubGluZS1ibG9jaycsXG4gICAgICAgICAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG4gICAgICAgICAgICAgICAgd2lkdGg6IHdpZHRoSW50LFxuICAgICAgICAgICAgICAgIGhlaWdodDogaGVpZ2h0SW50XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgLz5cbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBtdXN0IHVzZSBcIndpZHRoXCIgYW5kIFwiaGVpZ2h0XCIgcHJvcGVydGllcyBvciBcImxheW91dD0nZmlsbCdcIiBwcm9wZXJ0eS5gKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBsZXQgaW1nQXR0cmlidXRlcyA9IHtcbiAgICAgICAgc3JjOiAnZGF0YTppbWFnZS9naWY7YmFzZTY0LFIwbEdPRGxoQVFBQkFJQUFBQUFBQVAvLy95SDVCQUVBQUFBQUxBQUFBQUFCQUFFQUFBSUJSQUE3JyxcbiAgICAgICAgc3JjU2V0OiB1bmRlZmluZWQsXG4gICAgICAgIHNpemVzOiB1bmRlZmluZWRcbiAgICB9O1xuICAgIGlmIChpc1Zpc2libGUpIHtcbiAgICAgICAgaW1nQXR0cmlidXRlcyA9IGdlbmVyYXRlSW1nQXR0cnMoe1xuICAgICAgICAgICAgc3JjLFxuICAgICAgICAgICAgdW5vcHRpbWl6ZWQsXG4gICAgICAgICAgICBsYXlvdXQsXG4gICAgICAgICAgICB3aWR0aDogd2lkdGhJbnQsXG4gICAgICAgICAgICBxdWFsaXR5OiBxdWFsaXR5SW50LFxuICAgICAgICAgICAgc2l6ZXMsXG4gICAgICAgICAgICBsb2FkZXJcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGxldCBzcmNTdHJpbmcgPSBzcmM7XG4gICAgcmV0dXJuKC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7XG4gICAgICAgIHN0eWxlOiB3cmFwcGVyU3R5bGVcbiAgICB9LCBzaXplclN0eWxlID8gLyojX19QVVJFX18qLyBfcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHtcbiAgICAgICAgc3R5bGU6IHNpemVyU3R5bGVcbiAgICB9LCBzaXplclN2ZyA/IC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImltZ1wiLCB7XG4gICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgICBtYXhXaWR0aDogJzEwMCUnLFxuICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgICAgIG1hcmdpbjogMCxcbiAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxuICAgICAgICAgICAgcGFkZGluZzogMFxuICAgICAgICB9LFxuICAgICAgICBhbHQ6IFwiXCIsXG4gICAgICAgIFwiYXJpYS1oaWRkZW5cIjogdHJ1ZSxcbiAgICAgICAgc3JjOiBgZGF0YTppbWFnZS9zdmcreG1sO2Jhc2U2NCwkeygwLCBfdG9CYXNlNjQpLnRvQmFzZTY0KHNpemVyU3ZnKX1gXG4gICAgfSkgOiBudWxsKSA6IG51bGwsIC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImltZ1wiLCBPYmplY3QuYXNzaWduKHtcbiAgICB9LCByZXN0LCBpbWdBdHRyaWJ1dGVzLCB7XG4gICAgICAgIGRlY29kaW5nOiBcImFzeW5jXCIsXG4gICAgICAgIFwiZGF0YS1uaW1nXCI6IGxheW91dCxcbiAgICAgICAgY2xhc3NOYW1lOiBjbGFzc05hbWUsXG4gICAgICAgIHJlZjogKGltZyk9PntcbiAgICAgICAgICAgIHNldFJlZihpbWcpO1xuICAgICAgICAgICAgaGFuZGxlTG9hZGluZyhpbWcsIHNyY1N0cmluZywgbGF5b3V0LCBwbGFjZWhvbGRlciwgb25Mb2FkaW5nQ29tcGxldGUpO1xuICAgICAgICB9LFxuICAgICAgICBzdHlsZTogX29iamVjdFNwcmVhZCh7XG4gICAgICAgIH0sIGltZ1N0eWxlLCBibHVyU3R5bGUpXG4gICAgfSkpLCAvKiNfX1BVUkVfXyovIF9yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJub3NjcmlwdFwiLCBudWxsLCAvKiNfX1BVUkVfXyovIF9yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJpbWdcIiwgT2JqZWN0LmFzc2lnbih7XG4gICAgfSwgcmVzdCwgZ2VuZXJhdGVJbWdBdHRycyh7XG4gICAgICAgIHNyYyxcbiAgICAgICAgdW5vcHRpbWl6ZWQsXG4gICAgICAgIGxheW91dCxcbiAgICAgICAgd2lkdGg6IHdpZHRoSW50LFxuICAgICAgICBxdWFsaXR5OiBxdWFsaXR5SW50LFxuICAgICAgICBzaXplcyxcbiAgICAgICAgbG9hZGVyXG4gICAgfSksIHtcbiAgICAgICAgZGVjb2Rpbmc6IFwiYXN5bmNcIixcbiAgICAgICAgXCJkYXRhLW5pbWdcIjogbGF5b3V0LFxuICAgICAgICBzdHlsZTogaW1nU3R5bGUsXG4gICAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lLFxuICAgICAgICBsb2FkaW5nOiBsb2FkaW5nIHx8ICdsYXp5J1xuICAgIH0pKSksIHByaW9yaXR5ID8gLy8gTm90ZSBob3cgd2Ugb21pdCB0aGUgYGhyZWZgIGF0dHJpYnV0ZSwgYXMgaXQgd291bGQgb25seSBiZSByZWxldmFudFxuICAgIC8vIGZvciBicm93c2VycyB0aGF0IGRvIG5vdCBzdXBwb3J0IGBpbWFnZXNyY3NldGAsIGFuZCBpbiB0aG9zZSBjYXNlc1xuICAgIC8vIGl0IHdvdWxkIGxpa2VseSBjYXVzZSB0aGUgaW5jb3JyZWN0IGltYWdlIHRvIGJlIHByZWxvYWRlZC5cbiAgICAvL1xuICAgIC8vIGh0dHBzOi8vaHRtbC5zcGVjLndoYXR3Zy5vcmcvbXVsdGlwYWdlL3NlbWFudGljcy5odG1sI2F0dHItbGluay1pbWFnZXNyY3NldFxuICAgIC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChfaGVhZC5kZWZhdWx0LCBudWxsLCAvKiNfX1BVUkVfXyovIF9yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJsaW5rXCIsIHtcbiAgICAgICAga2V5OiAnX19uaW1nLScgKyBpbWdBdHRyaWJ1dGVzLnNyYyArIGltZ0F0dHJpYnV0ZXMuc3JjU2V0ICsgaW1nQXR0cmlidXRlcy5zaXplcyxcbiAgICAgICAgcmVsOiBcInByZWxvYWRcIixcbiAgICAgICAgYXM6IFwiaW1hZ2VcIixcbiAgICAgICAgaHJlZjogaW1nQXR0cmlidXRlcy5zcmNTZXQgPyB1bmRlZmluZWQgOiBpbWdBdHRyaWJ1dGVzLnNyYyxcbiAgICAgICAgLy8gQHRzLWlnbm9yZTogaW1hZ2VzcmNzZXQgaXMgbm90IHlldCBpbiB0aGUgbGluayBlbGVtZW50IHR5cGUuXG4gICAgICAgIGltYWdlc3Jjc2V0OiBpbWdBdHRyaWJ1dGVzLnNyY1NldCxcbiAgICAgICAgLy8gQHRzLWlnbm9yZTogaW1hZ2VzaXplcyBpcyBub3QgeWV0IGluIHRoZSBsaW5rIGVsZW1lbnQgdHlwZS5cbiAgICAgICAgaW1hZ2VzaXplczogaW1nQXR0cmlidXRlcy5zaXplc1xuICAgIH0pKSA6IG51bGwpKTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVNyYyhzcmMpIHtcbiAgICByZXR1cm4gc3JjWzBdID09PSAnLycgPyBzcmMuc2xpY2UoMSkgOiBzcmM7XG59XG5mdW5jdGlvbiBpbWdpeExvYWRlcih7IHJvb3QgLCBzcmMgLCB3aWR0aCAsIHF1YWxpdHkgIH0pIHtcbiAgICAvLyBEZW1vOiBodHRwczovL3N0YXRpYy5pbWdpeC5uZXQvZGFpc3kucG5nP2F1dG89Zm9ybWF0JmZpdD1tYXgmdz0zMDBcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKGAke3Jvb3R9JHtub3JtYWxpemVTcmMoc3JjKX1gKTtcbiAgICBjb25zdCBwYXJhbXMgPSB1cmwuc2VhcmNoUGFyYW1zO1xuICAgIHBhcmFtcy5zZXQoJ2F1dG8nLCBwYXJhbXMuZ2V0KCdhdXRvJykgfHwgJ2Zvcm1hdCcpO1xuICAgIHBhcmFtcy5zZXQoJ2ZpdCcsIHBhcmFtcy5nZXQoJ2ZpdCcpIHx8ICdtYXgnKTtcbiAgICBwYXJhbXMuc2V0KCd3JywgcGFyYW1zLmdldCgndycpIHx8IHdpZHRoLnRvU3RyaW5nKCkpO1xuICAgIGlmIChxdWFsaXR5KSB7XG4gICAgICAgIHBhcmFtcy5zZXQoJ3EnLCBxdWFsaXR5LnRvU3RyaW5nKCkpO1xuICAgIH1cbiAgICByZXR1cm4gdXJsLmhyZWY7XG59XG5mdW5jdGlvbiBha2FtYWlMb2FkZXIoeyByb290ICwgc3JjICwgd2lkdGggIH0pIHtcbiAgICByZXR1cm4gYCR7cm9vdH0ke25vcm1hbGl6ZVNyYyhzcmMpfT9pbXdpZHRoPSR7d2lkdGh9YDtcbn1cbmZ1bmN0aW9uIGNsb3VkaW5hcnlMb2FkZXIoeyByb290ICwgc3JjICwgd2lkdGggLCBxdWFsaXR5ICB9KSB7XG4gICAgLy8gRGVtbzogaHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vZGVtby9pbWFnZS91cGxvYWQvd18zMDAsY19saW1pdCxxX2F1dG8vdHVydGxlcy5qcGdcbiAgICBjb25zdCBwYXJhbXMgPSBbXG4gICAgICAgICdmX2F1dG8nLFxuICAgICAgICAnY19saW1pdCcsXG4gICAgICAgICd3XycgKyB3aWR0aCxcbiAgICAgICAgJ3FfJyArIChxdWFsaXR5IHx8ICdhdXRvJylcbiAgICBdO1xuICAgIGxldCBwYXJhbXNTdHJpbmcgPSBwYXJhbXMuam9pbignLCcpICsgJy8nO1xuICAgIHJldHVybiBgJHtyb290fSR7cGFyYW1zU3RyaW5nfSR7bm9ybWFsaXplU3JjKHNyYyl9YDtcbn1cbmZ1bmN0aW9uIGN1c3RvbUxvYWRlcih7IHNyYyAgfSkge1xuICAgIHRocm93IG5ldyBFcnJvcihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBpcyBtaXNzaW5nIFwibG9hZGVyXCIgcHJvcC5gICsgYFxcblJlYWQgbW9yZTogaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvbmV4dC1pbWFnZS1taXNzaW5nLWxvYWRlcmApO1xufVxuZnVuY3Rpb24gZGVmYXVsdExvYWRlcih7IHJvb3QgLCBzcmMgLCB3aWR0aCAsIHF1YWxpdHkgIH0pIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICBjb25zdCBtaXNzaW5nVmFsdWVzID0gW107XG4gICAgICAgIC8vIHRoZXNlIHNob3VsZCBhbHdheXMgYmUgcHJvdmlkZWQgYnV0IG1ha2Ugc3VyZSB0aGV5IGFyZVxuICAgICAgICBpZiAoIXNyYykgbWlzc2luZ1ZhbHVlcy5wdXNoKCdzcmMnKTtcbiAgICAgICAgaWYgKCF3aWR0aCkgbWlzc2luZ1ZhbHVlcy5wdXNoKCd3aWR0aCcpO1xuICAgICAgICBpZiAobWlzc2luZ1ZhbHVlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE5leHQgSW1hZ2UgT3B0aW1pemF0aW9uIHJlcXVpcmVzICR7bWlzc2luZ1ZhbHVlcy5qb2luKCcsICcpfSB0byBiZSBwcm92aWRlZC4gTWFrZSBzdXJlIHlvdSBwYXNzIHRoZW0gYXMgcHJvcHMgdG8gdGhlIFxcYG5leHQvaW1hZ2VcXGAgY29tcG9uZW50LiBSZWNlaXZlZDogJHtKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgc3JjLFxuICAgICAgICAgICAgICAgIHdpZHRoLFxuICAgICAgICAgICAgICAgIHF1YWxpdHlcbiAgICAgICAgICAgIH0pfWApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzcmMuc3RhcnRzV2l0aCgnLy8nKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gcGFyc2Ugc3JjIFwiJHtzcmN9XCIgb24gXFxgbmV4dC9pbWFnZVxcYCwgcHJvdG9jb2wtcmVsYXRpdmUgVVJMICgvLykgbXVzdCBiZSBjaGFuZ2VkIHRvIGFuIGFic29sdXRlIFVSTCAoaHR0cDovLyBvciBodHRwczovLylgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXNyYy5zdGFydHNXaXRoKCcvJykgJiYgY29uZmlnRG9tYWlucykge1xuICAgICAgICAgICAgbGV0IHBhcnNlZFNyYztcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcGFyc2VkU3JjID0gbmV3IFVSTChzcmMpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIHBhcnNlIHNyYyBcIiR7c3JjfVwiIG9uIFxcYG5leHQvaW1hZ2VcXGAsIGlmIHVzaW5nIHJlbGF0aXZlIGltYWdlIGl0IG11c3Qgc3RhcnQgd2l0aCBhIGxlYWRpbmcgc2xhc2ggXCIvXCIgb3IgYmUgYW4gYWJzb2x1dGUgVVJMIChodHRwOi8vIG9yIGh0dHBzOi8vKWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAndGVzdCcgJiYgIWNvbmZpZ0RvbWFpbnMuaW5jbHVkZXMocGFyc2VkU3JjLmhvc3RuYW1lKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBzcmMgcHJvcCAoJHtzcmN9KSBvbiBcXGBuZXh0L2ltYWdlXFxgLCBob3N0bmFtZSBcIiR7cGFyc2VkU3JjLmhvc3RuYW1lfVwiIGlzIG5vdCBjb25maWd1cmVkIHVuZGVyIGltYWdlcyBpbiB5b3VyIFxcYG5leHQuY29uZmlnLmpzXFxgXFxuYCArIGBTZWUgbW9yZSBpbmZvOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9uZXh0LWltYWdlLXVuY29uZmlndXJlZC1ob3N0YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGAke3Jvb3R9P3VybD0ke2VuY29kZVVSSUNvbXBvbmVudChzcmMpfSZ3PSR7d2lkdGh9JnE9JHtxdWFsaXR5IHx8IDc1fWA7XG59XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWltYWdlLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy5kZWZhdWx0ID0gdm9pZCAwO1xudmFyIF9yZWFjdCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcInJlYWN0XCIpKTtcbnZhciBfcm91dGVyID0gcmVxdWlyZShcIi4uL3NoYXJlZC9saWIvcm91dGVyL3JvdXRlclwiKTtcbnZhciBfcm91dGVyMSA9IHJlcXVpcmUoXCIuL3JvdXRlclwiKTtcbnZhciBfdXNlSW50ZXJzZWN0aW9uID0gcmVxdWlyZShcIi4vdXNlLWludGVyc2VjdGlvblwiKTtcbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gICAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICAgICAgZGVmYXVsdDogb2JqXG4gICAgfTtcbn1cbmNvbnN0IHByZWZldGNoZWQgPSB7XG59O1xuZnVuY3Rpb24gcHJlZmV0Y2gocm91dGVyLCBocmVmLCBhcywgb3B0aW9ucykge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJyB8fCAhcm91dGVyKSByZXR1cm47XG4gICAgaWYgKCEoMCwgX3JvdXRlcikuaXNMb2NhbFVSTChocmVmKSkgcmV0dXJuO1xuICAgIC8vIFByZWZldGNoIHRoZSBKU09OIHBhZ2UgaWYgYXNrZWQgKG9ubHkgaW4gdGhlIGNsaWVudClcbiAgICAvLyBXZSBuZWVkIHRvIGhhbmRsZSBhIHByZWZldGNoIGVycm9yIGhlcmUgc2luY2Ugd2UgbWF5IGJlXG4gICAgLy8gbG9hZGluZyB3aXRoIHByaW9yaXR5IHdoaWNoIGNhbiByZWplY3QgYnV0IHdlIGRvbid0XG4gICAgLy8gd2FudCB0byBmb3JjZSBuYXZpZ2F0aW9uIHNpbmNlIHRoaXMgaXMgb25seSBhIHByZWZldGNoXG4gICAgcm91dGVyLnByZWZldGNoKGhyZWYsIGFzLCBvcHRpb25zKS5jYXRjaCgoZXJyKT0+e1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgLy8gcmV0aHJvdyB0byBzaG93IGludmFsaWQgVVJMIGVycm9yc1xuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgY29uc3QgY3VyTG9jYWxlID0gb3B0aW9ucyAmJiB0eXBlb2Ygb3B0aW9ucy5sb2NhbGUgIT09ICd1bmRlZmluZWQnID8gb3B0aW9ucy5sb2NhbGUgOiByb3V0ZXIgJiYgcm91dGVyLmxvY2FsZTtcbiAgICAvLyBKb2luIG9uIGFuIGludmFsaWQgVVJJIGNoYXJhY3RlclxuICAgIHByZWZldGNoZWRbaHJlZiArICclJyArIGFzICsgKGN1ckxvY2FsZSA/ICclJyArIGN1ckxvY2FsZSA6ICcnKV0gPSB0cnVlO1xufVxuZnVuY3Rpb24gaXNNb2RpZmllZEV2ZW50KGV2ZW50KSB7XG4gICAgY29uc3QgeyB0YXJnZXQgIH0gPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgIHJldHVybiB0YXJnZXQgJiYgdGFyZ2V0ICE9PSAnX3NlbGYnIHx8IGV2ZW50Lm1ldGFLZXkgfHwgZXZlbnQuY3RybEtleSB8fCBldmVudC5zaGlmdEtleSB8fCBldmVudC5hbHRLZXkgfHwgZXZlbnQubmF0aXZlRXZlbnQgJiYgZXZlbnQubmF0aXZlRXZlbnQud2hpY2ggPT09IDI7XG59XG5mdW5jdGlvbiBsaW5rQ2xpY2tlZChlLCByb3V0ZXIsIGhyZWYsIGFzLCByZXBsYWNlLCBzaGFsbG93LCBzY3JvbGwsIGxvY2FsZSkge1xuICAgIGNvbnN0IHsgbm9kZU5hbWUgIH0gPSBlLmN1cnJlbnRUYXJnZXQ7XG4gICAgaWYgKG5vZGVOYW1lID09PSAnQScgJiYgKGlzTW9kaWZpZWRFdmVudChlKSB8fCAhKDAsIF9yb3V0ZXIpLmlzTG9jYWxVUkwoaHJlZikpKSB7XG4gICAgICAgIC8vIGlnbm9yZSBjbGljayBmb3IgYnJvd3NlcuKAmXMgZGVmYXVsdCBiZWhhdmlvclxuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAvLyAgYXZvaWQgc2Nyb2xsIGZvciB1cmxzIHdpdGggYW5jaG9yIHJlZnNcbiAgICBpZiAoc2Nyb2xsID09IG51bGwgJiYgYXMuaW5kZXhPZignIycpID49IDApIHtcbiAgICAgICAgc2Nyb2xsID0gZmFsc2U7XG4gICAgfVxuICAgIC8vIHJlcGxhY2Ugc3RhdGUgaW5zdGVhZCBvZiBwdXNoIGlmIHByb3AgaXMgcHJlc2VudFxuICAgIHJvdXRlcltyZXBsYWNlID8gJ3JlcGxhY2UnIDogJ3B1c2gnXShocmVmLCBhcywge1xuICAgICAgICBzaGFsbG93LFxuICAgICAgICBsb2NhbGUsXG4gICAgICAgIHNjcm9sbFxuICAgIH0pO1xufVxuZnVuY3Rpb24gTGluayhwcm9wcykge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGZ1bmN0aW9uIGNyZWF0ZVByb3BFcnJvcihhcmdzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IEVycm9yKGBGYWlsZWQgcHJvcCB0eXBlOiBUaGUgcHJvcCBcXGAke2FyZ3Mua2V5fVxcYCBleHBlY3RzIGEgJHthcmdzLmV4cGVjdGVkfSBpbiBcXGA8TGluaz5cXGAsIGJ1dCBnb3QgXFxgJHthcmdzLmFjdHVhbH1cXGAgaW5zdGVhZC5gICsgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gXCJcXG5PcGVuIHlvdXIgYnJvd3NlcidzIGNvbnNvbGUgdG8gdmlldyB0aGUgQ29tcG9uZW50IHN0YWNrIHRyYWNlLlwiIDogJycpKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgICAgICBjb25zdCByZXF1aXJlZFByb3BzR3VhcmQgPSB7XG4gICAgICAgICAgICBocmVmOiB0cnVlXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHJlcXVpcmVkUHJvcHMgPSBPYmplY3Qua2V5cyhyZXF1aXJlZFByb3BzR3VhcmQpO1xuICAgICAgICByZXF1aXJlZFByb3BzLmZvckVhY2goKGtleSk9PntcbiAgICAgICAgICAgIGlmIChrZXkgPT09ICdocmVmJykge1xuICAgICAgICAgICAgICAgIGlmIChwcm9wc1trZXldID09IG51bGwgfHwgdHlwZW9mIHByb3BzW2tleV0gIT09ICdzdHJpbmcnICYmIHR5cGVvZiBwcm9wc1trZXldICE9PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBjcmVhdGVQcm9wRXJyb3Ioe1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0ZWQ6ICdgc3RyaW5nYCBvciBgb2JqZWN0YCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3R1YWw6IHByb3BzW2tleV0gPT09IG51bGwgPyAnbnVsbCcgOiB0eXBlb2YgcHJvcHNba2V5XVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgICAgICAgICAgICAgIGNvbnN0IF8gPSBrZXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgICAgICBjb25zdCBvcHRpb25hbFByb3BzR3VhcmQgPSB7XG4gICAgICAgICAgICBhczogdHJ1ZSxcbiAgICAgICAgICAgIHJlcGxhY2U6IHRydWUsXG4gICAgICAgICAgICBzY3JvbGw6IHRydWUsXG4gICAgICAgICAgICBzaGFsbG93OiB0cnVlLFxuICAgICAgICAgICAgcGFzc0hyZWY6IHRydWUsXG4gICAgICAgICAgICBwcmVmZXRjaDogdHJ1ZSxcbiAgICAgICAgICAgIGxvY2FsZTogdHJ1ZVxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBvcHRpb25hbFByb3BzID0gT2JqZWN0LmtleXMob3B0aW9uYWxQcm9wc0d1YXJkKTtcbiAgICAgICAgb3B0aW9uYWxQcm9wcy5mb3JFYWNoKChrZXkpPT57XG4gICAgICAgICAgICBjb25zdCB2YWxUeXBlID0gdHlwZW9mIHByb3BzW2tleV07XG4gICAgICAgICAgICBpZiAoa2V5ID09PSAnYXMnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BzW2tleV0gJiYgdmFsVHlwZSAhPT0gJ3N0cmluZycgJiYgdmFsVHlwZSAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgY3JlYXRlUHJvcEVycm9yKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkOiAnYHN0cmluZ2Agb3IgYG9iamVjdGAnLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0dWFsOiB2YWxUeXBlXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSAnbG9jYWxlJykge1xuICAgICAgICAgICAgICAgIGlmIChwcm9wc1trZXldICYmIHZhbFR5cGUgIT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBlY3RlZDogJ2BzdHJpbmdgJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdHVhbDogdmFsVHlwZVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGtleSA9PT0gJ3JlcGxhY2UnIHx8IGtleSA9PT0gJ3Njcm9sbCcgfHwga2V5ID09PSAnc2hhbGxvdycgfHwga2V5ID09PSAncGFzc0hyZWYnIHx8IGtleSA9PT0gJ3ByZWZldGNoJykge1xuICAgICAgICAgICAgICAgIGlmIChwcm9wc1trZXldICE9IG51bGwgJiYgdmFsVHlwZSAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBlY3RlZDogJ2Bib29sZWFuYCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3R1YWw6IHZhbFR5cGVcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgICAgICAgICAgICAgICBjb25zdCBfID0ga2V5O1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgLy8gVGhpcyBob29rIGlzIGluIGEgY29uZGl0aW9uYWwgYnV0IHRoYXQgaXMgb2sgYmVjYXVzZSBgcHJvY2Vzcy5lbnYuTk9ERV9FTlZgIG5ldmVyIGNoYW5nZXNcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgICAgIGNvbnN0IGhhc1dhcm5lZCA9IF9yZWFjdC5kZWZhdWx0LnVzZVJlZihmYWxzZSk7XG4gICAgICAgIGlmIChwcm9wcy5wcmVmZXRjaCAmJiAhaGFzV2FybmVkLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGhhc1dhcm5lZC5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignTmV4dC5qcyBhdXRvLXByZWZldGNoZXMgYXV0b21hdGljYWxseSBiYXNlZCBvbiB2aWV3cG9ydC4gVGhlIHByZWZldGNoIGF0dHJpYnV0ZSBpcyBubyBsb25nZXIgbmVlZGVkLiBNb3JlOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9wcmVmZXRjaC10cnVlLWRlcHJlY2F0ZWQnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBwID0gcHJvcHMucHJlZmV0Y2ggIT09IGZhbHNlO1xuICAgIGNvbnN0IHJvdXRlciA9ICgwLCBfcm91dGVyMSkudXNlUm91dGVyKCk7XG4gICAgY29uc3QgeyBocmVmICwgYXMgIH0gPSBfcmVhY3QuZGVmYXVsdC51c2VNZW1vKCgpPT57XG4gICAgICAgIGNvbnN0IFtyZXNvbHZlZEhyZWYsIHJlc29sdmVkQXNdID0gKDAsIF9yb3V0ZXIpLnJlc29sdmVIcmVmKHJvdXRlciwgcHJvcHMuaHJlZiwgdHJ1ZSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBocmVmOiByZXNvbHZlZEhyZWYsXG4gICAgICAgICAgICBhczogcHJvcHMuYXMgPyAoMCwgX3JvdXRlcikucmVzb2x2ZUhyZWYocm91dGVyLCBwcm9wcy5hcykgOiByZXNvbHZlZEFzIHx8IHJlc29sdmVkSHJlZlxuICAgICAgICB9O1xuICAgIH0sIFtcbiAgICAgICAgcm91dGVyLFxuICAgICAgICBwcm9wcy5ocmVmLFxuICAgICAgICBwcm9wcy5hc1xuICAgIF0pO1xuICAgIGxldCB7IGNoaWxkcmVuICwgcmVwbGFjZSAsIHNoYWxsb3cgLCBzY3JvbGwgLCBsb2NhbGUgIH0gPSBwcm9wcztcbiAgICAvLyBEZXByZWNhdGVkLiBXYXJuaW5nIHNob3duIGJ5IHByb3BUeXBlIGNoZWNrLiBJZiB0aGUgY2hpbGRyZW4gcHJvdmlkZWQgaXMgYSBzdHJpbmcgKDxMaW5rPmV4YW1wbGU8L0xpbms+KSB3ZSB3cmFwIGl0IGluIGFuIDxhPiB0YWdcbiAgICBpZiAodHlwZW9mIGNoaWxkcmVuID09PSAnc3RyaW5nJykge1xuICAgICAgICBjaGlsZHJlbiA9IC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImFcIiwgbnVsbCwgY2hpbGRyZW4pO1xuICAgIH1cbiAgICAvLyBUaGlzIHdpbGwgcmV0dXJuIHRoZSBmaXJzdCBjaGlsZCwgaWYgbXVsdGlwbGUgYXJlIHByb3ZpZGVkIGl0IHdpbGwgdGhyb3cgYW4gZXJyb3JcbiAgICBsZXQgY2hpbGQ7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjaGlsZCA9IF9yZWFjdC5kZWZhdWx0LkNoaWxkcmVuLm9ubHkoY2hpbGRyZW4pO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgTXVsdGlwbGUgY2hpbGRyZW4gd2VyZSBwYXNzZWQgdG8gPExpbms+IHdpdGggXFxgaHJlZlxcYCBvZiBcXGAke3Byb3BzLmhyZWZ9XFxgIGJ1dCBvbmx5IG9uZSBjaGlsZCBpcyBzdXBwb3J0ZWQgaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvbGluay1tdWx0aXBsZS1jaGlsZHJlbmAgKyAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyBcIiBcXG5PcGVuIHlvdXIgYnJvd3NlcidzIGNvbnNvbGUgdG8gdmlldyB0aGUgQ29tcG9uZW50IHN0YWNrIHRyYWNlLlwiIDogJycpKTtcbiAgICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAgIGNoaWxkID0gX3JlYWN0LmRlZmF1bHQuQ2hpbGRyZW4ub25seShjaGlsZHJlbik7XG4gICAgfVxuICAgIGNvbnN0IGNoaWxkUmVmID0gY2hpbGQgJiYgdHlwZW9mIGNoaWxkID09PSAnb2JqZWN0JyAmJiBjaGlsZC5yZWY7XG4gICAgY29uc3QgW3NldEludGVyc2VjdGlvblJlZiwgaXNWaXNpYmxlXSA9ICgwLCBfdXNlSW50ZXJzZWN0aW9uKS51c2VJbnRlcnNlY3Rpb24oe1xuICAgICAgICByb290TWFyZ2luOiAnMjAwcHgnXG4gICAgfSk7XG4gICAgY29uc3Qgc2V0UmVmID0gX3JlYWN0LmRlZmF1bHQudXNlQ2FsbGJhY2soKGVsKT0+e1xuICAgICAgICBzZXRJbnRlcnNlY3Rpb25SZWYoZWwpO1xuICAgICAgICBpZiAoY2hpbGRSZWYpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY2hpbGRSZWYgPT09ICdmdW5jdGlvbicpIGNoaWxkUmVmKGVsKTtcbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjaGlsZFJlZiA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICBjaGlsZFJlZi5jdXJyZW50ID0gZWw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbXG4gICAgICAgIGNoaWxkUmVmLFxuICAgICAgICBzZXRJbnRlcnNlY3Rpb25SZWZcbiAgICBdKTtcbiAgICBfcmVhY3QuZGVmYXVsdC51c2VFZmZlY3QoKCk9PntcbiAgICAgICAgY29uc3Qgc2hvdWxkUHJlZmV0Y2ggPSBpc1Zpc2libGUgJiYgcCAmJiAoMCwgX3JvdXRlcikuaXNMb2NhbFVSTChocmVmKTtcbiAgICAgICAgY29uc3QgY3VyTG9jYWxlID0gdHlwZW9mIGxvY2FsZSAhPT0gJ3VuZGVmaW5lZCcgPyBsb2NhbGUgOiByb3V0ZXIgJiYgcm91dGVyLmxvY2FsZTtcbiAgICAgICAgY29uc3QgaXNQcmVmZXRjaGVkID0gcHJlZmV0Y2hlZFtocmVmICsgJyUnICsgYXMgKyAoY3VyTG9jYWxlID8gJyUnICsgY3VyTG9jYWxlIDogJycpXTtcbiAgICAgICAgaWYgKHNob3VsZFByZWZldGNoICYmICFpc1ByZWZldGNoZWQpIHtcbiAgICAgICAgICAgIHByZWZldGNoKHJvdXRlciwgaHJlZiwgYXMsIHtcbiAgICAgICAgICAgICAgICBsb2NhbGU6IGN1ckxvY2FsZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9LCBbXG4gICAgICAgIGFzLFxuICAgICAgICBocmVmLFxuICAgICAgICBpc1Zpc2libGUsXG4gICAgICAgIGxvY2FsZSxcbiAgICAgICAgcCxcbiAgICAgICAgcm91dGVyXG4gICAgXSk7XG4gICAgY29uc3QgY2hpbGRQcm9wcyA9IHtcbiAgICAgICAgcmVmOiBzZXRSZWYsXG4gICAgICAgIG9uQ2xpY2s6IChlKT0+e1xuICAgICAgICAgICAgaWYgKGNoaWxkLnByb3BzICYmIHR5cGVvZiBjaGlsZC5wcm9wcy5vbkNsaWNrID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgY2hpbGQucHJvcHMub25DbGljayhlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghZS5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgICAgICAgbGlua0NsaWNrZWQoZSwgcm91dGVyLCBocmVmLCBhcywgcmVwbGFjZSwgc2hhbGxvdywgc2Nyb2xsLCBsb2NhbGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjaGlsZFByb3BzLm9uTW91c2VFbnRlciA9IChlKT0+e1xuICAgICAgICBpZiAoISgwLCBfcm91dGVyKS5pc0xvY2FsVVJMKGhyZWYpKSByZXR1cm47XG4gICAgICAgIGlmIChjaGlsZC5wcm9wcyAmJiB0eXBlb2YgY2hpbGQucHJvcHMub25Nb3VzZUVudGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBjaGlsZC5wcm9wcy5vbk1vdXNlRW50ZXIoZSk7XG4gICAgICAgIH1cbiAgICAgICAgcHJlZmV0Y2gocm91dGVyLCBocmVmLCBhcywge1xuICAgICAgICAgICAgcHJpb3JpdHk6IHRydWVcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICAvLyBJZiBjaGlsZCBpcyBhbiA8YT4gdGFnIGFuZCBkb2Vzbid0IGhhdmUgYSBocmVmIGF0dHJpYnV0ZSwgb3IgaWYgdGhlICdwYXNzSHJlZicgcHJvcGVydHkgaXNcbiAgICAvLyBkZWZpbmVkLCB3ZSBzcGVjaWZ5IHRoZSBjdXJyZW50ICdocmVmJywgc28gdGhhdCByZXBldGl0aW9uIGlzIG5vdCBuZWVkZWQgYnkgdGhlIHVzZXJcbiAgICBpZiAocHJvcHMucGFzc0hyZWYgfHwgY2hpbGQudHlwZSA9PT0gJ2EnICYmICEoJ2hyZWYnIGluIGNoaWxkLnByb3BzKSkge1xuICAgICAgICBjb25zdCBjdXJMb2NhbGUgPSB0eXBlb2YgbG9jYWxlICE9PSAndW5kZWZpbmVkJyA/IGxvY2FsZSA6IHJvdXRlciAmJiByb3V0ZXIubG9jYWxlO1xuICAgICAgICAvLyB3ZSBvbmx5IHJlbmRlciBkb21haW4gbG9jYWxlcyBpZiB3ZSBhcmUgY3VycmVudGx5IG9uIGEgZG9tYWluIGxvY2FsZVxuICAgICAgICAvLyBzbyB0aGF0IGxvY2FsZSBsaW5rcyBhcmUgc3RpbGwgdmlzaXRhYmxlIGluIGRldmVsb3BtZW50L3ByZXZpZXcgZW52c1xuICAgICAgICBjb25zdCBsb2NhbGVEb21haW4gPSByb3V0ZXIgJiYgcm91dGVyLmlzTG9jYWxlRG9tYWluICYmICgwLCBfcm91dGVyKS5nZXREb21haW5Mb2NhbGUoYXMsIGN1ckxvY2FsZSwgcm91dGVyICYmIHJvdXRlci5sb2NhbGVzLCByb3V0ZXIgJiYgcm91dGVyLmRvbWFpbkxvY2FsZXMpO1xuICAgICAgICBjaGlsZFByb3BzLmhyZWYgPSBsb2NhbGVEb21haW4gfHwgKDAsIF9yb3V0ZXIpLmFkZEJhc2VQYXRoKCgwLCBfcm91dGVyKS5hZGRMb2NhbGUoYXMsIGN1ckxvY2FsZSwgcm91dGVyICYmIHJvdXRlci5kZWZhdWx0TG9jYWxlKSk7XG4gICAgfVxuICAgIHJldHVybigvKiNfX1BVUkVfXyovIF9yZWFjdC5kZWZhdWx0LmNsb25lRWxlbWVudChjaGlsZCwgY2hpbGRQcm9wcykpO1xufVxudmFyIF9kZWZhdWx0ID0gTGluaztcbmV4cG9ydHMuZGVmYXVsdCA9IF9kZWZhdWx0O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1saW5rLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCA9IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoO1xuZXhwb3J0cy5ub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaCA9IHZvaWQgMDtcbmZ1bmN0aW9uIHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGgpIHtcbiAgICByZXR1cm4gcGF0aC5lbmRzV2l0aCgnLycpICYmIHBhdGggIT09ICcvJyA/IHBhdGguc2xpY2UoMCwgLTEpIDogcGF0aDtcbn1cbmNvbnN0IG5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoID0gcHJvY2Vzcy5lbnYuX19ORVhUX1RSQUlMSU5HX1NMQVNIID8gKHBhdGgpPT57XG4gICAgaWYgKC9cXC5bXi9dK1xcLz8kLy50ZXN0KHBhdGgpKSB7XG4gICAgICAgIHJldHVybiByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRoKTtcbiAgICB9IGVsc2UgaWYgKHBhdGguZW5kc1dpdGgoJy8nKSkge1xuICAgICAgICByZXR1cm4gcGF0aDtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gcGF0aCArICcvJztcbiAgICB9XG59IDogcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2g7XG5leHBvcnRzLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoID0gbm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2g7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vcm1hbGl6ZS10cmFpbGluZy1zbGFzaC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICAgIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHMucmVxdWVzdElkbGVDYWxsYmFjayA9IGV4cG9ydHMuY2FuY2VsSWRsZUNhbGxiYWNrID0gdm9pZCAwO1xuY29uc3QgcmVxdWVzdElkbGVDYWxsYmFjayA9IHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyAmJiBzZWxmLnJlcXVlc3RJZGxlQ2FsbGJhY2sgJiYgc2VsZi5yZXF1ZXN0SWRsZUNhbGxiYWNrLmJpbmQod2luZG93KSB8fCBmdW5jdGlvbihjYikge1xuICAgIGxldCBzdGFydCA9IERhdGUubm93KCk7XG4gICAgcmV0dXJuIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgIGNiKHtcbiAgICAgICAgICAgIGRpZFRpbWVvdXQ6IGZhbHNlLFxuICAgICAgICAgICAgdGltZVJlbWFpbmluZzogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIE1hdGgubWF4KDAsIDUwIC0gKERhdGUubm93KCkgLSBzdGFydCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9LCAxKTtcbn07XG5leHBvcnRzLnJlcXVlc3RJZGxlQ2FsbGJhY2sgPSByZXF1ZXN0SWRsZUNhbGxiYWNrO1xuY29uc3QgY2FuY2VsSWRsZUNhbGxiYWNrID0gdHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnICYmIHNlbGYuY2FuY2VsSWRsZUNhbGxiYWNrICYmIHNlbGYuY2FuY2VsSWRsZUNhbGxiYWNrLmJpbmQod2luZG93KSB8fCBmdW5jdGlvbihpZCkge1xuICAgIHJldHVybiBjbGVhclRpbWVvdXQoaWQpO1xufTtcbmV4cG9ydHMuY2FuY2VsSWRsZUNhbGxiYWNrID0gY2FuY2VsSWRsZUNhbGxiYWNrO1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZXF1ZXN0LWlkbGUtY2FsbGJhY2suanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLm1hcmtBc3NldEVycm9yID0gbWFya0Fzc2V0RXJyb3I7XG5leHBvcnRzLmlzQXNzZXRFcnJvciA9IGlzQXNzZXRFcnJvcjtcbmV4cG9ydHMuZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCA9IGdldENsaWVudEJ1aWxkTWFuaWZlc3Q7XG5leHBvcnRzLmNyZWF0ZVJvdXRlTG9hZGVyID0gY3JlYXRlUm91dGVMb2FkZXI7XG52YXIgX2dldEFzc2V0UGF0aEZyb21Sb3V0ZSA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4uL3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL2dldC1hc3NldC1wYXRoLWZyb20tcm91dGVcIikpO1xudmFyIF9yZXF1ZXN0SWRsZUNhbGxiYWNrID0gcmVxdWlyZShcIi4vcmVxdWVzdC1pZGxlLWNhbGxiYWNrXCIpO1xuZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgICByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDoge1xuICAgICAgICBkZWZhdWx0OiBvYmpcbiAgICB9O1xufVxuLy8gMy44cyB3YXMgYXJiaXRyYXJpbHkgY2hvc2VuIGFzIGl0J3Mgd2hhdCBodHRwczovL3dlYi5kZXYvaW50ZXJhY3RpdmVcbi8vIGNvbnNpZGVycyBhcyBcIkdvb2RcIiB0aW1lLXRvLWludGVyYWN0aXZlLiBXZSBtdXN0IGFzc3VtZSBzb21ldGhpbmcgd2VudFxuLy8gd3JvbmcgYmV5b25kIHRoaXMgcG9pbnQsIGFuZCB0aGVuIGZhbGwtYmFjayB0byBhIGZ1bGwgcGFnZSB0cmFuc2l0aW9uIHRvXG4vLyBzaG93IHRoZSB1c2VyIHNvbWV0aGluZyBvZiB2YWx1ZS5cbmNvbnN0IE1TX01BWF9JRExFX0RFTEFZID0gMzgwMDtcbmZ1bmN0aW9uIHdpdGhGdXR1cmUoa2V5LCBtYXAsIGdlbmVyYXRvcikge1xuICAgIGxldCBlbnRyeSA9IG1hcC5nZXQoa2V5KTtcbiAgICBpZiAoZW50cnkpIHtcbiAgICAgICAgaWYgKCdmdXR1cmUnIGluIGVudHJ5KSB7XG4gICAgICAgICAgICByZXR1cm4gZW50cnkuZnV0dXJlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZW50cnkpO1xuICAgIH1cbiAgICBsZXQgcmVzb2x2ZXI7XG4gICAgY29uc3QgcHJvbSA9IG5ldyBQcm9taXNlKChyZXNvbHZlKT0+e1xuICAgICAgICByZXNvbHZlciA9IHJlc29sdmU7XG4gICAgfSk7XG4gICAgbWFwLnNldChrZXksIGVudHJ5ID0ge1xuICAgICAgICByZXNvbHZlOiByZXNvbHZlcixcbiAgICAgICAgZnV0dXJlOiBwcm9tXG4gICAgfSk7XG4gICAgcmV0dXJuIGdlbmVyYXRvciA/IGdlbmVyYXRvcigpLnRoZW4oKHZhbHVlKT0+KHJlc29sdmVyKHZhbHVlKSwgdmFsdWUpXG4gICAgKSA6IHByb207XG59XG5mdW5jdGlvbiBoYXNQcmVmZXRjaChsaW5rKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpbmsnKTtcbiAgICAgICAgcmV0dXJuKC8vIGRldGVjdCBJRTExIHNpbmNlIGl0IHN1cHBvcnRzIHByZWZldGNoIGJ1dCBpc24ndCBkZXRlY3RlZFxuICAgICAgICAvLyB3aXRoIHJlbExpc3Quc3VwcG9ydFxuICAgICAgICAoISF3aW5kb3cuTVNJbnB1dE1ldGhvZENvbnRleHQgJiYgISFkb2N1bWVudC5kb2N1bWVudE1vZGUpIHx8IGxpbmsucmVsTGlzdC5zdXBwb3J0cygncHJlZmV0Y2gnKSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuY29uc3QgY2FuUHJlZmV0Y2ggPSBoYXNQcmVmZXRjaCgpO1xuZnVuY3Rpb24gcHJlZmV0Y2hWaWFEb20oaHJlZiwgYXMsIGxpbmspIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlcywgcmVqKT0+e1xuICAgICAgICBpZiAoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgbGlua1tyZWw9XCJwcmVmZXRjaFwiXVtocmVmXj1cIiR7aHJlZn1cIl1gKSkge1xuICAgICAgICAgICAgcmV0dXJuIHJlcygpO1xuICAgICAgICB9XG4gICAgICAgIGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaW5rJyk7XG4gICAgICAgIC8vIFRoZSBvcmRlciBvZiBwcm9wZXJ0eSBhc3NpZ25tZW50IGhlcmUgaXMgaW50ZW50aW9uYWw6XG4gICAgICAgIGlmIChhcykgbGluay5hcyA9IGFzO1xuICAgICAgICBsaW5rLnJlbCA9IGBwcmVmZXRjaGA7XG4gICAgICAgIGxpbmsuY3Jvc3NPcmlnaW4gPSBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOO1xuICAgICAgICBsaW5rLm9ubG9hZCA9IHJlcztcbiAgICAgICAgbGluay5vbmVycm9yID0gcmVqO1xuICAgICAgICAvLyBgaHJlZmAgc2hvdWxkIGFsd2F5cyBiZSBsYXN0OlxuICAgICAgICBsaW5rLmhyZWYgPSBocmVmO1xuICAgICAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKGxpbmspO1xuICAgIH0pO1xufVxuY29uc3QgQVNTRVRfTE9BRF9FUlJPUiA9IFN5bWJvbCgnQVNTRVRfTE9BRF9FUlJPUicpO1xuZnVuY3Rpb24gbWFya0Fzc2V0RXJyb3IoZXJyKSB7XG4gICAgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlcnIsIEFTU0VUX0xPQURfRVJST1IsIHtcbiAgICB9KTtcbn1cbmZ1bmN0aW9uIGlzQXNzZXRFcnJvcihlcnIpIHtcbiAgICByZXR1cm4gZXJyICYmIEFTU0VUX0xPQURfRVJST1IgaW4gZXJyO1xufVxuZnVuY3Rpb24gYXBwZW5kU2NyaXB0KHNyYywgc2NyaXB0KSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpPT57XG4gICAgICAgIHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICAgICAgICAvLyBUaGUgb3JkZXIgb2YgcHJvcGVydHkgYXNzaWdubWVudCBoZXJlIGlzIGludGVudGlvbmFsLlxuICAgICAgICAvLyAxLiBTZXR1cCBzdWNjZXNzL2ZhaWx1cmUgaG9va3MgaW4gY2FzZSB0aGUgYnJvd3NlciBzeW5jaHJvbm91c2x5XG4gICAgICAgIC8vICAgIGV4ZWN1dGVzIHdoZW4gYHNyY2AgaXMgc2V0LlxuICAgICAgICBzY3JpcHQub25sb2FkID0gcmVzb2x2ZTtcbiAgICAgICAgc2NyaXB0Lm9uZXJyb3IgPSAoKT0+cmVqZWN0KG1hcmtBc3NldEVycm9yKG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc2NyaXB0OiAke3NyY31gKSkpXG4gICAgICAgIDtcbiAgICAgICAgLy8gMi4gQ29uZmlndXJlIHRoZSBjcm9zcy1vcmlnaW4gYXR0cmlidXRlIGJlZm9yZSBzZXR0aW5nIGBzcmNgIGluIGNhc2UgdGhlXG4gICAgICAgIC8vICAgIGJyb3dzZXIgYmVnaW5zIHRvIGZldGNoLlxuICAgICAgICBzY3JpcHQuY3Jvc3NPcmlnaW4gPSBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOO1xuICAgICAgICAvLyAzLiBGaW5hbGx5LCBzZXQgdGhlIHNvdXJjZSBhbmQgaW5qZWN0IGludG8gdGhlIERPTSBpbiBjYXNlIHRoZSBjaGlsZFxuICAgICAgICAvLyAgICBtdXN0IGJlIGFwcGVuZGVkIGZvciBmZXRjaGluZyB0byBzdGFydC5cbiAgICAgICAgc2NyaXB0LnNyYyA9IHNyYztcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICAgIH0pO1xufVxuLy8gV2Ugd2FpdCBmb3IgcGFnZXMgdG8gYmUgYnVpbHQgaW4gZGV2IGJlZm9yZSB3ZSBzdGFydCB0aGUgcm91dGUgdHJhbnNpdGlvblxuLy8gdGltZW91dCB0byBwcmV2ZW50IGFuIHVuLW5lY2Vzc2FyeSBoYXJkIG5hdmlnYXRpb24gaW4gZGV2ZWxvcG1lbnQuXG5sZXQgZGV2QnVpbGRQcm9taXNlO1xuLy8gUmVzb2x2ZSBhIHByb21pc2UgdGhhdCB0aW1lcyBvdXQgYWZ0ZXIgZ2l2ZW4gYW1vdW50IG9mIG1pbGxpc2Vjb25kcy5cbmZ1bmN0aW9uIHJlc29sdmVQcm9taXNlV2l0aFRpbWVvdXQocCwgbXMsIGVycikge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KT0+e1xuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgICAgIHAudGhlbigocik9PntcbiAgICAgICAgICAgIC8vIFJlc29sdmVkLCBjYW5jZWwgdGhlIHRpbWVvdXRcbiAgICAgICAgICAgIGNhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgICAgICByZXNvbHZlKHIpO1xuICAgICAgICB9KS5jYXRjaChyZWplY3QpO1xuICAgICAgICAvLyBXZSB3cmFwIHRoZXNlIGNoZWNrcyBzZXBhcmF0ZWx5IGZvciBiZXR0ZXIgZGVhZC1jb2RlIGVsaW1pbmF0aW9uIGluXG4gICAgICAgIC8vIHByb2R1Y3Rpb24gYnVuZGxlcy5cbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgICAgICAgICAoZGV2QnVpbGRQcm9taXNlIHx8IFByb21pc2UucmVzb2x2ZSgpKS50aGVuKCgpPT57XG4gICAgICAgICAgICAgICAgKDAsIF9yZXF1ZXN0SWRsZUNhbGxiYWNrKS5yZXF1ZXN0SWRsZUNhbGxiYWNrKCgpPT5zZXRUaW1lb3V0KCgpPT57XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LCBtcylcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgICAgICAgICAoMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLnJlcXVlc3RJZGxlQ2FsbGJhY2soKCk9PnNldFRpbWVvdXQoKCk9PntcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSwgbXMpXG4gICAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgfSk7XG59XG5mdW5jdGlvbiBnZXRDbGllbnRCdWlsZE1hbmlmZXN0KCkge1xuICAgIGlmIChzZWxmLl9fQlVJTERfTUFOSUZFU1QpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShzZWxmLl9fQlVJTERfTUFOSUZFU1QpO1xuICAgIH1cbiAgICBjb25zdCBvbkJ1aWxkTWFuaWZlc3QgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSk9PntcbiAgICAgICAgLy8gTWFuZGF0b3J5IGJlY2F1c2UgdGhpcyBpcyBub3QgY29uY3VycmVudCBzYWZlOlxuICAgICAgICBjb25zdCBjYiA9IHNlbGYuX19CVUlMRF9NQU5JRkVTVF9DQjtcbiAgICAgICAgc2VsZi5fX0JVSUxEX01BTklGRVNUX0NCID0gKCk9PntcbiAgICAgICAgICAgIHJlc29sdmUoc2VsZi5fX0JVSUxEX01BTklGRVNUKTtcbiAgICAgICAgICAgIGNiICYmIGNiKCk7XG4gICAgICAgIH07XG4gICAgfSk7XG4gICAgcmV0dXJuIHJlc29sdmVQcm9taXNlV2l0aFRpbWVvdXQob25CdWlsZE1hbmlmZXN0LCBNU19NQVhfSURMRV9ERUxBWSwgbWFya0Fzc2V0RXJyb3IobmV3IEVycm9yKCdGYWlsZWQgdG8gbG9hZCBjbGllbnQgYnVpbGQgbWFuaWZlc3QnKSkpO1xufVxuZnVuY3Rpb24gZ2V0RmlsZXNGb3JSb3V0ZShhc3NldFByZWZpeCwgcm91dGUpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7XG4gICAgICAgICAgICBzY3JpcHRzOiBbXG4gICAgICAgICAgICAgICAgYXNzZXRQcmVmaXggKyAnL19uZXh0L3N0YXRpYy9jaHVua3MvcGFnZXMnICsgZW5jb2RlVVJJKCgwLCBfZ2V0QXNzZXRQYXRoRnJvbVJvdXRlKS5kZWZhdWx0KHJvdXRlLCAnLmpzJykpLCBcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAvLyBTdHlsZXMgYXJlIGhhbmRsZWQgYnkgYHN0eWxlLWxvYWRlcmAgaW4gZGV2ZWxvcG1lbnQ6XG4gICAgICAgICAgICBjc3M6IFtdXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCgpLnRoZW4oKG1hbmlmZXN0KT0+e1xuICAgICAgICBpZiAoIShyb3V0ZSBpbiBtYW5pZmVzdCkpIHtcbiAgICAgICAgICAgIHRocm93IG1hcmtBc3NldEVycm9yKG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvb2t1cCByb3V0ZTogJHtyb3V0ZX1gKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYWxsRmlsZXMgPSBtYW5pZmVzdFtyb3V0ZV0ubWFwKChlbnRyeSk9PmFzc2V0UHJlZml4ICsgJy9fbmV4dC8nICsgZW5jb2RlVVJJKGVudHJ5KVxuICAgICAgICApO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc2NyaXB0czogYWxsRmlsZXMuZmlsdGVyKCh2KT0+di5lbmRzV2l0aCgnLmpzJylcbiAgICAgICAgICAgICksXG4gICAgICAgICAgICBjc3M6IGFsbEZpbGVzLmZpbHRlcigodik9PnYuZW5kc1dpdGgoJy5jc3MnKVxuICAgICAgICAgICAgKVxuICAgICAgICB9O1xuICAgIH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlUm91dGVMb2FkZXIoYXNzZXRQcmVmaXgpIHtcbiAgICBjb25zdCBlbnRyeXBvaW50cyA9IG5ldyBNYXAoKTtcbiAgICBjb25zdCBsb2FkZWRTY3JpcHRzID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IHN0eWxlU2hlZXRzID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IHJvdXRlcyA9IG5ldyBNYXAoKTtcbiAgICBmdW5jdGlvbiBtYXliZUV4ZWN1dGVTY3JpcHQoc3JjKSB7XG4gICAgICAgIGxldCBwcm9tID0gbG9hZGVkU2NyaXB0cy5nZXQoc3JjKTtcbiAgICAgICAgaWYgKHByb20pIHtcbiAgICAgICAgICAgIHJldHVybiBwcm9tO1xuICAgICAgICB9XG4gICAgICAgIC8vIFNraXAgZXhlY3V0aW5nIHNjcmlwdCBpZiBpdCdzIGFscmVhZHkgaW4gdGhlIERPTTpcbiAgICAgICAgaWYgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYHNjcmlwdFtzcmNePVwiJHtzcmN9XCJdYCkpIHtcbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICAgICAgfVxuICAgICAgICBsb2FkZWRTY3JpcHRzLnNldChzcmMsIHByb20gPSBhcHBlbmRTY3JpcHQoc3JjKSk7XG4gICAgICAgIHJldHVybiBwcm9tO1xuICAgIH1cbiAgICBmdW5jdGlvbiBmZXRjaFN0eWxlU2hlZXQoaHJlZikge1xuICAgICAgICBsZXQgcHJvbSA9IHN0eWxlU2hlZXRzLmdldChocmVmKTtcbiAgICAgICAgaWYgKHByb20pIHtcbiAgICAgICAgICAgIHJldHVybiBwcm9tO1xuICAgICAgICB9XG4gICAgICAgIHN0eWxlU2hlZXRzLnNldChocmVmLCBwcm9tID0gZmV0Y2goaHJlZikudGhlbigocmVzKT0+e1xuICAgICAgICAgICAgaWYgKCFyZXMub2spIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBsb2FkIHN0eWxlc2hlZXQ6ICR7aHJlZn1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXMudGV4dCgpLnRoZW4oKHRleHQpPT4oe1xuICAgICAgICAgICAgICAgICAgICBocmVmOiBocmVmLFxuICAgICAgICAgICAgICAgICAgICBjb250ZW50OiB0ZXh0XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0pLmNhdGNoKChlcnIpPT57XG4gICAgICAgICAgICB0aHJvdyBtYXJrQXNzZXRFcnJvcihlcnIpO1xuICAgICAgICB9KSk7XG4gICAgICAgIHJldHVybiBwcm9tO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICB3aGVuRW50cnlwb2ludCAocm91dGUpIHtcbiAgICAgICAgICAgIHJldHVybiB3aXRoRnV0dXJlKHJvdXRlLCBlbnRyeXBvaW50cyk7XG4gICAgICAgIH0sXG4gICAgICAgIG9uRW50cnlwb2ludCAocm91dGUsIGV4ZWN1dGUpIHtcbiAgICAgICAgICAgIFByb21pc2UucmVzb2x2ZShleGVjdXRlKS50aGVuKChmbik9PmZuKClcbiAgICAgICAgICAgICkudGhlbigoZXhwb3J0cyk9Pih7XG4gICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudDogZXhwb3J0cyAmJiBleHBvcnRzLmRlZmF1bHQgfHwgZXhwb3J0cyxcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0czogZXhwb3J0c1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAsIChlcnIpPT4oe1xuICAgICAgICAgICAgICAgICAgICBlcnJvcjogZXJyXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICkudGhlbigoaW5wdXQpPT57XG4gICAgICAgICAgICAgICAgY29uc3Qgb2xkID0gZW50cnlwb2ludHMuZ2V0KHJvdXRlKTtcbiAgICAgICAgICAgICAgICBlbnRyeXBvaW50cy5zZXQocm91dGUsIGlucHV0KTtcbiAgICAgICAgICAgICAgICBpZiAob2xkICYmICdyZXNvbHZlJyBpbiBvbGQpIG9sZC5yZXNvbHZlKGlucHV0KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICBsb2FkUm91dGUgKHJvdXRlLCBwcmVmZXRjaCkge1xuICAgICAgICAgICAgcmV0dXJuIHdpdGhGdXR1cmUocm91dGUsIHJvdXRlcywgKCk9PntcbiAgICAgICAgICAgICAgICBjb25zdCByb3V0ZUZpbGVzUHJvbWlzZSA9IGdldEZpbGVzRm9yUm91dGUoYXNzZXRQcmVmaXgsIHJvdXRlKS50aGVuKCh7IHNjcmlwdHMgLCBjc3MgIH0pPT57XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICAgICAgICAgICAgICBlbnRyeXBvaW50cy5oYXMocm91dGUpID8gW10gOiBQcm9taXNlLmFsbChzY3JpcHRzLm1hcChtYXliZUV4ZWN1dGVTY3JpcHQpKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFByb21pc2UuYWxsKGNzcy5tYXAoZmV0Y2hTdHlsZVNoZWV0KSksIFxuICAgICAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICB9KS50aGVuKChyZXMpPT57XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndoZW5FbnRyeXBvaW50KHJvdXRlKS50aGVuKChlbnRyeXBvaW50KT0+KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeXBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlczogcmVzWzFdXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ2RldmVsb3BtZW50Jykge1xuICAgICAgICAgICAgICAgICAgICBkZXZCdWlsZFByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSk9PntcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyb3V0ZUZpbGVzUHJvbWlzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByb3V0ZUZpbGVzUHJvbWlzZS5maW5hbGx5KCgpPT57XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiByZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0KHJvdXRlRmlsZXNQcm9taXNlLCBNU19NQVhfSURMRV9ERUxBWSwgbWFya0Fzc2V0RXJyb3IobmV3IEVycm9yKGBSb3V0ZSBkaWQgbm90IGNvbXBsZXRlIGxvYWRpbmc6ICR7cm91dGV9YCkpKS50aGVuKCh7IGVudHJ5cG9pbnQgLCBzdHlsZXMgIH0pPT57XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IE9iamVjdC5hc3NpZ24oe1xuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGVzOiBzdHlsZXNcbiAgICAgICAgICAgICAgICAgICAgfSwgZW50cnlwb2ludCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAnZXJyb3InIGluIGVudHJ5cG9pbnQgPyBlbnRyeXBvaW50IDogcmVzO1xuICAgICAgICAgICAgICAgIH0pLmNhdGNoKChlcnIpPT57XG4gICAgICAgICAgICAgICAgICAgIGlmIChwcmVmZXRjaCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2UgZG9uJ3Qgd2FudCB0byBjYWNoZSBlcnJvcnMgZHVyaW5nIHByZWZldGNoXG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yOiBlcnJcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICBwcmVmZXRjaCAocm91dGUpIHtcbiAgICAgICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWVMYWJzL3F1aWNrbGluay9ibG9iLzQ1M2E2NjFmYTFmYTk0MGUyZDJlMDQ0NDUyMzk4ZTM4YzY3YTk4ZmIvc3JjL2luZGV4Lm1qcyNMMTE1LUwxMThcbiAgICAgICAgICAgIC8vIExpY2Vuc2U6IEFwYWNoZSAyLjBcbiAgICAgICAgICAgIGxldCBjbjtcbiAgICAgICAgICAgIGlmIChjbiA9IG5hdmlnYXRvci5jb25uZWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgLy8gRG9uJ3QgcHJlZmV0Y2ggaWYgdXNpbmcgMkcgb3IgaWYgU2F2ZS1EYXRhIGlzIGVuYWJsZWQuXG4gICAgICAgICAgICAgICAgaWYgKGNuLnNhdmVEYXRhIHx8IC8yZy8udGVzdChjbi5lZmZlY3RpdmVUeXBlKSkgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGdldEZpbGVzRm9yUm91dGUoYXNzZXRQcmVmaXgsIHJvdXRlKS50aGVuKChvdXRwdXQpPT5Qcm9taXNlLmFsbChjYW5QcmVmZXRjaCA/IG91dHB1dC5zY3JpcHRzLm1hcCgoc2NyaXB0KT0+cHJlZmV0Y2hWaWFEb20oc2NyaXB0LCAnc2NyaXB0JylcbiAgICAgICAgICAgICAgICApIDogW10pXG4gICAgICAgICAgICApLnRoZW4oKCk9PntcbiAgICAgICAgICAgICAgICAoMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLnJlcXVlc3RJZGxlQ2FsbGJhY2soKCk9PnRoaXMubG9hZFJvdXRlKHJvdXRlLCB0cnVlKS5jYXRjaCgoKT0+e1xuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KS5jYXRjaCgvLyBzd2FsbG93IHByZWZldGNoIGVycm9yc1xuICAgICAgICAgICAgKCk9PntcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcbn1cblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGUtbG9hZGVyLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiUm91dGVyXCIsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBfcm91dGVyLmRlZmF1bHQ7XG4gICAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJ3aXRoUm91dGVyXCIsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBfd2l0aFJvdXRlci5kZWZhdWx0O1xuICAgIH1cbn0pO1xuZXhwb3J0cy51c2VSb3V0ZXIgPSB1c2VSb3V0ZXI7XG5leHBvcnRzLmNyZWF0ZVJvdXRlciA9IGNyZWF0ZVJvdXRlcjtcbmV4cG9ydHMubWFrZVB1YmxpY1JvdXRlckluc3RhbmNlID0gbWFrZVB1YmxpY1JvdXRlckluc3RhbmNlO1xuZXhwb3J0cy5kZWZhdWx0ID0gdm9pZCAwO1xudmFyIF9yZWFjdCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcInJlYWN0XCIpKTtcbnZhciBfcm91dGVyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vc2hhcmVkL2xpYi9yb3V0ZXIvcm91dGVyXCIpKTtcbnZhciBfcm91dGVyQ29udGV4dCA9IHJlcXVpcmUoXCIuLi9zaGFyZWQvbGliL3JvdXRlci1jb250ZXh0XCIpO1xudmFyIF93aXRoUm91dGVyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi93aXRoLXJvdXRlclwiKSk7XG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICAgIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgICAgIGRlZmF1bHQ6IG9ialxuICAgIH07XG59XG5jb25zdCBzaW5nbGV0b25Sb3V0ZXIgPSB7XG4gICAgcm91dGVyOiBudWxsLFxuICAgIHJlYWR5Q2FsbGJhY2tzOiBbXSxcbiAgICByZWFkeSAoY2IpIHtcbiAgICAgICAgaWYgKHRoaXMucm91dGVyKSByZXR1cm4gY2IoKTtcbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICB0aGlzLnJlYWR5Q2FsbGJhY2tzLnB1c2goY2IpO1xuICAgICAgICB9XG4gICAgfVxufTtcbi8vIENyZWF0ZSBwdWJsaWMgcHJvcGVydGllcyBhbmQgbWV0aG9kcyBvZiB0aGUgcm91dGVyIGluIHRoZSBzaW5nbGV0b25Sb3V0ZXJcbmNvbnN0IHVybFByb3BlcnR5RmllbGRzID0gW1xuICAgICdwYXRobmFtZScsXG4gICAgJ3JvdXRlJyxcbiAgICAncXVlcnknLFxuICAgICdhc1BhdGgnLFxuICAgICdjb21wb25lbnRzJyxcbiAgICAnaXNGYWxsYmFjaycsXG4gICAgJ2Jhc2VQYXRoJyxcbiAgICAnbG9jYWxlJyxcbiAgICAnbG9jYWxlcycsXG4gICAgJ2RlZmF1bHRMb2NhbGUnLFxuICAgICdpc1JlYWR5JyxcbiAgICAnaXNQcmV2aWV3JyxcbiAgICAnaXNMb2NhbGVEb21haW4nLFxuICAgICdkb21haW5Mb2NhbGVzJywgXG5dO1xuY29uc3Qgcm91dGVyRXZlbnRzID0gW1xuICAgICdyb3V0ZUNoYW5nZVN0YXJ0JyxcbiAgICAnYmVmb3JlSGlzdG9yeUNoYW5nZScsXG4gICAgJ3JvdXRlQ2hhbmdlQ29tcGxldGUnLFxuICAgICdyb3V0ZUNoYW5nZUVycm9yJyxcbiAgICAnaGFzaENoYW5nZVN0YXJ0JyxcbiAgICAnaGFzaENoYW5nZUNvbXBsZXRlJywgXG5dO1xuY29uc3QgY29yZU1ldGhvZEZpZWxkcyA9IFtcbiAgICAncHVzaCcsXG4gICAgJ3JlcGxhY2UnLFxuICAgICdyZWxvYWQnLFxuICAgICdiYWNrJyxcbiAgICAncHJlZmV0Y2gnLFxuICAgICdiZWZvcmVQb3BTdGF0ZScsIFxuXTtcbi8vIEV2ZW50cyBpcyBhIHN0YXRpYyBwcm9wZXJ0eSBvbiB0aGUgcm91dGVyLCB0aGUgcm91dGVyIGRvZXNuJ3QgaGF2ZSB0byBiZSBpbml0aWFsaXplZCB0byB1c2UgaXRcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShzaW5nbGV0b25Sb3V0ZXIsICdldmVudHMnLCB7XG4gICAgZ2V0ICgpIHtcbiAgICAgICAgcmV0dXJuIF9yb3V0ZXIuZGVmYXVsdC5ldmVudHM7XG4gICAgfVxufSk7XG51cmxQcm9wZXJ0eUZpZWxkcy5mb3JFYWNoKChmaWVsZCk9PntcbiAgICAvLyBIZXJlIHdlIG5lZWQgdG8gdXNlIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSBiZWNhdXNlIHdlIG5lZWQgdG8gcmV0dXJuXG4gICAgLy8gdGhlIHByb3BlcnR5IGFzc2lnbmVkIHRvIHRoZSBhY3R1YWwgcm91dGVyXG4gICAgLy8gVGhlIHZhbHVlIG1pZ2h0IGdldCBjaGFuZ2VkIGFzIHdlIGNoYW5nZSByb3V0ZXMgYW5kIHRoaXMgaXMgdGhlXG4gICAgLy8gcHJvcGVyIHdheSB0byBhY2Nlc3MgaXRcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoc2luZ2xldG9uUm91dGVyLCBmaWVsZCwge1xuICAgICAgICBnZXQgKCkge1xuICAgICAgICAgICAgY29uc3Qgcm91dGVyID0gZ2V0Um91dGVyKCk7XG4gICAgICAgICAgICByZXR1cm4gcm91dGVyW2ZpZWxkXTtcbiAgICAgICAgfVxuICAgIH0pO1xufSk7XG5jb3JlTWV0aG9kRmllbGRzLmZvckVhY2goKGZpZWxkKT0+e1xuICAgIHNpbmdsZXRvblJvdXRlcltmaWVsZF0gPSAoLi4uYXJncyk9PntcbiAgICAgICAgY29uc3Qgcm91dGVyID0gZ2V0Um91dGVyKCk7XG4gICAgICAgIHJldHVybiByb3V0ZXJbZmllbGRdKC4uLmFyZ3MpO1xuICAgIH07XG59KTtcbnJvdXRlckV2ZW50cy5mb3JFYWNoKChldmVudCk9PntcbiAgICBzaW5nbGV0b25Sb3V0ZXIucmVhZHkoKCk9PntcbiAgICAgICAgX3JvdXRlci5kZWZhdWx0LmV2ZW50cy5vbihldmVudCwgKC4uLmFyZ3MpPT57XG4gICAgICAgICAgICBjb25zdCBldmVudEZpZWxkID0gYG9uJHtldmVudC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX0ke2V2ZW50LnN1YnN0cmluZygxKX1gO1xuICAgICAgICAgICAgY29uc3QgX3NpbmdsZXRvblJvdXRlciA9IHNpbmdsZXRvblJvdXRlcjtcbiAgICAgICAgICAgIGlmIChfc2luZ2xldG9uUm91dGVyW2V2ZW50RmllbGRdKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgX3NpbmdsZXRvblJvdXRlcltldmVudEZpZWxkXSguLi5hcmdzKTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3Igd2hlbiBydW5uaW5nIHRoZSBSb3V0ZXIgZXZlbnQ6ICR7ZXZlbnRGaWVsZH1gKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgJHtlcnIubWVzc2FnZX1cXG4ke2Vyci5zdGFja31gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufSk7XG5mdW5jdGlvbiBnZXRSb3V0ZXIoKSB7XG4gICAgaWYgKCFzaW5nbGV0b25Sb3V0ZXIucm91dGVyKSB7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSAnTm8gcm91dGVyIGluc3RhbmNlIGZvdW5kLlxcbicgKyAnWW91IHNob3VsZCBvbmx5IHVzZSBcIm5leHQvcm91dGVyXCIgb24gdGhlIGNsaWVudCBzaWRlIG9mIHlvdXIgYXBwLlxcbic7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKTtcbiAgICB9XG4gICAgcmV0dXJuIHNpbmdsZXRvblJvdXRlci5yb3V0ZXI7XG59XG52YXIgX2RlZmF1bHQgPSBzaW5nbGV0b25Sb3V0ZXI7XG5leHBvcnRzLmRlZmF1bHQgPSBfZGVmYXVsdDtcbmZ1bmN0aW9uIHVzZVJvdXRlcigpIHtcbiAgICByZXR1cm4gX3JlYWN0LmRlZmF1bHQudXNlQ29udGV4dChfcm91dGVyQ29udGV4dC5Sb3V0ZXJDb250ZXh0KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlciguLi5hcmdzKSB7XG4gICAgc2luZ2xldG9uUm91dGVyLnJvdXRlciA9IG5ldyBfcm91dGVyLmRlZmF1bHQoLi4uYXJncyk7XG4gICAgc2luZ2xldG9uUm91dGVyLnJlYWR5Q2FsbGJhY2tzLmZvckVhY2goKGNiKT0+Y2IoKVxuICAgICk7XG4gICAgc2luZ2xldG9uUm91dGVyLnJlYWR5Q2FsbGJhY2tzID0gW107XG4gICAgcmV0dXJuIHNpbmdsZXRvblJvdXRlci5yb3V0ZXI7XG59XG5mdW5jdGlvbiBtYWtlUHVibGljUm91dGVySW5zdGFuY2Uocm91dGVyKSB7XG4gICAgY29uc3QgX3JvdXRlcjEgPSByb3V0ZXI7XG4gICAgY29uc3QgaW5zdGFuY2UgPSB7XG4gICAgfTtcbiAgICBmb3IgKGNvbnN0IHByb3BlcnR5IG9mIHVybFByb3BlcnR5RmllbGRzKXtcbiAgICAgICAgaWYgKHR5cGVvZiBfcm91dGVyMVtwcm9wZXJ0eV0gPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICBpbnN0YW5jZVtwcm9wZXJ0eV0gPSBPYmplY3QuYXNzaWduKEFycmF5LmlzQXJyYXkoX3JvdXRlcjFbcHJvcGVydHldKSA/IFtdIDoge1xuICAgICAgICAgICAgfSwgX3JvdXRlcjFbcHJvcGVydHldKSAvLyBtYWtlcyBzdXJlIHF1ZXJ5IGlzIG5vdCBzdGF0ZWZ1bFxuICAgICAgICAgICAgO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaW5zdGFuY2VbcHJvcGVydHldID0gX3JvdXRlcjFbcHJvcGVydHldO1xuICAgIH1cbiAgICAvLyBFdmVudHMgaXMgYSBzdGF0aWMgcHJvcGVydHkgb24gdGhlIHJvdXRlciwgdGhlIHJvdXRlciBkb2Vzbid0IGhhdmUgdG8gYmUgaW5pdGlhbGl6ZWQgdG8gdXNlIGl0XG4gICAgaW5zdGFuY2UuZXZlbnRzID0gX3JvdXRlci5kZWZhdWx0LmV2ZW50cztcbiAgICBjb3JlTWV0aG9kRmllbGRzLmZvckVhY2goKGZpZWxkKT0+e1xuICAgICAgICBpbnN0YW5jZVtmaWVsZF0gPSAoLi4uYXJncyk9PntcbiAgICAgICAgICAgIHJldHVybiBfcm91dGVyMVtmaWVsZF0oLi4uYXJncyk7XG4gICAgICAgIH07XG4gICAgfSk7XG4gICAgcmV0dXJuIGluc3RhbmNlO1xufVxuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yb3V0ZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLnVzZUludGVyc2VjdGlvbiA9IHVzZUludGVyc2VjdGlvbjtcbnZhciBfcmVhY3QgPSByZXF1aXJlKFwicmVhY3RcIik7XG52YXIgX3JlcXVlc3RJZGxlQ2FsbGJhY2sgPSByZXF1aXJlKFwiLi9yZXF1ZXN0LWlkbGUtY2FsbGJhY2tcIik7XG5jb25zdCBoYXNJbnRlcnNlY3Rpb25PYnNlcnZlciA9IHR5cGVvZiBJbnRlcnNlY3Rpb25PYnNlcnZlciAhPT0gJ3VuZGVmaW5lZCc7XG5mdW5jdGlvbiB1c2VJbnRlcnNlY3Rpb24oeyByb290TWFyZ2luICwgZGlzYWJsZWQgIH0pIHtcbiAgICBjb25zdCBpc0Rpc2FibGVkID0gZGlzYWJsZWQgfHwgIWhhc0ludGVyc2VjdGlvbk9ic2VydmVyO1xuICAgIGNvbnN0IHVub2JzZXJ2ZSA9ICgwLCBfcmVhY3QpLnVzZVJlZigpO1xuICAgIGNvbnN0IFt2aXNpYmxlLCBzZXRWaXNpYmxlXSA9ICgwLCBfcmVhY3QpLnVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBzZXRSZWYgPSAoMCwgX3JlYWN0KS51c2VDYWxsYmFjaygoZWwpPT57XG4gICAgICAgIGlmICh1bm9ic2VydmUuY3VycmVudCkge1xuICAgICAgICAgICAgdW5vYnNlcnZlLmN1cnJlbnQoKTtcbiAgICAgICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0Rpc2FibGVkIHx8IHZpc2libGUpIHJldHVybjtcbiAgICAgICAgaWYgKGVsICYmIGVsLnRhZ05hbWUpIHtcbiAgICAgICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gb2JzZXJ2ZShlbCwgKGlzVmlzaWJsZSk9PmlzVmlzaWJsZSAmJiBzZXRWaXNpYmxlKGlzVmlzaWJsZSlcbiAgICAgICAgICAgICwge1xuICAgICAgICAgICAgICAgIHJvb3RNYXJnaW5cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSwgW1xuICAgICAgICBpc0Rpc2FibGVkLFxuICAgICAgICByb290TWFyZ2luLFxuICAgICAgICB2aXNpYmxlXG4gICAgXSk7XG4gICAgKDAsIF9yZWFjdCkudXNlRWZmZWN0KCgpPT57XG4gICAgICAgIGlmICghaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIpIHtcbiAgICAgICAgICAgIGlmICghdmlzaWJsZSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkbGVDYWxsYmFjayA9ICgwLCBfcmVxdWVzdElkbGVDYWxsYmFjaykucmVxdWVzdElkbGVDYWxsYmFjaygoKT0+c2V0VmlzaWJsZSh0cnVlKVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgcmV0dXJuICgpPT4oMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLmNhbmNlbElkbGVDYWxsYmFjayhpZGxlQ2FsbGJhY2spXG4gICAgICAgICAgICAgICAgO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW1xuICAgICAgICB2aXNpYmxlXG4gICAgXSk7XG4gICAgcmV0dXJuIFtcbiAgICAgICAgc2V0UmVmLFxuICAgICAgICB2aXNpYmxlXG4gICAgXTtcbn1cbmZ1bmN0aW9uIG9ic2VydmUoZWxlbWVudCwgY2FsbGJhY2ssIG9wdGlvbnMpIHtcbiAgICBjb25zdCB7IGlkICwgb2JzZXJ2ZXIgLCBlbGVtZW50cyAgfSA9IGNyZWF0ZU9ic2VydmVyKG9wdGlvbnMpO1xuICAgIGVsZW1lbnRzLnNldChlbGVtZW50LCBjYWxsYmFjayk7XG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50KTtcbiAgICByZXR1cm4gZnVuY3Rpb24gdW5vYnNlcnZlKCkge1xuICAgICAgICBlbGVtZW50cy5kZWxldGUoZWxlbWVudCk7XG4gICAgICAgIG9ic2VydmVyLnVub2JzZXJ2ZShlbGVtZW50KTtcbiAgICAgICAgLy8gRGVzdHJveSBvYnNlcnZlciB3aGVuIHRoZXJlJ3Mgbm90aGluZyBsZWZ0IHRvIHdhdGNoOlxuICAgICAgICBpZiAoZWxlbWVudHMuc2l6ZSA9PT0gMCkge1xuICAgICAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICAgICAgb2JzZXJ2ZXJzLmRlbGV0ZShpZCk7XG4gICAgICAgIH1cbiAgICB9O1xufVxuY29uc3Qgb2JzZXJ2ZXJzID0gbmV3IE1hcCgpO1xuZnVuY3Rpb24gY3JlYXRlT2JzZXJ2ZXIob3B0aW9ucykge1xuICAgIGNvbnN0IGlkID0gb3B0aW9ucy5yb290TWFyZ2luIHx8ICcnO1xuICAgIGxldCBpbnN0YW5jZSA9IG9ic2VydmVycy5nZXQoaWQpO1xuICAgIGlmIChpbnN0YW5jZSkge1xuICAgICAgICByZXR1cm4gaW5zdGFuY2U7XG4gICAgfVxuICAgIGNvbnN0IGVsZW1lbnRzID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKChlbnRyaWVzKT0+e1xuICAgICAgICBlbnRyaWVzLmZvckVhY2goKGVudHJ5KT0+e1xuICAgICAgICAgICAgY29uc3QgY2FsbGJhY2sgPSBlbGVtZW50cy5nZXQoZW50cnkudGFyZ2V0KTtcbiAgICAgICAgICAgIGNvbnN0IGlzVmlzaWJsZSA9IGVudHJ5LmlzSW50ZXJzZWN0aW5nIHx8IGVudHJ5LmludGVyc2VjdGlvblJhdGlvID4gMDtcbiAgICAgICAgICAgIGlmIChjYWxsYmFjayAmJiBpc1Zpc2libGUpIHtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayhpc1Zpc2libGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9LCBvcHRpb25zKTtcbiAgICBvYnNlcnZlcnMuc2V0KGlkLCBpbnN0YW5jZSA9IHtcbiAgICAgICAgaWQsXG4gICAgICAgIG9ic2VydmVyLFxuICAgICAgICBlbGVtZW50c1xuICAgIH0pO1xuICAgIHJldHVybiBpbnN0YW5jZTtcbn1cblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlLWludGVyc2VjdGlvbi5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICAgIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHMuZGVmYXVsdCA9IHdpdGhSb3V0ZXI7XG52YXIgX3JlYWN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwicmVhY3RcIikpO1xudmFyIF9yb3V0ZXIgPSByZXF1aXJlKFwiLi9yb3V0ZXJcIik7XG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICAgIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgICAgIGRlZmF1bHQ6IG9ialxuICAgIH07XG59XG5mdW5jdGlvbiB3aXRoUm91dGVyKENvbXBvc2VkQ29tcG9uZW50KSB7XG4gICAgZnVuY3Rpb24gV2l0aFJvdXRlcldyYXBwZXIocHJvcHMpIHtcbiAgICAgICAgcmV0dXJuKC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChDb21wb3NlZENvbXBvbmVudCwgT2JqZWN0LmFzc2lnbih7XG4gICAgICAgICAgICByb3V0ZXI6ICgwLCBfcm91dGVyKS51c2VSb3V0ZXIoKVxuICAgICAgICB9LCBwcm9wcykpKTtcbiAgICB9XG4gICAgV2l0aFJvdXRlcldyYXBwZXIuZ2V0SW5pdGlhbFByb3BzID0gQ29tcG9zZWRDb21wb25lbnQuZ2V0SW5pdGlhbFByb3BzO1xuICAgIFdpdGhSb3V0ZXJXcmFwcGVyLm9yaWdHZXRJbml0aWFsUHJvcHMgPSBDb21wb3NlZENvbXBvbmVudC5vcmlnR2V0SW5pdGlhbFByb3BzO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnN0IG5hbWUgPSBDb21wb3NlZENvbXBvbmVudC5kaXNwbGF5TmFtZSB8fCBDb21wb3NlZENvbXBvbmVudC5uYW1lIHx8ICdVbmtub3duJztcbiAgICAgICAgV2l0aFJvdXRlcldyYXBwZXIuZGlzcGxheU5hbWUgPSBgd2l0aFJvdXRlcigke25hbWV9KWA7XG4gICAgfVxuICAgIHJldHVybiBXaXRoUm91dGVyV3JhcHBlcjtcbn1cblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9d2l0aC1yb3V0ZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLmdldERvbWFpbkxvY2FsZSA9IGdldERvbWFpbkxvY2FsZTtcbmV4cG9ydHMuYWRkTG9jYWxlID0gYWRkTG9jYWxlO1xuZXhwb3J0cy5kZWxMb2NhbGUgPSBkZWxMb2NhbGU7XG5leHBvcnRzLmhhc0Jhc2VQYXRoID0gaGFzQmFzZVBhdGg7XG5leHBvcnRzLmFkZEJhc2VQYXRoID0gYWRkQmFzZVBhdGg7XG5leHBvcnRzLmRlbEJhc2VQYXRoID0gZGVsQmFzZVBhdGg7XG5leHBvcnRzLmlzTG9jYWxVUkwgPSBpc0xvY2FsVVJMO1xuZXhwb3J0cy5pbnRlcnBvbGF0ZUFzID0gaW50ZXJwb2xhdGVBcztcbmV4cG9ydHMucmVzb2x2ZUhyZWYgPSByZXNvbHZlSHJlZjtcbmV4cG9ydHMuZGVmYXVsdCA9IHZvaWQgMDtcbnZhciBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCA9IHJlcXVpcmUoXCIuLi8uLi8uLi9jbGllbnQvbm9ybWFsaXplLXRyYWlsaW5nLXNsYXNoXCIpO1xudmFyIF9yb3V0ZUxvYWRlciA9IHJlcXVpcmUoXCIuLi8uLi8uLi9jbGllbnQvcm91dGUtbG9hZGVyXCIpO1xudmFyIF9kZW5vcm1hbGl6ZVBhZ2VQYXRoID0gcmVxdWlyZShcIi4uLy4uLy4uL3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGhcIik7XG52YXIgX25vcm1hbGl6ZUxvY2FsZVBhdGggPSByZXF1aXJlKFwiLi4vaTE4bi9ub3JtYWxpemUtbG9jYWxlLXBhdGhcIik7XG52YXIgX21pdHQgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuLi9taXR0XCIpKTtcbnZhciBfdXRpbHMgPSByZXF1aXJlKFwiLi4vdXRpbHNcIik7XG52YXIgX2lzRHluYW1pYyA9IHJlcXVpcmUoXCIuL3V0aWxzL2lzLWR5bmFtaWNcIik7XG52YXIgX3BhcnNlUmVsYXRpdmVVcmwgPSByZXF1aXJlKFwiLi91dGlscy9wYXJzZS1yZWxhdGl2ZS11cmxcIik7XG52YXIgX3F1ZXJ5c3RyaW5nID0gcmVxdWlyZShcIi4vdXRpbHMvcXVlcnlzdHJpbmdcIik7XG52YXIgX3Jlc29sdmVSZXdyaXRlcyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vdXRpbHMvcmVzb2x2ZS1yZXdyaXRlc1wiKSk7XG52YXIgX3JvdXRlTWF0Y2hlciA9IHJlcXVpcmUoXCIuL3V0aWxzL3JvdXRlLW1hdGNoZXJcIik7XG52YXIgX3JvdXRlUmVnZXggPSByZXF1aXJlKFwiLi91dGlscy9yb3V0ZS1yZWdleFwiKTtcbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gICAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICAgICAgZGVmYXVsdDogb2JqXG4gICAgfTtcbn1cbmxldCBkZXRlY3REb21haW5Mb2NhbGU7XG5pZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgIGRldGVjdERvbWFpbkxvY2FsZSA9IHJlcXVpcmUoJy4uL2kxOG4vZGV0ZWN0LWRvbWFpbi1sb2NhbGUnKS5kZXRlY3REb21haW5Mb2NhbGU7XG59XG5jb25zdCBiYXNlUGF0aCA9IHByb2Nlc3MuZW52Ll9fTkVYVF9ST1VURVJfQkFTRVBBVEggfHwgJyc7XG5mdW5jdGlvbiBidWlsZENhbmNlbGxhdGlvbkVycm9yKCkge1xuICAgIHJldHVybiBPYmplY3QuYXNzaWduKG5ldyBFcnJvcignUm91dGUgQ2FuY2VsbGVkJyksIHtcbiAgICAgICAgY2FuY2VsbGVkOiB0cnVlXG4gICAgfSk7XG59XG5mdW5jdGlvbiBhZGRQYXRoUHJlZml4KHBhdGgsIHByZWZpeCkge1xuICAgIHJldHVybiBwcmVmaXggJiYgcGF0aC5zdGFydHNXaXRoKCcvJykgPyBwYXRoID09PSAnLycgPyAoMCwgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gpLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoKHByZWZpeCkgOiBgJHtwcmVmaXh9JHtwYXRoTm9RdWVyeUhhc2gocGF0aCkgPT09ICcvJyA/IHBhdGguc3Vic3RyaW5nKDEpIDogcGF0aH1gIDogcGF0aDtcbn1cbmZ1bmN0aW9uIGdldERvbWFpbkxvY2FsZShwYXRoLCBsb2NhbGUsIGxvY2FsZXMsIGRvbWFpbkxvY2FsZXMpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICBsb2NhbGUgPSBsb2NhbGUgfHwgKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKHBhdGgsIGxvY2FsZXMpLmRldGVjdGVkTG9jYWxlO1xuICAgICAgICBjb25zdCBkZXRlY3RlZERvbWFpbiA9IGRldGVjdERvbWFpbkxvY2FsZShkb21haW5Mb2NhbGVzLCB1bmRlZmluZWQsIGxvY2FsZSk7XG4gICAgICAgIGlmIChkZXRlY3RlZERvbWFpbikge1xuICAgICAgICAgICAgcmV0dXJuIGBodHRwJHtkZXRlY3RlZERvbWFpbi5odHRwID8gJycgOiAncyd9Oi8vJHtkZXRlY3RlZERvbWFpbi5kb21haW59JHtiYXNlUGF0aCB8fCAnJ30ke2xvY2FsZSA9PT0gZGV0ZWN0ZWREb21haW4uZGVmYXVsdExvY2FsZSA/ICcnIDogYC8ke2xvY2FsZX1gfSR7cGF0aH1gO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuZnVuY3Rpb24gYWRkTG9jYWxlKHBhdGgsIGxvY2FsZSwgZGVmYXVsdExvY2FsZSkge1xuICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgIGNvbnN0IHBhdGhuYW1lID0gcGF0aE5vUXVlcnlIYXNoKHBhdGgpO1xuICAgICAgICBjb25zdCBwYXRoTG93ZXIgPSBwYXRobmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBjb25zdCBsb2NhbGVMb3dlciA9IGxvY2FsZSAmJiBsb2NhbGUudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgcmV0dXJuIGxvY2FsZSAmJiBsb2NhbGUgIT09IGRlZmF1bHRMb2NhbGUgJiYgIXBhdGhMb3dlci5zdGFydHNXaXRoKCcvJyArIGxvY2FsZUxvd2VyICsgJy8nKSAmJiBwYXRoTG93ZXIgIT09ICcvJyArIGxvY2FsZUxvd2VyID8gYWRkUGF0aFByZWZpeChwYXRoLCAnLycgKyBsb2NhbGUpIDogcGF0aDtcbiAgICB9XG4gICAgcmV0dXJuIHBhdGg7XG59XG5mdW5jdGlvbiBkZWxMb2NhbGUocGF0aCwgbG9jYWxlKSB7XG4gICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpIHtcbiAgICAgICAgY29uc3QgcGF0aG5hbWUgPSBwYXRoTm9RdWVyeUhhc2gocGF0aCk7XG4gICAgICAgIGNvbnN0IHBhdGhMb3dlciA9IHBhdGhuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGNvbnN0IGxvY2FsZUxvd2VyID0gbG9jYWxlICYmIGxvY2FsZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICByZXR1cm4gbG9jYWxlICYmIChwYXRoTG93ZXIuc3RhcnRzV2l0aCgnLycgKyBsb2NhbGVMb3dlciArICcvJykgfHwgcGF0aExvd2VyID09PSAnLycgKyBsb2NhbGVMb3dlcikgPyAocGF0aG5hbWUubGVuZ3RoID09PSBsb2NhbGUubGVuZ3RoICsgMSA/ICcvJyA6ICcnKSArIHBhdGguc3Vic3RyKGxvY2FsZS5sZW5ndGggKyAxKSA6IHBhdGg7XG4gICAgfVxuICAgIHJldHVybiBwYXRoO1xufVxuZnVuY3Rpb24gcGF0aE5vUXVlcnlIYXNoKHBhdGgpIHtcbiAgICBjb25zdCBxdWVyeUluZGV4ID0gcGF0aC5pbmRleE9mKCc/Jyk7XG4gICAgY29uc3QgaGFzaEluZGV4ID0gcGF0aC5pbmRleE9mKCcjJyk7XG4gICAgaWYgKHF1ZXJ5SW5kZXggPiAtMSB8fCBoYXNoSW5kZXggPiAtMSkge1xuICAgICAgICBwYXRoID0gcGF0aC5zdWJzdHJpbmcoMCwgcXVlcnlJbmRleCA+IC0xID8gcXVlcnlJbmRleCA6IGhhc2hJbmRleCk7XG4gICAgfVxuICAgIHJldHVybiBwYXRoO1xufVxuZnVuY3Rpb24gaGFzQmFzZVBhdGgocGF0aCkge1xuICAgIHBhdGggPSBwYXRoTm9RdWVyeUhhc2gocGF0aCk7XG4gICAgcmV0dXJuIHBhdGggPT09IGJhc2VQYXRoIHx8IHBhdGguc3RhcnRzV2l0aChiYXNlUGF0aCArICcvJyk7XG59XG5mdW5jdGlvbiBhZGRCYXNlUGF0aChwYXRoKSB7XG4gICAgLy8gd2Ugb25seSBhZGQgdGhlIGJhc2VwYXRoIG9uIHJlbGF0aXZlIHVybHNcbiAgICByZXR1cm4gYWRkUGF0aFByZWZpeChwYXRoLCBiYXNlUGF0aCk7XG59XG5mdW5jdGlvbiBkZWxCYXNlUGF0aChwYXRoKSB7XG4gICAgcGF0aCA9IHBhdGguc2xpY2UoYmFzZVBhdGgubGVuZ3RoKTtcbiAgICBpZiAoIXBhdGguc3RhcnRzV2l0aCgnLycpKSBwYXRoID0gYC8ke3BhdGh9YDtcbiAgICByZXR1cm4gcGF0aDtcbn1cbmZ1bmN0aW9uIGlzTG9jYWxVUkwodXJsKSB7XG4gICAgLy8gcHJldmVudCBhIGh5ZHJhdGlvbiBtaXNtYXRjaCBvbiBocmVmIGZvciB1cmwgd2l0aCBhbmNob3IgcmVmc1xuICAgIGlmICh1cmwuc3RhcnRzV2l0aCgnLycpIHx8IHVybC5zdGFydHNXaXRoKCcjJykgfHwgdXJsLnN0YXJ0c1dpdGgoJz8nKSkgcmV0dXJuIHRydWU7XG4gICAgdHJ5IHtcbiAgICAgICAgLy8gYWJzb2x1dGUgdXJscyBjYW4gYmUgbG9jYWwgaWYgdGhleSBhcmUgb24gdGhlIHNhbWUgb3JpZ2luXG4gICAgICAgIGNvbnN0IGxvY2F0aW9uT3JpZ2luID0gKDAsIF91dGlscykuZ2V0TG9jYXRpb25PcmlnaW4oKTtcbiAgICAgICAgY29uc3QgcmVzb2x2ZWQgPSBuZXcgVVJMKHVybCwgbG9jYXRpb25PcmlnaW4pO1xuICAgICAgICByZXR1cm4gcmVzb2x2ZWQub3JpZ2luID09PSBsb2NhdGlvbk9yaWdpbiAmJiBoYXNCYXNlUGF0aChyZXNvbHZlZC5wYXRobmFtZSk7XG4gICAgfSBjYXRjaCAoXykge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuZnVuY3Rpb24gaW50ZXJwb2xhdGVBcyhyb3V0ZSwgYXNQYXRobmFtZSwgcXVlcnkpIHtcbiAgICBsZXQgaW50ZXJwb2xhdGVkUm91dGUgPSAnJztcbiAgICBjb25zdCBkeW5hbWljUmVnZXggPSAoMCwgX3JvdXRlUmVnZXgpLmdldFJvdXRlUmVnZXgocm91dGUpO1xuICAgIGNvbnN0IGR5bmFtaWNHcm91cHMgPSBkeW5hbWljUmVnZXguZ3JvdXBzO1xuICAgIGNvbnN0IGR5bmFtaWNNYXRjaGVzID0gLy8gVHJ5IHRvIG1hdGNoIHRoZSBkeW5hbWljIHJvdXRlIGFnYWluc3QgdGhlIGFzUGF0aFxuICAgIChhc1BhdGhuYW1lICE9PSByb3V0ZSA/ICgwLCBfcm91dGVNYXRjaGVyKS5nZXRSb3V0ZU1hdGNoZXIoZHluYW1pY1JlZ2V4KShhc1BhdGhuYW1lKSA6ICcnKSB8fCAvLyBGYWxsIGJhY2sgdG8gcmVhZGluZyB0aGUgdmFsdWVzIGZyb20gdGhlIGhyZWZcbiAgICAvLyBUT0RPOiBzaG91bGQgdGhpcyB0YWtlIHByaW9yaXR5OyBhbHNvIG5lZWQgdG8gY2hhbmdlIGluIHRoZSByb3V0ZXIuXG4gICAgcXVlcnk7XG4gICAgaW50ZXJwb2xhdGVkUm91dGUgPSByb3V0ZTtcbiAgICBjb25zdCBwYXJhbXMgPSBPYmplY3Qua2V5cyhkeW5hbWljR3JvdXBzKTtcbiAgICBpZiAoIXBhcmFtcy5ldmVyeSgocGFyYW0pPT57XG4gICAgICAgIGxldCB2YWx1ZSA9IGR5bmFtaWNNYXRjaGVzW3BhcmFtXSB8fCAnJztcbiAgICAgICAgY29uc3QgeyByZXBlYXQgLCBvcHRpb25hbCAgfSA9IGR5bmFtaWNHcm91cHNbcGFyYW1dO1xuICAgICAgICAvLyBzdXBwb3J0IHNpbmdsZS1sZXZlbCBjYXRjaC1hbGxcbiAgICAgICAgLy8gVE9ETzogbW9yZSByb2J1c3QgaGFuZGxpbmcgZm9yIHVzZXItZXJyb3IgKHBhc3NpbmcgYC9gKVxuICAgICAgICBsZXQgcmVwbGFjZWQgPSBgWyR7cmVwZWF0ID8gJy4uLicgOiAnJ30ke3BhcmFtfV1gO1xuICAgICAgICBpZiAob3B0aW9uYWwpIHtcbiAgICAgICAgICAgIHJlcGxhY2VkID0gYCR7IXZhbHVlID8gJy8nIDogJyd9WyR7cmVwbGFjZWR9XWA7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlcGVhdCAmJiAhQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHZhbHVlID0gW1xuICAgICAgICAgICAgdmFsdWVcbiAgICAgICAgXTtcbiAgICAgICAgcmV0dXJuIChvcHRpb25hbCB8fCBwYXJhbSBpbiBkeW5hbWljTWF0Y2hlcykgJiYgLy8gSW50ZXJwb2xhdGUgZ3JvdXAgaW50byBkYXRhIFVSTCBpZiBwcmVzZW50XG4gICAgICAgIChpbnRlcnBvbGF0ZWRSb3V0ZSA9IGludGVycG9sYXRlZFJvdXRlLnJlcGxhY2UocmVwbGFjZWQsIHJlcGVhdCA/IHZhbHVlLm1hcCgvLyB0aGVzZSB2YWx1ZXMgc2hvdWxkIGJlIGZ1bGx5IGVuY29kZWQgaW5zdGVhZCBvZiBqdXN0XG4gICAgICAgIC8vIHBhdGggZGVsaW1pdGVyIGVzY2FwZWQgc2luY2UgdGhleSBhcmUgYmVpbmcgaW5zZXJ0ZWRcbiAgICAgICAgLy8gaW50byB0aGUgVVJMIGFuZCB3ZSBleHBlY3QgVVJMIGVuY29kZWQgc2VnbWVudHNcbiAgICAgICAgLy8gd2hlbiBwYXJzaW5nIGR5bmFtaWMgcm91dGUgcGFyYW1zXG4gICAgICAgIChzZWdtZW50KT0+ZW5jb2RlVVJJQ29tcG9uZW50KHNlZ21lbnQpXG4gICAgICAgICkuam9pbignLycpIDogZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKSkgfHwgJy8nKTtcbiAgICB9KSkge1xuICAgICAgICBpbnRlcnBvbGF0ZWRSb3V0ZSA9ICcnIC8vIGRpZCBub3Qgc2F0aXNmeSBhbGwgcmVxdWlyZW1lbnRzXG4gICAgICAgIDtcbiAgICAvLyBuLmIuIFdlIGlnbm9yZSB0aGlzIGVycm9yIGJlY2F1c2Ugd2UgaGFuZGxlIHdhcm5pbmcgZm9yIHRoaXMgY2FzZSBpblxuICAgIC8vIGRldmVsb3BtZW50IGluIHRoZSBgPExpbms+YCBjb21wb25lbnQgZGlyZWN0bHkuXG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIHBhcmFtcyxcbiAgICAgICAgcmVzdWx0OiBpbnRlcnBvbGF0ZWRSb3V0ZVxuICAgIH07XG59XG5mdW5jdGlvbiBvbWl0UGFybXNGcm9tUXVlcnkocXVlcnksIHBhcmFtcykge1xuICAgIGNvbnN0IGZpbHRlcmVkUXVlcnkgPSB7XG4gICAgfTtcbiAgICBPYmplY3Qua2V5cyhxdWVyeSkuZm9yRWFjaCgoa2V5KT0+e1xuICAgICAgICBpZiAoIXBhcmFtcy5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICAgICAgICBmaWx0ZXJlZFF1ZXJ5W2tleV0gPSBxdWVyeVtrZXldO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGZpbHRlcmVkUXVlcnk7XG59XG5mdW5jdGlvbiByZXNvbHZlSHJlZihyb3V0ZXIsIGhyZWYsIHJlc29sdmVBcykge1xuICAgIC8vIHdlIHVzZSBhIGR1bW15IGJhc2UgdXJsIGZvciByZWxhdGl2ZSB1cmxzXG4gICAgbGV0IGJhc2U7XG4gICAgbGV0IHVybEFzU3RyaW5nID0gdHlwZW9mIGhyZWYgPT09ICdzdHJpbmcnID8gaHJlZiA6ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKGhyZWYpO1xuICAgIC8vIHJlcGVhdGVkIHNsYXNoZXMgYW5kIGJhY2tzbGFzaGVzIGluIHRoZSBVUkwgYXJlIGNvbnNpZGVyZWRcbiAgICAvLyBpbnZhbGlkIGFuZCB3aWxsIG5ldmVyIG1hdGNoIGEgTmV4dC5qcyBwYWdlL2ZpbGVcbiAgICBjb25zdCB1cmxQcm90b01hdGNoID0gdXJsQXNTdHJpbmcubWF0Y2goL15bYS16QS1aXXsxLH06XFwvXFwvLyk7XG4gICAgY29uc3QgdXJsQXNTdHJpbmdOb1Byb3RvID0gdXJsUHJvdG9NYXRjaCA/IHVybEFzU3RyaW5nLnN1YnN0cih1cmxQcm90b01hdGNoWzBdLmxlbmd0aCkgOiB1cmxBc1N0cmluZztcbiAgICBjb25zdCB1cmxQYXJ0cyA9IHVybEFzU3RyaW5nTm9Qcm90by5zcGxpdCgnPycpO1xuICAgIGlmICgodXJsUGFydHNbMF0gfHwgJycpLm1hdGNoKC8oXFwvXFwvfFxcXFwpLykpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgSW52YWxpZCBocmVmIHBhc3NlZCB0byBuZXh0L3JvdXRlcjogJHt1cmxBc1N0cmluZ30sIHJlcGVhdGVkIGZvcndhcmQtc2xhc2hlcyAoLy8pIG9yIGJhY2tzbGFzaGVzIFxcXFwgYXJlIG5vdCB2YWxpZCBpbiB0aGUgaHJlZmApO1xuICAgICAgICBjb25zdCBub3JtYWxpemVkVXJsID0gKDAsIF91dGlscykubm9ybWFsaXplUmVwZWF0ZWRTbGFzaGVzKHVybEFzU3RyaW5nTm9Qcm90byk7XG4gICAgICAgIHVybEFzU3RyaW5nID0gKHVybFByb3RvTWF0Y2ggPyB1cmxQcm90b01hdGNoWzBdIDogJycpICsgbm9ybWFsaXplZFVybDtcbiAgICB9XG4gICAgLy8gUmV0dXJuIGJlY2F1c2UgaXQgY2Fubm90IGJlIHJvdXRlZCBieSB0aGUgTmV4dC5qcyByb3V0ZXJcbiAgICBpZiAoIWlzTG9jYWxVUkwodXJsQXNTdHJpbmcpKSB7XG4gICAgICAgIHJldHVybiByZXNvbHZlQXMgPyBbXG4gICAgICAgICAgICB1cmxBc1N0cmluZ1xuICAgICAgICBdIDogdXJsQXNTdHJpbmc7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIGJhc2UgPSBuZXcgVVJMKHVybEFzU3RyaW5nLnN0YXJ0c1dpdGgoJyMnKSA/IHJvdXRlci5hc1BhdGggOiByb3V0ZXIucGF0aG5hbWUsICdodHRwOi8vbicpO1xuICAgIH0gY2F0Y2ggKF8pIHtcbiAgICAgICAgLy8gZmFsbGJhY2sgdG8gLyBmb3IgaW52YWxpZCBhc1BhdGggdmFsdWVzIGUuZy4gLy9cbiAgICAgICAgYmFzZSA9IG5ldyBVUkwoJy8nLCAnaHR0cDovL24nKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZmluYWxVcmwgPSBuZXcgVVJMKHVybEFzU3RyaW5nLCBiYXNlKTtcbiAgICAgICAgZmluYWxVcmwucGF0aG5hbWUgPSAoMCwgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gpLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoKGZpbmFsVXJsLnBhdGhuYW1lKTtcbiAgICAgICAgbGV0IGludGVycG9sYXRlZEFzID0gJyc7XG4gICAgICAgIGlmICgoMCwgX2lzRHluYW1pYykuaXNEeW5hbWljUm91dGUoZmluYWxVcmwucGF0aG5hbWUpICYmIGZpbmFsVXJsLnNlYXJjaFBhcmFtcyAmJiByZXNvbHZlQXMpIHtcbiAgICAgICAgICAgIGNvbnN0IHF1ZXJ5ID0gKDAsIF9xdWVyeXN0cmluZykuc2VhcmNoUGFyYW1zVG9VcmxRdWVyeShmaW5hbFVybC5zZWFyY2hQYXJhbXMpO1xuICAgICAgICAgICAgY29uc3QgeyByZXN1bHQgLCBwYXJhbXMgIH0gPSBpbnRlcnBvbGF0ZUFzKGZpbmFsVXJsLnBhdGhuYW1lLCBmaW5hbFVybC5wYXRobmFtZSwgcXVlcnkpO1xuICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgIGludGVycG9sYXRlZEFzID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTogcmVzdWx0LFxuICAgICAgICAgICAgICAgICAgICBoYXNoOiBmaW5hbFVybC5oYXNoLFxuICAgICAgICAgICAgICAgICAgICBxdWVyeTogb21pdFBhcm1zRnJvbVF1ZXJ5KHF1ZXJ5LCBwYXJhbXMpXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gaWYgdGhlIG9yaWdpbiBkaWRuJ3QgY2hhbmdlLCBpdCBtZWFucyB3ZSByZWNlaXZlZCBhIHJlbGF0aXZlIGhyZWZcbiAgICAgICAgY29uc3QgcmVzb2x2ZWRIcmVmID0gZmluYWxVcmwub3JpZ2luID09PSBiYXNlLm9yaWdpbiA/IGZpbmFsVXJsLmhyZWYuc2xpY2UoZmluYWxVcmwub3JpZ2luLmxlbmd0aCkgOiBmaW5hbFVybC5ocmVmO1xuICAgICAgICByZXR1cm4gcmVzb2x2ZUFzID8gW1xuICAgICAgICAgICAgcmVzb2x2ZWRIcmVmLFxuICAgICAgICAgICAgaW50ZXJwb2xhdGVkQXMgfHwgcmVzb2x2ZWRIcmVmXG4gICAgICAgIF0gOiByZXNvbHZlZEhyZWY7XG4gICAgfSBjYXRjaCAoXykge1xuICAgICAgICByZXR1cm4gcmVzb2x2ZUFzID8gW1xuICAgICAgICAgICAgdXJsQXNTdHJpbmdcbiAgICAgICAgXSA6IHVybEFzU3RyaW5nO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHN0cmlwT3JpZ2luKHVybCkge1xuICAgIGNvbnN0IG9yaWdpbiA9ICgwLCBfdXRpbHMpLmdldExvY2F0aW9uT3JpZ2luKCk7XG4gICAgcmV0dXJuIHVybC5zdGFydHNXaXRoKG9yaWdpbikgPyB1cmwuc3Vic3RyaW5nKG9yaWdpbi5sZW5ndGgpIDogdXJsO1xufVxuZnVuY3Rpb24gcHJlcGFyZVVybEFzKHJvdXRlciwgdXJsLCBhcykge1xuICAgIC8vIElmIHVybCBhbmQgYXMgcHJvdmlkZWQgYXMgYW4gb2JqZWN0IHJlcHJlc2VudGF0aW9uLFxuICAgIC8vIHdlJ2xsIGZvcm1hdCB0aGVtIGludG8gdGhlIHN0cmluZyB2ZXJzaW9uIGhlcmUuXG4gICAgbGV0IFtyZXNvbHZlZEhyZWYsIHJlc29sdmVkQXNdID0gcmVzb2x2ZUhyZWYocm91dGVyLCB1cmwsIHRydWUpO1xuICAgIGNvbnN0IG9yaWdpbiA9ICgwLCBfdXRpbHMpLmdldExvY2F0aW9uT3JpZ2luKCk7XG4gICAgY29uc3QgaHJlZkhhZE9yaWdpbiA9IHJlc29sdmVkSHJlZi5zdGFydHNXaXRoKG9yaWdpbik7XG4gICAgY29uc3QgYXNIYWRPcmlnaW4gPSByZXNvbHZlZEFzICYmIHJlc29sdmVkQXMuc3RhcnRzV2l0aChvcmlnaW4pO1xuICAgIHJlc29sdmVkSHJlZiA9IHN0cmlwT3JpZ2luKHJlc29sdmVkSHJlZik7XG4gICAgcmVzb2x2ZWRBcyA9IHJlc29sdmVkQXMgPyBzdHJpcE9yaWdpbihyZXNvbHZlZEFzKSA6IHJlc29sdmVkQXM7XG4gICAgY29uc3QgcHJlcGFyZWRVcmwgPSBocmVmSGFkT3JpZ2luID8gcmVzb2x2ZWRIcmVmIDogYWRkQmFzZVBhdGgocmVzb2x2ZWRIcmVmKTtcbiAgICBjb25zdCBwcmVwYXJlZEFzID0gYXMgPyBzdHJpcE9yaWdpbihyZXNvbHZlSHJlZihyb3V0ZXIsIGFzKSkgOiByZXNvbHZlZEFzIHx8IHJlc29sdmVkSHJlZjtcbiAgICByZXR1cm4ge1xuICAgICAgICB1cmw6IHByZXBhcmVkVXJsLFxuICAgICAgICBhczogYXNIYWRPcmlnaW4gPyBwcmVwYXJlZEFzIDogYWRkQmFzZVBhdGgocHJlcGFyZWRBcylcbiAgICB9O1xufVxuZnVuY3Rpb24gcmVzb2x2ZUR5bmFtaWNSb3V0ZShwYXRobmFtZSwgcGFnZXMpIHtcbiAgICBjb25zdCBjbGVhblBhdGhuYW1lID0gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCgoMCwgX2Rlbm9ybWFsaXplUGFnZVBhdGgpLmRlbm9ybWFsaXplUGFnZVBhdGgocGF0aG5hbWUpKTtcbiAgICBpZiAoY2xlYW5QYXRobmFtZSA9PT0gJy80MDQnIHx8IGNsZWFuUGF0aG5hbWUgPT09ICcvX2Vycm9yJykge1xuICAgICAgICByZXR1cm4gcGF0aG5hbWU7XG4gICAgfVxuICAgIC8vIGhhbmRsZSByZXNvbHZpbmcgaHJlZiBmb3IgZHluYW1pYyByb3V0ZXNcbiAgICBpZiAoIXBhZ2VzLmluY2x1ZGVzKGNsZWFuUGF0aG5hbWUpKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBhcnJheS1jYWxsYmFjay1yZXR1cm5cbiAgICAgICAgcGFnZXMuc29tZSgocGFnZSk9PntcbiAgICAgICAgICAgIGlmICgoMCwgX2lzRHluYW1pYykuaXNEeW5hbWljUm91dGUocGFnZSkgJiYgKDAsIF9yb3V0ZVJlZ2V4KS5nZXRSb3V0ZVJlZ2V4KHBhZ2UpLnJlLnRlc3QoY2xlYW5QYXRobmFtZSkpIHtcbiAgICAgICAgICAgICAgICBwYXRobmFtZSA9IHBhZ2U7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZSk7XG59XG5jb25zdCBtYW51YWxTY3JvbGxSZXN0b3JhdGlvbiA9IHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04gJiYgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgJ3Njcm9sbFJlc3RvcmF0aW9uJyBpbiB3aW5kb3cuaGlzdG9yeSAmJiAhIWZ1bmN0aW9uKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGxldCB2ID0gJ19fbmV4dCc7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1zZXF1ZW5jZXNcbiAgICAgICAgcmV0dXJuIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0odiwgdiksIHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0odiksIHRydWU7XG4gICAgfSBjYXRjaCAobikge1xuICAgIH1cbn0oKTtcbmNvbnN0IFNTR19EQVRBX05PVF9GT1VORCA9IFN5bWJvbCgnU1NHX0RBVEFfTk9UX0ZPVU5EJyk7XG5mdW5jdGlvbiBmZXRjaFJldHJ5KHVybCwgYXR0ZW1wdHMpIHtcbiAgICByZXR1cm4gZmV0Y2godXJsLCB7XG4gICAgICAgIC8vIENvb2tpZXMgYXJlIHJlcXVpcmVkIHRvIGJlIHByZXNlbnQgZm9yIE5leHQuanMnIFNTRyBcIlByZXZpZXcgTW9kZVwiLlxuICAgICAgICAvLyBDb29raWVzIG1heSBhbHNvIGJlIHJlcXVpcmVkIGZvciBgZ2V0U2VydmVyU2lkZVByb3BzYC5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gPiBgZmV0Y2hgIHdvbuKAmXQgc2VuZCBjb29raWVzLCB1bmxlc3MgeW91IHNldCB0aGUgY3JlZGVudGlhbHMgaW5pdFxuICAgICAgICAvLyA+IG9wdGlvbi5cbiAgICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0ZldGNoX0FQSS9Vc2luZ19GZXRjaFxuICAgICAgICAvL1xuICAgICAgICAvLyA+IEZvciBtYXhpbXVtIGJyb3dzZXIgY29tcGF0aWJpbGl0eSB3aGVuIGl0IGNvbWVzIHRvIHNlbmRpbmcgJlxuICAgICAgICAvLyA+IHJlY2VpdmluZyBjb29raWVzLCBhbHdheXMgc3VwcGx5IHRoZSBgY3JlZGVudGlhbHM6ICdzYW1lLW9yaWdpbidgXG4gICAgICAgIC8vID4gb3B0aW9uIGluc3RlYWQgb2YgcmVseWluZyBvbiB0aGUgZGVmYXVsdC5cbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2dpdGh1Yi9mZXRjaCNjYXZlYXRzXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnc2FtZS1vcmlnaW4nXG4gICAgfSkudGhlbigocmVzKT0+e1xuICAgICAgICBpZiAoIXJlcy5vaykge1xuICAgICAgICAgICAgaWYgKGF0dGVtcHRzID4gMSAmJiByZXMuc3RhdHVzID49IDUwMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmZXRjaFJldHJ5KHVybCwgYXR0ZW1wdHMgLSAxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzLmpzb24oKS50aGVuKChkYXRhKT0+e1xuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YS5ub3RGb3VuZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBub3RGb3VuZDogU1NHX0RBVEFfTk9UX0ZPVU5EXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc3RhdGljIHByb3BzYCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBsb2FkIHN0YXRpYyBwcm9wc2ApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXMuanNvbigpO1xuICAgIH0pO1xufVxuZnVuY3Rpb24gZmV0Y2hOZXh0RGF0YShkYXRhSHJlZiwgaXNTZXJ2ZXJSZW5kZXIpIHtcbiAgICByZXR1cm4gZmV0Y2hSZXRyeShkYXRhSHJlZiwgaXNTZXJ2ZXJSZW5kZXIgPyAzIDogMSkuY2F0Y2goKGVycik9PntcbiAgICAgICAgLy8gV2Ugc2hvdWxkIG9ubHkgdHJpZ2dlciBhIHNlcnZlci1zaWRlIHRyYW5zaXRpb24gaWYgdGhpcyB3YXMgY2F1c2VkXG4gICAgICAgIC8vIG9uIGEgY2xpZW50LXNpZGUgdHJhbnNpdGlvbi4gT3RoZXJ3aXNlLCB3ZSdkIGdldCBpbnRvIGFuIGluZmluaXRlXG4gICAgICAgIC8vIGxvb3AuXG4gICAgICAgIGlmICghaXNTZXJ2ZXJSZW5kZXIpIHtcbiAgICAgICAgICAgICgwLCBfcm91dGVMb2FkZXIpLm1hcmtBc3NldEVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgZXJyO1xuICAgIH0pO1xufVxuY2xhc3MgUm91dGVyIHtcbiAgICBjb25zdHJ1Y3RvcihwYXRobmFtZTEsIHF1ZXJ5MSwgYXMxLCB7IGluaXRpYWxQcm9wcyAsIHBhZ2VMb2FkZXIgLCBBcHAgLCB3cmFwQXBwICwgQ29tcG9uZW50OiBDb21wb25lbnQxICwgZXJyOiBlcnIxICwgc3Vic2NyaXB0aW9uICwgaXNGYWxsYmFjayAsIGxvY2FsZSAsIGxvY2FsZXMgLCBkZWZhdWx0TG9jYWxlICwgZG9tYWluTG9jYWxlcyAsIGlzUHJldmlldyAgfSl7XG4gICAgICAgIC8vIFN0YXRpYyBEYXRhIENhY2hlXG4gICAgICAgIHRoaXMuc2RjID0ge1xuICAgICAgICB9O1xuICAgICAgICAvLyBJbi1mbGlnaHQgU2VydmVyIERhdGEgUmVxdWVzdHMsIGZvciBkZWR1cGluZ1xuICAgICAgICB0aGlzLnNkciA9IHtcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5faWR4ID0gMDtcbiAgICAgICAgdGhpcy5vblBvcFN0YXRlID0gKGUpPT57XG4gICAgICAgICAgICBjb25zdCBzdGF0ZSA9IGUuc3RhdGU7XG4gICAgICAgICAgICBpZiAoIXN0YXRlKSB7XG4gICAgICAgICAgICAgICAgLy8gV2UgZ2V0IHN0YXRlIGFzIHVuZGVmaW5lZCBmb3IgdHdvIHJlYXNvbnMuXG4gICAgICAgICAgICAgICAgLy8gIDEuIFdpdGggb2xkZXIgc2FmYXJpICg8IDgpIGFuZCBvbGRlciBjaHJvbWUgKDwgMzQpXG4gICAgICAgICAgICAgICAgLy8gIDIuIFdoZW4gdGhlIFVSTCBjaGFuZ2VkIHdpdGggI1xuICAgICAgICAgICAgICAgIC8vXG4gICAgICAgICAgICAgICAgLy8gSW4gdGhlIGJvdGggY2FzZXMsIHdlIGRvbid0IG5lZWQgdG8gcHJvY2VlZCBhbmQgY2hhbmdlIHRoZSByb3V0ZS5cbiAgICAgICAgICAgICAgICAvLyAoYXMgaXQncyBhbHJlYWR5IGNoYW5nZWQpXG4gICAgICAgICAgICAgICAgLy8gQnV0IHdlIGNhbiBzaW1wbHkgcmVwbGFjZSB0aGUgc3RhdGUgd2l0aCB0aGUgbmV3IGNoYW5nZXMuXG4gICAgICAgICAgICAgICAgLy8gQWN0dWFsbHksIGZvciAoMSkgd2UgZG9uJ3QgbmVlZCB0byBub3RoaW5nLiBCdXQgaXQncyBoYXJkIHRvIGRldGVjdCB0aGF0IGV2ZW50LlxuICAgICAgICAgICAgICAgIC8vIFNvLCBkb2luZyB0aGUgZm9sbG93aW5nIGZvciAoMSkgZG9lcyBubyBoYXJtLlxuICAgICAgICAgICAgICAgIGNvbnN0IHsgcGF0aG5hbWU6IHBhdGhuYW1lMSAsIHF1ZXJ5OiBxdWVyeTEgIH0gPSB0aGlzO1xuICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlU3RhdGUoJ3JlcGxhY2VTdGF0ZScsICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aG5hbWU6IGFkZEJhc2VQYXRoKHBhdGhuYW1lMSksXG4gICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiBxdWVyeTFcbiAgICAgICAgICAgICAgICB9KSwgKDAsIF91dGlscykuZ2V0VVJMKCkpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghc3RhdGUuX19OKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IGZvcmNlZFNjcm9sbDtcbiAgICAgICAgICAgIGNvbnN0IHsgdXJsICwgYXM6IGFzMSAsIG9wdGlvbnMgLCBpZHggIH0gPSBzdGF0ZTtcbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OKSB7XG4gICAgICAgICAgICAgICAgaWYgKG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pZHggIT09IGlkeCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gU25hcHNob3QgY3VycmVudCBzY3JvbGwgcG9zaXRpb246XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ19fbmV4dF9zY3JvbGxfJyArIHRoaXMuX2lkeCwgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB4OiBzZWxmLnBhZ2VYT2Zmc2V0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB5OiBzZWxmLnBhZ2VZT2Zmc2V0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAge1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVzdG9yZSBvbGQgc2Nyb2xsIHBvc2l0aW9uOlxuICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2ID0gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSgnX19uZXh0X3Njcm9sbF8nICsgaWR4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JjZWRTY3JvbGwgPSBKU09OLnBhcnNlKHYpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcmNlZFNjcm9sbCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeDogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeTogMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl9pZHggPSBpZHg7XG4gICAgICAgICAgICBjb25zdCB7IHBhdGhuYW1lOiBwYXRobmFtZTEgIH0gPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwodXJsKTtcbiAgICAgICAgICAgIC8vIE1ha2Ugc3VyZSB3ZSBkb24ndCByZS1yZW5kZXIgb24gaW5pdGlhbCBsb2FkLFxuICAgICAgICAgICAgLy8gY2FuIGJlIGNhdXNlZCBieSBuYXZpZ2F0aW5nIGJhY2sgZnJvbSBhbiBleHRlcm5hbCBzaXRlXG4gICAgICAgICAgICBpZiAodGhpcy5pc1NzciAmJiBhczEgPT09IHRoaXMuYXNQYXRoICYmIHBhdGhuYW1lMSA9PT0gdGhpcy5wYXRobmFtZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIElmIHRoZSBkb3duc3RyZWFtIGFwcGxpY2F0aW9uIHJldHVybnMgZmFsc3ksIHJldHVybi5cbiAgICAgICAgICAgIC8vIFRoZXkgd2lsbCB0aGVuIGJlIHJlc3BvbnNpYmxlIGZvciBoYW5kbGluZyB0aGUgZXZlbnQuXG4gICAgICAgICAgICBpZiAodGhpcy5fYnBzICYmICF0aGlzLl9icHMoc3RhdGUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5jaGFuZ2UoJ3JlcGxhY2VTdGF0ZScsIHVybCwgYXMxLCBPYmplY3QuYXNzaWduKHtcbiAgICAgICAgICAgIH0sIG9wdGlvbnMsIHtcbiAgICAgICAgICAgICAgICBzaGFsbG93OiBvcHRpb25zLnNoYWxsb3cgJiYgdGhpcy5fc2hhbGxvdyxcbiAgICAgICAgICAgICAgICBsb2NhbGU6IG9wdGlvbnMubG9jYWxlIHx8IHRoaXMuZGVmYXVsdExvY2FsZVxuICAgICAgICAgICAgfSksIGZvcmNlZFNjcm9sbCk7XG4gICAgICAgIH07XG4gICAgICAgIC8vIHJlcHJlc2VudHMgdGhlIGN1cnJlbnQgY29tcG9uZW50IGtleVxuICAgICAgICB0aGlzLnJvdXRlID0gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZTEpO1xuICAgICAgICAvLyBzZXQgdXAgdGhlIGNvbXBvbmVudCBjYWNoZSAoYnkgcm91dGUga2V5cylcbiAgICAgICAgdGhpcy5jb21wb25lbnRzID0ge1xuICAgICAgICB9O1xuICAgICAgICAvLyBXZSBzaG91bGQgbm90IGtlZXAgdGhlIGNhY2hlLCBpZiB0aGVyZSdzIGFuIGVycm9yXG4gICAgICAgIC8vIE90aGVyd2lzZSwgdGhpcyBjYXVzZSBpc3N1ZXMgd2hlbiB3aGVuIGdvaW5nIGJhY2sgYW5kXG4gICAgICAgIC8vIGNvbWUgYWdhaW4gdG8gdGhlIGVycm9yZWQgcGFnZS5cbiAgICAgICAgaWYgKHBhdGhuYW1lMSAhPT0gJy9fZXJyb3InKSB7XG4gICAgICAgICAgICB0aGlzLmNvbXBvbmVudHNbdGhpcy5yb3V0ZV0gPSB7XG4gICAgICAgICAgICAgICAgQ29tcG9uZW50OiBDb21wb25lbnQxLFxuICAgICAgICAgICAgICAgIGluaXRpYWw6IHRydWUsXG4gICAgICAgICAgICAgICAgcHJvcHM6IGluaXRpYWxQcm9wcyxcbiAgICAgICAgICAgICAgICBlcnI6IGVycjEsXG4gICAgICAgICAgICAgICAgX19OX1NTRzogaW5pdGlhbFByb3BzICYmIGluaXRpYWxQcm9wcy5fX05fU1NHLFxuICAgICAgICAgICAgICAgIF9fTl9TU1A6IGluaXRpYWxQcm9wcyAmJiBpbml0aWFsUHJvcHMuX19OX1NTUFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNvbXBvbmVudHNbJy9fYXBwJ10gPSB7XG4gICAgICAgICAgICBDb21wb25lbnQ6IEFwcCxcbiAgICAgICAgICAgIHN0eWxlU2hlZXRzOiBbXVxuICAgICAgICB9O1xuICAgICAgICAvLyBCYWNrd2FyZHMgY29tcGF0IGZvciBSb3V0ZXIucm91dGVyLmV2ZW50c1xuICAgICAgICAvLyBUT0RPOiBTaG91bGQgYmUgcmVtb3ZlIHRoZSBmb2xsb3dpbmcgbWFqb3IgdmVyc2lvbiBhcyBpdCB3YXMgbmV2ZXIgZG9jdW1lbnRlZFxuICAgICAgICB0aGlzLmV2ZW50cyA9IFJvdXRlci5ldmVudHM7XG4gICAgICAgIHRoaXMucGFnZUxvYWRlciA9IHBhZ2VMb2FkZXI7XG4gICAgICAgIHRoaXMucGF0aG5hbWUgPSBwYXRobmFtZTE7XG4gICAgICAgIHRoaXMucXVlcnkgPSBxdWVyeTE7XG4gICAgICAgIC8vIGlmIGF1dG8gcHJlcmVuZGVyZWQgYW5kIGR5bmFtaWMgcm91dGUgd2FpdCB0byB1cGRhdGUgYXNQYXRoXG4gICAgICAgIC8vIHVudGlsIGFmdGVyIG1vdW50IHRvIHByZXZlbnQgaHlkcmF0aW9uIG1pc21hdGNoXG4gICAgICAgIGNvbnN0IGF1dG9FeHBvcnREeW5hbWljID0gKDAsIF9pc0R5bmFtaWMpLmlzRHluYW1pY1JvdXRlKHBhdGhuYW1lMSkgJiYgc2VsZi5fX05FWFRfREFUQV9fLmF1dG9FeHBvcnQ7XG4gICAgICAgIHRoaXMuYXNQYXRoID0gYXV0b0V4cG9ydER5bmFtaWMgPyBwYXRobmFtZTEgOiBhczE7XG4gICAgICAgIHRoaXMuYmFzZVBhdGggPSBiYXNlUGF0aDtcbiAgICAgICAgdGhpcy5zdWIgPSBzdWJzY3JpcHRpb247XG4gICAgICAgIHRoaXMuY2xjID0gbnVsbDtcbiAgICAgICAgdGhpcy5fd3JhcEFwcCA9IHdyYXBBcHA7XG4gICAgICAgIC8vIG1ha2Ugc3VyZSB0byBpZ25vcmUgZXh0cmEgcG9wU3RhdGUgaW4gc2FmYXJpIG9uIG5hdmlnYXRpbmdcbiAgICAgICAgLy8gYmFjayBmcm9tIGV4dGVybmFsIHNpdGVcbiAgICAgICAgdGhpcy5pc1NzciA9IHRydWU7XG4gICAgICAgIHRoaXMuaXNGYWxsYmFjayA9IGlzRmFsbGJhY2s7XG4gICAgICAgIHRoaXMuaXNSZWFkeSA9ICEhKHNlbGYuX19ORVhUX0RBVEFfXy5nc3NwIHx8IHNlbGYuX19ORVhUX0RBVEFfXy5naXAgfHwgc2VsZi5fX05FWFRfREFUQV9fLmFwcEdpcCAmJiAhc2VsZi5fX05FWFRfREFUQV9fLmdzcCB8fCAhYXV0b0V4cG9ydER5bmFtaWMgJiYgIXNlbGYubG9jYXRpb24uc2VhcmNoICYmICFwcm9jZXNzLmVudi5fX05FWFRfSEFTX1JFV1JJVEVTKTtcbiAgICAgICAgdGhpcy5pc1ByZXZpZXcgPSAhIWlzUHJldmlldztcbiAgICAgICAgdGhpcy5pc0xvY2FsZURvbWFpbiA9IGZhbHNlO1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICAgICAgdGhpcy5sb2NhbGUgPSBsb2NhbGU7XG4gICAgICAgICAgICB0aGlzLmxvY2FsZXMgPSBsb2NhbGVzO1xuICAgICAgICAgICAgdGhpcy5kZWZhdWx0TG9jYWxlID0gZGVmYXVsdExvY2FsZTtcbiAgICAgICAgICAgIHRoaXMuZG9tYWluTG9jYWxlcyA9IGRvbWFpbkxvY2FsZXM7XG4gICAgICAgICAgICB0aGlzLmlzTG9jYWxlRG9tYWluID0gISFkZXRlY3REb21haW5Mb2NhbGUoZG9tYWluTG9jYWxlcywgc2VsZi5sb2NhdGlvbi5ob3N0bmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAvLyBtYWtlIHN1cmUgXCJhc1wiIGRvZXNuJ3Qgc3RhcnQgd2l0aCBkb3VibGUgc2xhc2hlcyBvciBlbHNlIGl0IGNhblxuICAgICAgICAgICAgLy8gdGhyb3cgYW4gZXJyb3IgYXMgaXQncyBjb25zaWRlcmVkIGludmFsaWRcbiAgICAgICAgICAgIGlmIChhczEuc3Vic3RyKDAsIDIpICE9PSAnLy8nKSB7XG4gICAgICAgICAgICAgICAgLy8gaW4gb3JkZXIgZm9yIGBlLnN0YXRlYCB0byB3b3JrIG9uIHRoZSBgb25wb3BzdGF0ZWAgZXZlbnRcbiAgICAgICAgICAgICAgICAvLyB3ZSBoYXZlIHRvIHJlZ2lzdGVyIHRoZSBpbml0aWFsIHJvdXRlIHVwb24gaW5pdGlhbGl6YXRpb25cbiAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICAgICAgICAgICAgICBsb2NhbGVcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIG9wdGlvbnMuX3Nob3VsZFJlc29sdmVIcmVmID0gYXMxICE9PSBwYXRobmFtZTE7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VTdGF0ZSgncmVwbGFjZVN0YXRlJywgKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTogYWRkQmFzZVBhdGgocGF0aG5hbWUxKSxcbiAgICAgICAgICAgICAgICAgICAgcXVlcnk6IHF1ZXJ5MVxuICAgICAgICAgICAgICAgIH0pLCAoMCwgX3V0aWxzKS5nZXRVUkwoKSwgb3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncG9wc3RhdGUnLCB0aGlzLm9uUG9wU3RhdGUpO1xuICAgICAgICAgICAgLy8gZW5hYmxlIGN1c3RvbSBzY3JvbGwgcmVzdG9yYXRpb24gaGFuZGxpbmcgd2hlbiBhdmFpbGFibGVcbiAgICAgICAgICAgIC8vIG90aGVyd2lzZSBmYWxsYmFjayB0byBicm93c2VyJ3MgZGVmYXVsdCBoYW5kbGluZ1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04pIHtcbiAgICAgICAgICAgICAgICBpZiAobWFudWFsU2Nyb2xsUmVzdG9yYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93Lmhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPSAnbWFudWFsJztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmVsb2FkKCkge1xuICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG4gICAgfVxuICAgIC8qKlxuICAgKiBHbyBiYWNrIGluIGhpc3RvcnlcbiAgICovIGJhY2soKSB7XG4gICAgICAgIHdpbmRvdy5oaXN0b3J5LmJhY2soKTtcbiAgICB9XG4gICAgLyoqXG4gICAqIFBlcmZvcm1zIGEgYHB1c2hTdGF0ZWAgd2l0aCBhcmd1bWVudHNcbiAgICogQHBhcmFtIHVybCBvZiB0aGUgcm91dGVcbiAgICogQHBhcmFtIGFzIG1hc2tzIGB1cmxgIGZvciB0aGUgYnJvd3NlclxuICAgKiBAcGFyYW0gb3B0aW9ucyBvYmplY3QgeW91IGNhbiBkZWZpbmUgYHNoYWxsb3dgIGFuZCBvdGhlciBvcHRpb25zXG4gICAqLyBwdXNoKHVybCwgYXMsIG9wdGlvbnMgPSB7XG4gICAgfSkge1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX1NDUk9MTF9SRVNUT1JBVElPTikge1xuICAgICAgICAgICAgLy8gVE9ETzogcmVtb3ZlIGluIHRoZSBmdXR1cmUgd2hlbiB3ZSB1cGRhdGUgaGlzdG9yeSBiZWZvcmUgcm91dGUgY2hhbmdlXG4gICAgICAgICAgICAvLyBpcyBjb21wbGV0ZSwgYXMgdGhlIHBvcHN0YXRlIGV2ZW50IHNob3VsZCBoYW5kbGUgdGhpcyBjYXB0dXJlLlxuICAgICAgICAgICAgaWYgKG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gU25hcHNob3Qgc2Nyb2xsIHBvc2l0aW9uIHJpZ2h0IGJlZm9yZSBuYXZpZ2F0aW5nIHRvIGEgbmV3IHBhZ2U6XG4gICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ19fbmV4dF9zY3JvbGxfJyArIHRoaXMuX2lkeCwgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgeDogc2VsZi5wYWdlWE9mZnNldCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHk6IHNlbGYucGFnZVlPZmZzZXRcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggIHtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgKHsgdXJsICwgYXMgIH0gPSBwcmVwYXJlVXJsQXModGhpcywgdXJsLCBhcykpO1xuICAgICAgICByZXR1cm4gdGhpcy5jaGFuZ2UoJ3B1c2hTdGF0ZScsIHVybCwgYXMsIG9wdGlvbnMpO1xuICAgIH1cbiAgICAvKipcbiAgICogUGVyZm9ybXMgYSBgcmVwbGFjZVN0YXRlYCB3aXRoIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0gdXJsIG9mIHRoZSByb3V0ZVxuICAgKiBAcGFyYW0gYXMgbWFza3MgYHVybGAgZm9yIHRoZSBicm93c2VyXG4gICAqIEBwYXJhbSBvcHRpb25zIG9iamVjdCB5b3UgY2FuIGRlZmluZSBgc2hhbGxvd2AgYW5kIG90aGVyIG9wdGlvbnNcbiAgICovIHJlcGxhY2UodXJsLCBhcywgb3B0aW9ucyA9IHtcbiAgICB9KSB7XG4gICAgICAgICh7IHVybCAsIGFzICB9ID0gcHJlcGFyZVVybEFzKHRoaXMsIHVybCwgYXMpKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2hhbmdlKCdyZXBsYWNlU3RhdGUnLCB1cmwsIGFzLCBvcHRpb25zKTtcbiAgICB9XG4gICAgYXN5bmMgY2hhbmdlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucywgZm9yY2VkU2Nyb2xsKSB7XG4gICAgICAgIGlmICghaXNMb2NhbFVSTCh1cmwpKSB7XG4gICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IHVybDtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzaG91bGRSZXNvbHZlSHJlZiA9IHVybCA9PT0gYXMgfHwgb3B0aW9ucy5faCB8fCBvcHRpb25zLl9zaG91bGRSZXNvbHZlSHJlZjtcbiAgICAgICAgLy8gZm9yIHN0YXRpYyBwYWdlcyB3aXRoIHF1ZXJ5IHBhcmFtcyBpbiB0aGUgVVJMIHdlIGRlbGF5XG4gICAgICAgIC8vIG1hcmtpbmcgdGhlIHJvdXRlciByZWFkeSB1bnRpbCBhZnRlciB0aGUgcXVlcnkgaXMgdXBkYXRlZFxuICAgICAgICBpZiAob3B0aW9ucy5faCkge1xuICAgICAgICAgICAgdGhpcy5pc1JlYWR5ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcmV2TG9jYWxlID0gdGhpcy5sb2NhbGU7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICB0aGlzLmxvY2FsZSA9IG9wdGlvbnMubG9jYWxlID09PSBmYWxzZSA/IHRoaXMuZGVmYXVsdExvY2FsZSA6IG9wdGlvbnMubG9jYWxlIHx8IHRoaXMubG9jYWxlO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBvcHRpb25zLmxvY2FsZSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICBvcHRpb25zLmxvY2FsZSA9IHRoaXMubG9jYWxlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcGFyc2VkQXMgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwoaGFzQmFzZVBhdGgoYXMpID8gZGVsQmFzZVBhdGgoYXMpIDogYXMpO1xuICAgICAgICAgICAgY29uc3QgbG9jYWxlUGF0aFJlc3VsdCA9ICgwLCBfbm9ybWFsaXplTG9jYWxlUGF0aCkubm9ybWFsaXplTG9jYWxlUGF0aChwYXJzZWRBcy5wYXRobmFtZSwgdGhpcy5sb2NhbGVzKTtcbiAgICAgICAgICAgIGlmIChsb2NhbGVQYXRoUmVzdWx0LmRldGVjdGVkTG9jYWxlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2NhbGUgPSBsb2NhbGVQYXRoUmVzdWx0LmRldGVjdGVkTG9jYWxlO1xuICAgICAgICAgICAgICAgIHBhcnNlZEFzLnBhdGhuYW1lID0gYWRkQmFzZVBhdGgocGFyc2VkQXMucGF0aG5hbWUpO1xuICAgICAgICAgICAgICAgIGFzID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkQXMpO1xuICAgICAgICAgICAgICAgIHVybCA9IGFkZEJhc2VQYXRoKCgwLCBfbm9ybWFsaXplTG9jYWxlUGF0aCkubm9ybWFsaXplTG9jYWxlUGF0aChoYXNCYXNlUGF0aCh1cmwpID8gZGVsQmFzZVBhdGgodXJsKSA6IHVybCwgdGhpcy5sb2NhbGVzKS5wYXRobmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgZGlkTmF2aWdhdGUgPSBmYWxzZTtcbiAgICAgICAgICAgIC8vIHdlIG5lZWQgdG8gd3JhcCB0aGlzIGluIHRoZSBlbnYgY2hlY2sgYWdhaW4gc2luY2UgcmVnZW5lcmF0b3IgcnVudGltZVxuICAgICAgICAgICAgLy8gbW92ZXMgdGhpcyBvbiBpdHMgb3duIGR1ZSB0byB0aGUgcmV0dXJuXG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICAgICAgICAgIHZhciByZWY7XG4gICAgICAgICAgICAgICAgLy8gaWYgdGhlIGxvY2FsZSBpc24ndCBjb25maWd1cmVkIGhhcmQgbmF2aWdhdGUgdG8gc2hvdyA0MDQgcGFnZVxuICAgICAgICAgICAgICAgIGlmICghKChyZWYgPSB0aGlzLmxvY2FsZXMpID09PSBudWxsIHx8IHJlZiA9PT0gdm9pZCAwID8gdm9pZCAwIDogcmVmLmluY2x1ZGVzKHRoaXMubG9jYWxlKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgcGFyc2VkQXMucGF0aG5hbWUgPSBhZGRMb2NhbGUocGFyc2VkQXMucGF0aG5hbWUsIHRoaXMubG9jYWxlKTtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWRBcyk7XG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMgd2FzIHByZXZpb3VzbHkgYSByZXR1cm4gYnV0IHdhcyByZW1vdmVkIGluIGZhdm9yXG4gICAgICAgICAgICAgICAgICAgIC8vIG9mIGJldHRlciBkZWFkIGNvZGUgZWxpbWluYXRpb24gd2l0aCByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAgICAgICAgICAgICAgIGRpZE5hdmlnYXRlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBkZXRlY3RlZERvbWFpbiA9IGRldGVjdERvbWFpbkxvY2FsZSh0aGlzLmRvbWFpbkxvY2FsZXMsIHVuZGVmaW5lZCwgdGhpcy5sb2NhbGUpO1xuICAgICAgICAgICAgLy8gd2UgbmVlZCB0byB3cmFwIHRoaXMgaW4gdGhlIGVudiBjaGVjayBhZ2FpbiBzaW5jZSByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAgICAgICAvLyBtb3ZlcyB0aGlzIG9uIGl0cyBvd24gZHVlIHRvIHRoZSByZXR1cm5cbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICAgICAgLy8gaWYgd2UgYXJlIG5hdmlnYXRpbmcgdG8gYSBkb21haW4gbG9jYWxlIGVuc3VyZSB3ZSByZWRpcmVjdCB0byB0aGVcbiAgICAgICAgICAgICAgICAvLyBjb3JyZWN0IGRvbWFpblxuICAgICAgICAgICAgICAgIGlmICghZGlkTmF2aWdhdGUgJiYgZGV0ZWN0ZWREb21haW4gJiYgdGhpcy5pc0xvY2FsZURvbWFpbiAmJiBzZWxmLmxvY2F0aW9uLmhvc3RuYW1lICE9PSBkZXRlY3RlZERvbWFpbi5kb21haW4pIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXNOb0Jhc2VQYXRoID0gZGVsQmFzZVBhdGgoYXMpO1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IGBodHRwJHtkZXRlY3RlZERvbWFpbi5odHRwID8gJycgOiAncyd9Oi8vJHtkZXRlY3RlZERvbWFpbi5kb21haW59JHthZGRCYXNlUGF0aChgJHt0aGlzLmxvY2FsZSA9PT0gZGV0ZWN0ZWREb21haW4uZGVmYXVsdExvY2FsZSA/ICcnIDogYC8ke3RoaXMubG9jYWxlfWB9JHthc05vQmFzZVBhdGggPT09ICcvJyA/ICcnIDogYXNOb0Jhc2VQYXRofWAgfHwgJy8nKX1gO1xuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzIHdhcyBwcmV2aW91c2x5IGEgcmV0dXJuIGJ1dCB3YXMgcmVtb3ZlZCBpbiBmYXZvclxuICAgICAgICAgICAgICAgICAgICAvLyBvZiBiZXR0ZXIgZGVhZCBjb2RlIGVsaW1pbmF0aW9uIHdpdGggcmVnZW5lcmF0b3IgcnVudGltZVxuICAgICAgICAgICAgICAgICAgICBkaWROYXZpZ2F0ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGRpZE5hdmlnYXRlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKCgpPT57XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFvcHRpb25zLl9oKSB7XG4gICAgICAgICAgICB0aGlzLmlzU3NyID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgLy8gbWFya2luZyByb3V0ZSBjaGFuZ2VzIGFzIGEgbmF2aWdhdGlvbiBzdGFydCBlbnRyeVxuICAgICAgICBpZiAoX3V0aWxzLlNUKSB7XG4gICAgICAgICAgICBwZXJmb3JtYW5jZS5tYXJrKCdyb3V0ZUNoYW5nZScpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgc2hhbGxvdyA9ZmFsc2UgIH0gPSBvcHRpb25zO1xuICAgICAgICBjb25zdCByb3V0ZVByb3BzID0ge1xuICAgICAgICAgICAgc2hhbGxvd1xuICAgICAgICB9O1xuICAgICAgICBpZiAodGhpcy5faW5GbGlnaHRSb3V0ZSkge1xuICAgICAgICAgICAgdGhpcy5hYm9ydENvbXBvbmVudExvYWQodGhpcy5faW5GbGlnaHRSb3V0ZSwgcm91dGVQcm9wcyk7XG4gICAgICAgIH1cbiAgICAgICAgYXMgPSBhZGRCYXNlUGF0aChhZGRMb2NhbGUoaGFzQmFzZVBhdGgoYXMpID8gZGVsQmFzZVBhdGgoYXMpIDogYXMsIG9wdGlvbnMubG9jYWxlLCB0aGlzLmRlZmF1bHRMb2NhbGUpKTtcbiAgICAgICAgY29uc3QgY2xlYW5lZEFzID0gZGVsTG9jYWxlKGhhc0Jhc2VQYXRoKGFzKSA/IGRlbEJhc2VQYXRoKGFzKSA6IGFzLCB0aGlzLmxvY2FsZSk7XG4gICAgICAgIHRoaXMuX2luRmxpZ2h0Um91dGUgPSBhcztcbiAgICAgICAgbGV0IGxvY2FsZUNoYW5nZSA9IHByZXZMb2NhbGUgIT09IHRoaXMubG9jYWxlO1xuICAgICAgICAvLyBJZiB0aGUgdXJsIGNoYW5nZSBpcyBvbmx5IHJlbGF0ZWQgdG8gYSBoYXNoIGNoYW5nZVxuICAgICAgICAvLyBXZSBzaG91bGQgbm90IHByb2NlZWQuIFdlIHNob3VsZCBvbmx5IGNoYW5nZSB0aGUgc3RhdGUuXG4gICAgICAgIC8vIFdBUk5JTkc6IGBfaGAgaXMgYW4gaW50ZXJuYWwgb3B0aW9uIGZvciBoYW5kaW5nIE5leHQuanMgY2xpZW50LXNpZGVcbiAgICAgICAgLy8gaHlkcmF0aW9uLiBZb3VyIGFwcCBzaG91bGQgX25ldmVyXyB1c2UgdGhpcyBwcm9wZXJ0eS4gSXQgbWF5IGNoYW5nZSBhdFxuICAgICAgICAvLyBhbnkgdGltZSB3aXRob3V0IG5vdGljZS5cbiAgICAgICAgaWYgKCFvcHRpb25zLl9oICYmIHRoaXMub25seUFIYXNoQ2hhbmdlKGNsZWFuZWRBcykgJiYgIWxvY2FsZUNoYW5nZSkge1xuICAgICAgICAgICAgdGhpcy5hc1BhdGggPSBjbGVhbmVkQXM7XG4gICAgICAgICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ2hhc2hDaGFuZ2VTdGFydCcsIGFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgIC8vIFRPRE86IGRvIHdlIG5lZWQgdGhlIHJlc29sdmVkIGhyZWYgd2hlbiBvbmx5IGEgaGFzaCBjaGFuZ2U/XG4gICAgICAgICAgICB0aGlzLmNoYW5nZVN0YXRlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucyk7XG4gICAgICAgICAgICB0aGlzLnNjcm9sbFRvSGFzaChjbGVhbmVkQXMpO1xuICAgICAgICAgICAgdGhpcy5ub3RpZnkodGhpcy5jb21wb25lbnRzW3RoaXMucm91dGVdLCBudWxsKTtcbiAgICAgICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgnaGFzaENoYW5nZUNvbXBsZXRlJywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHBhcnNlZCA9ICgwLCBfcGFyc2VSZWxhdGl2ZVVybCkucGFyc2VSZWxhdGl2ZVVybCh1cmwpO1xuICAgICAgICBsZXQgeyBwYXRobmFtZTogcGF0aG5hbWUxICwgcXVlcnk6IHF1ZXJ5MSAgfSA9IHBhcnNlZDtcbiAgICAgICAgLy8gVGhlIGJ1aWxkIG1hbmlmZXN0IG5lZWRzIHRvIGJlIGxvYWRlZCBiZWZvcmUgYXV0by1zdGF0aWMgZHluYW1pYyBwYWdlc1xuICAgICAgICAvLyBnZXQgdGhlaXIgcXVlcnkgcGFyYW1ldGVycyB0byBhbGxvdyBlbnN1cmluZyB0aGV5IGNhbiBiZSBwYXJzZWQgcHJvcGVybHlcbiAgICAgICAgLy8gd2hlbiByZXdyaXR0ZW4gdG9cbiAgICAgICAgbGV0IHBhZ2VzLCByZXdyaXRlcztcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHBhZ2VzID0gYXdhaXQgdGhpcy5wYWdlTG9hZGVyLmdldFBhZ2VMaXN0KCk7XG4gICAgICAgICAgICAoeyBfX3Jld3JpdGVzOiByZXdyaXRlcyAgfSA9IGF3YWl0ICgwLCBfcm91dGVMb2FkZXIpLmdldENsaWVudEJ1aWxkTWFuaWZlc3QoKSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycjEpIHtcbiAgICAgICAgICAgIC8vIElmIHdlIGZhaWwgdG8gcmVzb2x2ZSB0aGUgcGFnZSBsaXN0IG9yIGNsaWVudC1idWlsZCBtYW5pZmVzdCwgd2UgbXVzdFxuICAgICAgICAgICAgLy8gZG8gYSBzZXJ2ZXItc2lkZSB0cmFuc2l0aW9uOlxuICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBhcztcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJZiBhc2tlZCB0byBjaGFuZ2UgdGhlIGN1cnJlbnQgVVJMIHdlIHNob3VsZCByZWxvYWQgdGhlIGN1cnJlbnQgcGFnZVxuICAgICAgICAvLyAobm90IGxvY2F0aW9uLnJlbG9hZCgpIGJ1dCByZWxvYWQgZ2V0SW5pdGlhbFByb3BzIGFuZCBvdGhlciBOZXh0LmpzIHN0dWZmcylcbiAgICAgICAgLy8gV2UgYWxzbyBuZWVkIHRvIHNldCB0aGUgbWV0aG9kID0gcmVwbGFjZVN0YXRlIGFsd2F5c1xuICAgICAgICAvLyBhcyB0aGlzIHNob3VsZCBub3QgZ28gaW50byB0aGUgaGlzdG9yeSAoVGhhdCdzIGhvdyBicm93c2VycyB3b3JrKVxuICAgICAgICAvLyBXZSBzaG91bGQgY29tcGFyZSB0aGUgbmV3IGFzUGF0aCB0byB0aGUgY3VycmVudCBhc1BhdGgsIG5vdCB0aGUgdXJsXG4gICAgICAgIGlmICghdGhpcy51cmxJc05ldyhjbGVhbmVkQXMpICYmICFsb2NhbGVDaGFuZ2UpIHtcbiAgICAgICAgICAgIG1ldGhvZCA9ICdyZXBsYWNlU3RhdGUnO1xuICAgICAgICB9XG4gICAgICAgIC8vIHdlIG5lZWQgdG8gcmVzb2x2ZSB0aGUgYXMgdmFsdWUgdXNpbmcgcmV3cml0ZXMgZm9yIGR5bmFtaWMgU1NHXG4gICAgICAgIC8vIHBhZ2VzIHRvIGFsbG93IGJ1aWxkaW5nIHRoZSBkYXRhIFVSTCBjb3JyZWN0bHlcbiAgICAgICAgbGV0IHJlc29sdmVkQXMgPSBhcztcbiAgICAgICAgLy8gdXJsIGFuZCBhcyBzaG91bGQgYWx3YXlzIGJlIHByZWZpeGVkIHdpdGggYmFzZVBhdGggYnkgdGhpc1xuICAgICAgICAvLyBwb2ludCBieSBlaXRoZXIgbmV4dC9saW5rIG9yIHJvdXRlci5wdXNoL3JlcGxhY2Ugc28gc3RyaXAgdGhlXG4gICAgICAgIC8vIGJhc2VQYXRoIGZyb20gdGhlIHBhdGhuYW1lIHRvIG1hdGNoIHRoZSBwYWdlcyBkaXIgMS10by0xXG4gICAgICAgIHBhdGhuYW1lMSA9IHBhdGhuYW1lMSA/ICgwLCBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCkucmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2goZGVsQmFzZVBhdGgocGF0aG5hbWUxKSkgOiBwYXRobmFtZTE7XG4gICAgICAgIGlmIChzaG91bGRSZXNvbHZlSHJlZiAmJiBwYXRobmFtZTEgIT09ICcvX2Vycm9yJykge1xuICAgICAgICAgICAgb3B0aW9ucy5fc2hvdWxkUmVzb2x2ZUhyZWYgPSB0cnVlO1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9IQVNfUkVXUklURVMgJiYgYXMuc3RhcnRzV2l0aCgnLycpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmV3cml0ZXNSZXN1bHQgPSAoMCwgX3Jlc29sdmVSZXdyaXRlcykuZGVmYXVsdChhZGRCYXNlUGF0aChhZGRMb2NhbGUoY2xlYW5lZEFzLCB0aGlzLmxvY2FsZSkpLCBwYWdlcywgcmV3cml0ZXMsIHF1ZXJ5MSwgKHApPT5yZXNvbHZlRHluYW1pY1JvdXRlKHAsIHBhZ2VzKVxuICAgICAgICAgICAgICAgICwgdGhpcy5sb2NhbGVzKTtcbiAgICAgICAgICAgICAgICByZXNvbHZlZEFzID0gcmV3cml0ZXNSZXN1bHQuYXNQYXRoO1xuICAgICAgICAgICAgICAgIGlmIChyZXdyaXRlc1Jlc3VsdC5tYXRjaGVkUGFnZSAmJiByZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWYpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gaWYgdGhpcyBkaXJlY3RseSBtYXRjaGVzIGEgcGFnZSB3ZSBuZWVkIHRvIHVwZGF0ZSB0aGUgaHJlZiB0b1xuICAgICAgICAgICAgICAgICAgICAvLyBhbGxvdyB0aGUgY29ycmVjdCBwYWdlIGNodW5rIHRvIGJlIGxvYWRlZFxuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTEgPSByZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWY7XG4gICAgICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IGFkZEJhc2VQYXRoKHBhdGhuYW1lMSk7XG4gICAgICAgICAgICAgICAgICAgIHVybCA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSByZXNvbHZlRHluYW1pY1JvdXRlKHBhdGhuYW1lMSwgcGFnZXMpO1xuICAgICAgICAgICAgICAgIGlmIChwYXJzZWQucGF0aG5hbWUgIT09IHBhdGhuYW1lMSkge1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTEgPSBwYXJzZWQucGF0aG5hbWU7XG4gICAgICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IGFkZEJhc2VQYXRoKHBhdGhuYW1lMSk7XG4gICAgICAgICAgICAgICAgICAgIHVybCA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJvdXRlID0gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZTEpO1xuICAgICAgICBpZiAoIWlzTG9jYWxVUkwoYXMpKSB7XG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBocmVmOiBcIiR7dXJsfVwiIGFuZCBhczogXCIke2FzfVwiLCByZWNlaXZlZCByZWxhdGl2ZSBocmVmIGFuZCBleHRlcm5hbCBhc2AgKyBgXFxuU2VlIG1vcmUgaW5mbzogaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvaW52YWxpZC1yZWxhdGl2ZS11cmwtZXh0ZXJuYWwtYXNgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYXM7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmVzb2x2ZWRBcyA9IGRlbExvY2FsZShkZWxCYXNlUGF0aChyZXNvbHZlZEFzKSwgdGhpcy5sb2NhbGUpO1xuICAgICAgICBpZiAoKDAsIF9pc0R5bmFtaWMpLmlzRHluYW1pY1JvdXRlKHJvdXRlKSkge1xuICAgICAgICAgICAgY29uc3QgcGFyc2VkQXMgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwocmVzb2x2ZWRBcyk7XG4gICAgICAgICAgICBjb25zdCBhc1BhdGhuYW1lID0gcGFyc2VkQXMucGF0aG5hbWU7XG4gICAgICAgICAgICBjb25zdCByb3V0ZVJlZ2V4ID0gKDAsIF9yb3V0ZVJlZ2V4KS5nZXRSb3V0ZVJlZ2V4KHJvdXRlKTtcbiAgICAgICAgICAgIGNvbnN0IHJvdXRlTWF0Y2ggPSAoMCwgX3JvdXRlTWF0Y2hlcikuZ2V0Um91dGVNYXRjaGVyKHJvdXRlUmVnZXgpKGFzUGF0aG5hbWUpO1xuICAgICAgICAgICAgY29uc3Qgc2hvdWxkSW50ZXJwb2xhdGUgPSByb3V0ZSA9PT0gYXNQYXRobmFtZTtcbiAgICAgICAgICAgIGNvbnN0IGludGVycG9sYXRlZEFzID0gc2hvdWxkSW50ZXJwb2xhdGUgPyBpbnRlcnBvbGF0ZUFzKHJvdXRlLCBhc1BhdGhuYW1lLCBxdWVyeTEpIDoge1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmICghcm91dGVNYXRjaCB8fCBzaG91bGRJbnRlcnBvbGF0ZSAmJiAhaW50ZXJwb2xhdGVkQXMucmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbWlzc2luZ1BhcmFtcyA9IE9iamVjdC5rZXlzKHJvdXRlUmVnZXguZ3JvdXBzKS5maWx0ZXIoKHBhcmFtKT0+IXF1ZXJ5MVtwYXJhbV1cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIGlmIChtaXNzaW5nUGFyYW1zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgJHtzaG91bGRJbnRlcnBvbGF0ZSA/IGBJbnRlcnBvbGF0aW5nIGhyZWZgIDogYE1pc21hdGNoaW5nIFxcYGFzXFxgIGFuZCBcXGBocmVmXFxgYH0gZmFpbGVkIHRvIG1hbnVhbGx5IHByb3ZpZGUgYCArIGB0aGUgcGFyYW1zOiAke21pc3NpbmdQYXJhbXMuam9pbignLCAnKX0gaW4gdGhlIFxcYGhyZWZcXGAncyBcXGBxdWVyeVxcYGApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigoc2hvdWxkSW50ZXJwb2xhdGUgPyBgVGhlIHByb3ZpZGVkIFxcYGhyZWZcXGAgKCR7dXJsfSkgdmFsdWUgaXMgbWlzc2luZyBxdWVyeSB2YWx1ZXMgKCR7bWlzc2luZ1BhcmFtcy5qb2luKCcsICcpfSkgdG8gYmUgaW50ZXJwb2xhdGVkIHByb3Blcmx5LiBgIDogYFRoZSBwcm92aWRlZCBcXGBhc1xcYCB2YWx1ZSAoJHthc1BhdGhuYW1lfSkgaXMgaW5jb21wYXRpYmxlIHdpdGggdGhlIFxcYGhyZWZcXGAgdmFsdWUgKCR7cm91dGV9KS4gYCkgKyBgUmVhZCBtb3JlOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy8ke3Nob3VsZEludGVycG9sYXRlID8gJ2hyZWYtaW50ZXJwb2xhdGlvbi1mYWlsZWQnIDogJ2luY29tcGF0aWJsZS1ocmVmLWFzJ31gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHNob3VsZEludGVycG9sYXRlKSB7XG4gICAgICAgICAgICAgICAgYXMgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihPYmplY3QuYXNzaWduKHtcbiAgICAgICAgICAgICAgICB9LCBwYXJzZWRBcywge1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTogaW50ZXJwb2xhdGVkQXMucmVzdWx0LFxuICAgICAgICAgICAgICAgICAgICBxdWVyeTogb21pdFBhcm1zRnJvbVF1ZXJ5KHF1ZXJ5MSwgaW50ZXJwb2xhdGVkQXMucGFyYW1zKVxuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gTWVyZ2UgcGFyYW1zIGludG8gYHF1ZXJ5YCwgb3ZlcndyaXRpbmcgYW55IHNwZWNpZmllZCBpbiBzZWFyY2hcbiAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKHF1ZXJ5MSwgcm91dGVNYXRjaCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZVN0YXJ0JywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgdmFyIHJlZiwgcmVmMTtcbiAgICAgICAgICAgIGxldCByb3V0ZUluZm8gPSBhd2FpdCB0aGlzLmdldFJvdXRlSW5mbyhyb3V0ZSwgcGF0aG5hbWUxLCBxdWVyeTEsIGFzLCByZXNvbHZlZEFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgIGxldCB7IGVycm9yICwgcHJvcHMgLCBfX05fU1NHICwgX19OX1NTUCAgfSA9IHJvdXRlSW5mbztcbiAgICAgICAgICAgIC8vIGhhbmRsZSByZWRpcmVjdCBvbiBjbGllbnQtdHJhbnNpdGlvblxuICAgICAgICAgICAgaWYgKChfX05fU1NHIHx8IF9fTl9TU1ApICYmIHByb3BzKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BzLnBhZ2VQcm9wcyAmJiBwcm9wcy5wYWdlUHJvcHMuX19OX1JFRElSRUNUKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRlc3RpbmF0aW9uID0gcHJvcHMucGFnZVByb3BzLl9fTl9SRURJUkVDVDtcbiAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgaWYgZGVzdGluYXRpb24gaXMgaW50ZXJuYWwgKHJlc29sdmVzIHRvIGEgcGFnZSkgYW5kIGF0dGVtcHRcbiAgICAgICAgICAgICAgICAgICAgLy8gY2xpZW50LW5hdmlnYXRpb24gaWYgaXQgaXMgZmFsbGluZyBiYWNrIHRvIGhhcmQgbmF2aWdhdGlvbiBpZlxuICAgICAgICAgICAgICAgICAgICAvLyBpdCdzIG5vdFxuICAgICAgICAgICAgICAgICAgICBpZiAoZGVzdGluYXRpb24uc3RhcnRzV2l0aCgnLycpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJzZWRIcmVmID0gKDAsIF9wYXJzZVJlbGF0aXZlVXJsKS5wYXJzZVJlbGF0aXZlVXJsKGRlc3RpbmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlZEhyZWYucGF0aG5hbWUgPSByZXNvbHZlRHluYW1pY1JvdXRlKHBhcnNlZEhyZWYucGF0aG5hbWUsIHBhZ2VzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHsgdXJsOiBuZXdVcmwgLCBhczogbmV3QXMgIH0gPSBwcmVwYXJlVXJsQXModGhpcywgZGVzdGluYXRpb24sIGRlc3RpbmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNoYW5nZShtZXRob2QsIG5ld1VybCwgbmV3QXMsIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gZGVzdGluYXRpb247XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgoKT0+e1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5pc1ByZXZpZXcgPSAhIXByb3BzLl9fTl9QUkVWSUVXO1xuICAgICAgICAgICAgICAgIC8vIGhhbmRsZSBTU0cgZGF0YSA0MDRcbiAgICAgICAgICAgICAgICBpZiAocHJvcHMubm90Rm91bmQgPT09IFNTR19EQVRBX05PVF9GT1VORCkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgbm90Rm91bmRSb3V0ZTtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuZmV0Y2hDb21wb25lbnQoJy80MDQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vdEZvdW5kUm91dGUgPSAnLzQwNCc7XG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKF8pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vdEZvdW5kUm91dGUgPSAnL19lcnJvcic7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcm91dGVJbmZvID0gYXdhaXQgdGhpcy5nZXRSb3V0ZUluZm8obm90Rm91bmRSb3V0ZSwgbm90Rm91bmRSb3V0ZSwgcXVlcnkxLCBhcywgcmVzb2x2ZWRBcywge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2hhbGxvdzogZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdiZWZvcmVIaXN0b3J5Q2hhbmdlJywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgdGhpcy5jaGFuZ2VTdGF0ZShtZXRob2QsIHVybCwgYXMsIG9wdGlvbnMpO1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBhcHBDb21wID0gdGhpcy5jb21wb25lbnRzWycvX2FwcCddLkNvbXBvbmVudDtcbiAgICAgICAgICAgICAgICB3aW5kb3cubmV4dC5pc1ByZXJlbmRlcmVkID0gYXBwQ29tcC5nZXRJbml0aWFsUHJvcHMgPT09IGFwcENvbXAub3JpZ0dldEluaXRpYWxQcm9wcyAmJiAhcm91dGVJbmZvLkNvbXBvbmVudC5nZXRJbml0aWFsUHJvcHM7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5faCAmJiBwYXRobmFtZTEgPT09ICcvX2Vycm9yJyAmJiAoKHJlZiA9IHNlbGYuX19ORVhUX0RBVEFfXy5wcm9wcykgPT09IG51bGwgfHwgcmVmID09PSB2b2lkIDAgPyB2b2lkIDAgOiAocmVmMSA9IHJlZi5wYWdlUHJvcHMpID09PSBudWxsIHx8IHJlZjEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlZjEuc3RhdHVzQ29kZSkgPT09IDUwMCAmJiAocHJvcHMgPT09IG51bGwgfHwgcHJvcHMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHByb3BzLnBhZ2VQcm9wcykpIHtcbiAgICAgICAgICAgICAgICAvLyBlbnN1cmUgc3RhdHVzQ29kZSBpcyBzdGlsbCBjb3JyZWN0IGZvciBzdGF0aWMgNTAwIHBhZ2VcbiAgICAgICAgICAgICAgICAvLyB3aGVuIHVwZGF0aW5nIHF1ZXJ5IGluZm9ybWF0aW9uXG4gICAgICAgICAgICAgICAgcHJvcHMucGFnZVByb3BzLnN0YXR1c0NvZGUgPSA1MDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBzaGFsbG93IHJvdXRpbmcgaXMgb25seSBhbGxvd2VkIGZvciBzYW1lIHBhZ2UgVVJMIGNoYW5nZXMuXG4gICAgICAgICAgICBjb25zdCBpc1ZhbGlkU2hhbGxvd1JvdXRlID0gb3B0aW9ucy5zaGFsbG93ICYmIHRoaXMucm91dGUgPT09IHJvdXRlO1xuICAgICAgICAgICAgdmFyIF9zY3JvbGw7XG4gICAgICAgICAgICBjb25zdCBzaG91bGRTY3JvbGwgPSAoX3Njcm9sbCA9IG9wdGlvbnMuc2Nyb2xsKSAhPT0gbnVsbCAmJiBfc2Nyb2xsICE9PSB2b2lkIDAgPyBfc2Nyb2xsIDogIWlzVmFsaWRTaGFsbG93Um91dGU7XG4gICAgICAgICAgICBjb25zdCByZXNldFNjcm9sbCA9IHNob3VsZFNjcm9sbCA/IHtcbiAgICAgICAgICAgICAgICB4OiAwLFxuICAgICAgICAgICAgICAgIHk6IDBcbiAgICAgICAgICAgIH0gOiBudWxsO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5zZXQocm91dGUsIHBhdGhuYW1lMSwgcXVlcnkxLCBjbGVhbmVkQXMsIHJvdXRlSW5mbywgZm9yY2VkU2Nyb2xsICE9PSBudWxsICYmIGZvcmNlZFNjcm9sbCAhPT0gdm9pZCAwID8gZm9yY2VkU2Nyb2xsIDogcmVzZXRTY3JvbGwpLmNhdGNoKChlKT0+e1xuICAgICAgICAgICAgICAgIGlmIChlLmNhbmNlbGxlZCkgZXJyb3IgPSBlcnJvciB8fCBlO1xuICAgICAgICAgICAgICAgIGVsc2UgdGhyb3cgZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJywgZXJyb3IsIGNsZWFuZWRBcywgcm91dGVQcm9wcyk7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmxvY2FsZSkge1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQubGFuZyA9IHRoaXMubG9jYWxlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VDb21wbGV0ZScsIGFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9IGNhdGNoIChlcnIxKSB7XG4gICAgICAgICAgICBpZiAoZXJyMS5jYW5jZWxsZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBlcnIxO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNoYW5nZVN0YXRlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucyA9IHtcbiAgICB9KSB7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHdpbmRvdy5oaXN0b3J5ID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFdhcm5pbmc6IHdpbmRvdy5oaXN0b3J5IGlzIG5vdCBhdmFpbGFibGUuYCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cuaGlzdG9yeVttZXRob2RdID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFdhcm5pbmc6IHdpbmRvdy5oaXN0b3J5LiR7bWV0aG9kfSBpcyBub3QgYXZhaWxhYmxlYCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChtZXRob2QgIT09ICdwdXNoU3RhdGUnIHx8ICgwLCBfdXRpbHMpLmdldFVSTCgpICE9PSBhcykge1xuICAgICAgICAgICAgdGhpcy5fc2hhbGxvdyA9IG9wdGlvbnMuc2hhbGxvdztcbiAgICAgICAgICAgIHdpbmRvdy5oaXN0b3J5W21ldGhvZF0oe1xuICAgICAgICAgICAgICAgIHVybCxcbiAgICAgICAgICAgICAgICBhcyxcbiAgICAgICAgICAgICAgICBvcHRpb25zLFxuICAgICAgICAgICAgICAgIF9fTjogdHJ1ZSxcbiAgICAgICAgICAgICAgICBpZHg6IHRoaXMuX2lkeCA9IG1ldGhvZCAhPT0gJ3B1c2hTdGF0ZScgPyB0aGlzLl9pZHggOiB0aGlzLl9pZHggKyAxXG4gICAgICAgICAgICB9LCAvLyBNb3N0IGJyb3dzZXJzIGN1cnJlbnRseSBpZ25vcmVzIHRoaXMgcGFyYW1ldGVyLCBhbHRob3VnaCB0aGV5IG1heSB1c2UgaXQgaW4gdGhlIGZ1dHVyZS5cbiAgICAgICAgICAgIC8vIFBhc3NpbmcgdGhlIGVtcHR5IHN0cmluZyBoZXJlIHNob3VsZCBiZSBzYWZlIGFnYWluc3QgZnV0dXJlIGNoYW5nZXMgdG8gdGhlIG1ldGhvZC5cbiAgICAgICAgICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9IaXN0b3J5L3JlcGxhY2VTdGF0ZVxuICAgICAgICAgICAgJycsIGFzKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBoYW5kbGVSb3V0ZUluZm9FcnJvcihlcnIsIHBhdGhuYW1lLCBxdWVyeSwgYXMsIHJvdXRlUHJvcHMsIGxvYWRFcnJvckZhaWwpIHtcbiAgICAgICAgaWYgKGVyci5jYW5jZWxsZWQpIHtcbiAgICAgICAgICAgIC8vIGJ1YmJsZSB1cCBjYW5jZWxsYXRpb24gZXJyb3JzXG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCgwLCBfcm91dGVMb2FkZXIpLmlzQXNzZXRFcnJvcihlcnIpIHx8IGxvYWRFcnJvckZhaWwpIHtcbiAgICAgICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VFcnJvcicsIGVyciwgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgLy8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgcGFnZSBpdCBjb3VsZCBiZSBvbmUgb2YgZm9sbG93aW5nIHJlYXNvbnNcbiAgICAgICAgICAgIC8vICAxLiBQYWdlIGRvZXNuJ3QgZXhpc3RzXG4gICAgICAgICAgICAvLyAgMi4gUGFnZSBkb2VzIGV4aXN0IGluIGEgZGlmZmVyZW50IHpvbmVcbiAgICAgICAgICAgIC8vICAzLiBJbnRlcm5hbCBlcnJvciB3aGlsZSBsb2FkaW5nIHRoZSBwYWdlXG4gICAgICAgICAgICAvLyBTbywgZG9pbmcgYSBoYXJkIHJlbG9hZCBpcyB0aGUgcHJvcGVyIHdheSB0byBkZWFsIHdpdGggdGhpcy5cbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYXM7XG4gICAgICAgICAgICAvLyBDaGFuZ2luZyB0aGUgVVJMIGRvZXNuJ3QgYmxvY2sgZXhlY3V0aW5nIHRoZSBjdXJyZW50IGNvZGUgcGF0aC5cbiAgICAgICAgICAgIC8vIFNvIGxldCdzIHRocm93IGEgY2FuY2VsbGF0aW9uIGVycm9yIHN0b3AgdGhlIHJvdXRpbmcgbG9naWMuXG4gICAgICAgICAgICB0aHJvdyBidWlsZENhbmNlbGxhdGlvbkVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGxldCBDb21wb25lbnQxO1xuICAgICAgICAgICAgbGV0IHN0eWxlU2hlZXRzO1xuICAgICAgICAgICAgbGV0IHByb3BzO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBDb21wb25lbnQxID09PSAndW5kZWZpbmVkJyB8fCB0eXBlb2Ygc3R5bGVTaGVldHMgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgKHsgcGFnZTogQ29tcG9uZW50MSAsIHN0eWxlU2hlZXRzICB9ID0gYXdhaXQgdGhpcy5mZXRjaENvbXBvbmVudCgnL19lcnJvcicpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHJvdXRlSW5mbyA9IHtcbiAgICAgICAgICAgICAgICBwcm9wcyxcbiAgICAgICAgICAgICAgICBDb21wb25lbnQ6IENvbXBvbmVudDEsXG4gICAgICAgICAgICAgICAgc3R5bGVTaGVldHMsXG4gICAgICAgICAgICAgICAgZXJyLFxuICAgICAgICAgICAgICAgIGVycm9yOiBlcnJcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAoIXJvdXRlSW5mby5wcm9wcykge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHJvdXRlSW5mby5wcm9wcyA9IGF3YWl0IHRoaXMuZ2V0SW5pdGlhbFByb3BzKENvbXBvbmVudDEsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycixcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGhuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZ2lwRXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGluIGVycm9yIHBhZ2UgYGdldEluaXRpYWxQcm9wc2A6ICcsIGdpcEVycik7XG4gICAgICAgICAgICAgICAgICAgIHJvdXRlSW5mby5wcm9wcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcm91dGVJbmZvO1xuICAgICAgICB9IGNhdGNoIChyb3V0ZUluZm9FcnIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmhhbmRsZVJvdXRlSW5mb0Vycm9yKHJvdXRlSW5mb0VyciwgcGF0aG5hbWUsIHF1ZXJ5LCBhcywgcm91dGVQcm9wcywgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYXN5bmMgZ2V0Um91dGVJbmZvKHJvdXRlLCBwYXRobmFtZSwgcXVlcnksIGFzLCByZXNvbHZlZEFzLCByb3V0ZVByb3BzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBleGlzdGluZ1JvdXRlSW5mbyA9IHRoaXMuY29tcG9uZW50c1tyb3V0ZV07XG4gICAgICAgICAgICBpZiAocm91dGVQcm9wcy5zaGFsbG93ICYmIGV4aXN0aW5nUm91dGVJbmZvICYmIHRoaXMucm91dGUgPT09IHJvdXRlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGV4aXN0aW5nUm91dGVJbmZvO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgY2FjaGVkUm91dGVJbmZvID0gZXhpc3RpbmdSb3V0ZUluZm8gJiYgJ2luaXRpYWwnIGluIGV4aXN0aW5nUm91dGVJbmZvID8gdW5kZWZpbmVkIDogZXhpc3RpbmdSb3V0ZUluZm87XG4gICAgICAgICAgICBjb25zdCByb3V0ZUluZm8gPSBjYWNoZWRSb3V0ZUluZm8gPyBjYWNoZWRSb3V0ZUluZm8gOiBhd2FpdCB0aGlzLmZldGNoQ29tcG9uZW50KHJvdXRlKS50aGVuKChyZXMpPT4oe1xuICAgICAgICAgICAgICAgICAgICBDb21wb25lbnQ6IHJlcy5wYWdlLFxuICAgICAgICAgICAgICAgICAgICBzdHlsZVNoZWV0czogcmVzLnN0eWxlU2hlZXRzLFxuICAgICAgICAgICAgICAgICAgICBfX05fU1NHOiByZXMubW9kLl9fTl9TU0csXG4gICAgICAgICAgICAgICAgICAgIF9fTl9TU1A6IHJlcy5tb2QuX19OX1NTUFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY29uc3QgeyBDb21wb25lbnQ6IENvbXBvbmVudDEgLCBfX05fU1NHICwgX19OX1NTUCAgfSA9IHJvdXRlSW5mbztcbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBpc1ZhbGlkRWxlbWVudFR5cGUgIH0gPSByZXF1aXJlKCdyZWFjdC1pcycpO1xuICAgICAgICAgICAgICAgIGlmICghaXNWYWxpZEVsZW1lbnRUeXBlKENvbXBvbmVudDEpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVGhlIGRlZmF1bHQgZXhwb3J0IGlzIG5vdCBhIFJlYWN0IENvbXBvbmVudCBpbiBwYWdlOiBcIiR7cGF0aG5hbWV9XCJgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgZGF0YUhyZWY7XG4gICAgICAgICAgICBpZiAoX19OX1NTRyB8fCBfX05fU1NQKSB7XG4gICAgICAgICAgICAgICAgZGF0YUhyZWYgPSB0aGlzLnBhZ2VMb2FkZXIuZ2V0RGF0YUhyZWYoKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZSxcbiAgICAgICAgICAgICAgICAgICAgcXVlcnlcbiAgICAgICAgICAgICAgICB9KSwgcmVzb2x2ZWRBcywgX19OX1NTRywgdGhpcy5sb2NhbGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcHJvcHMgPSBhd2FpdCB0aGlzLl9nZXREYXRhKCgpPT5fX05fU1NHID8gdGhpcy5fZ2V0U3RhdGljRGF0YShkYXRhSHJlZikgOiBfX05fU1NQID8gdGhpcy5fZ2V0U2VydmVyRGF0YShkYXRhSHJlZikgOiB0aGlzLmdldEluaXRpYWxQcm9wcyhDb21wb25lbnQxLCAvLyB3ZSBwcm92aWRlIEFwcFRyZWUgbGF0ZXIgc28gdGhpcyBuZWVkcyB0byBiZSBgYW55YFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgICAgICAgICBhc1BhdGg6IGFzLFxuICAgICAgICAgICAgICAgICAgICBsb2NhbGU6IHRoaXMubG9jYWxlLFxuICAgICAgICAgICAgICAgICAgICBsb2NhbGVzOiB0aGlzLmxvY2FsZXMsXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHRMb2NhbGU6IHRoaXMuZGVmYXVsdExvY2FsZVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcm91dGVJbmZvLnByb3BzID0gcHJvcHM7XG4gICAgICAgICAgICB0aGlzLmNvbXBvbmVudHNbcm91dGVdID0gcm91dGVJbmZvO1xuICAgICAgICAgICAgcmV0dXJuIHJvdXRlSW5mbztcbiAgICAgICAgfSBjYXRjaCAoZXJyMikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlUm91dGVJbmZvRXJyb3IoZXJyMiwgcGF0aG5hbWUsIHF1ZXJ5LCBhcywgcm91dGVQcm9wcyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2V0KHJvdXRlLCBwYXRobmFtZSwgcXVlcnksIGFzLCBkYXRhLCByZXNldFNjcm9sbCkge1xuICAgICAgICB0aGlzLmlzRmFsbGJhY2sgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5yb3V0ZSA9IHJvdXRlO1xuICAgICAgICB0aGlzLnBhdGhuYW1lID0gcGF0aG5hbWU7XG4gICAgICAgIHRoaXMucXVlcnkgPSBxdWVyeTtcbiAgICAgICAgdGhpcy5hc1BhdGggPSBhcztcbiAgICAgICAgcmV0dXJuIHRoaXMubm90aWZ5KGRhdGEsIHJlc2V0U2Nyb2xsKTtcbiAgICB9XG4gICAgLyoqXG4gICAqIENhbGxiYWNrIHRvIGV4ZWN1dGUgYmVmb3JlIHJlcGxhY2luZyByb3V0ZXIgc3RhdGVcbiAgICogQHBhcmFtIGNiIGNhbGxiYWNrIHRvIGJlIGV4ZWN1dGVkXG4gICAqLyBiZWZvcmVQb3BTdGF0ZShjYikge1xuICAgICAgICB0aGlzLl9icHMgPSBjYjtcbiAgICB9XG4gICAgb25seUFIYXNoQ2hhbmdlKGFzKSB7XG4gICAgICAgIGlmICghdGhpcy5hc1BhdGgpIHJldHVybiBmYWxzZTtcbiAgICAgICAgY29uc3QgW29sZFVybE5vSGFzaCwgb2xkSGFzaF0gPSB0aGlzLmFzUGF0aC5zcGxpdCgnIycpO1xuICAgICAgICBjb25zdCBbbmV3VXJsTm9IYXNoLCBuZXdIYXNoXSA9IGFzLnNwbGl0KCcjJyk7XG4gICAgICAgIC8vIE1ha2VzIHN1cmUgd2Ugc2Nyb2xsIHRvIHRoZSBwcm92aWRlZCBoYXNoIGlmIHRoZSB1cmwvaGFzaCBhcmUgdGhlIHNhbWVcbiAgICAgICAgaWYgKG5ld0hhc2ggJiYgb2xkVXJsTm9IYXNoID09PSBuZXdVcmxOb0hhc2ggJiYgb2xkSGFzaCA9PT0gbmV3SGFzaCkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgdGhlIHVybHMgYXJlIGNoYW5nZSwgdGhlcmUncyBtb3JlIHRoYW4gYSBoYXNoIGNoYW5nZVxuICAgICAgICBpZiAob2xkVXJsTm9IYXNoICE9PSBuZXdVcmxOb0hhc2gpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJZiB0aGUgaGFzaCBoYXMgY2hhbmdlZCwgdGhlbiBpdCdzIGEgaGFzaCBvbmx5IGNoYW5nZS5cbiAgICAgICAgLy8gVGhpcyBjaGVjayBpcyBuZWNlc3NhcnkgdG8gaGFuZGxlIGJvdGggdGhlIGVudGVyIGFuZFxuICAgICAgICAvLyBsZWF2ZSBoYXNoID09PSAnJyBjYXNlcy4gVGhlIGlkZW50aXR5IGNhc2UgZmFsbHMgdGhyb3VnaFxuICAgICAgICAvLyBhbmQgaXMgdHJlYXRlZCBhcyBhIG5leHQgcmVsb2FkLlxuICAgICAgICByZXR1cm4gb2xkSGFzaCAhPT0gbmV3SGFzaDtcbiAgICB9XG4gICAgc2Nyb2xsVG9IYXNoKGFzKSB7XG4gICAgICAgIGNvbnN0IFssIGhhc2hdID0gYXMuc3BsaXQoJyMnKTtcbiAgICAgICAgLy8gU2Nyb2xsIHRvIHRvcCBpZiB0aGUgaGFzaCBpcyBqdXN0IGAjYCB3aXRoIG5vIHZhbHVlIG9yIGAjdG9wYFxuICAgICAgICAvLyBUbyBtaXJyb3IgYnJvd3NlcnNcbiAgICAgICAgaWYgKGhhc2ggPT09ICcnIHx8IGhhc2ggPT09ICd0b3AnKSB7XG4gICAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gRmlyc3Qgd2UgY2hlY2sgaWYgdGhlIGVsZW1lbnQgYnkgaWQgaXMgZm91bmRcbiAgICAgICAgY29uc3QgaWRFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGhhc2gpO1xuICAgICAgICBpZiAoaWRFbCkge1xuICAgICAgICAgICAgaWRFbC5zY3JvbGxJbnRvVmlldygpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIElmIHRoZXJlJ3Mgbm8gZWxlbWVudCB3aXRoIHRoZSBpZCwgd2UgY2hlY2sgdGhlIGBuYW1lYCBwcm9wZXJ0eVxuICAgICAgICAvLyBUbyBtaXJyb3IgYnJvd3NlcnNcbiAgICAgICAgY29uc3QgbmFtZUVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeU5hbWUoaGFzaClbMF07XG4gICAgICAgIGlmIChuYW1lRWwpIHtcbiAgICAgICAgICAgIG5hbWVFbC5zY3JvbGxJbnRvVmlldygpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHVybElzTmV3KGFzUGF0aCkge1xuICAgICAgICByZXR1cm4gdGhpcy5hc1BhdGggIT09IGFzUGF0aDtcbiAgICB9XG4gICAgLyoqXG4gICAqIFByZWZldGNoIHBhZ2UgY29kZSwgeW91IG1heSB3YWl0IGZvciB0aGUgZGF0YSBkdXJpbmcgcGFnZSByZW5kZXJpbmcuXG4gICAqIFRoaXMgZmVhdHVyZSBvbmx5IHdvcmtzIGluIHByb2R1Y3Rpb24hXG4gICAqIEBwYXJhbSB1cmwgdGhlIGhyZWYgb2YgcHJlZmV0Y2hlZCBwYWdlXG4gICAqIEBwYXJhbSBhc1BhdGggdGhlIGFzIHBhdGggb2YgdGhlIHByZWZldGNoZWQgcGFnZVxuICAgKi8gYXN5bmMgcHJlZmV0Y2godXJsLCBhc1BhdGggPSB1cmwsIG9wdGlvbnMgPSB7XG4gICAgfSkge1xuICAgICAgICBsZXQgcGFyc2VkID0gKDAsIF9wYXJzZVJlbGF0aXZlVXJsKS5wYXJzZVJlbGF0aXZlVXJsKHVybCk7XG4gICAgICAgIGxldCB7IHBhdGhuYW1lOiBwYXRobmFtZTIgIH0gPSBwYXJzZWQ7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5sb2NhbGUgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICAgICAgcGF0aG5hbWUyID0gKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKHBhdGhuYW1lMiwgdGhpcy5sb2NhbGVzKS5wYXRobmFtZTtcbiAgICAgICAgICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSBwYXRobmFtZTI7XG4gICAgICAgICAgICAgICAgdXJsID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKTtcbiAgICAgICAgICAgICAgICBsZXQgcGFyc2VkQXMgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwoYXNQYXRoKTtcbiAgICAgICAgICAgICAgICBjb25zdCBsb2NhbGVQYXRoUmVzdWx0ID0gKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKHBhcnNlZEFzLnBhdGhuYW1lLCB0aGlzLmxvY2FsZXMpO1xuICAgICAgICAgICAgICAgIHBhcnNlZEFzLnBhdGhuYW1lID0gbG9jYWxlUGF0aFJlc3VsdC5wYXRobmFtZTtcbiAgICAgICAgICAgICAgICBvcHRpb25zLmxvY2FsZSA9IGxvY2FsZVBhdGhSZXN1bHQuZGV0ZWN0ZWRMb2NhbGUgfHwgdGhpcy5kZWZhdWx0TG9jYWxlO1xuICAgICAgICAgICAgICAgIGFzUGF0aCA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZEFzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwYWdlcyA9IGF3YWl0IHRoaXMucGFnZUxvYWRlci5nZXRQYWdlTGlzdCgpO1xuICAgICAgICBsZXQgcmVzb2x2ZWRBcyA9IGFzUGF0aDtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9IQVNfUkVXUklURVMgJiYgYXNQYXRoLnN0YXJ0c1dpdGgoJy8nKSkge1xuICAgICAgICAgICAgbGV0IHJld3JpdGVzO1xuICAgICAgICAgICAgKHsgX19yZXdyaXRlczogcmV3cml0ZXMgIH0gPSBhd2FpdCAoMCwgX3JvdXRlTG9hZGVyKS5nZXRDbGllbnRCdWlsZE1hbmlmZXN0KCkpO1xuICAgICAgICAgICAgY29uc3QgcmV3cml0ZXNSZXN1bHQgPSAoMCwgX3Jlc29sdmVSZXdyaXRlcykuZGVmYXVsdChhZGRCYXNlUGF0aChhZGRMb2NhbGUoYXNQYXRoLCB0aGlzLmxvY2FsZSkpLCBwYWdlcywgcmV3cml0ZXMsIHBhcnNlZC5xdWVyeSwgKHApPT5yZXNvbHZlRHluYW1pY1JvdXRlKHAsIHBhZ2VzKVxuICAgICAgICAgICAgLCB0aGlzLmxvY2FsZXMpO1xuICAgICAgICAgICAgcmVzb2x2ZWRBcyA9IGRlbExvY2FsZShkZWxCYXNlUGF0aChyZXdyaXRlc1Jlc3VsdC5hc1BhdGgpLCB0aGlzLmxvY2FsZSk7XG4gICAgICAgICAgICBpZiAocmV3cml0ZXNSZXN1bHQubWF0Y2hlZFBhZ2UgJiYgcmV3cml0ZXNSZXN1bHQucmVzb2x2ZWRIcmVmKSB7XG4gICAgICAgICAgICAgICAgLy8gaWYgdGhpcyBkaXJlY3RseSBtYXRjaGVzIGEgcGFnZSB3ZSBuZWVkIHRvIHVwZGF0ZSB0aGUgaHJlZiB0b1xuICAgICAgICAgICAgICAgIC8vIGFsbG93IHRoZSBjb3JyZWN0IHBhZ2UgY2h1bmsgdG8gYmUgbG9hZGVkXG4gICAgICAgICAgICAgICAgcGF0aG5hbWUyID0gcmV3cml0ZXNSZXN1bHQucmVzb2x2ZWRIcmVmO1xuICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IHBhdGhuYW1lMjtcbiAgICAgICAgICAgICAgICB1cmwgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcGFyc2VkLnBhdGhuYW1lID0gcmVzb2x2ZUR5bmFtaWNSb3V0ZShwYXJzZWQucGF0aG5hbWUsIHBhZ2VzKTtcbiAgICAgICAgICAgIGlmIChwYXJzZWQucGF0aG5hbWUgIT09IHBhdGhuYW1lMikge1xuICAgICAgICAgICAgICAgIHBhdGhuYW1lMiA9IHBhcnNlZC5wYXRobmFtZTtcbiAgICAgICAgICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSBwYXRobmFtZTI7XG4gICAgICAgICAgICAgICAgdXJsID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCByb3V0ZSA9ICgwLCBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCkucmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gocGF0aG5hbWUyKTtcbiAgICAgICAgLy8gUHJlZmV0Y2ggaXMgbm90IHN1cHBvcnRlZCBpbiBkZXZlbG9wbWVudCBtb2RlIGJlY2F1c2UgaXQgd291bGQgdHJpZ2dlciBvbi1kZW1hbmQtZW50cmllc1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgIHRoaXMucGFnZUxvYWRlci5faXNTc2cocm91dGUpLnRoZW4oKGlzU3NnKT0+e1xuICAgICAgICAgICAgICAgIHJldHVybiBpc1NzZyA/IHRoaXMuX2dldFN0YXRpY0RhdGEodGhpcy5wYWdlTG9hZGVyLmdldERhdGFIcmVmKHVybCwgcmVzb2x2ZWRBcywgdHJ1ZSwgdHlwZW9mIG9wdGlvbnMubG9jYWxlICE9PSAndW5kZWZpbmVkJyA/IG9wdGlvbnMubG9jYWxlIDogdGhpcy5sb2NhbGUpKSA6IGZhbHNlO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0aGlzLnBhZ2VMb2FkZXJbb3B0aW9ucy5wcmlvcml0eSA/ICdsb2FkUGFnZScgOiAncHJlZmV0Y2gnXShyb3V0ZSksIFxuICAgICAgICBdKTtcbiAgICB9XG4gICAgYXN5bmMgZmV0Y2hDb21wb25lbnQocm91dGUpIHtcbiAgICAgICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuICAgICAgICBjb25zdCBjYW5jZWwgPSB0aGlzLmNsYyA9ICgpPT57XG4gICAgICAgICAgICBjYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBjb21wb25lbnRSZXN1bHQgPSBhd2FpdCB0aGlzLnBhZ2VMb2FkZXIubG9hZFBhZ2Uocm91dGUpO1xuICAgICAgICBpZiAoY2FuY2VsbGVkKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihgQWJvcnQgZmV0Y2hpbmcgY29tcG9uZW50IGZvciByb3V0ZTogXCIke3JvdXRlfVwiYCk7XG4gICAgICAgICAgICBlcnJvci5jYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNhbmNlbCA9PT0gdGhpcy5jbGMpIHtcbiAgICAgICAgICAgIHRoaXMuY2xjID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29tcG9uZW50UmVzdWx0O1xuICAgIH1cbiAgICBfZ2V0RGF0YShmbikge1xuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IGNhbmNlbCA9ICgpPT57XG4gICAgICAgICAgICBjYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLmNsYyA9IGNhbmNlbDtcbiAgICAgICAgcmV0dXJuIGZuKCkudGhlbigoZGF0YSk9PntcbiAgICAgICAgICAgIGlmIChjYW5jZWwgPT09IHRoaXMuY2xjKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jbGMgPSBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNhbmNlbGxlZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycjIgPSBuZXcgRXJyb3IoJ0xvYWRpbmcgaW5pdGlhbCBwcm9wcyBjYW5jZWxsZWQnKTtcbiAgICAgICAgICAgICAgICBlcnIyLmNhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyMjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgX2dldFN0YXRpY0RhdGEoZGF0YUhyZWYpIHtcbiAgICAgICAgY29uc3QgeyBocmVmOiBjYWNoZUtleSAgfSA9IG5ldyBVUkwoZGF0YUhyZWYsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAncHJvZHVjdGlvbicgJiYgIXRoaXMuaXNQcmV2aWV3ICYmIHRoaXMuc2RjW2NhY2hlS2V5XSkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh0aGlzLnNkY1tjYWNoZUtleV0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmZXRjaE5leHREYXRhKGRhdGFIcmVmLCB0aGlzLmlzU3NyKS50aGVuKChkYXRhKT0+e1xuICAgICAgICAgICAgdGhpcy5zZGNbY2FjaGVLZXldID0gZGF0YTtcbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgX2dldFNlcnZlckRhdGEoZGF0YUhyZWYpIHtcbiAgICAgICAgY29uc3QgeyBocmVmOiByZXNvdXJjZUtleSAgfSA9IG5ldyBVUkwoZGF0YUhyZWYsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgaWYgKHRoaXMuc2RyW3Jlc291cmNlS2V5XSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2RyW3Jlc291cmNlS2V5XTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5zZHJbcmVzb3VyY2VLZXldID0gZmV0Y2hOZXh0RGF0YShkYXRhSHJlZiwgdGhpcy5pc1NzcikudGhlbigoZGF0YSk9PntcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLnNkcltyZXNvdXJjZUtleV07XG4gICAgICAgICAgICByZXR1cm4gZGF0YTtcbiAgICAgICAgfSkuY2F0Y2goKGVycjIpPT57XG4gICAgICAgICAgICBkZWxldGUgdGhpcy5zZHJbcmVzb3VyY2VLZXldO1xuICAgICAgICAgICAgdGhyb3cgZXJyMjtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGdldEluaXRpYWxQcm9wcyhDb21wb25lbnQsIGN0eCkge1xuICAgICAgICBjb25zdCB7IENvbXBvbmVudDogQXBwMSAgfSA9IHRoaXMuY29tcG9uZW50c1snL19hcHAnXTtcbiAgICAgICAgY29uc3QgQXBwVHJlZSA9IHRoaXMuX3dyYXBBcHAoQXBwMSk7XG4gICAgICAgIGN0eC5BcHBUcmVlID0gQXBwVHJlZTtcbiAgICAgICAgcmV0dXJuICgwLCBfdXRpbHMpLmxvYWRHZXRJbml0aWFsUHJvcHMoQXBwMSwge1xuICAgICAgICAgICAgQXBwVHJlZSxcbiAgICAgICAgICAgIENvbXBvbmVudCxcbiAgICAgICAgICAgIHJvdXRlcjogdGhpcyxcbiAgICAgICAgICAgIGN0eFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgYWJvcnRDb21wb25lbnRMb2FkKGFzLCByb3V0ZVByb3BzKSB7XG4gICAgICAgIGlmICh0aGlzLmNsYykge1xuICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJywgYnVpbGRDYW5jZWxsYXRpb25FcnJvcigpLCBhcywgcm91dGVQcm9wcyk7XG4gICAgICAgICAgICB0aGlzLmNsYygpO1xuICAgICAgICAgICAgdGhpcy5jbGMgPSBudWxsO1xuICAgICAgICB9XG4gICAgfVxuICAgIG5vdGlmeShkYXRhLCByZXNldFNjcm9sbCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zdWIoZGF0YSwgdGhpcy5jb21wb25lbnRzWycvX2FwcCddLkNvbXBvbmVudCwgcmVzZXRTY3JvbGwpO1xuICAgIH1cbn1cblJvdXRlci5ldmVudHMgPSAoMCwgX21pdHQpLmRlZmF1bHQoKTtcbmV4cG9ydHMuZGVmYXVsdCA9IFJvdXRlcjtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGVyLmpzLm1hcCIsImltcG9ydCBSZWFjdCwge3VzZUVmZmVjdCwgdXNlU3RhdGV9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cyc7XHJcbmltcG9ydCB0eXBlIHsgTmV4dFBhZ2UgfSBmcm9tICduZXh0J1xyXG5pbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnO1xyXG5pbXBvcnQgRmFxIGZyb20gJy4uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL0ZhcSc7XHJcbmltcG9ydCBIZXJvIGZyb20gJy4uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL0hlcm8vSGVybyc7XHJcbmltcG9ydCBOYXZCYXIgZnJvbSAnLi4vc3JjL2NvbXBvbmVudHMvU2hhcmVkL05hdkJhci9OYXZCYXInO1xyXG5pbXBvcnQgV2hhdERhIGZyb20gJy4uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL1doYXREYSc7XHJcbmltcG9ydCBDb21tdW5pdHkgZnJvbSAnLi4vc3JjL2NvbXBvbmVudHMvTGFuZGluZ1BhZ2UvQ29tbXVuaXR5JztcclxuaW1wb3J0IEZvb3RlciBmcm9tICcuLi9zcmMvY29tcG9uZW50cy9MYW5kaW5nUGFnZS9Gb290ZXInO1xyXG5pbXBvcnQgUm9hZG1hcCBmcm9tICcuLi9zcmMvY29tcG9uZW50cy9MYW5kaW5nUGFnZS9Sb2FkbWFwL1JvYWRtYXAnO1xyXG5pbXBvcnQgRXZvbHV0aW9uIGZyb20gJy4uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL0V2b2x1dGlvbi9Fdm9sdXRpb24nO1xyXG5pbXBvcnQgRWdncyBmcm9tICcuLi9zcmMvY29tcG9uZW50cy9MYW5kaW5nUGFnZS9FZ2dzJztcclxuaW1wb3J0IEJ1bm5pZXNDYXJvdXNlbCBmcm9tICcuLi9zcmMvY29tcG9uZW50cy9MYW5kaW5nUGFnZS9CdW5uaWVzQ2Fyb3VzZWwnO1xyXG5cclxuaW1wb3J0IHsgV2ViM1Byb3ZpZGVyIH0gZnJvbSAnQGV0aGVyc3Byb2plY3QvcHJvdmlkZXJzJztcclxuaW1wb3J0IHsgZXRoZXJzIH0gZnJvbSBcImV0aGVyc1wiO1xyXG5pbXBvcnQgV2ViM01vZGFsIGZyb20gJ3dlYjNtb2RhbCc7XHJcbmltcG9ydCBXYWxsZXRDb25uZWN0UHJvdmlkZXIgZnJvbSAnQHdhbGxldGNvbm5lY3Qvd2ViMy1wcm92aWRlcic7XHJcbmltcG9ydCBNaW50Qm94IGZyb20gJy4uL3NyYy9jb21wb25lbnRzL0xhbmRpbmdQYWdlL01pbnRCb3gvTWludEJveCc7XHJcblxyXG5pbXBvcnQgeyBnZXRORlRBZGRyZXNzLCBnZXRORlRDb250cmFjdCB9IGZyb20gJy4uL3NyYy91dGlscy93ZWIzbGliJztcclxuaW1wb3J0IHsgSW50MzIgfSBmcm9tICdic29uJztcclxuXHJcblxyXG5jb25zdCBMYW5kaW5nV3JhcCA9IHN0eWxlZC5tYWluYFxyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbmA7XHJcblxyXG5jb25zdCBEYUJ1bm55X05GVF9BZGRyZXNzID0gcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfREFCVU5OWV9ORlRDT05UUkFDVF9BRERSRVNTO1xyXG5jb25zdCBJTkZVUkFfSUQgPSBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19JTkZVUkFfQVBJX0tFWV8xO1xyXG5cclxuY29uc3QgSG9tZTogTmV4dFBhZ2UgPSAoKSA9PiB7XHJcbiAgY29uc3QgW25ldHdvcmtOYW1lLCBzZXROZXR3b3JrTmFtZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3Byb3ZpZGVyLCBzZXRQcm92aWRlcl0gPSB1c2VTdGF0ZTxXZWIzUHJvdmlkZXI+KCk7XHJcbiAgY29uc3QgW3VzZXJCYWxhbmNlLCBzZXRVc2VyQmFsYW5jZV0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbYWRkcmVzcywgc2V0QWRkcmVzc10gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3VzZXJEYXRhLCBzZXRVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7IGFkZHJlc3M6ICcnLCBiYWxhbmNlOiAwLCBuZXR3b3JrOiAnJ30pO1xyXG4gIGNvbnN0IFttZXNzYWdlICwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnJyk7XHJcblxyXG4gIGNvbnN0IHByb3ZpZGVyT3B0aW9ucyA9IHtcclxuICAgIHdhbGxldGNvbm5lY3Q6IHtcclxuICAgICAgcGFja2FnZTogV2FsbGV0Q29ubmVjdFByb3ZpZGVyLCAvLyByZXF1aXJlZFxyXG4gICAgICBvcHRpb25zOiB7XHJcbiAgICAgICAgaW5mdXJhSWQ6IElORlVSQV9JRCAvLyByZXF1aXJlZFxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgaW50ZXJmYWNlIGFzc2V0RCB7XHJcbiAgICBidXllckFkZHJlc3M6IHN0cmluZyxcclxuICAgIG5vcm1hbFRva2VuSWRzOiBudW1iZXIgW10sXHJcbiAgICByYXJlVG9rZW5JZHM6IG51bWJlciBbXSxcclxuICAgIHRvdGFsUHJpY2VQYWlkOiBudW1iZXIsXHJcbiAgICBlbWFpbElkOiBzdHJpbmcsXHJcbiAgICBzdWJzY3JpYmVTdGF0dXM6IGJvb2xlYW4sXHJcbiAgICBwdXJjaGFzZWRUaW1lU3RhbXA6IG51bWJlcixcclxuICB9XHJcblxyXG4gIGxldCBhc3NldERhdGE6IGFzc2V0RCA9IHtcclxuICAgIGJ1eWVyQWRkcmVzczogJycsXHJcbiAgICBub3JtYWxUb2tlbklkczogW10sXHJcbiAgICByYXJlVG9rZW5JZHM6IFtdLFxyXG4gICAgdG90YWxQcmljZVBhaWQ6IDAsXHJcbiAgICBlbWFpbElkOiAnJyxcclxuICAgIHN1YnNjcmliZVN0YXR1czogZmFsc2UsXHJcbiAgICBwdXJjaGFzZWRUaW1lU3RhbXA6IDAsXHJcbiAgfVxyXG5cclxuXHJcbiAgLy9JdCBpcyBjYWxsZWQgd2hlbiBtaW50IGJ1dHRvbiBpcyBwcmVzc2VkLlxyXG4gIGNvbnN0IG9uTWludFRva2VuID0gYXN5bmMgKGU6YW55LCB0b2tlbkNvdW50Om51bWJlciwgaXNSYXJpdHk6Ym9vbGVhbikgPT4ge1xyXG4gICAgLy8gY29uc29sZS5sb2coJ01pbnQgdG9rZW4gY2xpY2tlZC4uLicsIHRva2VuQ291bnQsIHJhcml0eSk7XHJcbiAgICBcclxuICAgIC8vIHRva2VuQ291bnQgPSAyO1xyXG4gICAgbGV0IHRva2VuUHJpY2UgPSBpc1Jhcml0eSA/IDAuMTIgOiAwLjA4OyBcclxuICAgIC8vIGxldCB0b2tlblByaWNlID0gMC4wNTtcclxuICAgIGNvbnNvbGUubG9nKCdvbk1pbnRUb2tlbiBjYWxsZWQgLi4uJywgdG9rZW5Db3VudCwgdG9rZW5QcmljZSk7XHJcbiAgICAvLyByZXR1cm47XHJcblxyXG4gICAgY29uc29sZS5sb2coJ0RhYnVubnkgYWRkcmVzczonLCBEYUJ1bm55X05GVF9BZGRyZXNzKTtcclxuICAgIGNvbnNvbGUubG9nKCduZnQgYWRkcmVzcyBmcm9tIHdlYjNsaWI6JywgZ2V0TkZUQWRkcmVzcygpKTtcclxuICAgIGlmKHByb3ZpZGVyKXtcclxuICAgICAgbGV0IHNpZ25lciA9IHByb3ZpZGVyLmdldFNpZ25lcigpO1xyXG4gICAgICBjb25zdCBhY2NvdW50QWRkcmVzcyA9IGF3YWl0IHNpZ25lci5nZXRBZGRyZXNzKCk7XHJcbiAgICAgIGNvbnNvbGUubG9nKGFjY291bnRBZGRyZXNzKTtcclxuXHJcbiAgICAgIGNvbnN0IG5mdENvbnRyYWN0ID0gYXdhaXQgZ2V0TkZUQ29udHJhY3Qoc2lnbmVyKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBsZXQgcmVjZWlwdCA9IGF3YWl0IHR4LndhaXQoKVxyXG4gICAgICAgIGNvbnN0IHByaWNlID0gZXRoZXJzLnV0aWxzLnBhcnNlRXRoZXIoKHRva2VuUHJpY2UqdG9rZW5Db3VudCkudG9TdHJpbmcoKSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ1ByaWNlIG9mIGFzc2V0OicsIHByaWNlLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgIGxldCByZWNlaXB0ID0gYXdhaXQgbmZ0Q29udHJhY3QubWludCh0b2tlbkNvdW50LCBpc1Jhcml0eSwge3ZhbHVlOiBwcmljZX0pXHJcbiAgICAgICAgLnRoZW4oIGFzeW5jICh0eDogYW55KSA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiB0eC53YWl0KCkudGhlbigocmVjZWlwdDogYW55KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1JlY2VpcHQ6JywgcmVjZWlwdCk7XHJcbiAgICAgICAgICAgICAgbGV0IHRva2VuSWRzOiBudW1iZXJbXSA9IFtdO1xyXG4gICAgICAgICAgICAgIHJlY2VpcHQuZXZlbnRzLmZvckVhY2goKGV2ZW50OiBhbnkpID0+IHtcclxuICAgICAgICAgICAgICAgIHRva2VuSWRzLnB1c2goTnVtYmVyKGV2ZW50LmFyZ3NbMl0pKTtcclxuICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgIC8vIGxldCB2YWx1ZSA9IHJlY2VpcHQuZXZlbnRzWzBdLmFyZ3NbMl07XHJcbiAgICAgICAgICAgICAgLy8gbGV0IHRva2VuSWQgPSB2YWx1ZS50b051bWJlcigpO1xyXG4gICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiVG9rZW5JZCBtaW50ZWQ6OlwiLCB0b2tlbklkKTtcclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgaWYoIWlzUmFyaXR5KSBcclxuICAgICAgICAgICAgICAgICAgICBhc3NldERhdGEubm9ybWFsVG9rZW5JZHMgPSB0b2tlbklkcztcclxuICAgICAgICAgICAgICAgIGlmKGlzUmFyaXR5KVxyXG4gICAgICAgICAgICAgICAgICAgIGFzc2V0RGF0YS5yYXJlVG9rZW5JZHMgPSB0b2tlbklkcztcclxuICAgICAgICAgICAgICAgIGFzc2V0RGF0YS5idXllckFkZHJlc3MgPSB1c2VyRGF0YS5hZGRyZXNzO1xyXG4gICAgICAgICAgICAgICAgYXNzZXREYXRhLnRvdGFsUHJpY2VQYWlkID0gTnVtYmVyKHRva2VuUHJpY2UqdG9rZW5Db3VudCk7XHJcbiAgICAgICAgICAgICAgICBhc3NldERhdGEucHVyY2hhc2VkVGltZVN0YW1wID0gTnVtYmVyKG5ldyBEYXRlKCkpO1xyXG4gIFxyXG4gICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gZmV0Y2goJy9hcGkvYXNzZXRzJywge1xyXG4gICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGFzc2V0RGF0YSksXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdFcnJvciB3aGlsZSB1cGRhdGluZyBkYXRhIHRvIEJhY2tlbmQnLCBlcnIpO1xyXG4gICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIHN0YXR1czogJ1N1Y2Nlc3MnLFxyXG4gICAgICAgICAgICAgICAgZGF0YTogJ1Rva2VuSWQ6JysgdG9rZW5JZHMudG9TdHJpbmcoKSxcclxuICAgICAgICAgICAgICAgIGVycm9yOiAnJyBcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH0sIChlcnJvcjogYW55KSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygnRVJST1Igb2NjdXJlZDE6OicsIGVycm9yKTtcclxuICAgICAgICAgIGxldCBlcnJNZXNzID0gZXJyb3IubWVzc2FnZS5zdGFydHNXaXRoKCdNZXRhTWFzaycpID8gZXJyb3IubWVzc2FnZTogZXJyb3IuZXJyb3IubWVzc2FnZSA/IGVycm9yLmVycm9yLm1lc3NhZ2UgOiBlcnJvci5tZXNzYWdlIDtcclxuICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHN0YXR1czogJ0ZhaWxlZCcsXHJcbiAgICAgICAgICAgIGRhdGE6ICcnLFxyXG4gICAgICAgICAgICBlcnJvcjogZXJyTWVzc1xyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc29sZS5sb2coJ0ZpYW5sIFN0YXR1cyA6OiByZWNlaXB0OjonLCByZWNlaXB0KTtcclxuICAgICAgICBpZihyZWNlaXB0LnN0YXR1cyA9PT0gJ0ZhaWxlZCcpXHJcbiAgICAgICAgICBzZXRNZXNzYWdlKHJlY2VpcHQuZXJyb3IpO1xyXG4gICAgICAgIGVsc2Ugc2V0TWVzc2FnZShyZWNlaXB0LmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdNaW50aW5nIEZhaWxlZDonLCBlcnIubWVzc2FnZSk7XHJcbiAgICAgICAgc2V0TWVzc2FnZShcIk1pbnRpbmcgRmFpbGVkOiBcIisgZXJyLm1lc3NhZ2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBlbHNle1xyXG4gICAgICBjb25zb2xlLmxvZygnUGxlYXNlIGxvZ2luIHRvIHdhbGxldCcpO1xyXG4gICAgICBhbGVydChcIlBsZWFzZSBsb2dpbiB0byBDb25uZWN0IHRvIFdhbGxldFwiKVxyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICAvL0l0IGlzIGNhbGxlZCB3aGVuIGNvbm5lY3Qgd2FsbGV0IGJ1dHRvbiBpcyBjbGlja2VkIFxyXG4gIGNvbnN0IG9uQ29ubmVjdFdhbGxldCA9IGFzeW5jICgpID0+IHtcclxuXHJcbiAgICBjb25zb2xlLmxvZygnV2FsbGV0IGNvbm5lY3QgY2xpY2tlZC4uLicpO1xyXG4gICAgXHJcbiAgICBpZighdXNlckRhdGEuYWRkcmVzcyl7XHJcbiAgICAgIGxldCB3ZWIzTW9kYWwgPSBuZXcgV2ViM01vZGFsKHtcclxuICAgICAgICAvL25ldHdvcms6IFwibWFpbm5ldFwiLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIGNhY2hlUHJvdmlkZXI6IGZhbHNlLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIHByb3ZpZGVyT3B0aW9ucywgLy8gcmVxdWlyZWRcclxuICAgICAgfSk7XHJcbiAgICAgIHdlYjNNb2RhbC5jbGVhckNhY2hlZFByb3ZpZGVyKCk7XHJcbiAgICAgIGxldCB3ZWIzcHJvdmlkZXIgPSBhd2FpdCB3ZWIzTW9kYWwuY29ubmVjdCgpO1xyXG4gICAgICBjb25zb2xlLmxvZygnV2ViM01vZGFsLmNvbm5lY3Q6OicsIHdlYjNwcm92aWRlcik7XHJcbiAgICAgIFxyXG4gICAgICB3ZWIzcHJvdmlkZXIgPSBuZXcgV2ViM1Byb3ZpZGVyKHdlYjNwcm92aWRlcik7XHJcbiAgICAgIGNvbnNvbGUubG9nKCd3ZWIzcHJvdmlkZXI6OicsIHdlYjNwcm92aWRlcik7XHJcbiAgICAgIHNldFByb3ZpZGVyKHdlYjNwcm92aWRlcik7XHJcblxyXG4gICAgICBpZiAod2ViM3Byb3ZpZGVyKSB7XHJcbiAgICAgICAgbGV0IG5ldHdvcmtkYXRhID0gYXdhaXQgd2ViM3Byb3ZpZGVyLmdldE5ldHdvcmsoKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIk5ldHdvcmsgRGF0YTo6XCIsIG5ldHdvcmtkYXRhKTtcclxuICAgICAgICBjb25zb2xlLmxvZygnTmFtZTonLCBuZXR3b3JrZGF0YS5uYW1lKTtcclxuICAgICAgICBpZihuZXR3b3JrZGF0YS5uYW1lICE9PSBcInJpbmtlYnlcIil7XHJcbiAgICAgICAgICBzZXRNZXNzYWdlKCdQbGVhc2Ugc3dpdGNoIHRvIHJpbmtlYnkgbmV0d29yaycpO1xyXG4gICAgICAgICAgY29uc29sZS5sb2coJ1BsZWFzZSBzd2l0Y2ggdG8gcmlua2VieSBuZXR3b3JrJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgc2lnbmVyID0gd2ViM3Byb3ZpZGVyLmdldFNpZ25lcigpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdzaWduZXI6Jywgc2lnbmVyKTtcclxuICAgICAgICBcclxuICAgICAgICBsZXQgYWRkID0gYXdhaXQgc2lnbmVyLmdldEFkZHJlc3MoKTtcclxuICAgICAgICBjb25zb2xlLmxvZygnYWRkcmVzczogJywgYWRkKTtcclxuICAgICAgICBsZXQgYmFsID0gTnVtYmVyKGV0aGVycy51dGlscy5mb3JtYXRFdGhlcigoYXdhaXQgc2lnbmVyLmdldEJhbGFuY2UoKSkudG9TdHJpbmcoKSkpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiQWNjb3VudHM6XCIsIGFkZCk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJCYWxhbmNlOlwiLGJhbCk7XHJcbiAgICAgICAgc2V0TmV0d29ya05hbWUobmV0d29ya2RhdGEubmFtZSk7XHJcbiAgICAgICAgc2V0QWRkcmVzcyhhZGQpO1xyXG4gICAgICAgIHNldFVzZXJCYWxhbmNlKGJhbCk7XHJcbiAgICAgICAgc2V0VXNlckRhdGEoe2FkZHJlc3M6IGFkZCwgYmFsYW5jZTogYmFsLCBuZXR3b3JrOiBuZXR3b3JrZGF0YS5uYW1lfSk7XHJcbiAgICAgICAgLy8gc2V0TWVzc2FnZSgnQ29ubmVjdCBzdWNjZXNzZnVsbHknKTtcclxuICAgICAgfVxyXG4gICAgfWVsc2V7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdVc2VyIGxvZ2dlZCBvdXQuLi4hISEnKTtcclxuICAgICAgLy8gc2V0TWVzc2FnZSgnZGlzY29ubmVjdGVkJylcclxuICAgICAgc2V0VXNlckRhdGEoe2FkZHJlc3M6ICcnLCBiYWxhbmNlOiAwLCBuZXR3b3JrOiAnJ30pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxIZWFkPlxyXG4gICAgICAgIDx0aXRsZT5Ib21lIHwgRGFidW5ueTwvdGl0bGU+XHJcbiAgICAgICAgPG1ldGEgbmFtZT1cInZpZXdwb3J0XCIgY29udGVudD1cImluaXRpYWwtc2NhbGU9MS4wLCB3aWR0aD1kZXZpY2Utd2lkdGhcIiBrZXk9XCJ2aWV3cG9ydFwiIC8+XHJcbiAgICAgICAgPG1ldGEgbmFtZT1cImRlc2NyaXB0aW9uXCIgY29udGVudD1cIkRhYnVubnkgY3VyYXRlZCBORlQgYXJ0XCIgLz5cclxuICAgICAgICA8bWV0YSBuYW1lPVwicm9ib3RzXCIgY29udGVudD1cImluZGV4LCBmb2xsb3dcIiAvPlxyXG4gICAgICAgIDxtZXRhIGh0dHBFcXVpdj1cIkNvbnRlbnQtVHlwZVwiIGNvbnRlbnQ9XCJ0ZXh0L2h0bWw7Y2hhcnNldD1VVEYtOFwiIC8+XHJcbiAgICAgICAgPG1ldGEgbmFtZT1cImtleXdvcmRzXCIgY29udGVudD1cIk5GVCwgYXJ0LCBibG9ja2NoYWluLCBkaWdpdGFsIGFydCwgY29sbGVjdGlvbiwgdG9rZW5cIiAvPlxyXG4gICAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6dGl0bGVcIiBjb250ZW50PVwiRGFidW5ueSBORlRcIiAvPlxyXG4gICAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6ZGVzY3JpcHRpb25cIiBjb250ZW50PVwiRGFidW5ueSBjdXJhdGVkIE5GVCBhcnRcIiAvPlxyXG4gICAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6aW1hZ2VcIiBjb250ZW50PVwiLi4vcHVibGljL2ltZy9idW5ueTEucG5nXCIgLz5cclxuICAgICAgICA8bWV0YSBwcm9wZXJ0eT1cIm9nOnVybFwiIGNvbnRlbnQ9XCJodHRwczovL3d3dy5kYWJ1bm55bmZ0LmNvbS9cIiAvPlxyXG4gICAgICAgIDxtZXRhIG5hbWU9XCJ0d2l0dGVyOmNhcmRcIiBjb250ZW50PVwic3VtbWFyeV9sYXJnZV9pbWFnZVwiIC8+XHJcbiAgICAgICAgPG1ldGEgcHJvcGVydHk9XCJvZzpzaXRlX25hbWVcIiBjb250ZW50PVwiRGFidW5ueSBORlRcIiAvPlxyXG4gICAgICAgIDxtZXRhIG5hbWU9XCJ0d2l0dGVyOmltYWdlOmFsdFwiIGNvbnRlbnQ9XCJEYWJ1bm55IE5GVFwiIC8+XHJcbiAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIGhyZWY9XCIvaW1nL2Zhdmljb24ucG5nXCIgLz5cclxuICAgICAgPC9IZWFkPlxyXG5cclxuICAgICAgPExhbmRpbmdXcmFwPlxyXG4gICAgICAgIDxOYXZCYXIgey4uLnVzZXJEYXRhfSBvbkNvbm5lY3RXYWxsZXQ9e29uQ29ubmVjdFdhbGxldH0vPlxyXG4gICAgICAgIDxIZXJvIHsuLi51c2VyRGF0YX0gcHJvdmlkZXI9e3Byb3ZpZGVyfSBvbk1pbnRUb2tlbj17b25NaW50VG9rZW59Lz5cclxuICAgICAgIHsvKiAgPE1pbnRCb3ggey4uLnVzZXJEYXRhfSBwcm92aWRlcj17cHJvdmlkZXJ9IG9uTWludFRva2VuPXtvbk1pbnRUb2tlbn0vPiovfVxyXG4gICAgICAgIHsvKiA8ZGl2PjxoND57bWVzc2FnZX08L2g0PjwvZGl2PiAgKi99XHJcbiAgICAgICAgPFdoYXREYSAvPlxyXG4gICAgICAgIDxCdW5uaWVzQ2Fyb3VzZWwgLz5cclxuICAgICAgICA8RXZvbHV0aW9uIC8+XHJcbiAgICAgICAgPEVnZ3MgLz5cclxuICAgICAgICA8Q29tbXVuaXR5IC8+XHJcbiAgICAgICAgPFJvYWRtYXAgLz5cclxuICAgICAgICA8RmFxIC8+XHJcbiAgICAgICAgPEZvb3RlciB7Li4udXNlckRhdGF9Lz5cclxuICAgICAgPC9MYW5kaW5nV3JhcD5cclxuICAgIDwvPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgSG9tZVxyXG5cclxuIiwiXHJcbmltcG9ydCBJbWFnZSBmcm9tICduZXh0L2ltYWdlJztcclxuaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VTd2lwZWFibGUgfSBmcm9tIFwicmVhY3Qtc3dpcGVhYmxlXCI7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCBmb250cyBmcm9tICcuLi8uLi9zdHlsZXMvdHlwb2dyYXBoeSc7XHJcbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9QcmVwIENvbXBvbmVudHNcclxuXHJcbmxldCBoaXN0b3J5SXRlbXMgPSBbXHJcbiAge1xyXG4gICAgaW1hZ2U6IGBTbGlkZUJhcl8xYCxcclxuICB9LFxyXG4gIHtcclxuICAgIGltYWdlOiBgU2xpZGVCYXJfMmAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpbWFnZTogYFNsaWRlQmFyXzNgLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaW1hZ2U6IGBTbGlkZUJhcl80YCxcclxuICB9LFxyXG4gIHtcclxuICAgIGltYWdlOiBgU2xpZGVCYXJfNWAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpbWFnZTogYFNsaWRlQmFyXzZgLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaW1hZ2U6IGBTbGlkZUJhcl83YCxcclxuICB9LFxyXG5dO1xyXG5cclxuXHJcbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1N0eWxlc1xyXG5cclxuY29uc3QgU2VjdGlvbldyYXAgPSBzdHlsZWQuc2VjdGlvbmBcclxuICBiYWNrZ3JvdW5kOiAjYWNkZmZiO1xyXG5gO1xyXG5cclxuY29uc3QgSXRlbVdyYXAgPSBzdHlsZWQuZGl2YFxyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgKiB7XHJcbiAgICB3aWR0aDogY2FsYygxMDB2dy83KTtcclxuXHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICAgIHdpZHRoOiAxNy41dnc7XHJcbiAgICB9XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgICAgd2lkdGg6IDMwdnc7XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQmxvY2sgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG5gO1xyXG5cclxuY29uc3QgUGFyYWdyYXBoID0gc3R5bGVkLnBgXHJcbiAgZGlzcGxheTogbm9uZTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbWFyZ2luLXRvcDogNDhweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHBhZGRpbmc6IDAgMzJweCAzMnB4IDMycHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDk3MHB4KSB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE0NDAuZm9udFNpemV9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzc2OC5mb250U2l6ZX07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc1MDAuZm9udFNpemV9O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEl0ZW0gPSAoeyBpbWFnZSB9OiB7IGltYWdlOiBzdHJpbmc7IH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPEl0ZW1XcmFwPlxyXG4gICAgICA8SW1hZ2VcclxuICAgICAgICBzcmM9e2AvaW1nLyR7aW1hZ2V9LnBuZ2B9XHJcbiAgICAgICAgYWx0PVwiYnVubnlcIlxyXG4gICAgICAgIHdpZHRoPXszMjB9XHJcbiAgICAgICAgaGVpZ2h0PXszMjB9XHJcbiAgICAgIC8+XHJcbiAgICA8L0l0ZW1XcmFwPlxyXG4gICk7XHJcbn07XHJcblxyXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9Db21wb25lbnRcclxuXHJcbmNvbnN0IEJ1bm5pZXNDYXJvdXNlbCA9ICgpID0+IHtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgcHJlc3NIb2xkKCk7XHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHByZXNzSG9sZCA9ICgpID0+IHtcclxuICAgIGxldCBjbGlja2VkID0gZmFsc2U7XHJcbiAgICBsZXQgY291bnQ6IG51bWJlciwgZGlyZWN0aW9uOiBudW1iZXIsIHNpemVTbGlkZXI6IG51bWJlciwgc3RhdGU6IG51bWJlciwgdGFyZ2V0O1xyXG4gICAgbGV0IGl0ZW0gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJ1bm5pZXNab25lXCIpIGFzIGFueTtcclxuICAgIGxldCBleHBhbnNpb25SYXRlID0gMjIuNTsgLy8gc3BlZWQgZm9yIGRlc2t0b3BcclxuXHJcbiAgICBpdGVtLmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZWRvd25cIiwgKGV2OiBFdmVudCkgPT4ge1xyXG4gICAgICBldi5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICBpdGVtID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJidW5uaWVzWm9uZVwiKSBhcyBIVE1MRWxlbWVudDtcclxuICAgICAgdGFyZ2V0ID0gaXRlbS5zdHlsZS50cmFuc2Zvcm07XHJcbiAgICAgIHNpemVTbGlkZXIgPSAoaXRlbS5jaGlsZHJlbi5sZW5ndGggLSAxKSAqIGV4cGFuc2lvblJhdGU7XHJcbiAgICAgIHN0YXRlID0gcGFyc2VJbnQodGFyZ2V0LnN1YnN0cmluZygxMSwgdGFyZ2V0LmluZGV4T2YoXCIpXCIpIC0gMSkpO1xyXG4gICAgICBjbGlja2VkID0gdHJ1ZTtcclxuICAgICAgY291bnQgPSAwO1xyXG4gICAgfSk7XHJcblxyXG4gICAgaXRlbS5hZGRFdmVudExpc3RlbmVyKFwibW91c2Vtb3ZlXCIsIChldjogYW55KSA9PiB7XHJcbiAgICAgIGV2LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgIGlmIChjbGlja2VkKSB7XHJcbiAgICAgICAgZGlyZWN0aW9uID0gZXYubW92ZW1lbnRYIDwgMCA/IC0xIDogMTtcclxuICAgICAgICBjb3VudCA9IGNvdW50ICsgZGlyZWN0aW9uIC8gNTtcclxuICAgICAgICBpdGVtLnN0eWxlLnRyYW5zZm9ybSA9IGB0cmFuc2xhdGVYKCR7c3RhdGUgKyBjb3VudCAqIDJ9dncpYC5yZXBsYWNlKFxyXG4gICAgICAgICAgXCItLVwiLFxyXG4gICAgICAgICAgXCItXCJcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIGl0ZW0uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNldXBcIiwgKGV2OiBFdmVudCkgPT4ge1xyXG4gICAgICBjb25zdCBvbmVFbGVtZW50V2lkdGggPSBpdGVtLmZpcnN0Q2hpbGQub2Zmc2V0V2lkdGg7XHJcbiAgICAgIGNvbnN0IG51bWJlck9mRWxlbWVudCA9IGl0ZW0uY2hpbGRyZW4ubGVuZ3RoO1xyXG4gICAgICBjb25zdCBuZXh0UG9zaXRpb24gPSAob25lRWxlbWVudFdpZHRoICogbnVtYmVyT2ZFbGVtZW50IC8gd2luZG93LmlubmVyV2lkdGggLSAxKSAqIC0xMDA7XHJcbiAgICAgIGNvbnN0IHByZXZpb3VzUG9zaXRpb24gPSAwO1xyXG5cclxuICAgICAgZXYucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgY2xpY2tlZCA9IGZhbHNlO1xyXG4gICAgICBjb3VudCA9IDA7XHJcbiAgICAgIGlmIChkaXJlY3Rpb24gPT09IDEpIHtcclxuICAgICAgICBzdGF0ZSA9IHByZXZpb3VzUG9zaXRpb247XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc3RhdGUgPSBuZXh0UG9zaXRpb247XHJcbiAgICAgIH1cclxuICAgICAgaXRlbS5zdHlsZS50cmFuc2l0aW9uID0gYGFsbCAuNXMgZWFzZS1vdXRgO1xyXG4gICAgICBpdGVtLnN0eWxlLnRyYW5zZm9ybSA9IGB0cmFuc2xhdGVYKCR7c3RhdGV9dncpYC5yZXBsYWNlKFwiLS1cIiwgXCItXCIpO1xyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBpdGVtLnN0eWxlLnRyYW5zaXRpb24gPSBcIlwiO1xyXG4gICAgICB9LCA1MDApO1xyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2V0VmFyaWFibGVzID0gKCkgPT4ge1xyXG4gICAgY29uc3QgZXhwYW5zaW9uUmF0ZSA9IDEwMDtcclxuICAgIGNvbnN0IGVsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJ1bm5pZXNab25lXCIpIGFzIGFueTtcclxuICAgIGNvbnN0IHNpemVTbGlkZXIgPSAoZWxlbWVudC5jaGlsZHJlbi5sZW5ndGggLSAxKSAqIGV4cGFuc2lvblJhdGU7XHJcbiAgICBjb25zdCB0YXJnZXQgPSBlbGVtZW50LnN0eWxlLnRyYW5zZm9ybTtcclxuICAgIGNvbnN0IGN1cnJlbnRQb3NpdGlvbiA9IHBhcnNlSW50KFxyXG4gICAgICB0YXJnZXQuc3Vic3RyaW5nKDExLCB0YXJnZXQuaW5kZXhPZihcIilcIikgLSAxKVxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCBvbmVFbGVtZW50V2lkdGggPSBlbGVtZW50LmZpcnN0Q2hpbGQub2Zmc2V0V2lkdGg7XHJcbiAgICBjb25zdCBudW1iZXJPZkVsZW1lbnQgPSBlbGVtZW50LmNoaWxkcmVuLmxlbmd0aDtcclxuXHJcbiAgICBjb25zdCBuZXh0UG9zaXRpb24gPSAob25lRWxlbWVudFdpZHRoICogbnVtYmVyT2ZFbGVtZW50IC8gd2luZG93LmlubmVyV2lkdGggLSAxKSAqIC0xMDA7XHJcbiAgICBjb25zdCBwcmV2aW91c1Bvc2l0aW9uID0gMDtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBleHBhbnNpb25SYXRlOiBleHBhbnNpb25SYXRlLFxyXG4gICAgICBlbGVtZW50OiBlbGVtZW50LFxyXG4gICAgICBjdXJyZW50UG9zaXRpb246IGN1cnJlbnRQb3NpdGlvbixcclxuICAgICAgbmV4dFBvc2l0aW9uOiBuZXh0UG9zaXRpb24sXHJcbiAgICAgIHByZXZpb3VzUG9zaXRpb246IHByZXZpb3VzUG9zaXRpb24sXHJcbiAgICAgIHNpemVTbGlkZXI6IHNpemVTbGlkZXIsXHJcbiAgICB9O1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZXJzID0gdXNlU3dpcGVhYmxlKHtcclxuICAgIG9uU3dpcGluZzogKHsgZGVsdGFYLCBkaXIgfSkgPT4ge1xyXG4gICAgICBpZiAoZGlyID09PSBcIkxlZnRcIiB8fCBcIlJpZ2h0XCIpIHtcclxuICAgICAgICBjb25zdCB7IGN1cnJlbnRQb3NpdGlvbiwgZWxlbWVudCB9ID0gc2V0VmFyaWFibGVzKCk7XHJcbiAgICAgICAgY29uc3Qgc3BlZWQgPSAxICogTWF0aC5zaWduKGRlbHRhWCk7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS50cmFuc2Zvcm0gPSBgdHJhbnNsYXRlWCgke2N1cnJlbnRQb3NpdGlvbiArIHNwZWVkfXZ3KWA7XHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICBvblN3aXBlZExlZnQ6ICgpID0+IHtcclxuICAgICAgY29uc3QgeyBuZXh0UG9zaXRpb24sIGVsZW1lbnQgfSA9IHNldFZhcmlhYmxlcygpO1xyXG4gICAgICBlbGVtZW50LnN0eWxlLnRyYW5zaXRpb24gPSBgYWxsIC41cyBlYXNlLW91dGA7XHJcbiAgICAgIGVsZW1lbnQuc3R5bGUudHJhbnNmb3JtID0gYHRyYW5zbGF0ZVgoJHtuZXh0UG9zaXRpb259dncpYDtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uID0gXCJcIjtcclxuICAgICAgfSwgNTAwKTtcclxuICAgIH0sXHJcbiAgICBvblN3aXBlZFJpZ2h0OiAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IHsgcHJldmlvdXNQb3NpdGlvbiwgZWxlbWVudCB9ID0gc2V0VmFyaWFibGVzKCk7XHJcbiAgICAgIGVsZW1lbnQuc3R5bGUudHJhbnNpdGlvbiA9IGBhbGwgLjVzIGVhc2Utb3V0YDtcclxuICAgICAgZWxlbWVudC5zdHlsZS50cmFuc2Zvcm0gPSBgdHJhbnNsYXRlWCgke3ByZXZpb3VzUG9zaXRpb259dncpYDtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uID0gXCJcIjtcclxuICAgICAgfSwgNTAwKTtcclxuICAgIH0sXHJcbiAgICBkZWx0YTogMTAsXHJcbiAgICBwcmV2ZW50RGVmYXVsdFRvdWNobW92ZUV2ZW50OiBmYWxzZSxcclxuICAgIHRyYWNrVG91Y2g6IHRydWUsXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U2VjdGlvbldyYXA+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnVubmllc1wiPlxyXG4gICAgICAgIDxCbG9ja1xyXG4gICAgICAgICAgaWQ9XCJidW5uaWVzWm9uZVwiXHJcbiAgICAgICAgICBzdHlsZT17eyB0cmFuc2Zvcm06IFwidHJhbnNsYXRlWCgwKVwiIH19XHJcbiAgICAgICAgICB7Li4uaGFuZGxlcnN9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2hpc3RvcnlJdGVtcy5tYXAoKGVsZW1lbnQpID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICA8SXRlbVxyXG4gICAgICAgICAgICAgICAga2V5PXtlbGVtZW50LmltYWdlfVxyXG4gICAgICAgICAgICAgICAgaW1hZ2U9e2VsZW1lbnQuaW1hZ2V9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvQmxvY2s+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8UGFyYWdyYXBoPlxyXG4gICAgICAgIERhIEJ1bm55IGlzIGEgdHJpYmUgb2YgOCwwMDAgcHJvZ3JhbW1hdGljYWxseSBnZW5lcmF0ZWQgTkZUIGJ1bm5pZXMgdGhhdCByZXNpZGUgaW4gdGhlIEV0aGVyZXVtIGJsb2NrY2hhaW4uXHJcbiAgICAgICAgR2VuZXJhdGlvbiAxIHdhcyBpbmN1YmF0ZWQgZnJvbSBhIHJhbmRvbWl6ZWQgY29tYmluYXRpb24gb2YgbW9yZSB0aGFuIDIwMCB1bmlxdWUgdHJhaXRzLCBvdXQgb2YgNCwzMjAsMDAwIHRvdGFsXHJcbiAgICAgICAgcG9zc2liaWxpdGllcy4gRWFjaCBidW5ueSBoYXMgYSB1bmlxdWUgY2hhcmFjdGVyIGFuZCBhcHBlYXJhbmNlIHdoaWNoIG1ha2VzIGhpbS9oZXIg4oCcRGHigJ0gQnVubnkuLi4uXHJcbiAgICAgIDwvUGFyYWdyYXBoPlxyXG4gICAgPC9TZWN0aW9uV3JhcD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQnVubmllc0Nhcm91c2VsO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xyXG5pbXBvcnQgZm9udHMgZnJvbSAnLi4vLi4vc3R5bGVzL3R5cG9ncmFwaHknO1xyXG5cclxuY29uc3QgU2VjdGlvbiA9IHN0eWxlZC5zZWN0aW9uYFxyXG4gIGJhY2tncm91bmQtY29sb3I6ICM1ZGYyYmM7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHBhZGRpbmc6IDIwcHggMCAwIDA7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5NTBweCkge1xyXG4gICAgcGFkZGluZy1ib3R0b206IDEwMHB4O1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTMwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgSW5uZXJXcmFwID0gc3R5bGVkLmRpdmBcclxuICBtYXgtd2lkdGg6IDkwcmVtO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG4gIHBhZGRpbmc6IDAgM3JlbTtcclxuICBAbWVkaWEgKG1heC13aWR0aDoxMTUwcHgpIHtcclxuICAgIHBhZGRpbmc6IDAgMjBweDtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBUaXRsZVRvcCA9IHN0eWxlZC5oMmBcclxuICBmb250LXdlaWdodDogNzAwO1xyXG4gIGZvbnQtc2l6ZTogY2FsYygke2ZvbnRzLmZvbnQ0MC53MTkyMC5mb250U2l6ZX0gKiAxLjM1KTtcclxuICBjb2xvcjogI0JFNkRGRjtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbWFyZ2luLXRvcDogMjBweDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICBmb250LXNpemU6IGNhbGMoJHtmb250cy5mb250NDAudzE2NjAuZm9udFNpemV9ICogMS4zNSk7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogY2FsYygke2ZvbnRzLmZvbnQ0MC53MTQ0MC5mb250U2l6ZX0gKiAxLjM1KTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6IGNhbGMoJHtmb250cy5mb250NDAudzc2OC5mb250U2l6ZX0gKiAxLjM1KTtcclxuXHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgZm9udC1zaXplOiBjYWxjKCR7Zm9udHMuZm9udDQwLnc1MDAuZm9udFNpemV9ICogMS4zNSk7XHJcbiAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG4gIH1cclxuXHJcbmA7XHJcblxyXG5jb25zdCBUaXRsZSA9IHN0eWxlZChUaXRsZVRvcClgXHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTkyMC5mb250U2l6ZX07XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTY2MC5mb250U2l6ZX07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzE0NDAuZm9udFNpemV9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzc2OC5mb250U2l6ZX07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53NTAwLmZvbnRTaXplfTtcclxuICAgIG1hcmdpbi10b3A6IDEycHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgUG9zaXRpb24gPSBzdHlsZWQucGBcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE5MjAuZm9udFNpemV9O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW4tdG9wOiAuMzEyNXJlbTtcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNjYwLmZvbnRTaXplfTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTQ0MC5mb250U2l6ZX07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NzY4LmZvbnRTaXplfTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc1MDAuZm9udFNpemV9O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEltYWdlV3JhcCA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgbWluLXdpZHRoOiAxMTEwcHg7XHJcbiAgbWF4LXdpZHRoOiAxMTEwcHg7XHJcbiAgbWFyZ2luOiAzLjc1cmVtIGF1dG8gMCBhdXRvO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOjExNTBweCkge1xyXG4gICAgZmxleC13cmFwOiB3cmFwO1xyXG4gICAgbWluLXdpZHRoOiB1bnNldDtcclxuICAgIG1heC13aWR0aDogNjAwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgbWFyZ2luOiAgMjRweCBhdXRvIDAgYXV0bztcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBJbWFnZUJveCA9IHN0eWxlZC5kaXZgXHJcbiAgd2lkdGg6IDE1LjkzNzVyZW07XHJcbiAgaGVpZ2h0OiAxNS45Mzc1cmVtO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOjExNTBweCkge1xyXG4gICAgd2lkdGg6IHVuc2V0O1xyXG4gICAgaGVpZ2h0OiB1bnNldDtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBCdW5ueUJveCA9IHN0eWxlZC5kaXZgXHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMTUwcHgpIHtcclxuICAgIHdpZHRoOiBjYWxjKDUwJSAtIC41cmVtKTtcclxuICAgICYmOm50aC1vZi10eXBlKDMpLCAmJjpudGgtb2YtdHlwZSg0KSB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDMycHg7XHJcbiAgICB9XHJcbiAgICAmJjpudGgtb2YtdHlwZSgxKSwgJiY6bnRoLW9mLXR5cGUoMykge1xyXG4gICAgICBtYXJnaW4tcmlnaHQ6IC41cmVtO1xyXG4gICAgfVxyXG4gICAgJiY6bnRoLW9mLXR5cGUoMiksICYmOm50aC1vZi10eXBlKDQpIHtcclxuICAgICAgbWFyZ2luLWxlZnQ6IC41cmVtO1xyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEJ1YmJsZXNJbWFnZSA9IHN0eWxlZC5kaXZgXHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDA7XHJcbiAgYm90dG9tOiAxODBweDtcclxuICBtYXJnaW4tYm90dG9tOiAtMTkwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5NTBweCkge1xyXG4gICAgYm90dG9tOiA4MHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGJvdHRvbTogNTBweDtcclxuICB9XHJcbiAgaW1nIHtcclxuICAgIHdpZHRoOiAxMDB2dztcclxuICAgIGhlaWdodDogYXV0bztcclxuICB9XHJcbmA7XHJcblxyXG50eXBlIEJ1bm55VHlwZSA9IHtcclxuICBpbWFnZTogc3RyaW5nO1xyXG4gIHRpdGxlOiBzdHJpbmc7XHJcbiAgcG9zaXRpb246IHN0cmluZztcclxufVxyXG5cclxuY29uc3QgQnVubnkgPSAoeyBpbWFnZSwgdGl0bGUsIHBvc2l0aW9uIH06IEJ1bm55VHlwZSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8QnVubnlCb3g+XHJcbiAgICAgIDxJbWFnZUJveD5cclxuICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgIHdpZHRoPXsyNTV9XHJcbiAgICAgICAgICBoZWlnaHQ9ezI1NX1cclxuICAgICAgICAgIHNyYz17YC9pbWcvJHtpbWFnZX1gfVxyXG4gICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L0ltYWdlQm94PlxyXG4gICAgICA8VGl0bGU+e3RpdGxlfTwvVGl0bGU+XHJcbiAgICAgIDxQb3NpdGlvbj57cG9zaXRpb259PC9Qb3NpdGlvbj5cclxuICAgIDwvQnVubnlCb3g+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCBDb21tdW5pdHkgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxTZWN0aW9uPlxyXG4gICAgICA8SW5uZXJXcmFwPlxyXG4gICAgICAgIDxUaXRsZVRvcD5EYSBCdW5ueSBDb21tdW5pdHkgT3JnYW5pemVyczwvVGl0bGVUb3A+XHJcbiAgICAgICAgPEltYWdlV3JhcD5cclxuICAgICAgICAgIDxCdW5ueSBpbWFnZT1cIkNocmlzdHkucG5nXCIgdGl0bGU9XCJEYSBDaHJpc3R5XCIgcG9zaXRpb249XCJDb25jZXB0IEFydGlzdFwiIC8+XHJcbiAgICAgICAgICA8QnVubnkgaW1hZ2U9XCJEYXZpZC5wbmdcIiB0aXRsZT1cIkRhIERhdmlkXCIgcG9zaXRpb249XCJUZWNoICYgUHJvZHVjdFwiIC8+XHJcbiAgICAgICAgICA8QnVubnkgaW1hZ2U9XCJDYW5ueS5wbmdcIiB0aXRsZT1cIkRhIENhbm55XCIgcG9zaXRpb249XCJCaXogJiBPcHNcIiAvPlxyXG4gICAgICAgICAgPEJ1bm55IGltYWdlPVwiT3NjYXJfYmx1ZS5wbmdcIiB0aXRsZT1cIkRhIE9zY2FyXCIgcG9zaXRpb249XCJNYXJrZXRpbmdcIiAvPlxyXG4gICAgICAgIDwvSW1hZ2VXcmFwPlxyXG4gICAgICA8L0lubmVyV3JhcD5cclxuICAgICAgPEJ1YmJsZXNJbWFnZT5cclxuICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgIHdpZHRoPXsxNDQwfVxyXG4gICAgICAgICAgaGVpZ2h0PXs1MDR9XHJcbiAgICAgICAgICBzcmM9XCIvaW1nL2J1YmJsZXNfcmVkLnBuZ1wiXHJcbiAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvQnViYmxlc0ltYWdlPlxyXG4gICAgPC9TZWN0aW9uID5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbW11bml0eTsiLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcclxuaW1wb3J0IENhcnJvdEhlYWRlciBmcm9tICcuLi9TaGFyZWQvQ2Fycm90SGVhZGVyL0NhcnJvdEhlYWRlcic7XHJcbmltcG9ydCBmb250cyBmcm9tICcuLi8uLi9zdHlsZXMvdHlwb2dyYXBoeSc7XHJcblxyXG5jb25zdCBTZWN0aW9uID0gc3R5bGVkLnNlY3Rpb25gXHJcbiAgYmFja2dyb3VuZDogI0JFNkRGRjtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgbWluLWhlaWdodDogMzByZW07XHJcbiAgcGFkZGluZzogMTUwcHggMzJweCAyMDBweCAzMnB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMDAwcHgpIHtcclxuICAgIHBhZGRpbmc6IDgwcHggMzJweCAyMDBweCAzMnB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIHBhZGRpbmc6IDgwcHggMCAyMDBweCAxNnB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEhlYWRlcldyYXAgPSBzdHlsZWQuZGl2YFxyXG4gIG1heC13aWR0aDogMTIyMHB4O1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTAwMHB4KSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxNnB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEVnZ3NJbWFnZXMgPSBzdHlsZWQuZGl2PHsgaGVpZ2h0OiBudW1iZXIgfT5gXHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDA7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAkeyh7IGhlaWdodCB9KSA9PiBoZWlnaHQgKiAyfXB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEzMDBweCkge1xyXG4gICAgdG9wOiAzMHB4O1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDkwMHB4KSB7XHJcbiAgICBoZWlnaHQ6ICR7KHsgaGVpZ2h0IH0pID0+IGhlaWdodCAqIDN9cHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgRWdnc0xpc3QgPSBzdHlsZWQudWxgXHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG1heC13aWR0aDogMTIyMHB4O1xyXG4gIG1hcmdpbjogMTUwcHggYXV0byAwIGF1dG87XHJcbiAgYm9yZGVyLXJhZGl1czogMjNweDtcclxuICBwYWRkaW5nOiA0NXB4IDQ1cHggMTkwcHggNzBweDtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBwYWRkaW5nOiAyNnB4IDMycHggMTIwcHggNDBweDtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBCYWNrZ3JvdW5kID0gc3R5bGVkLmltZ2BcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IDEyMjBweDtcclxuICBoZWlnaHQ6IDM2MHB4O1xyXG4gIHotaW5kZXg6IDA7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjAwcHgpIHtcclxuICAgIGhlaWdodDogMzcwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMzAwcHgpIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzg2cHgpIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQmFja2dyb3VuZE1vYmlsZSA9IHN0eWxlZC5pbWdgXHJcbiAgZGlzcGxheTogbm9uZTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiBjYWxjKDEwMCUgLSA4MHB4KTtcclxuICB6LWluZGV4OiAwO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzg2cHgpIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQmFja2dyb3VuZE1vYmlsZVNtYWxsID0gc3R5bGVkLmltZ2BcclxuICBkaXNwbGF5OiBub25lO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogMDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDgwcHgpO1xyXG4gIHotaW5kZXg6IDA7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgVG9wSW1hZ2UgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiAxO1xyXG4gIGJvdHRvbTogMjgwcHg7XHJcbiAgcmlnaHQ6IDE1cHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgYm90dG9tOiAyNDBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDExNTBweCkge1xyXG4gICAgYm90dG9tOiAyNzBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEwMDBweCkge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgcmlnaHQ6IHVuc2V0O1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgd2lkdGg6IDQwMHB4O1xyXG4gICAgaGVpZ2h0OiAyMzVweDtcclxuICAgIG1hcmdpbi10b3A6IC01MHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNjAwcHgpIHtcclxuICAgIHdpZHRoOiAyODBweDtcclxuICAgIGhlaWdodDogMTE1cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAwO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNDUwcHgpIHtcclxuICAgIHdpZHRoOiAyMDBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIG1hcmdpbi10b3A6IC0yMHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IExpc3RJdGVtID0gc3R5bGVkLmxpYFxyXG4gIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE5MjAuZm9udFNpemV9O1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjJweDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgei1pbmRleDogMTtcclxuICBzcGFuIHtcclxuICAgIGNvbG9yOiAjQkU2REZGO1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTY2MC5mb250U2l6ZX07XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMnB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNDQwLmZvbnRTaXplfTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc3NjguZm9udFNpemV9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NTAwLmZvbnRTaXplfTtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBUaXRsZSA9IHN0eWxlZC5oM2BcclxuICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxOTIwLmZvbnRTaXplfTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjRweDtcclxuICB6LWluZGV4OiAxO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTY2MC5mb250U2l6ZX07XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMnB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNDQwLmZvbnRTaXplfTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc3NjguZm9udFNpemV9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NTAwLmZvbnRTaXplfTtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBUZXh0ID0gc3R5bGVkLnBgXHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyMC53MTkyMC5mb250U2l6ZX07XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHNwYW4ge1xyXG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2MDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyMC53MTY2MC5mb250U2l6ZX07XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDIwLncxNjYwLmZvbnRTaXplfTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNjAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUzMHB4KSB7XHJcbiAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICBsaW5lLWhlaWdodDogMTJweDtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBCdWJibGVJbWFnZSA9IHN0eWxlZC5kaXZgXHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDA7XHJcbiAgbGVmdDogMDtcclxuICBib3R0b206IC0xMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGltZyB7XHJcbiAgICB3aWR0aDogMTAwdnc7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgRWdnTGlzdE91dGVyV3JhcCA9IHN0eWxlZC5kaXZgXHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG1heC13aWR0aDogMTIyMHB4O1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG5gO1xyXG5cclxuY29uc3QgRWdnc0luZm9MaXN0ID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIG1heC13aWR0aDogMTAwMHB4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICAvL2FkanVzdCBldmVyeSBib3ggdG8gZWdnIGltYWdlXHJcblxyXG4gID4gZGl2Om50aC1vZi10eXBlKDEpIHtcclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIGxlZnQ6IC0xMHB4O1xyXG4gICAgfVxyXG4gICAgLnRleHQtcG9zaXRpb24tZml4IHtcclxuICAgICAgcGFkZGluZzogMCAxNSU7XHJcbiAgICAgIHRvcDogNTBweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgICAgICB0b3A6IDEwcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5lZ2ctcG9zaXRpb24tZml4IHtcclxuICAgICAgdG9wOiAwO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgPiBkaXY6bnRoLW9mLXR5cGUoMikge1xyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgbGVmdDogLTEwcHg7XHJcbiAgICB9XHJcbiAgICAudGV4dC1wb3NpdGlvbi1maXgge1xyXG4gICAgICBwYWRkaW5nOiAwIDE3LjUlO1xyXG4gICAgfVxyXG4gICAgLmVnZy1wb3NpdGlvbi1maXgge1xyXG4gICAgICB0b3A6IC0xMHB4O1xyXG4gICAgICBAbWVkaWEgKG1heC13aWR0aDogMTMwMHB4KSB7XHJcbiAgICAgICAgdG9wOiAwO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICA+IGRpdjpudGgtb2YtdHlwZSgzKSB7XHJcbiAgICAudGV4dC1wb3NpdGlvbi1maXgge1xyXG4gICAgICBwYWRkaW5nOiAwIDEyJTtcclxuICAgICAgdG9wOiA0MHB4O1xyXG4gICAgICBsZWZ0OiAtMjBweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICAgICAgcGFkZGluZzogMCAyMCU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5lZ2ctcG9zaXRpb24tZml4IHtcclxuICAgICAgdG9wOiAyNXB4O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgPiBkaXY6bnRoLW9mLXR5cGUoNCkge1xyXG4gICAgLnRleHQtcG9zaXRpb24tZml4IHtcclxuICAgICAgcGFkZGluZzogMCAxNSU7XHJcbiAgICAgIHBhZGRpbmctdG9wOiAxMDBweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICAgICAgbGVmdDogLTE1cHg7XHJcbiAgICAgIH1cclxuICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDU0MHB4KSB7XHJcbiAgICAgICAgcGFkZGluZy10b3A6IDQwcHg7XHJcbiAgICAgIH1cclxuICAgICAgcCB7XHJcbiAgICAgICAgd2lkdGg6IDkwJTtcclxuICAgICAgICBtYXJnaW46IDAgYXV0bztcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmVnZy1wb3NpdGlvbi1maXgge1xyXG4gICAgICB0b3A6IDA7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICA+IGRpdjpudGgtb2YtdHlwZSg1KSB7XHJcbiAgICAudGV4dC1wb3NpdGlvbi1maXgge1xyXG4gICAgICBwYWRkaW5nOiAwIDEwJTtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICB0b3A6IC0yMHB4O1xyXG4gICAgfVxyXG4gICAgLmVnZy1wb3NpdGlvbi1maXgge1xyXG4gICAgICB0b3A6IDVweDtcclxuICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDEzMDBweCkge1xyXG4gICAgICAgIHRvcDogMDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgPiBkaXY6bnRoLW9mLXR5cGUoNikge1xyXG4gICAgLnRleHQtcG9zaXRpb24tZml4IHtcclxuICAgICAgcGFkZGluZzogMCAxMCU7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgbGVmdDogLTIwcHg7XHJcbiAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgICAgICBwYWRkaW5nOiAwIDE1JTtcclxuICAgICAgfVxyXG4gICAgICBAbWVkaWEgKG1heC13aWR0aDogMTIwMHB4KSB7XHJcbiAgICAgICAgdG9wOiAzMHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAuZWdnLXBvc2l0aW9uLWZpeCB7XHJcbiAgICAgIHRvcDogNDBweDtcclxuICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDEzMDBweCkge1xyXG4gICAgICAgIHRvcDogMjBweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEVnZ3NJbmZvID0gc3R5bGVkLmRpdmBcclxuICBmbGV4LWJhc2lzOiBjYWxjKDEwMCUvMyk7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogOTAwcHgpIHtcclxuICAgIGZsZXgtYmFzaXM6IGNhbGMoMTAwJS8yKTtcclxuICB9XHJcblxyXG4gICYmOmhvdmVyIHtcclxuICAgIGFuaW1hdGlvbjogc2hha2UgMC44cyBjdWJpYy1iZXppZXIoLjM3LC4wOCwuMjAsLjkxKSBib3RoO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcclxuICAgIHBlcnNwZWN0aXZlOiAxMDAwcHg7XHJcbiAgICBiYWNrZmFjZS12aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgfVxyXG5cclxuICBAa2V5ZnJhbWVzIHNoYWtlIHtcclxuICAgIDEwJSwgOTAlIHtcclxuICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMnB4LCAwLCAwKTtcclxuICAgIH1cclxuXHJcbiAgICAyMCUsIDgwJSB7XHJcbiAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMXB4LCAwLCAwKTtcclxuICAgIH1cclxuXHJcbiAgICAzMCUsIDUwJSwgNzAlIHtcclxuICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtM3B4LCAwLCAwKTtcclxuICAgIH1cclxuXHJcbiAgICA0MCUsIDYwJSB7XHJcbiAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMXB4LCAwLCAwKTtcclxuICAgIH1cclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBFZ2dJbWFnZVdyYXAgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBsZWZ0OiAwO1xyXG4gIHRvcDogMDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgei1pbmRleDogMDtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEzMDBweCkge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDkwMHB4KSB7XHJcblxyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEVnZ3NEYXRhID0gKCkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8RWdnc0luZm9MaXN0PlxyXG4gICAgICA8RWdnc0luZm8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXBvc2l0aW9uLWZpeFwiPlxyXG4gICAgICAgICAgPFRpdGxlPlJhcml0eS5Ub29sczwvVGl0bGU+XHJcbiAgICAgICAgICA8VGV4dD5cclxuICAgICAgICAgICAgZm9yIGdlbmVyYXRpdmUgYXJ0IGF0dHJpYnV0ZXMgcmFua2luZyBhbmQgcmFyaXR5IGxvb2t1cCBkZWRpY2F0ZWQgdG8gcmVnaXN0ZXJlZCBORlQgY29sbGVjdGlvbnMgb25seVxyXG4gICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxFZ2dJbWFnZVdyYXAgY2xhc3NOYW1lPVwiZWdnLXBvc2l0aW9uLWZpeFwiPlxyXG4gICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgIHdpZHRoPXs0MjR9XHJcbiAgICAgICAgICAgIGhlaWdodD17NjI4fVxyXG4gICAgICAgICAgICBzcmM9XCIvaW1nL2FsbF9lZ2dzXzAxLnBuZ1wiXHJcbiAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvRWdnSW1hZ2VXcmFwPlxyXG4gICAgICA8L0VnZ3NJbmZvPlxyXG4gICAgICA8RWdnc0luZm8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXBvc2l0aW9uLWZpeFwiPlxyXG4gICAgICAgICAgPFRpdGxlPkZhaXIgTGF1bmNoPC9UaXRsZT5cclxuICAgICAgICAgIDxUZXh0PjAuMDggRVRIIHRvIHVubG9jayBhbnkgQnVubnk8L1RleHQ+XHJcbiAgICAgICAgICA8VGV4dD4wLjEyIEVUSCBmb3IgbW9yZSBjaGFuY2UgdG8gdW5sb2NrIGEgU3VwZXIgUmFyZSAoU1JCL1NTUkIvU0IrKSBCdW5ueSBhbmQgc3BlY2lhbCBleGNsdXNpdmUgcGVya3M8L1RleHQ+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPEVnZ0ltYWdlV3JhcCBjbGFzc05hbWU9XCJlZ2ctcG9zaXRpb24tZml4XCIgaWQ9XCJmaXJzdEVnZ1wiPlxyXG4gICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgIHdpZHRoPXs0MTd9XHJcbiAgICAgICAgICAgIGhlaWdodD17NjI4fVxyXG4gICAgICAgICAgICBzcmM9XCIvaW1nL2FsbF9lZ2dzXzAyLnBuZ1wiXHJcbiAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvRWdnSW1hZ2VXcmFwPlxyXG4gICAgICA8L0VnZ3NJbmZvPlxyXG4gICAgICA8RWdnc0luZm8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXBvc2l0aW9uLWZpeFwiPlxyXG4gICAgICAgICAgPFRpdGxlPk93bmVyc2hpcCAmIENvbW1lcmNpYWwgVXNhZ2UgUmlnaHRzPC9UaXRsZT5cclxuICAgICAgICAgIDxUZXh0PmFzc2lnbmVkIHRvIERhIEJ1bm55IE5GVCBob2xkZXJzPC9UZXh0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxFZ2dJbWFnZVdyYXAgY2xhc3NOYW1lPVwiZWdnLXBvc2l0aW9uLWZpeFwiPlxyXG4gICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgIHdpZHRoPXs0NDN9XHJcbiAgICAgICAgICAgIGhlaWdodD17NjI4fVxyXG4gICAgICAgICAgICBzcmM9XCIvaW1nL2FsbF9lZ2dzXzAzLnBuZ1wiXHJcbiAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvRWdnSW1hZ2VXcmFwPlxyXG4gICAgICA8L0VnZ3NJbmZvPlxyXG4gICAgICA8RWdnc0luZm8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXBvc2l0aW9uLWZpeFwiPlxyXG4gICAgICAgICAgPFRpdGxlPlBlcnNvbmFsaXplZCBEYSBCdW5ueSBEaWdpdGFsICYgUGh5c2ljYWwgTWVyY2hhbmRpc2U8L1RpdGxlPlxyXG4gICAgICAgICAgPFRleHQ+RXhjbHVzaXZlIEFjY2VzcyBmb3IgPHNwYW4+YWxsIGN1cnJlbnQgTkZUIGhvbGRlcnM8L3NwYW4+IChkZXRhaWxzIHRvIGJlIHJlbGVhc2VkIG9uIERpc2NvcmQpPC9UZXh0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxFZ2dJbWFnZVdyYXAgY2xhc3NOYW1lPVwiZWdnLXBvc2l0aW9uLWZpeFwiPlxyXG4gICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgIHdpZHRoPXs0MjR9XHJcbiAgICAgICAgICAgIGhlaWdodD17NjI3fVxyXG4gICAgICAgICAgICBzcmM9XCIvaW1nL2FsbF9lZ2dzXzA0LnBuZ1wiXHJcbiAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvRWdnSW1hZ2VXcmFwPlxyXG4gICAgICA8L0VnZ3NJbmZvPlxyXG4gICAgICA8RWdnc0luZm8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXBvc2l0aW9uLWZpeFwiPlxyXG4gICAgICAgICAgPFRpdGxlPkNvbW11bml0eSBXYWxsZXQ8L1RpdGxlPlxyXG4gICAgICAgICAgPFRleHQ+ZnVuZGVkIGJ5IERhIEJ1bm55IE5GVCBFUkMtMjAgdG9rZW4gcHJvY2VlZHMgdG8gc3VwcG9ydCBjb21tdW5pdHkgZXZlbnRzIGFuZCBtYXJrZXRpbmcgY29zdHM8L1RleHQ+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPEVnZ0ltYWdlV3JhcCBjbGFzc05hbWU9XCJlZ2ctcG9zaXRpb24tZml4XCI+XHJcbiAgICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgICAgd2lkdGg9ezQxN31cclxuICAgICAgICAgICAgaGVpZ2h0PXs2Mjd9XHJcbiAgICAgICAgICAgIHNyYz1cIi9pbWcvYWxsX2VnZ3NfMDUucG5nXCJcclxuICAgICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9FZ2dJbWFnZVdyYXA+XHJcbiAgICAgIDwvRWdnc0luZm8+XHJcbiAgICAgIDxFZ2dzSW5mbz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcG9zaXRpb24tZml4XCI+XHJcbiAgICAgICAgICA8VGl0bGU+UGVyaW9kaWMgR2l2ZWF3YXlzPC9UaXRsZT5cclxuICAgICAgICAgIDxUZXh0PnRvIHJld2FyZCBEYSBCdW5ueSBORlQgaG9sZGVycyBmb3IgYmVpbmcgcGFydCBvZiB0aGUgZmFtaWx5PC9UZXh0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxFZ2dJbWFnZVdyYXAgY2xhc3NOYW1lPVwiZWdnLXBvc2l0aW9uLWZpeFwiPlxyXG4gICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgIHdpZHRoPXs0NDN9XHJcbiAgICAgICAgICAgIGhlaWdodD17NjI3fVxyXG4gICAgICAgICAgICBzcmM9XCIvaW1nL2FsbF9lZ2dzXzA2LnBuZ1wiXHJcbiAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvRWdnSW1hZ2VXcmFwPlxyXG4gICAgICA8L0VnZ3NJbmZvPlxyXG4gICAgPC9FZ2dzSW5mb0xpc3Q+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCBFZ2dzSGVhZGVyRGV0YWlscyA9ICgpID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPEVnZ0xpc3RPdXRlcldyYXA+XHJcbiAgICAgIDxUb3BJbWFnZT5cclxuICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgIHdpZHRoPXs0ODYvMS4yfVxyXG4gICAgICAgICAgaGVpZ2h0PXs2MDUvMS4yfVxyXG4gICAgICAgICAgc3JjPVwiL2ltZy9CdW5ueSBIb2xlIEdJRi5naWZcIlxyXG4gICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L1RvcEltYWdlPlxyXG4gICAgICA8RWdnc0xpc3Q+XHJcbiAgICAgICAgPEJhY2tncm91bmQgYWx0PVwiXCIgc3JjPVwiaW1nL3JlYy1iYWNrZ3JvdW5kLnBuZ1wiIC8+XHJcbiAgICAgICAgPEJhY2tncm91bmRNb2JpbGUgYWx0PVwiXCIgc3JjPVwiaW1nL3JlYy1iYWNrZ3JvdW5kLW1vYmlsZS5wbmdcIiAvPlxyXG4gICAgICAgIDxCYWNrZ3JvdW5kTW9iaWxlU21hbGwgYWx0PVwiXCIgc3JjPVwiaW1nL3JlYy1iYWNrZ3JvdW5kLW1vYmlsZS1zbWFsbC5wbmdcIiAvPlxyXG4gICAgICAgIDxMaXN0SXRlbT5cclxuICAgICAgICAgIERpc2NvcmQtYmFzZWQgY29tbXVuaXR5IGZvciBhbGwgRGEgQnVubnkgTkZUIGhvbGRlcnNcclxuICAgICAgICA8L0xpc3RJdGVtPlxyXG4gICAgICAgIDxMaXN0SXRlbT5cclxuICAgICAgICAgIE1lbWJlcnMtb25seSBhY2Nlc3MgdG8gPHNwYW4+UmFiYml0IEhvbGU8L3NwYW4+LCBhbiBleGNsdXNpdmUgY2x1YmhvdXNlIHdob3NlIGJlbmVmaXRzIGFuZCBvZmZlcmluZ3Mgd2lsbCB1bmxvY2sgd2l0aCByb2FkbWFwXHJcbiAgICAgICAgICBtaWxlc3RvbmUgYWN0aXZhdGlvbnMgKHNlZSBiZWxvdylcclxuICAgICAgICA8L0xpc3RJdGVtPlxyXG4gICAgICAgIDxMaXN0SXRlbT5cclxuICAgICAgICAgIFdlIHN1cHBvcnQgPHNwYW4+cmVhbCByYWJiaXRzPC9zcGFuPiBnbG9iYWxseSBieSBkb25hdGluZyBvZiA1JSBvZiBORlQgc2FsZXMgbmV0IHByb2NlZWRzIHRvIHRoZSBIb3VzZSBSYWJiaXQgU29jaWV0eVxyXG4gICAgICAgIDwvTGlzdEl0ZW0+XHJcbiAgICAgIDwvRWdnc0xpc3Q+XHJcbiAgICA8L0VnZ0xpc3RPdXRlcldyYXA+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCBFZ2dzID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtsaXN0SGVpZ2h0LCBzZXRMaXN0SGVpZ2h0XSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICBjb25zdCByZXNpemVFdmVudEhhbmRsZSA9ICgpID0+IHtcclxuICAgIGNvbnN0IGVnZ0ltYWdlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2ZpcnN0RWdnJyk/LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdpbWcnKVswXSBhcyBIVE1MRWxlbWVudDtcclxuICAgIGNvbnN0IGltYWdlSGVpZ2h0ID0gZWdnSW1hZ2Uub2Zmc2V0SGVpZ2h0O1xyXG4gICAgc2V0TGlzdEhlaWdodChpbWFnZUhlaWdodCk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHJlc2l6ZUV2ZW50SGFuZGxlKCk7XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgcmVzaXplRXZlbnRIYW5kbGUpO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHJlc2l6ZUV2ZW50SGFuZGxlKTtcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNlY3Rpb24+XHJcbiAgICAgIDxIZWFkZXJXcmFwPlxyXG4gICAgICAgIDxDYXJyb3RIZWFkZXIgYmdDb2xvcj1cIiNFQ0Q2RkZcIiBwYWRkaW5nPVwiMS41NjI1cmVtIDMycHggMjVweCA4MHB4XCI+XHJcbiAgICAgICAgICBXZWxjb21lIERvd24gdGhlIFJhYmJpdCBIb2xlLi4uIHRvIE91ciBDb21tdW5pdHkhXHJcbiAgICAgICAgPC9DYXJyb3RIZWFkZXI+XHJcbiAgICAgIDwvSGVhZGVyV3JhcD5cclxuICAgICAgPEVnZ3NIZWFkZXJEZXRhaWxzIC8+XHJcbiAgICAgIDxFZ2dzSW1hZ2VzIGhlaWdodD17bGlzdEhlaWdodH0+XHJcbiAgICAgICAgPEVnZ3NEYXRhIC8+XHJcbiAgICAgIDwvRWdnc0ltYWdlcz5cclxuICAgICAgPEJ1YmJsZUltYWdlPlxyXG4gICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgd2lkdGg9ezE0NDB9XHJcbiAgICAgICAgICBoZWlnaHQ9ezQzNn1cclxuICAgICAgICAgIHNyYz1cIi9pbWcvYnViYmxlc19ncmVlbi5wbmdcIlxyXG4gICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L0J1YmJsZUltYWdlPlxyXG4gICAgPC9TZWN0aW9uID5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEVnZ3M7IiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcclxuaW1wb3J0IGZvbnRzIGZyb20gJy4uLy4uLy4uL3N0eWxlcy90eXBvZ3JhcGh5JztcclxuXHJcbmNvbnN0IEJhY2tJbkRheXMgPSBzdHlsZWQuZGl2YFxyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuYDtcclxuXHJcbmNvbnN0IENvbnRlbnRJbWFnZSA9IHN0eWxlZC5kaXZgXHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDA7XHJcbiAgbGVmdDogMDtcclxuICB0b3A6IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG5gO1xyXG5cclxuY29uc3QgQ29udGVudFRleHQgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiAxO1xyXG4gIGxlZnQ6IDA7XHJcbiAgdG9wOiAwO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XHJcbmA7XHJcblxyXG5jb25zdCBDb250ZW50V3JhcCA9IHN0eWxlZC5kaXZgXHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG1hcmdpbi1ib3R0b206IC0xMDBweDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTI1MHB4KSB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAtMTQwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMDAwcHgpIHtcclxuICAgIG1hcmdpbi1ib3R0b206IC0xMTBweDtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBCYWNrSW5EYXlzVGV4dCA9IHN0eWxlZC5kaXZgXHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxOTIwLmhlaWdodH07XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHAge1xyXG4gICAgbWF4LXdpZHRoOiA1OTBweDtcclxuICAgIHdpZHRoOiA2MCU7XHJcblxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDMwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNjYwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53MTY2MC5oZWlnaHR9O1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTQ0MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzE0NDAuaGVpZ2h0fTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMjUwcHgpIHtcclxuICAgIHBhZGRpbmc6IDAgMCAwIDUwcHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0b3A6IC01MHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IFRocmVlQnVubmllcyA9IHN0eWxlZC5kaXZgXHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5gO1xyXG5cclxuY29uc3QgVGhyZWVCdW5uaWVzVGV4dCA9IHN0eWxlZC5kaXZgXHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxOTIwLmhlaWdodH07XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHRvcDogLTdyZW07XHJcbiAgcCB7XHJcbiAgICBtYXgtd2lkdGg6IDU5MHB4O1xyXG4gICAgd2lkdGg6IDYwJTtcclxuXHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICAgIHBhZGRpbmctcmlnaHQ6IDMwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNjYwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53MTY2MC5oZWlnaHR9O1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTQ0MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzE0NDAuaGVpZ2h0fTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMjUwcHgpIHtcclxuICAgIHBhZGRpbmc6IDAgNTBweCAwIDUwcHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0b3A6IC0xMjBweDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMTUwcHgpIHtcclxuICAgIHRvcDogLTgwcHg7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogOTcwcHgpIHtcclxuICAgIHRvcDogLTY1cHg7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogODUwcHgpIHtcclxuICAgIHRvcDogLTMwcHg7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzc2OC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzc2OC5oZWlnaHR9O1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc1MDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0Lnc1MDAuaGVpZ2h0fTtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBBbnRNaW5lciA9IHN0eWxlZC5kaXZgXHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG5gO1xyXG5cclxuY29uc3QgQW50TWluZXJUZXh0ID0gc3R5bGVkLmRpdmBcclxuICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxOTIwLmZvbnRTaXplfTtcclxuICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzE5MjAuaGVpZ2h0fTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHRvcDogLTEycmVtO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE2NjAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxNjYwLmhlaWdodH07XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNDQwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53MTQ0MC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzc2OC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzc2OC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzUwMC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzUwMC5oZWlnaHR9O1xyXG4gIH1cclxuICBwIHtcclxuICAgIG1heC13aWR0aDogNjgwcHg7XHJcbiAgICB3aWR0aDogNjAlO1xyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDEyNTBweCkge1xyXG4gICAgICB3aWR0aDogNjUlO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcblxyXG5gO1xyXG5cclxuY29uc3QgQ29udGVudERlc2t0b3AgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxDb250ZW50V3JhcD5cclxuICAgICAgPENvbnRlbnRJbWFnZT5cclxuICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgIHdpZHRoPXsxMTE0fVxyXG4gICAgICAgICAgaGVpZ2h0PXsxNzg5fVxyXG4gICAgICAgICAgc3JjPXtcIi9pbWcvZnVsbC1wYXRocy5wbmdcIn1cclxuICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9Db250ZW50SW1hZ2U+XHJcbiAgICAgIDxDb250ZW50VGV4dD5cclxuICAgICAgICA8QmFja0luRGF5cz5cclxuICAgICAgICAgIDxCYWNrSW5EYXlzVGV4dD5cclxuICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgVGhlIG9yaWdpbiBvZiBEYSBCdW5ueSB0cmliZSBpcyBhIG9uZS1pbi1hLWJpbGxpb24sIHNpbmd1bGFyIGNvaW5jaWRlbmNlIG9uIGVhcnRoIG92ZXIgdGhlIGNvdXJzZSBvZiBldm9sdXRpb24uLi5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9CYWNrSW5EYXlzVGV4dD5cclxuICAgICAgICA8L0JhY2tJbkRheXM+XHJcbiAgICAgICAgPFRocmVlQnVubmllcz5cclxuICAgICAgICAgIDxUaHJlZUJ1bm5pZXNUZXh0PlxyXG4gICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICBGb3IgZ2VuZXJhdGlvbnMsIGxpZmUgY291bGRuJmFwb3M7dCBiZSBtb3JlIGJvcmluZyBmb3IgYSB0cmliZSBvZiBMaWxhYyBSYWJiaXRzIGluaGFiaXRlZCBvbiB0aGUgRWFzdGVyIElzbGFuZCBvZiBDaGlsZS5cclxuICAgICAgICAgICAgICBUaGVzZSByYWJiaXRzIHNwZW50IHRoZWlyIGxpZmV0aW1lIGF0IHRoZSBmYWN0b3J5LCBzdGFydmVkIGFuZCBkZXByaXZlZCwgbWFzcy1wcm9kdWNpbmcgYXJ0aWZpY2lhbCBlZ2dzIGZvciBhIGZlc3RpdmFsXHJcbiAgICAgICAgICAgICAgY2VsZWJyYXRlZCBpbiB0aGUgcG9zdC1pbmR1c3RyaWFsaXplZCBodW1hbiBzb2NpZXR5IOKAlCBpbiBhIG1lYWdlciBleGNoYW5nZSBmb3Igb25seSB0aHJlZSBjYXJyb3RzIGEgZGF5LlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L1RocmVlQnVubmllc1RleHQ+XHJcbiAgICAgICAgPC9UaHJlZUJ1bm5pZXM+XHJcbiAgICAgICAgPEFudE1pbmVyPlxyXG4gICAgICAgICAgPEFudE1pbmVyVGV4dD5cclxuICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgVGhlIGxpZmUtY2hhbmdpbmcgbW9tZW50IGFycml2ZWQgb25lIGRheSB3aGVuIGEgdHJpYmUgbWVtYmVyIGZvdW5kIGFuIGlkbGVkIEFudG1pbmVyIFMxOSBpbiB0aGUgcmVtbmFudHMgb2YgYW4gYWJhbmRvbmVkIGZhY3RvcnlcclxuICAgICAgICAgICAgICBoYXZvY2tlZCBieSBhIGRlYWRseSB2b2xjYW5pYyBlcnJ1cHRpb24uIEl0IHNvb24gb2NjdXJyZWQgdG8gYSByYWJiaXQgdGhhdCBpdCBjYW4gZ2V0IGNyeXB0byBmcm9tIHRoZSBtYWNoaW5lLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L0FudE1pbmVyVGV4dD5cclxuICAgICAgICA8L0FudE1pbmVyPlxyXG4gICAgICA8L0NvbnRlbnRUZXh0PlxyXG4gICAgPC9Db250ZW50V3JhcD5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbnRlbnREZXNrdG9wO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xyXG5pbXBvcnQgZm9udHMgZnJvbSAnLi4vLi4vLi4vc3R5bGVzL3R5cG9ncmFwaHknO1xyXG5cclxuY29uc3QgQ29udGVudEltYWdlID0gc3R5bGVkLmRpdmBcclxuICB6LWluZGV4OiAwO1xyXG4gIHRvcDogMDtcclxuICB3aWR0aDogMTAwdnc7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuYDtcclxuXHJcbmNvbnN0IENvbnRlbnRUZXh0ID0gc3R5bGVkLmRpdmBcclxuICB6LWluZGV4OiAxO1xyXG4gIGxlZnQ6IDA7XHJcbiAgdG9wOiAwO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuYDtcclxuXHJcbmNvbnN0IENvbnRlbnRXcmFwID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgbWFyZ2luLXRvcDogOTBweDtcclxuYDtcclxuXHJcbmNvbnN0IEJsb2NrVGV4dCA9IHN0eWxlZC5kaXZgXHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NzY4LmZvbnRTaXplfTtcclxuICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzc2OC5oZWlnaHR9O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NTAwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53NTAwLmhlaWdodH07XHJcbiAgfVxyXG4gIHAge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZzogMCA0OHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEJsb2NrV3JhcCA9IHN0eWxlZC5kaXZgXHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG5gO1xyXG5cclxuY29uc3QgQ29udGVudE1vYmlsZSA9ICgpID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPENvbnRlbnRXcmFwPlxyXG4gICAgICA8Q29udGVudFRleHQ+XHJcbiAgICAgICAgPEJsb2NrV3JhcD5cclxuICAgICAgICAgIDxCbG9ja1RleHQ+XHJcbiAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgIFRoZSBvcmlnaW4gb2YgRGEgQnVubnkgdHJpYmUgaXMgYSBvbmUtaW4tYS1iaWxsaW9uLCBzaW5ndWxhciBjb2luY2lkZW5jZSBvbiBlYXJ0aCBvdmVyIHRoZSBjb3Vyc2Ugb2YgZXZvbHV0aW9uLi4uXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvQmxvY2tUZXh0PlxyXG4gICAgICAgICAgPENvbnRlbnRJbWFnZT5cclxuICAgICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgICAgd2lkdGg9ezc2OX1cclxuICAgICAgICAgICAgICBoZWlnaHQ9ezY4NH1cclxuICAgICAgICAgICAgICBzcmM9e1wiL2ltZy9wYXRoX21vYmlsZV90b3AucG5nXCJ9XHJcbiAgICAgICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvQ29udGVudEltYWdlPlxyXG4gICAgICAgIDwvQmxvY2tXcmFwPlxyXG4gICAgICAgIDxCbG9ja1dyYXA+XHJcbiAgICAgICAgICA8QmxvY2tUZXh0PlxyXG4gICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICBGb3IgZ2VuZXJhdGlvbnMsIGxpZmUgY291bGRuJmFwb3M7dCBiZSBtb3JlIGJvcmluZyBmb3IgYSB0cmliZSBvZiBMaWxhYyBSYWJiaXRzIGluaGFiaXRlZCBvbiB0aGUgRWFzdGVyIElzbGFuZCBvZiBDaGlsZS5cclxuICAgICAgICAgICAgICBUaGVzZSByYWJiaXRzIHNwZW50IHRoZWlyIGxpZmV0aW1lIGF0IHRoZSBmYWN0b3J5LCBzdGFydmVkIGFuZCBkZXByaXZlZCwgbWFzcy1wcm9kdWNpbmcgYXJ0aWZpY2lhbCBlZ2dzIGZvciBhIGZlc3RpdmFsXHJcbiAgICAgICAgICAgICAgY2VsZWJyYXRlZCBpbiB0aGUgcG9zdC1pbmR1c3RyaWFsaXplZCBodW1hbiBzb2NpZXR5IOKAlCBpbiBhIG1lYWdlciBleGNoYW5nZSBmb3Igb25seSB0aHJlZSBjYXJyb3RzIGEgZGF5LlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L0Jsb2NrVGV4dD5cclxuICAgICAgICAgIDxDb250ZW50SW1hZ2U+XHJcbiAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgIHdpZHRoPXs3Njl9XHJcbiAgICAgICAgICAgICAgaGVpZ2h0PXs2NDh9XHJcbiAgICAgICAgICAgICAgc3JjPXtcIi9pbWcvcGF0aF9tb2JpbGVfbWlkZGxlLnBuZ1wifVxyXG4gICAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0NvbnRlbnRJbWFnZT5cclxuICAgICAgICA8L0Jsb2NrV3JhcD5cclxuICAgICAgICA8QmxvY2tXcmFwPlxyXG4gICAgICAgICAgPEJsb2NrVGV4dD5cclxuICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgVGhlIGxpZmUtY2hhbmdpbmcgbW9tZW50IGFycml2ZWQgb25lIGRheSB3aGVuIGEgdHJpYmUgbWVtYmVyIGZvdW5kIGFuIGlkbGVkIEFudG1pbmVyIFMxOSBpbiB0aGUgcmVtbmFudHMgb2YgYW4gYWJhbmRvbmVkIGZhY3RvcnlcclxuICAgICAgICAgICAgICBoYXZvY2tlZCBieSBhIGRlYWRseSB2b2xjYW5pYyBlcnJ1cHRpb24uIEl0IHNvb24gb2NjdXJyZWQgdG8gYSByYWJiaXQgdGhhdCBpdCBjYW4gZ2V0IGNyeXB0byBmcm9tIHRoZSBtYWNoaW5lLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L0Jsb2NrVGV4dD5cclxuICAgICAgICAgIDxDb250ZW50SW1hZ2U+XHJcbiAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgIHdpZHRoPXs3Njl9XHJcbiAgICAgICAgICAgICAgaGVpZ2h0PXs3MDh9XHJcbiAgICAgICAgICAgICAgc3JjPXtcIi9pbWcvcGF0aF9tb2JpbGVfYm90dG9tLnBuZ1wifVxyXG4gICAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0NvbnRlbnRJbWFnZT5cclxuICAgICAgICA8L0Jsb2NrV3JhcD5cclxuICAgICAgPC9Db250ZW50VGV4dD5cclxuICAgIDwvQ29udGVudFdyYXA+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb250ZW50TW9iaWxlO1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcclxuaW1wb3J0IENhcnJvdEhlYWRlciBmcm9tICcuLi8uLi9TaGFyZWQvQ2Fycm90SGVhZGVyL0NhcnJvdEhlYWRlcic7XHJcbmltcG9ydCBDb250ZW50RGVza3RvcCBmcm9tICcuL0NvbnRlbnREZXNrdG9wJztcclxuaW1wb3J0IENvbnRlbnRNb2JpbGUgZnJvbSAnLi9Db250ZW50TW9iaWxlJztcclxuaW1wb3J0IGZvbnRzIGZyb20gJy4uLy4uLy4uL3N0eWxlcy90eXBvZ3JhcGh5JztcclxuXHJcbmNvbnN0IFNlY3Rpb24gPSBzdHlsZWQuc2VjdGlvbmBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkZENzREO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIG1pbi1oZWlnaHQ6IDMwcmVtO1xyXG5gO1xyXG5cclxuY29uc3QgQnViYmxlc0ltYWdlID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgei1pbmRleDogMDtcclxuICB0b3A6IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaW1nIHtcclxuICAgIHdpZHRoOiAxMDB2dztcclxuICAgIGhlaWdodDogYXV0bztcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBIZWFkZXJXcmFwID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5gO1xyXG5cclxuY29uc3QgSW5uZXJXcmFwID0gc3R5bGVkLmRpdmBcclxuICBtYXgtd2lkdGg6IDExMTBweDtcclxuICBtYXJnaW46IDAgYXV0bztcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgbWF4LXdpZHRoOiA5NTBweDtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBCb3R0b21UZXh0ID0gc3R5bGVkLnBgXHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxOTIwLmhlaWdodH07XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE2NjAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxNjYwLmhlaWdodH07XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBtYXJnaW4tdG9wOiAzMHB4O1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTQ0MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzE0NDAuaGVpZ2h0fTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMjUwcHgpIHtcclxuICAgIHBhZGRpbmc6IDUwcHggNDhweCAxMHB4IDQ4cHg7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDo4MDBweCkge1xyXG4gICAgcGFkZGluZzogMCAwIDEwcHggMDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDAgNDhweDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NzY4LmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53NzY4LmhlaWdodH07XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzUwMC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzUwMC5oZWlnaHR9O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEZ1bm55QnVubmllc0ltYWdlID0gc3R5bGVkLmRpdmBcclxuICBtYXgtd2lkdGg6IDExNDBweDtcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBtYXJnaW4tdG9wOiA1MHB4O1xyXG4gIHRvcDogMTBweDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgbWF4LXdpZHRoOiAxMDUwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA4MDBweCkge1xyXG4gICAgbWFyZ2luLXRvcDogMDtcclxuICAgIHdpZHRoOiAxMTAlO1xyXG4gICAgbGVmdDogLTUlO1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEV2b2x1dGlvbiA9ICgpID0+IHtcclxuICBjb25zdCBbaXNNb2JpbGUsIHNldElzTW9iaWxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgcmVzaXplRXZlbnRIYW5kbGUgPSAoKSA9PiB7XHJcbiAgICBpZiAod2luZG93LmlubmVyV2lkdGggPCA4MDApIHtcclxuICAgICAgc2V0SXNNb2JpbGUodHJ1ZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRJc01vYmlsZShmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHJlc2l6ZUV2ZW50SGFuZGxlKCk7XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgcmVzaXplRXZlbnRIYW5kbGUpO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHJlc2l6ZUV2ZW50SGFuZGxlKTtcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNlY3Rpb24gaWQ9XCJyYWJiaXRcIiA+XHJcbiAgICAgIDxCdWJibGVzSW1hZ2U+XHJcbiAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICB3aWR0aD17MTQ0MH1cclxuICAgICAgICAgIGhlaWdodD17MzM2fVxyXG4gICAgICAgICAgc3JjPVwiL2ltZy9idWJibGVzX2JsdWVfdXAucG5nXCJcclxuICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9CdWJibGVzSW1hZ2U+XHJcbiAgICAgIDxJbm5lcldyYXA+XHJcbiAgICAgICAgPEhlYWRlcldyYXA+XHJcbiAgICAgICAgICA8Q2Fycm90SGVhZGVyIGJnQ29sb3I9XCIjRkZFREFGXCIgcGFkZGluZz1cIjEuNTYyNXJlbSA0LjA2MjVyZW0gMjVweCA2Ljg3NXJlbVwiPlxyXG4gICAgICAgICAgICBFdm9sdXRpb24gb2YgRGEgQnVubnlcclxuICAgICAgICAgIDwvQ2Fycm90SGVhZGVyPlxyXG4gICAgICAgIDwvSGVhZGVyV3JhcD5cclxuICAgICAgICB7aXNNb2JpbGVcclxuICAgICAgICAgID9cclxuICAgICAgICAgIDxDb250ZW50TW9iaWxlIC8+XHJcbiAgICAgICAgICA6XHJcbiAgICAgICAgICA8Q29udGVudERlc2t0b3AgLz5cclxuICAgICAgICB9XHJcbiAgICAgICAgPEJvdHRvbVRleHQ+XHJcbiAgICAgICAgICBJdCBzb29uIG9jY3VycmVkIHRvIGFub3RoZXIgcmFiYml0IHRoYXQgY3J5cHRvIHRyYWRlIHdheSBtb3JlIGNhcnJvdHMgd2l0aCBodW1hbnMgdGhhbiBjaG9jb2xhdGUgZWdncy4gSXQgc29vbiBvY2N1cmVkIHRvIHlldCBhbm90aGVyXHJcbiAgICAgICAgICByYWJiaXQgdGhhdCBjYXJyb3RzIGFyZSB0b28gYmxhbmQgZm9yIGhpcyB0YXN0ZSwgYW5kIGhlIG9yZGVyZWQgcGl6emEgZm9yIHRoZSBmaXJzdCB0aW1lLiBUaGUg4oCcQWhhIeKAnSBtb21lbnRzIGNvbnRpbnVlZCB0byBjYXNjYWRlIGFuZCBvbmVcclxuICAgICAgICAgIGRheSwgYSB0cmliZSBtZW1iZXIgZGVjaWRlZCB0byB0YWtlIGZ1bm55IHBvcnRyYWl0cyBvZiBldmVyeW9uZSBvbiB0aGUgaXNsYW5kIGFuZCBzZWxsIG9ubGluZSBhcyBORlRzIC0gYW5kIHRoaXMgZ2l2ZXMgcmlzZSB0byBEYSBCdW5ueSFcclxuICAgICAgICA8L0JvdHRvbVRleHQ+XHJcbiAgICAgIDwvSW5uZXJXcmFwPlxyXG4gICAgICA8RnVubnlCdW5uaWVzSW1hZ2U+XHJcbiAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICB3aWR0aD17MTQ0MH1cclxuICAgICAgICAgIGhlaWdodD17NDQzfVxyXG4gICAgICAgICAgc3JjPVwiL2ltZy9mdW5ueV9idW5pZXMucG5nXCJcclxuICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9GdW5ueUJ1bm5pZXNJbWFnZT5cclxuICAgIDwvU2VjdGlvbiA+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFdm9sdXRpb247IiwiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xyXG5pbXBvcnQgQ2Fycm90SGVhZGVyIGZyb20gJy4uL1NoYXJlZC9DYXJyb3RIZWFkZXIvQ2Fycm90SGVhZGVyJztcclxuaW1wb3J0IGZvbnRzIGZyb20gJy4uLy4uL3N0eWxlcy90eXBvZ3JhcGh5JztcclxuXHJcbmNvbnN0IFNlY3Rpb24gPSBzdHlsZWQuc2VjdGlvbmBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzlCOUZGO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBwYWRkaW5nLXRvcDogOXJlbTtcclxuICBwYWRkaW5nLWJvdHRvbTogMjVyZW07XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6NzY4cHgpIHtcclxuICAgIHBhZGRpbmctdG9wOiA0OHB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206ICAyNDBweDtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBIZWFkZXJXcmFwID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5gO1xyXG5cclxuY29uc3QgSW5uZXJMaW1pdCA9IHN0eWxlZC5zZWN0aW9uYFxyXG4gIG1heC13aWR0aDogOTByZW07XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbmA7XHJcblxyXG5jb25zdCBQYXJhZ3JhcGggPSBzdHlsZWQucGBcclxuICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxOTIwLmZvbnRTaXplfTtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTY2MC5mb250U2l6ZX07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE0NDAuZm9udFNpemV9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzc2OC5mb250U2l6ZX07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NTAwLmZvbnRTaXplfTtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBRdWVzdGlvbldyYXAgPSBzdHlsZWQuZGl2YFxyXG4gIG1hcmdpbi10b3A6IDYuMjVyZW07XHJcbiAgcGFkZGluZzogMy4xMjVyZW0gODBweDtcclxuICBtYXJnaW46IDAgODBweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjQkJFN0ZGO1xyXG4gIGJvcmRlcjogM3B4IHNvbGlkICMwMDAwMDA7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBib3gtc2hhZG93OjAgOHB4IDAgIzAwMDAwMDtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6NzY4cHgpIHtcclxuICAgIHBhZGRpbmc6IDE2cHg7XHJcbiAgICBtYXJnaW46IDAgMTZweDtcclxuICAgIGJveC1zaGFkb3c6IDAgMy4ycHggMCAwICMwMDAwMDA7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgVGV4dEhlYWRlciA9IHN0eWxlZC5oM2BcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkZCOUI5O1xyXG4gIGJvcmRlci1yYWRpdXM6IDguNDM3NXJlbTtcclxuICBoZWlnaHQ6IDQuNjVyZW07XHJcbiAgcGFkZGluZzogMS41cmVtIDQwcHg7XHJcbiAgYm94LXNoYWRvdzogMTZweCAxNnB4IDAgMCAjMDAwMDAwO1xyXG4gIHdpZHRoOiBtYXgtY29udGVudDtcclxuICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxOTIwLmZvbnRTaXplfTtcclxuICBtYXJnaW46IDNyZW0gODBweCAzcmVtIDgwcHg7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE2NjAuZm9udFNpemV9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNDQwLmZvbnRTaXplfTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc3NjguZm9udFNpemV9O1xyXG4gICAgbWFyZ2luOiAgMjRweCBhdXRvICAyNHB4IGF1dG87XHJcbiAgICBoZWlnaHQ6IDM4cHg7XHJcbiAgICBwYWRkaW5nOiAxMHB4IDMwcHg7XHJcbiAgICBib3gtc2hhZG93OiA2LjVweCA2LjVweCAwIDAgIzAwMDAwMDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc1MDAuZm9udFNpemV9O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IFRleHRIZWFkZXJGaXJzdCA9IHN0eWxlZChUZXh0SGVhZGVyKWBcclxuICBtYXJnaW46IDVyZW0gODBweCAzcmVtIDgwcHg7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOjc2OHB4KSB7XHJcbiAgICBtYXJnaW46IDMycHggYXV0byA0OHB4IGF1dG87XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgTGlzdCA9IHN0eWxlZC51bGBcclxuICBwYWRkaW5nLWxlZnQ6IDQwcHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6NzY4cHgpIHtcclxuICAgIHBhZGRpbmctbGVmdDogMTZweDtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBMaXN0SXRlbSA9IHN0eWxlZC5saWBcclxuICBmb250LWZhbWlseTogJ1NwYWNlIEdyb3Rlc2snLCBzYW5zLXNlcmlmO1xyXG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTkyMC5mb250U2l6ZX07XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE2NjAuZm9udFNpemV9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNDQwLmZvbnRTaXplfTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc3NjguZm9udFNpemV9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzUwMC5mb250U2l6ZX07XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQnViYmxlc0ltYWdlID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgei1pbmRleDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIGJvdHRvbTogLTEwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaW1nIHtcclxuICAgIHdpZHRoOiAxMDB2dztcclxuICAgIGhlaWdodDogYXV0bztcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBEcm9wRG93biA9IHN0eWxlZC5kaXY8eyBleHBhbmRlZDogYm9vbGVhbiB9PmBcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIGhlaWdodDogJHsoeyBleHBhbmRlZCB9KSA9PiBleHBhbmRlZCA/IDc1OCA6IDB9cHg7XHJcbiAgdHJhbnNpdGlvbjogaGVpZ2h0IC41cyBlYXNlLW91dDtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEwMDBweCkge1xyXG4gICAgaGVpZ2h0OiAkeyh7IGV4cGFuZGVkIH0pID0+IGV4cGFuZGVkID8gNjIwIDogMH1weDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgaGVpZ2h0OiAkeyh7IGV4cGFuZGVkIH0pID0+IGV4cGFuZGVkID8gMjAwIDogMH1weDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgaGVpZ2h0OiAkeyh7IGV4cGFuZGVkIH0pID0+IGV4cGFuZGVkID8gMjYwIDogMH1weDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAzMjBweCkge1xyXG4gICAgaGVpZ2h0OiAkeyh7IGV4cGFuZGVkIH0pID0+IGV4cGFuZGVkID8gMjgwIDogMH1weDtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBDbGlja1Nob3cgPSBzdHlsZWQuZGl2PHsgZXhwYW5kZWQ6IGJvb2xlYW4gfT5gXHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDI7XHJcbiAgbWFyZ2luOiA1MHB4IDAgMCAwO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE5MjAuZm9udFNpemV9O1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE2NjAuZm9udFNpemV9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNDQwLmZvbnRTaXplfTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc3NjguZm9udFNpemV9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzUwMC5mb250U2l6ZX07XHJcbiAgfVxyXG5cclxuICBzdmcge1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG4gICAgZmlsbDogI2ZmZjtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKCR7KHsgZXhwYW5kZWQgfSkgPT4gZXhwYW5kZWQgPyA1NDAgOiAwfWRlZyk7XHJcbiAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gLjJzIGVhc2Utb3V0O1xyXG5cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgICB3aWR0aDogMjRweDtcclxuICAgICAgaGVpZ2h0OiAyNHB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA0cHg7XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQXJyb3cgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMzMwIDMzMFwiPlxyXG4gICAgICA8cGF0aCBkPVwiTTMyNS42MDcsNzkuMzkzYy01Ljg1Ny01Ljg1Ny0xNS4zNTUtNS44NTgtMjEuMjEzLDAuMDAxbC0xMzkuMzksMTM5LjM5M0wyNS42MDcsNzkuMzkzXHJcbiAgICAgICAgICAgICAgYy01Ljg1Ny01Ljg1Ny0xNS4zNTUtNS44NTgtMjEuMjEzLDAuMDAxYy01Ljg1OCw1Ljg1OC01Ljg1OCwxNS4zNTUsMCwyMS4yMTNsMTUwLjAwNCwxNTBjMi44MTMsMi44MTMsNi42MjgsNC4zOTMsMTAuNjA2LDQuMzkzXHJcbiAgICAgICAgICAgICAgczcuNzk0LTEuNTgxLDEwLjYwNi00LjM5NGwxNDkuOTk2LTE1MEMzMzEuNDY1LDk0Ljc0OSwzMzEuNDY1LDg1LjI1MSwzMjUuNjA3LDc5LjM5M3pcIi8+XHJcbiAgICA8L3N2Zz5cclxuICApXHJcbn1cclxuXHJcbmNvbnN0IEZhcSA9ICgpID0+IHtcclxuICBjb25zdCBbZXhwYW5kZWQsIHNldEV4cGFuZGVkXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlU2hvdyA9ICgpID0+IHtcclxuICAgIHNldEV4cGFuZGVkKCFleHBhbmRlZCk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNlY3Rpb24+XHJcbiAgICAgIDxJbm5lckxpbWl0IGlkPVwiZmFxXCI+XHJcbiAgICAgICAgPEhlYWRlcldyYXA+XHJcbiAgICAgICAgICA8Q2Fycm90SGVhZGVyIGJnQ29sb3I9XCIjQzZFQkZGXCIgcGFkZGluZz1cIjEuNTYyNXJlbSA2NHB4IDI1cHggOTZweFwiPlxyXG4gICAgICAgICAgICBGcmVxdWVudGx5IEFza2VkIFF1ZXN0aW9uc1xyXG4gICAgICAgICAgPC9DYXJyb3RIZWFkZXI+XHJcbiAgICAgICAgPC9IZWFkZXJXcmFwPlxyXG4gICAgICAgIDxUZXh0SGVhZGVyRmlyc3Q+SG93IHJhcmUgaXMgbXkgQnVubnk/PC9UZXh0SGVhZGVyRmlyc3Q+XHJcbiAgICAgICAgPFF1ZXN0aW9uV3JhcD5cclxuICAgICAgICAgIDxQYXJhZ3JhcGg+4oCcQWxsIGJ1bm5pZXMgYXJlIHJhcmUgYnV0IHNvbWUgYXJlIG1vcmUgcmFyZSB0aGFuIG90aGVycy7igJ0gT24gdGhlIHNjYWxlIG9mIDEtMTAwJTo8L1BhcmFncmFwaD5cclxuICAgICAgICAgIDxMaXN0PlxyXG4gICAgICAgICAgICA8TGlzdEl0ZW0+NCwwMDAgKDUwJSkgYXJlIGZyZWVseSByb2FtaW5nIFdpbGQgQnVubmllcyBhYnVuZGFudCBldmVyeXdoZXJlIG9uIHRoZSBJc2xhbmQsPC9MaXN0SXRlbT5cclxuICAgICAgICAgICAgPExpc3RJdGVtPjIsNTAwICgzMSUpIGFyZSBSYXJlIEJ1bm5pZXMgKFJCKSBmb3VuZCBpbiBzZWxlY3QgaGFiaXRhdHMsPC9MaXN0SXRlbT5cclxuICAgICAgICAgICAgPExpc3RJdGVtPjEsMDAwICgxMyUpIGFyZSBTdXBlciBSYXJlIEJ1bm5pZXMgKFNSQikgaGlkZGVuIGluIERhIEJ1bm55IFJhYmJpdCBIb2xlLDwvTGlzdEl0ZW0+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbT41MDAgKDYlKSBhcmUgU3VwZXIgU3VwZXIgUmFyZSBCdW5uaWVzIChTU1JCKSB0aGF0IHRyYXZlbCB2aWEgc2VjcmV0IHVuZGVyZ3JvdW5kIHBhdGh3YXlzIG9ubHksIGFuZDwvTGlzdEl0ZW0+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbT41MCAoeyc8J30xJSkgYXJlIFN1cGVyaW9yIEJ1bm5pZXMgKFNCKykgZXF1aXBwZWQgb25seSB3aXRoIG9uZS1vZi1hLWtpbmQgYWNjZXNzb3JpZXMgYW5kIG91dGZpdHMuPC9MaXN0SXRlbT5cclxuICAgICAgICAgIDwvTGlzdD5cclxuICAgICAgICA8L1F1ZXN0aW9uV3JhcD5cclxuICAgICAgICA8VGV4dEhlYWRlcj5XaGF0IGlzIGFuIE5GVD88L1RleHRIZWFkZXI+XHJcbiAgICAgICAgPFF1ZXN0aW9uV3JhcD5cclxuICAgICAgICAgIDxQYXJhZ3JhcGg+XHJcbiAgICAgICAgICAgIE5GVCBzdGFuZHMgZm9yIOKAnE5vbi1mdW5naWJsZSB0b2tlbuKAnSBhbmQgaXMgYSBmYW5jeSB3YXkgb2Ygc2F5aW5nIGl04oCZcyBhIHVuaXF1ZSwgb25lIG9mIGEga2luZCBkaWdpdGFsIGl0ZW0gdGhhdCB1c2VycyBjYW4gYnV5LCBvd24sXHJcbiAgICAgICAgICAgIGFuZCB0cmFkZS4gU29tZSBORlRzIG1haW4gZnVuY3Rpb24gYXJlIHRvIGJlIGRpZ2l0YWwgYXJ0IGFuZCBsb29rIGNvb2wsIHNvbWUgb2ZmZXIgYWRkaXRpb25hbCB1dGlsaXR5IGxpa2UgZXhjbHVzaXZlIGFjY2VzcyB0b1xyXG4gICAgICAgICAgICB3ZWJzaXRlcyBvciBwYXJ0aWNpcGF0aW9uIGluIGFuIGV2ZW50LCB0aGluayBvZiBpdCBsaWtlIGEgcmFyZSBwaWVjZSBvZiBhcnQgdGhhdCBjYW4gYWxzbyBhY3QgYXMgYSDigJxtZW1iZXJz4oCdIGNhcmQuXHJcbiAgICAgICAgICA8L1BhcmFncmFwaD5cclxuICAgICAgICA8L1F1ZXN0aW9uV3JhcD5cclxuICAgICAgICA8VGV4dEhlYWRlcj5XaGF0IGlzIE1ldGFtYXNrPzwvVGV4dEhlYWRlcj5cclxuICAgICAgICA8UXVlc3Rpb25XcmFwPlxyXG4gICAgICAgICAgPFBhcmFncmFwaD5cclxuICAgICAgICAgICAgTWV0YW1hc2sgaXMgYSBjcnlwdG8gd2FsbGV0IHRoYXQgY2FuIHN0b3JlIHlvdXIgRXRoZXJldW0sIGFuZCBpcyBuZWVkZWQgdG8gcHVyY2hhc2UgYW5kIG1pbnQgRGEgQnVubnkuIEhhdmluZyBhIHdhbGxldCBnaXZlcyB5b3UgYW5cclxuICAgICAgICAgICAgRXRoZXJldW0gYWRkcmVzcyAoaS5lLiAweEFCQ0TigKYuMTIzNCksIHRoaXMgaXMgd2hlcmUgeW91ciBORlQgd2lsbCBiZSBzdG9yZWQuIExlYXJuIG1vcmUgYWJvdXQgTWV0YW1hc2sgYW5kIGhvdyBlYXN5IGl0IGlzIHRvIHVzZSBvdmVyIGhlcmUhIChodHRwczovL21ldGFtYXNrLmlvLylcclxuICAgICAgICAgIDwvUGFyYWdyYXBoPlxyXG4gICAgICAgIDwvUXVlc3Rpb25XcmFwPlxyXG4gICAgICAgIDxDbGlja1Nob3cgb25DbGljaz17dG9nZ2xlU2hvd30gZXhwYW5kZWQ9e2V4cGFuZGVkfT5cclxuICAgICAgICAgIE1vcmVcclxuICAgICAgICAgIDxBcnJvdyAvPlxyXG4gICAgICAgIDwvQ2xpY2tTaG93PlxyXG4gICAgICAgIDxEcm9wRG93biBleHBhbmRlZD17ZXhwYW5kZWR9PlxyXG4gICAgICAgICAgPFRleHRIZWFkZXI+V2hhdCBpcyBPcGVuU2VhPzwvVGV4dEhlYWRlcj5cclxuICAgICAgICAgIDxRdWVzdGlvbldyYXA+XHJcbiAgICAgICAgICAgIDxQYXJhZ3JhcGg+XHJcbiAgICAgICAgICAgICAgT3BlblNlYSBpcyBhIHBlZXItdG8tcGVlciBtYXJrZXRwbGFjZSBmb3IgY3J5cHRvIGNvbGxlY3RpYmxlcyBhbmQgbm9uLWZ1bmdpYmxlIHRva2Vucy4gSXQgc2VydmVzIGFzIGEgc2Vjb25kYXJ5IG1hcmtldCBmb3IgTkZUcy4gRGEgQnVubnkgTkZUIENvbGxlY3Rpb24gY2FuIGJlXHJcbiAgICAgICAgICAgICAgdHJhZGVkIG9uIE9wZW5TZWEgKERhIEJ1bm55IE5GVCkgKGh0dHBzOi8vb3BlbnNlYS5pby8pXHJcbiAgICAgICAgICAgIDwvUGFyYWdyYXBoPlxyXG4gICAgICAgICAgPC9RdWVzdGlvbldyYXA+XHJcbiAgICAgICAgICA8VGV4dEhlYWRlcj5IYXZlIE1vcmUgUXVlc3Rpb25zPzwvVGV4dEhlYWRlcj5cclxuICAgICAgICAgIDxRdWVzdGlvbldyYXA+XHJcbiAgICAgICAgICAgIDxQYXJhZ3JhcGg+XHJcbiAgICAgICAgICAgIENvbWUgY2hhdCB3aXRoIHVzIG9uIERpc2NvcmQgKGh0dHBzOi8vZGlzY29yZC5nZy9xMk1kTXRoRjJ6KVxyXG4gICAgICAgICAgICA8L1BhcmFncmFwaD5cclxuICAgICAgICAgIDwvUXVlc3Rpb25XcmFwPlxyXG4gICAgICAgIDwvRHJvcERvd24+XHJcbiAgICAgIDwvSW5uZXJMaW1pdD5cclxuICAgICAgPEJ1YmJsZXNJbWFnZT5cclxuICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgIHdpZHRoPXsxNDQwfVxyXG4gICAgICAgICAgaGVpZ2h0PXs0NDN9XHJcbiAgICAgICAgICBzcmM9XCIvaW1nL2J1YmJsZXNfeWVsbG93LnBuZ1wiXHJcbiAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvQnViYmxlc0ltYWdlPlxyXG4gICAgPC9TZWN0aW9uID5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEZhcTsiLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XHJcbmltcG9ydCBJbWFnZSBmcm9tICduZXh0L2ltYWdlJztcclxuaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cyc7XHJcbmltcG9ydCBmb250cyBmcm9tICcuLi8uLi9zdHlsZXMvdHlwb2dyYXBoeSc7XHJcbmltcG9ydCB7IG5mdGFkZHJlc3MgfSBmcm9tIFwiLi4vLi4vdXRpbHMvY29uZmlnXCI7XHJcbmltcG9ydCB2YWxpZGF0b3IgZnJvbSAndmFsaWRhdG9yJztcclxuaW1wb3J0IHsgRElTQ09SRF9MSU5LIH0gZnJvbSAnLi4vLi4vbGlua3MvTGlua3MnO1xyXG5cclxuY29uc3QgU2VjdGlvbiA9IHN0eWxlZC5zZWN0aW9uYFxyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmQ3NGM7XHJcbiAgaGVpZ2h0OiA0NC4zNzVyZW07XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHBhZGRpbmc6IDMuMTI1cmVtIDAgMCAwO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOjExMDBweCkge1xyXG4gICAgaGVpZ2h0OiB1bnNldDtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gIFxyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IElubmVyV3JhcCA9IHN0eWxlZC5kaXZgXHJcbiAgcGFkZGluZzogMCAzMnB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdG9wOiAtMjgwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQnVubnlJbWFnZSA9IHN0eWxlZC5kaXZgXHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDM7XHJcbiAgbGVmdDogIC00LjY4NzVyZW07XHJcbiAgdG9wOiAtMTkuMTg3NXJlbTtcclxuICB3aWR0aDogMjUuOTM3NXJlbTtcclxuICBAbWVkaWEgKG1heC13aWR0aDoxMTAwcHgpIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGxlZnQ6IC0zMHB4O1xyXG4gICAgdG9wOiA4MHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIHdpZHRoOiAyNTBweDtcclxuICAgIGxlZnQ6IC0yNXB4O1xyXG4gICAgdG9wOiA1NXB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IExhbmRzY2FwZUltYWdlID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgei1pbmRleDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIGJvdHRvbTogMDtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMTEwcHgpIHtcclxuICAgIGJvdHRvbTogMDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBib3R0b206IDA7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgU21hcnRDb250cmFjdFdyYXAgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB6LWluZGV4OiAxO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIG1heC13aWR0aDogMTExMHB4O1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDoxMTAwcHgpIHtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IFNtYXJ0TGVmdCA9IHN0eWxlZC5kaXZgXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6MTEwMHB4KSB7XHJcbiAgICBvcmRlcjogMTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IDYwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgVGV4dFRvcCA9IHN0eWxlZC5wYFxyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxOTIwLmhlaWdodH07XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTY2MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzE2NjAuaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTQ0MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzE0NDAuaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc3NjguZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc3NjguaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc1MDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc1MDAuaGVpZ2h0fTtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBUZXh0TWlkZGxlID0gc3R5bGVkLmFgXHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxOTIwLmhlaWdodH07XHJcbiAgY29sb3I6ICM0QTdBNzI7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XHJcbiAgbWFyZ2luLXRvcDogMjVweDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNjYwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53MTY2MC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNDQwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53MTQ0MC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzc2OC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzc2OC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzUwMC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzUwMC5oZWlnaHR9O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IFRva2VuQm90dG9tID0gc3R5bGVkLnBgXHJcbiAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxOTIwLmZvbnRTaXplfTtcclxuICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzE5MjAuaGVpZ2h0fTtcclxuICBtYXJnaW4tdG9wOiAzNXB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDE0cHg7XHJcbiAgd29yZC1icmVhazogYnJlYWstYWxsO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE2NjAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxNjYwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE0NDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxNDQwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NzY4LmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53NzY4LmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NTAwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53NTAwLmhlaWdodH07XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgU21hcnRSaWdodCA9IHN0eWxlZC5hYFxyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBwYWRkaW5nLXRvcDogNC4zNzVyZW07XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6MTEwMHB4KSB7XHJcbiAgICBvcmRlcjogMDtcclxuICAgIHBhZGRpbmctdG9wOiAwO1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IFRleHRSaWdodCA9IHN0eWxlZC5wYFxyXG53aWR0aDogMzM0LjNweDtcclxuaGVpZ2h0OiAxMzUuMzRweDtcclxuZm9udC1mYW1pbHk6IFNwYWNlIEdyb3Rlc2s7XHJcbmZvbnQtc3R5bGU6IG5vcm1hbDtcclxuZm9udC13ZWlnaHQ6IDYwMDtcclxuZm9udC1zaXplOiAyNy43NjE5cHg7XHJcbmxpbmUtaGVpZ2h0OiAzNXB4O1xyXG5kaXNwbGF5OiBmbGV4O1xyXG5hbGlnbi1pdGVtczogY2VudGVyO1xyXG50ZXh0LWFsaWduOiBjZW50ZXI7XHJcbmNvbG9yOiAjMDAwMDAwO1xyXG4gIHBhZGRpbmc6IDJyZW0gMjBweCAyMHB4IDIwcHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGJhY2tncm91bmQ6ICNFN0Q3RjQ7XHJcbiAgYm9yZGVyOiAzLjVweCBzb2xpZCAjMDAwMDAwO1xyXG4gIGJveC1zaGFkb3c6IDlweCA5cHggMCAjMDAwMDAwO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XHJcbiAgaGVpZ2h0OiA2cmVtO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMjcuNzYxOXB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6IDI3Ljc2MTlweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyMC53MTQ0MC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDoxMTAwcHgpIHtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjAudzc2OC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjAudzc2OC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjAudzUwMC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjAudzUwMC5oZWlnaHR9O1xyXG4gICAgd2lkdGg6IDIwMHB4O1xyXG4gICAgaGVpZ2h0OiB1bnNldDtcclxuICAgIHBhZGRpbmc6IDMycHggMjBweCAyMHB4IDIwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgTGlua3MgPSBzdHlsZWQudWxgXHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgbWFyZ2luLXRvcDogMTIwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbmA7XHJcblxyXG5jb25zdCBJdGVtID0gc3R5bGVkLmxpYFxyXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbiAgcGFkZGluZzogMCAzLjEyNXJlbTtcclxuICBmb250LXdlaWdodDogNzAwO1xyXG4gIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjAudzE5MjAuZm9udFNpemV9O1xyXG4gIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyMC53MTkyMC5oZWlnaHR9O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjAudzE2NjAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDIwLncxNjYwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjAudzE0NDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDIwLncxNDQwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOjExMDBweCkge1xyXG4gICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyMC53NzY4LmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyMC53NzY4LmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyMC53NTAwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyMC53NTAwLmhlaWdodH07XHJcbiAgfVxyXG5cclxuICBhIHtcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQ29weXJpZ2h0ID0gc3R5bGVkLmRpdmBcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgfVxyXG5gO1xyXG5jb25zdCBFbWFpbFN1YnNjcmliZSA9IHN0eWxlZC5kaXZgXHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB6LWluZGV4OiAxO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gIH1cclxuYDtcclxuY29uc3QgQ3VzdG9tSW5wdXRUZXh0ID0gc3R5bGVkLmlucHV0YFxyXG5iYWNrZ3JvdW5kOiAjRkZGRkZGO1xyXG5ib3JkZXI6IDNweCBzb2xpZCAjMDAwMDAwO1xyXG5ib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG5ib3JkZXItcmFkaXVzOiAxMXB4O1xyXG53aWR0aDogNDcxcHg7XHJcbmhlaWdodDogNjhweDtcclxuZm9udC1mYW1pbHk6IFNwYWNlIEdyb3Rlc2s7XHJcbmZvbnQtc3R5bGU6IG5vcm1hbDtcclxuZm9udC13ZWlnaHQ6IDUwMDtcclxuZm9udC1zaXplOiAyNXB4O1xyXG5saW5lLWhlaWdodDogMzJweDtcclxuY29sb3I6ICNCNUI1QjU7XHJcbm1hcmdpbi1yaWdodDogMTVweDtcclxuICBwYWRkaW5nOiAwIDEycHg7XHJcbmBcclxuY29uc3QgQ3VzdG9tSW5wdXRCdG4gPSBzdHlsZWQuaW5wdXRgXHJcbmJhY2tncm91bmQ6ICM5NkVCQkE7XHJcbmJvcmRlcjogM3B4IHNvbGlkICMwMDAwMDA7XHJcbmJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbmJveC1zaGFkb3c6IDNweCA0cHggMHB4ICMwMDAwMDA7XHJcbmJvcmRlci1yYWRpdXM6IDExcHg7XHJcbmZvbnQtZmFtaWx5OiBTcGFjZSBHcm90ZXNrO1xyXG5mb250LXN0eWxlOiBub3JtYWw7XHJcbmZvbnQtd2VpZ2h0OiA1MDA7XHJcbmZvbnQtc2l6ZTogMzBweDtcclxubGluZS1oZWlnaHQ6IDM4cHg7XHJcbmNvbG9yOiAjMDAwMDAwO1xyXG53aWR0aDogMTQycHg7XHJcbmhlaWdodDogNjhweDtcclxuICBwYWRkaW5nOiAwIDEycHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG5gXHJcbmNvbnN0IFBhcmFncmFwaCA9IHN0eWxlZC5wYFxyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBsaW5lLWhlaWdodDogMjZweDtcclxuICBwYWRkaW5nLWJvdHRvbTogMTAwcHg7XHJcbmA7XHJcblxyXG5jb25zdCBEaXNwbGF5TWVzc2FnZSA9IHN0eWxlZC5kaXZgXHJcbiAgY29sb3I6IHJlZDtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB6LWluZGV4OiAxO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICB9XHJcbmBcclxuY29uc3QgTG9hZGVyID0gc3R5bGVkLnBgXHJcbiAgY29sb3I6IGJsYWNrO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgei1pbmRleDogMTtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgfVxyXG5gXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgYWRkcmVzczogc3RyaW5nO1xyXG4gIGJhbGFuY2U6IG51bWJlcjtcclxuICBuZXR3b3JrOiBzdHJpbmc7XHJcbn1cclxuXHJcbmNvbnN0IEZvb3RlciA9ICh7YWRkcmVzcywgYmFsYW5jZSwgbmV0d29ya306IFByb3BzKSA9PiB7XHJcblxyXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKCcnKTtcclxuXHJcbiAgY29uc3Qgb25FbWFpbFN1YnNjcmliZUhhbmRsZSA9YXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0TWVzc2FnZSgnJyk7XHJcbiAgICBpZighdmFsaWRhdG9yLmlzRW1haWwoZW1haWwpKXtcclxuICAgICAgc2V0TWVzc2FnZSgnUGxlYXNlIGVudGVyIGEgdmFsaWQgZW1haWwgaWQnKTtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbGV0IGVtYWlsRGF0YSA9IHtcclxuICAgICAgICBlbWFpbElkOiBlbWFpbCxcclxuICAgICAgICB1c2VyQWRkcmVzczogYWRkcmVzc1xyXG4gICAgICB9XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGxldCByZXNwb25zZSA9IGF3YWl0IGZldGNoKCcvYXBpL2VtYWlscycsIHtcclxuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGVtYWlsRGF0YSksXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgbGV0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ1Jlc3BvbnNlIGZyb20gc2VydmVyOiAnLCByZXNwb25zZSwgZGF0YSk7XHJcbiAgICAgICAgc2V0TWVzc2FnZShkYXRhLm1lc3NhZ2UpO1xyXG4gICAgICAgIFxyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnRXJyb3Igd2hpbGUgdXBkYXRpbmcgZGF0YSB0byBCYWNrZW5kJywgZXJyKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgY29uc29sZS5sb2coJ0VtYWlsIGlkIGlzIDogJywgZW1haWwpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxTZWN0aW9uPlxyXG4gICAgICA8SW5uZXJXcmFwPlxyXG4gICAgICAgIDxTbWFydENvbnRyYWN0V3JhcD5cclxuICAgICAgICAgIDxTbWFydExlZnQ+XHJcbiAgICAgICAgICAgIDxUZXh0VG9wPlZlcmlmaWVkIFNtYXJ0IENvbnRyYWN0OjwvVGV4dFRvcD5cclxuICAgICAgICAgICAgPFRleHRNaWRkbGUgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXJcIiBocmVmPXtcImh0dHBzOi8vcmlua2VieS5ldGhlcnNjYW4uaW8vYWRkcmVzcy9cIituZnRhZGRyZXNzfT5WaWV3IG9uIEV0aGVyc2NhbjwvVGV4dE1pZGRsZT5cclxuICAgICAgICAgICAgPFRva2VuQm90dG9tPntuZnRhZGRyZXNzPyBuZnRhZGRyZXNzIDogJzB4Li4uJ308L1Rva2VuQm90dG9tPlxyXG4gICAgICAgICAgICA8RW1haWxTdWJzY3JpYmU+XHJcbiAgICAgICAgICA8Q3VzdG9tSW5wdXRUZXh0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cImVtYWlsXCIgaWQ9XCJlbWFpbElkXCIgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfS8+XHJcbiAgICAgICAgICA8Q3VzdG9tSW5wdXRCdG4gdHlwZT1cImJ1dHRvblwiIHZhbHVlPVwiSm9pblwiIG9uQ2xpY2s9e29uRW1haWxTdWJzY3JpYmVIYW5kbGV9Lz5cclxuICAgICAgICAgIDxEaXNwbGF5TWVzc2FnZT57bWVzc2FnZX08L0Rpc3BsYXlNZXNzYWdlPlxyXG4gICAgICAgIDwvRW1haWxTdWJzY3JpYmU+XHJcbiAgICAgICAgICA8L1NtYXJ0TGVmdD5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPFNtYXJ0UmlnaHQgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXJcIiBocmVmPXtESVNDT1JEX0xJTkt9PlxyXG4gICAgICAgICAgICA8QnVubnlJbWFnZT5cclxuICAgICAgICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgICAgICAgIHdpZHRoPXs0MTV9XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ9ezQ4M31cclxuICAgICAgICAgICAgICAgIHNyYz1cIi9pbWcvRGlzY29yZCBCdW5ueSBHSUYuZ2lmXCJcclxuICAgICAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9CdW5ueUltYWdlPlxyXG4gICAgICAgICAgICA8VGV4dFJpZ2h0PkpvaW4gb3VyIERpc2NvcmQgQ2hhbm5lbDwvVGV4dFJpZ2h0PlxyXG4gICAgICAgICAgPC9TbWFydFJpZ2h0PlxyXG4gICAgICAgIDwvU21hcnRDb250cmFjdFdyYXA+XHJcbiAgICAgICAgPExpbmtzPlxyXG4gICAgICAgICAgPEl0ZW0+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCJodHRwczovL3d3dy5kYWJ1bm55bmZ0LmNvbS9wcml2YWN5XCI+XHJcbiAgICAgICAgICAgICAgPGE+UHJpdmF0ZSBQb2xpY3kgJiMzODsgQ29ubmVjdCBXYWxsZXQ8L2E+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgIDwvSXRlbT5cclxuICAgICAgICA8L0xpbmtzPlxyXG4gICAgICAgIDxDb3B5cmlnaHQ+XHJcbiAgICAgICAgICA8UGFyYWdyYXBoPkAyMDIxIERhIEJ1bm55IE5GVCA8YnI+PC9icj5cclxuICAgICAgICAgIFByb2R1Y2VkIGJ5IE1vb25MYWIgQ28uLCBhIERlY2VudGFsaXplZCBBdXRvbm9tb3VzIE9yZ2FuaXphdGlvbiAoREFPKVxyXG4gICAgICAgICAgPC9QYXJhZ3JhcGg+XHJcbiAgICAgICAgICB7LyogPFBhcmFncmFwaD5Qcm9kdWNlZCBmcm9tIEJ1bm55IExhbmQ8L1BhcmFncmFwaD4gKi99XHJcbiAgICAgICAgPC9Db3B5cmlnaHQ+XHJcbiAgICAgICAgXHJcbiAgICAgIDwvSW5uZXJXcmFwPlxyXG4gICAgICA8TGFuZHNjYXBlSW1hZ2U+XHJcbiAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICB3aWR0aD17MTQzOX1cclxuICAgICAgICAgIGhlaWdodD17MzE2fVxyXG4gICAgICAgICAgc3JjPVwiL2ltZy9sYW5kc2NhcGUucG5nXCJcclxuICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9MYW5kc2NhcGVJbWFnZT5cclxuICAgICAgXHJcbiAgICAgIFxyXG4gICAgPC9TZWN0aW9uPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRm9vdGVyOyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xyXG5pbXBvcnQgQ291bnRkb3duIGZyb20gJ3JlYWN0LWNvdW50ZG93bic7XHJcbmltcG9ydCB7IENPTk5FQ1RfU1RBVFVTLCBTQUxFX1NUQVRVUyB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL0ludGVyZmFjZSc7XHJcbmltcG9ydCBmb250cyBmcm9tICcuLi8uLi8uLi8uLi9zdHlsZXMvdHlwb2dyYXBoeSc7XHJcblxyXG5jb25zdCBDdGFCdXR0b24gPSBzdHlsZWQuZGl2YFxyXG4gIHdpZHRoOiAyOC40Mzc1cmVtO1xyXG4gIGhlaWdodDogNy41cmVtO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB0b3A6IC0xNC43NXJlbTtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBtYXJnaW46IDAgYXV0bztcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgd2lkdGg6IDIycmVtO1xyXG4gICAgaGVpZ2h0OiA2cmVtO1xyXG4gICAgdG9wOiAycmVtO1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDExNTBweCkge1xyXG4gICAgdG9wOiA1cmVtO1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICB3aWR0aDogMTQuNXJlbTtcclxuICAgIGhlaWdodDogMy44NzVyZW07XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgRmlyc3RMYXllciA9IHN0eWxlZC5kaXZgXHJcbiAgYmFja2dyb3VuZDogI0ZGREMyNTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgei1pbmRleDogMjtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogMDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgYm9yZGVyLXJhZGl1czogMTZweDtcclxuICBib3JkZXI6IDNweCBzb2xpZCAjMDAwMDAwO1xyXG5gO1xyXG5cclxuY29uc3QgU2Vjb25kTGF5ZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGJhY2tncm91bmQ6ICM0QTdBNzI7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgdG9wOiAtLjkzNzVyZW07XHJcbiAgbGVmdDogLjkzNzVyZW07XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJvcmRlci1yYWRpdXM6IDE2cHg7XHJcbiAgYm9yZGVyOiAzcHggc29saWQgIzAwMDAwMDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIHRvcDogLTAuMzM3NXJlbTtcclxuICAgIGxlZnQ6IDAuMzM3NXJlbTtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBCdXR0b25UZXh0ID0gc3R5bGVkLnBgXHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxOTIwLmhlaWdodH07XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzE2NjAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxNjYwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzE0NDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxNDQwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53NzY4LmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQ0MC53NzY4LmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc1MDAuZm9udFNpemV9O1xyXG4gICAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzUwMC5oZWlnaHR9O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEJ1dHRvblRleHRDbGljayA9IHN0eWxlZChCdXR0b25UZXh0KWBcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbmA7XHJcblxyXG5jb25zdCBMZWZ0Q29ybmVyU1ZHID0gKCkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3ZnIHdpZHRoPVwiNTBcIiBoZWlnaHQ9XCIzNlwiIHZpZXdCb3g9XCIwIDAgNTAgMzZcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cclxuICAgICAgPHBhdGggZD1cIk01IDMxLjM0NzJWMTkuMDk1N0M1IDExLjM2MzcgMTEuMjY4IDUuMDk1NyAxOSA1LjA5NTdINDVcIiBzdHJva2U9XCJ3aGl0ZVwiIHN0cm9rZVdpZHRoPVwiOVwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XHJcbiAgICA8L3N2Zz5cclxuICApXHJcbn1cclxuXHJcbmNvbnN0IFJpZ2h0Q29ybmVyU1ZHID0gKCkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3ZnIHdpZHRoPVwiOTJcIiBoZWlnaHQ9XCIyNVwiIHZpZXdCb3g9XCIwIDAgOTIgMjVcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cclxuICAgICAgPHBhdGggZD1cIk04Ny41IDUuMjM2NDlMODcuNSA1LjU5MjY3Qzg3LjUgMTMuMzI0NyA4MS4yMzIgMTkuNTkyNyA3My41IDE5LjU5MjdMNC41IDE5LjU5MjhcIiBzdHJva2U9XCJ3aGl0ZVwiIHN0cm9rZVdpZHRoPVwiOVwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XHJcbiAgICA8L3N2Zz5cclxuXHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCBMZWZ0Q29ybmVyID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgei1pbmRleDogMztcclxuICBsZWZ0OiAxMHB4O1xyXG4gIHRvcDogMTBweDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGxlZnQ6IC41MjVyZW07XHJcbiAgICB0b3A6IC4zMjVyZW07XHJcbiAgfVxyXG4gIHN2ZyB7XHJcbiAgICB3aWR0aDogNDBweDtcclxuICAgIGhlaWdodDogMS42ODc1cmVtO1xyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICAgIGhlaWdodDogMTMuNXB4O1xyXG4gICAgICB3aWR0aDogMjBweDtcclxuICAgIH1cclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBSaWdodENvcm5lciA9IHN0eWxlZC5kaXZgXHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDM7XHJcbiAgcmlnaHQ6IC4zMTI1cmVtO1xyXG4gIGJvdHRvbTogMTBweDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGJvdHRvbTogLjEyNXJlbTtcclxuICB9XHJcbiAgc3ZnIHtcclxuICAgIHdpZHRoOiA1LjE4NzVyZW07XHJcbiAgICBoZWlnaHQ6IDAuOTM3NXJlbTtcclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgICAgIHdpZHRoOiA0MnB4O1xyXG4gICAgICAgIGhlaWdodDogNy41cHg7XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG5pbnRlcmZhY2UgQ29ubmVjdEJ1dHRvbiB7XHJcbiAgY29ubmVjdFN0YXR1cz86IENPTk5FQ1RfU1RBVFVTLFxyXG4gIHNhbGVTdGF0dXM/OiBTQUxFX1NUQVRVU1xyXG4gIHRleHQ/OiBzdHJpbmcsXHJcbiAgc2V0U2hvd01pbnRCb3g6IChzaG93OiBib29sZWFuKSA9PiB2b2lkXHJcbn1cclxuXHJcbmNvbnN0IENvbm5lY3RCdXR0b24gPSAocHJvcHM6IENvbm5lY3RCdXR0b24pID0+IHtcclxuICBjb25zdCB7IGNvbm5lY3RTdGF0dXMgPSAwLCBzYWxlU3RhdHVzID0gMCwgc2V0U2hvd01pbnRCb3ggfSA9IHByb3BzO1xyXG4gIGNvbnNvbGUubG9nKGNvbm5lY3RTdGF0dXMsIHNhbGVTdGF0dXMpXHJcbiAgcmV0dXJuIChcclxuICAgIDxDdGFCdXR0b24+XHJcbiAgICAgIDxMZWZ0Q29ybmVyPlxyXG4gICAgICAgIDxMZWZ0Q29ybmVyU1ZHIC8+XHJcbiAgICAgIDwvTGVmdENvcm5lcj5cclxuICAgICAgPEZpcnN0TGF5ZXIgLz5cclxuICAgICAgPFNlY29uZExheWVyIC8+XHJcbiAgICAgIHtzYWxlU3RhdHVzID09PSBTQUxFX1NUQVRVUy5PRkZTQUxFICYmIDxCdXR0b25UZXh0PlxyXG4gICAgICAgIHsvKiA8Q291bnRkb3duIGRhdGU9JzIwMjEtMTEtMDhUMDA6MDA6MDAnIC8+ICovfVxyXG4gICAgICAgIFRCQVxyXG4gICAgICA8L0J1dHRvblRleHQ+fVxyXG4gICAgICB7c2FsZVN0YXR1cyA9PT0gU0FMRV9TVEFUVVMuT05TQUxFICYmIGNvbm5lY3RTdGF0dXMgPT09IENPTk5FQ1RfU1RBVFVTLkNPTk5FQ1QgJiYgPEJ1dHRvblRleHRDbGljayBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TWludEJveCh0cnVlKX0+XHJcbiAgICAgICAgQ29ubmVjdFxyXG4gICAgICA8L0J1dHRvblRleHRDbGljaz59XHJcbiAgICAgIDxSaWdodENvcm5lcj5cclxuICAgICAgICA8UmlnaHRDb3JuZXJTVkcgLz5cclxuICAgICAgPC9SaWdodENvcm5lcj5cclxuICAgIDwvQ3RhQnV0dG9uPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ29ubmVjdEJ1dHRvbjtcclxuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcbmltcG9ydCBDb25uZWN0QnV0dG9uIGZyb20gJy4vQ29ubmVjdEJ1dHRvbi9Db25uZWN0QnV0dG9uJztcclxuaW1wb3J0IE1pbnRCdXR0b24gZnJvbSAnLi9NaW50QnV0dG9uL01pbnRCdXR0b24nO1xyXG5pbXBvcnQgeyBESVNDT1JEX0xJTksgfSBmcm9tICcuLi8uLi8uLi91dGlscy9MaW5rcyc7XHJcbmltcG9ydCBmb250cyBmcm9tIFwiLi4vLi4vLi4vc3R5bGVzL3R5cG9ncmFwaHlcIjtcclxuaW1wb3J0IHsgUmVhY3RDaGlsZCB9IGZyb20gJ2hvaXN0LW5vbi1yZWFjdC1zdGF0aWNzL25vZGVfbW9kdWxlcy9AdHlwZXMvcmVhY3QnO1xyXG5cclxuY29uc3QgU2VjdGlvbiA9IHN0eWxlZC5zZWN0aW9uYFxyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAtMTBweDtcclxuICAgIHBhZGRpbmctdG9wOiAxMjVweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGhlaWdodDogIDEwNTZweDtcclxuICAgIEBtZWRpYSAobWF4LWhlaWdodDogOTAwcHgpIGFuZCAobWluLXdpZHRoOiAxMDAxcHgpIHtcclxuICAgICAgICBwYWRkaW5nLXRvcDogMTAwcHg7XHJcbiAgICB9XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICAgICAgaGVpZ2h0OiAgNjMwcHg7XHJcbiAgICB9XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTAwMHB4KSB7XHJcbiAgICAgICAgaGVpZ2h0OiAgNjcwcHg7XHJcbiAgICB9XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNjIwcHgpIHtcclxuICAgICAgICBoZWlnaHQ6ICA2MjBweDtcclxuICAgIH1cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgICAgIGhlaWdodDogIDcxMHB4O1xyXG4gICAgfVxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDQwMHB4KSB7XHJcbiAgICAgICAgaGVpZ2h0OiAgNjQwcHg7XHJcbiAgICB9XHJcbmA7XHJcblxyXG5jb25zdCBCYW5uZXJJbWFnZSA9IHN0eWxlZC5kaXZgXHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB6LWluZGV4OiAwO1xyXG4gICAgcGFkZGluZzogMCAgMjRweDtcclxuICAgIGhlaWdodDogIDgwMHB4O1xyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgICAgIGhlaWdodDogIDM5MHB4O1xyXG4gICAgfVxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDEwMDBweCkge1xyXG4gICAgICAgIGhlaWdodDogIDM0MHB4O1xyXG4gICAgfVxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICAgICAgaGVpZ2h0OiAgMzM1cHg7XHJcbiAgICB9XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgICAgICBoZWlnaHQ6IDM3MHB4O1xyXG4gICAgfVxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDQwMHB4KSB7XHJcbiAgICAgICAgaGVpZ2h0OiAgMzIwcHg7XHJcbiAgICB9XHJcbmA7XHJcblxyXG5jb25zdCBCdW5ueUltYWdlID0gc3R5bGVkLmRpdmBcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICB0b3A6ICAzMjBweDtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcclxuICAgIG1pbi13aWR0aDogNjA1cHg7XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICAgICAgaGVpZ2h0OiAgY2FsYyg2MDVweC8xLjUpO1xyXG4gICAgICAgIHRvcDogIDI1MHB4O1xyXG4gICAgfVxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICAgICAgbWluLXdpZHRoOiA0MDBweDtcclxuICAgIH1cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgICAgIG1pbi13aWR0aDogMzIwcHg7XHJcbiAgICAgICAgdG9wOiAgMjQwcHg7XHJcbiAgICB9XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNDAwcHgpIHtcclxuICAgICAgICBtaW4td2lkdGg6IDI5MHB4O1xyXG4gICAgICAgIHRvcDogIDIyNHB4O1xyXG4gICAgfVxyXG5gO1xyXG5cclxuY29uc3QgQnViYmxlSW1hZ2UgPSBzdHlsZWQuZGl2YFxyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgei1pbmRleDogMDtcclxuICAgIHRvcDogLTI3dnc7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxMjAwcHgpIHtcclxuICAgICAgICB0b3A6IC0yNXZ3O1xyXG4gICAgfVxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICAgICAgdG9wOiAtMTAwcHg7XHJcbiAgICB9XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgICAgICB0b3A6IC0yNXB4O1xyXG4gICAgfVxyXG4gICAgaW1nIHtcclxuICAgICAgICB3aWR0aDogMTAwdnc7XHJcbiAgICAgICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgfVxyXG5gO1xyXG5cclxuY29uc3QgSm9pbkJveERlc2t0b3AgPSBzdHlsZWQuZGl2YFxyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdG9wOiAtNTAwcHg7XHJcbiAgICByaWdodDogMTYwcHg7XHJcbiAgICB6LWluZGV4OjE7XHJcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgIG1heC13aWR0aDogOTkwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgICAgIHRvcDogLTE1MHB4O1xyXG4gICAgICAgIHJpZ2h0OiAxODBweDtcclxuICAgIH1cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxMTUwcHgpIHtcclxuICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgfVxyXG4gICAgc3ZnIHtcclxuICAgICAgICB3aWR0aDogMjE0cHg7XHJcbiAgICB9XHJcbmA7XHJcblxyXG5jb25zdCBKb2luQm94TW9iaWxlID0gc3R5bGVkLmRpdmBcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHotaW5kZXg6IDU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB0b3A6IDZyZW07XHJcbiAgICBtYXgtd2lkdGg6IDk5MHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTE1MHB4KSB7XHJcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB9XHJcbiAgICBzdmcge1xyXG4gICAgICAgIHdpZHRoOiAyMTRweDtcclxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgICAgICAgICAgd2lkdGg6IDE2NnB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuYDtcclxuXHJcbmNvbnN0IEpvaW5DdGEgPSBzdHlsZWQucGBcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjAudzE5MjAuZm9udFNpemV9O1xyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDE2MDBweCkge1xyXG4gICAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNjYwLmZvbnRTaXplfTtcclxuICAgIH1cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTQ0MC5mb250U2l6ZX07XHJcbiAgICB9XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NzY4LmZvbnRTaXplfTtcclxuICAgIH1cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzUwMC5mb250U2l6ZX07XHJcbiAgICB9XHJcbmA7XHJcblxyXG5jb25zdCBNaW50Qm94ID0gc3R5bGVkLmRpdmBcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJveC1zaGFkb3c6IDBweCA4cHggMHB4IDBweCAjMDAwMDAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzRweDtcclxuICAgIGJvcmRlcjogNHB4IHNvbGlkICMwMDAwMDA7XHJcbiAgICBiYWNrZ3JvdW5kOiAjODdFRUY0O1xyXG4gICAgcGFkZGluZzogNjBweCAxMjVweCA1MHB4IDEyNXB4O1xyXG4gICAgei1pbmRleDogNTtcclxuICAgIHRvcDogNjcwcHg7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAwKTtcclxuXHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMHB4IDdweCAwcHggMHB4ICMwMDAwMDA7XHJcbiAgICAgICAgcGFkZGluZzogNDVweCA3MHB4IDM1cHggNzBweDtcclxuICAgICAgICB0b3A6IDUyMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDBweCA0cHggMHB4IDBweCAjMDAwMDAwO1xyXG4gICAgICAgIHBhZGRpbmc6IDE1cHggNTBweCAyMHB4IDUwcHg7XHJcbiAgICAgICAgYm9yZGVyOiAzcHggc29saWQgIzAwMDAwMDtcclxuICAgIH1cclxuXHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNDAwcHgpIHtcclxuICAgICAgICB0b3A6IDUwMHB4O1xyXG4gICAgICAgIHBhZGRpbmc6IDE1cHggNDBweCAyMHB4IDQwcHg7XHJcbiAgICB9XHJcbmA7XHJcblxyXG5jb25zdCBNaW50VG9wID0gc3R5bGVkLmRpdmBcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgPiBkaXY6Zmlyc3Qtb2YtdHlwZSB7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xyXG4gICAgICAgIDphY3RpdmUge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjY2NjO1xyXG4gICAgICAgIH1cclxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTJweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICA+IGRpdjpsYXN0LW9mLXR5cGUge1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDEycHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDhweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgPiBkaXYge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNGRkZGRkY7XHJcbiAgICAgICAgYm9yZGVyOiA0cHggc29saWQgIzAwMDAwMDtcclxuICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDM5LjVweDtcclxuICAgICAgICBsZXR0ZXItc3BhY2luZzogMC4wNGVtO1xyXG4gICAgICAgIGNvbG9yOiAjMDAwMDAwO1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICBwYWRkaW5nOiAxMHB4IDUwcHg7XHJcbiAgICAgICAgXHJcbiAgICAgICAgOmhvdmVyIHtcclxuICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGRkO1xyXG4gICAgICAgIH1cclxuICAgICAgICA6Zm9jdXMge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNEE3QTcyO1xyXG4gICAgICAgICAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgICAgICB9XHJcbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiA4cHggMzVweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwIDEycHg7XHJcbiAgICAgICAgICAgIGJvcmRlcjogM3B4IHNvbGlkICMwMDAwMDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwIHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTJweDtcclxuXHJcbiAgICAgICAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDhweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogNXB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHN2ZyB7XHJcbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gICAgICAgICAgICB3aWR0aDogMThweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgICAgICAgICB3aWR0aDogMTJweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbmA7XHJcblxyXG5jb25zdCBNaW50TWlkZGxlID0gc3R5bGVkLmRpdmBcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRDdBNkZGO1xyXG4gICAgYm9yZGVyOiA0cHggc29saWQgIzAwMDAwMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDM5LjVweDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgcGFkZGluZzogMTBweCA1MHB4IDE1cHggNTBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcblxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgICAgICBwYWRkaW5nOiA4cHggMzVweCAxMnB4IDM1cHg7XHJcbiAgICB9XHJcblxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgICBwYWRkaW5nOiA2cHggMjJweCA4cHggMjJweDtcclxuICAgIH1cclxuXHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgcGFkZGluZzogNHB4IDE2cHggNnB4IDE2cHg7XHJcbiAgICAgICAgYm9yZGVyOiAzcHggc29saWQgIzAwMDAwMDtcclxuICAgIH1cclxuXHJcbiAgICBwIHtcclxuICAgICAgICBwYWRkaW5nOiAwIDgwcHg7XHJcblxyXG4gICAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgICAgICAgICAgcGFkZGluZzogMCA1NXB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwIDM1cHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGRpdiB7XHJcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgIHRyYW5zaXRpb246IDAuM3MgYWxsO1xyXG4gICAgICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgfVxyXG4gICAgZGl2OmhvdmVyIHtcclxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICM4N0VFRjQ7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICBcclxuICAgIH1cclxuYDtcclxuXHJcbmNvbnN0IENsb3NlID0gc3R5bGVkLmRpdmBcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMThweDtcclxuICAgIHJpZ2h0OiAxOHB4O1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcblxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIH1cclxuXHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgICAgICB0b3A6IDEycHg7XHJcbiAgICAgICAgcmlnaHQ6IDEycHg7XHJcbiAgICB9XHJcbmA7XHJcblxyXG5jb25zdCBSYXJpdHkgPSBzdHlsZWQucGBcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBmb250LWZhbWlseTogJ1NwYWNlIEdyb3Rlc2snLCBzYW5zLXNlcmlmO1xyXG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMzBweDtcclxuICAgIGxldHRlci1zcGFjaW5nOiAwLjA0ZW07XHJcbiAgICBtYXJnaW46IDE1cHggMCAzMHB4IDA7XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAyNHB4O1xyXG4gICAgfVxyXG5cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxMjAwcHgpIHtcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDIwcHg7XHJcbiAgICAgICAgbWFyZ2luOiAxMHB4IDAgMjBweCAwO1xyXG4gICAgfVxyXG5cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICBsaW5lLWhlaWdodDogMTRweDtcclxuICAgIH1cclxuYDtcclxuXHJcbmNvbnN0IExpbWl0ID0gc3R5bGVkLnBgXHJcbiAgICBtYXJnaW46IDE1cHggMCAzNXB4IDA7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgZm9udC1mYW1pbHk6ICdTcGFjZSBHcm90ZXNrJywgc2Fucy1zZXJpZjtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAzMHB4O1xyXG4gICAgbGV0dGVyLXNwYWNpbmc6IDAuMDRlbTtcclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgICB9XHJcblxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICBsaW5lLWhlaWdodDogMjBweDtcclxuICAgICAgICBtYXJnaW46IDEwcHggMCAyMHB4IDA7XHJcbiAgICB9XHJcblxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxNHB4O1xyXG4gICAgfVxyXG5gO1xyXG5cclxuXHJcbmNvbnN0IFN5bWJvbCA9ICh7IGNoaWxkcmVuLCBvblJhcml0eVByaWNlQ2xpY2tlZCwgdGFiaW5kZXggfTogeyBjaGlsZHJlbjogUmVhY3RDaGlsZCwgb25SYXJpdHlQcmljZUNsaWNrZWQ6IGFueSwgdGFiaW5kZXg6IHN0cmluZyB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgIG9uQ2xpY2s9e29uUmFyaXR5UHJpY2VDbGlja2VkfSB0YWJJbmRleD17TnVtYmVyKHRhYmluZGV4KX0+XHJcbiAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyM1wiIGhlaWdodD1cIjM3XCIgdmlld0JveD1cIjAgMCAyMyAzN1wiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxyXG4gICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xMS40MTY5IDI3LjcwMjZMMC4wNTkwODIgMjAuOTk5OEwxMS40MSAzNy4wMDEyTDIyLjc3MzYgMjAuOTk5OEwxMS40MSAyNy43MDI2SDExLjQxNjlaTTExLjU4NTcgMEwwLjIzMjUyIDE4Ljg0MzRMMTEuNTg1NyAyNS41NTc4TDIyLjk0MzYgMTguODUwM0wxMS41ODU3IDBaXCIgZmlsbD1cImJsYWNrXCIgLz5cclxuICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgIDxwPntjaGlsZHJlbn08L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApXHJcbn1cclxuXHJcbmNvbnN0IEFycm93ID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8c3ZnIHdpZHRoPVwiMjYzXCIgaGVpZ2h0PVwiMTdcIiB2aWV3Qm94PVwiMCAwIDI2MyAxN1wiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxyXG4gICAgICAgICAgICA8bGluZSB4MT1cIjJcIiB5MT1cIjE1XCIgeDI9XCIyNjFcIiB5Mj1cIjE1XCIgc3Ryb2tlPVwiYmxhY2tcIiBzdHJva2VXaWR0aD1cIjRcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiAvPlxyXG4gICAgICAgICAgICA8bGluZSB4MT1cIjIzMy42M1wiIHkxPVwiMi45NjAxXCIgeDI9XCIyNTkuOTZcIiB5Mj1cIjE0LjM2OTdcIiBzdHJva2U9XCJibGFja1wiIHN0cm9rZVdpZHRoPVwiNFwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XHJcbiAgICAgICAgPC9zdmc+XHJcbiAgICApXHJcbn1cclxuXHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge1xyXG4gICAgcHJvdmlkZXI6IGFueTtcclxuICAgIG9uTWludFRva2VuOiBhbnk7XHJcbiAgICBhZGRyZXNzOiBzdHJpbmc7XHJcbiAgICBiYWxhbmNlOiBudW1iZXI7XHJcbiAgICBuZXR3b3JrOiBzdHJpbmc7XHJcbn1cclxuXHJcbmNvbnN0IEhlcm8gPSAoe3Byb3ZpZGVyLCBhZGRyZXNzLCBiYWxhbmNlLCBuZXR3b3JrLCBvbk1pbnRUb2tlbn06IFByb3BzKSA9PiB7XHJcbiAgICBjb25zdCBbcmVzaXplRmFjdG9yLCBzZXRSZXNpemVGYWN0b3JdID0gdXNlU3RhdGUoMSk7XHJcbiAgICBjb25zdCBbYnVubnlDb3VudCwgc2V0QnVubnlDb3VudF0gPSB1c2VTdGF0ZSgxKTtcclxuICAgIGNvbnN0IFtzaG93TWludEJveCwgc2V0U2hvd01pbnRCb3hdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgICBjb25zdCBbaXNSYXJpdHksIHNldElzUmFyaXR5XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFttaW50QnRuVGV4dCwgc2V0TWludEJ0blRleHRdID0gdXNlU3RhdGUoJ01pbnQnKTtcclxuXHJcbiAgICBjb25zdCBvbk1pbnRUb2tlbjEgPSBhc3luYyAoZTogYW55KSA9PiB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdvbk1pbnRUb2tlbjEgY2xpY2tlZC4uLicsIGUudGFyZ2V0KTtcclxuICAgICAgICBzZXRNaW50QnRuVGV4dCgnTWludGluZy4uLicpO1xyXG4gICAgICAgIC8vIGUudGFyZ2V0LnZhbHVlID0gJ01pbnRpbmcuLi4nO1xyXG4gICAgICAgIGF3YWl0IG9uTWludFRva2VuKGUsIGJ1bm55Q291bnQsIGlzUmFyaXR5KTtcclxuICAgICAgICAvLyBlLnRhcmdldC52YWx1ZSA9J01pbml0ZWQgVG9rZW5zJztcclxuICAgICAgICBzZXRNaW50QnRuVGV4dCgnTWludCcpO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IG9uUmFyaXR5UHJpY2VDbGlja2VkID0gKGU6IGFueSkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdDbGlja2VkIEl0ZW06ICcsIGUpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGxldCBwcmljZSA9IGUuY3VycmVudFRhcmdldC5pbm5lclRleHQ7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ0N1cnJlbnRUYXJnZXQnLCBlLmN1cnJlbnRUYXJnZXQpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdQcmljZSBzZWxlY3RlZDonLCBwcmljZSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHByaWNlID09PSBcIjAuMDhcIikgc2V0SXNSYXJpdHkoZmFsc2UpO1xyXG4gICAgICAgIGVsc2Ugc2V0SXNSYXJpdHkodHJ1ZSk7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcmVzaXplRXZlbnRIYW5kbGUgPSAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgd2luZG93V2lkdGggPSB3aW5kb3cuaW5uZXJXaWR0aDtcclxuICAgICAgICBzd2l0Y2ggKHRydWUpIHtcclxuICAgICAgICAgICAgY2FzZSB3aW5kb3dXaWR0aCA+IDE2NjA6XHJcbiAgICAgICAgICAgICAgICBzZXRSZXNpemVGYWN0b3IoMS41KTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgc2V0UmVzaXplRmFjdG9yKDEuODUpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBhbW91bnRDaGFuZ2UgPSAoYW1vdW50OiBzdHJpbmcpID0+IHtcclxuICAgICAgICBzd2l0Y2ggKGFtb3VudCkge1xyXG4gICAgICAgICAgICBjYXNlICdpbmNyZWFzZSc6XHJcbiAgICAgICAgICAgICAgICBidW5ueUNvdW50IDwgMjUgJiYgc2V0QnVubnlDb3VudChidW5ueUNvdW50ICsgMSk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnZGVjcmVhc2UnOlxyXG4gICAgICAgICAgICAgICAgYnVubnlDb3VudCA+IDEgJiYgc2V0QnVubnlDb3VudChidW5ueUNvdW50IC0gMSk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICByZXNpemVFdmVudEhhbmRsZSgpO1xyXG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCByZXNpemVFdmVudEhhbmRsZSk7XHJcbiAgICAgICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHJlc2l6ZUV2ZW50SGFuZGxlKTtcclxuICAgICAgICB9O1xyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFNlY3Rpb24+XHJcbiAgICAgICAgICAgIDxCYW5uZXJJbWFnZT5cclxuICAgICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoPXs5OTAgLyByZXNpemVGYWN0b3J9XHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PXs1NjAgLyByZXNpemVGYWN0b3J9XHJcbiAgICAgICAgICAgICAgICAgICAgc3JjPVwiL2ltZy9iYW5uZXIucG5nXCJcclxuICAgICAgICAgICAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9CYW5uZXJJbWFnZT5cclxuICAgICAgICAgICAgPEpvaW5Cb3hEZXNrdG9wPlxyXG4gICAgICAgICAgICAgICAgPGEgcmVsPVwibm9yZWZlcnJlclwiIHRhcmdldD1cIl9ibGFua1wiIGhyZWY9e0RJU0NPUkRfTElOS30+XHJcbiAgICAgICAgICAgICAgICAgICAgPEFycm93IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPEpvaW5DdGE+Sm9pbiBvdXIgRGlzY29yZCBDaGFubmVsPC9Kb2luQ3RhPlxyXG4gICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICA8L0pvaW5Cb3hEZXNrdG9wPlxyXG4gICAgICAgICAgICA8QnVubnlJbWFnZT5cclxuICAgICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoPXs2MDUgLyByZXNpemVGYWN0b3J9XHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PXs2MDUgLyByZXNpemVGYWN0b3J9XHJcbiAgICAgICAgICAgICAgICAgICAgc3JjPVwiL2ltZy9EYSBCdW5ueSBIb21lcGFnZSBTaHVmZmxlLmdpZlwiXHJcbiAgICAgICAgICAgICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvQnVubnlJbWFnZT5cclxuICAgICAgICAgICAgPENvbm5lY3RCdXR0b24gc2V0U2hvd01pbnRCb3g9e3NldFNob3dNaW50Qm94fSAvPlxyXG4gICAgICAgICAgICA8Sm9pbkJveE1vYmlsZT5cclxuICAgICAgICAgICAgICAgIDxhIHJlbD1cIm5vcmVmZXJyZXJcIiB0YXJnZXQ9XCJfYmxhbmtcIiBocmVmPXtESVNDT1JEX0xJTkt9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxBcnJvdyAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxKb2luQ3RhPkpvaW4gb3VyIERpc2NvcmQgQ2hhbm5lbDwvSm9pbkN0YT5cclxuICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPC9Kb2luQm94TW9iaWxlPlxyXG4gICAgICAgICAgICA8QnViYmxlSW1hZ2U+XHJcbiAgICAgICAgICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aD17MTQ0MH1cclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9ezQ2M31cclxuICAgICAgICAgICAgICAgICAgICBzcmM9XCIvaW1nL2J1YmJsZXMucG5nXCJcclxuICAgICAgICAgICAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9CdWJibGVJbWFnZT5cclxuICAgICAgICAgICAge3Nob3dNaW50Qm94ICYmIChcclxuICAgICAgICAgICAgICAgIDxNaW50Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxDbG9zZSBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TWludEJveChmYWxzZSl9Plg8L0Nsb3NlPlxyXG4gICAgICAgICAgICAgICAgICAgIDxNaW50VG9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U3ltYm9sIG9uUmFyaXR5UHJpY2VDbGlja2VkPXtvblJhcml0eVByaWNlQ2xpY2tlZH0gdGFiaW5kZXg9XCIxXCI+MC4wODwvU3ltYm9sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U3ltYm9sIG9uUmFyaXR5UHJpY2VDbGlja2VkPXtvblJhcml0eVByaWNlQ2xpY2tlZH0gdGFiaW5kZXg9XCIyXCI+MC4xMjwvU3ltYm9sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvTWludFRvcD5cclxuICAgICAgICAgICAgICAgICAgICA8UmFyaXR5PigzeCBSYXJpdHkgQm9vc3QpPC9SYXJpdHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPE1pbnRNaWRkbGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtidW5ueUNvdW50ID4gMSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IG9uQ2xpY2s9eygpID0+IGFtb3VudENoYW5nZShcImRlY3JlYXNlXCIpfT4tPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPntidW5ueUNvdW50fTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2J1bm55Q291bnQgPCAyNSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IG9uQ2xpY2s9eygpID0+IGFtb3VudENoYW5nZShcImluY3JlYXNlXCIpfT4rPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9NaW50TWlkZGxlPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW1pdD4yNSBNQVg8L0xpbWl0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxNaW50QnV0dG9uIG9uTWludFRva2VuMT17b25NaW50VG9rZW4xfSBtaW50QnRuVGV4dD17bWludEJ0blRleHR9Lz5cclxuICAgICAgICAgICAgICAgIDwvTWludEJveD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICA8L1NlY3Rpb24+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhlcm87XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xyXG5pbXBvcnQgZm9udHMgZnJvbSAnLi4vLi4vLi4vLi4vc3R5bGVzL3R5cG9ncmFwaHknO1xyXG5cclxuY29uc3QgQ3RhQnV0dG9uID0gc3R5bGVkLmRpdmBcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDUuNXJlbTtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgaGVpZ2h0OiA0cmVtO1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEZpcnN0TGF5ZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGJhY2tncm91bmQ6ICNGRkRDMjU7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDI7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJvcmRlci1yYWRpdXM6IDE2cHg7XHJcbiAgYm9yZGVyOiAzcHggc29saWQgIzAwMDAwMDtcclxuYDtcclxuXHJcbmNvbnN0IFNlY29uZExheWVyID0gc3R5bGVkLmRpdmBcclxuICBiYWNrZ3JvdW5kOiAjNEE3QTcyO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiAxO1xyXG4gIHRvcDogLS45Mzc1cmVtO1xyXG4gIGxlZnQ6IC45Mzc1cmVtO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBib3JkZXItcmFkaXVzOiAxNnB4O1xyXG4gIGJvcmRlcjogM3B4IHNvbGlkICMwMDAwMDA7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICB0b3A6IC0wLjMzNzVyZW07XHJcbiAgICBsZWZ0OiAwLjMzNzVyZW07XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQnV0dG9uVGV4dCA9IHN0eWxlZC5wYFxyXG4gIGZvbnQtc2l6ZTogMzBweDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgei1pbmRleDogNDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2MDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTY2MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzE2NjAuaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTQ0MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzE0NDAuaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc3NjguZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc3NjguaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzUwMC5mb250U2l6ZX07XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQ0MC53NTAwLmhlaWdodH07XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgTGVmdENvcm5lclNWRyA9ICgpID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPHN2ZyB3aWR0aD1cIjUwXCIgaGVpZ2h0PVwiMzZcIiB2aWV3Qm94PVwiMCAwIDUwIDM2XCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XHJcbiAgICAgIDxwYXRoIGQ9XCJNNSAzMS4zNDcyVjE5LjA5NTdDNSAxMS4zNjM3IDExLjI2OCA1LjA5NTcgMTkgNS4wOTU3SDQ1XCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2VXaWR0aD1cIjlcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiAvPlxyXG4gICAgPC9zdmc+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCBSaWdodENvcm5lclNWRyA9ICgpID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPHN2ZyB3aWR0aD1cIjkyXCIgaGVpZ2h0PVwiMjVcIiB2aWV3Qm94PVwiMCAwIDkyIDI1XCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XHJcbiAgICAgIDxwYXRoIGQ9XCJNODcuNSA1LjIzNjQ5TDg3LjUgNS41OTI2N0M4Ny41IDEzLjMyNDcgODEuMjMyIDE5LjU5MjcgNzMuNSAxOS41OTI3TDQuNSAxOS41OTI4XCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2VXaWR0aD1cIjlcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiAvPlxyXG4gICAgPC9zdmc+XHJcblxyXG4gIClcclxufVxyXG5cclxuY29uc3QgTGVmdENvcm5lciA9IHN0eWxlZC5kaXZgXHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDM7XHJcbiAgbGVmdDogMTBweDtcclxuICB0b3A6IDEwcHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBsZWZ0OiAuNTI1cmVtO1xyXG4gICAgdG9wOiAuMzI1cmVtO1xyXG4gIH1cclxuICBzdmcge1xyXG4gICAgd2lkdGg6IDQwcHg7XHJcbiAgICBoZWlnaHQ6IDEuNjg3NXJlbTtcclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgICBoZWlnaHQ6IDEzLjVweDtcclxuICAgICAgd2lkdGg6IDIwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgUmlnaHRDb3JuZXIgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiAzO1xyXG4gIHJpZ2h0OiAuMzEyNXJlbTtcclxuICBib3R0b206IDEwcHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBib3R0b206IC4xMjVyZW07XHJcbiAgfVxyXG4gIHN2ZyB7XHJcbiAgICB3aWR0aDogNS4xODc1cmVtO1xyXG4gICAgaGVpZ2h0OiAwLjkzNzVyZW07XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgICAgICB3aWR0aDogNDJweDtcclxuICAgICAgICBoZWlnaHQ6IDcuNXB4O1xyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IE1pbnRCdXR0b24gPSAoe29uTWludFRva2VuMSwgbWludEJ0blRleHR9IDogYW55KSA9PiB7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q3RhQnV0dG9uID5cclxuICAgICAgPExlZnRDb3JuZXI+XHJcbiAgICAgICAgPExlZnRDb3JuZXJTVkcgLz5cclxuICAgICAgPC9MZWZ0Q29ybmVyPlxyXG4gICAgICA8Rmlyc3RMYXllciAvPlxyXG4gICAgICA8U2Vjb25kTGF5ZXIgLz5cclxuICAgICAgPEJ1dHRvblRleHQgb25DbGljaz17b25NaW50VG9rZW4xfT5cclxuICAgICAgICB7bWludEJ0blRleHR9XHJcbiAgICAgIDwvQnV0dG9uVGV4dD5cclxuICAgICAgPFJpZ2h0Q29ybmVyPlxyXG4gICAgICAgIDxSaWdodENvcm5lclNWRyAvPlxyXG4gICAgICA8L1JpZ2h0Q29ybmVyPlxyXG4gICAgPC9DdGFCdXR0b24+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNaW50QnV0dG9uO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuaW1wb3J0IHtcclxuICBDYWxlbmRhckJveCxcclxuICBEYXRlc1NpZGUsXHJcbiAgRGF0ZVRleHQsXHJcbiAgTGluZURvd24sXHJcbiAgSW5mb1NpZGUsXHJcbiAgSW5mb1dyYXAsXHJcbiAgSGVhdnlJbmZvLFxyXG4gIEluZm9MaXN0LFxyXG4gIEluZm9JdGVtLFxyXG59IGZyb20gJy4vQ2FsZW5kYXJTdHlsZSc7XHJcblxyXG5jb25zdCBDYWxlbmRhckJveEZvdXIgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxDYWxlbmRhckJveD5cclxuICAgICAgPERhdGVzU2lkZT5cclxuICAgICAgICA8RGF0ZVRleHQ+MTEvMjAyMTwvRGF0ZVRleHQ+XHJcbiAgICAgICAgPExpbmVEb3duIC8+XHJcbiAgICAgIDwvRGF0ZXNTaWRlPlxyXG4gICAgICA8SW5mb1NpZGU+XHJcbiAgICAgICAgPEluZm9XcmFwPlxyXG4gICAgICAgICAgPEhlYXZ5SW5mbz5PZmZpY2lhbCBMYXVuY2g8L0hlYXZ5SW5mbz5cclxuICAgICAgICAgIDxJbmZvTGlzdD5cclxuICAgICAgICAgICAgPEluZm9JdGVtPlVUQyA2UE0gQERhQnVubnlORlQuY29tPC9JbmZvSXRlbT5cclxuICAgICAgICAgICAgPEluZm9JdGVtPlN1cHBseTogNSwwMDArIChCdXkgTGltaXQ6IDIwKTwvSW5mb0l0ZW0+XHJcbiAgICAgICAgICA8L0luZm9MaXN0PlxyXG4gICAgICAgIDwvSW5mb1dyYXA+XHJcbiAgICAgIDwvSW5mb1NpZGU+XHJcbiAgICA8L0NhbGVuZGFyQm94PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2FsZW5kYXJCb3hGb3VyO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuaW1wb3J0IHtcclxuICBDYWxlbmRhckJveCxcclxuICBEYXRlc1NpZGUsXHJcbiAgRGF0ZVRleHQsXHJcbiAgTGluZURvd24sXHJcbiAgSW5mb1NpZGUsXHJcbiAgSW5mb1dyYXAsXHJcbiAgSGVhdnlJbmZvLFxyXG4gIExpZ2h0SW5mbyxcclxuICBJbmZvTGlzdCxcclxuICBJbmZvSXRlbSxcclxufSBmcm9tICcuL0NhbGVuZGFyU3R5bGUnO1xyXG5cclxuY29uc3QgQ2FsZW5kYXJCb3hPbmUgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxDYWxlbmRhckJveD5cclxuICAgICAgPERhdGVzU2lkZT5cclxuICAgICAgICA8RGF0ZVRleHQ+MTAvMTEvMjAyMTwvRGF0ZVRleHQ+XHJcbiAgICAgICAgPExpbmVEb3duIC8+XHJcbiAgICAgIDwvRGF0ZXNTaWRlPlxyXG4gICAgICA8SW5mb1NpZGU+XHJcbiAgICAgICAgPEluZm9XcmFwPlxyXG4gICAgICAgICAgPEhlYXZ5SW5mbz5XZWJzaXRlIE9mZmljaWFsIExhdW5jaDwvSGVhdnlJbmZvPlxyXG4gICAgICAgICAgPEhlYXZ5SW5mbz5EaXNjb3JkIENvbW11bml0eSBPZmZpY2lhbCBMYXVuY2g8L0hlYXZ5SW5mbz5cclxuICAgICAgICAgIDxMaWdodEluZm8+RGlzY29yZDogaHR0cHM6Ly9kaXNjb3JkLmdnL3AzVVFqaFEzPC9MaWdodEluZm8+XHJcbiAgICAgICAgICA8SW5mb0xpc3Q+XHJcbiAgICAgICAgICAgIDxJbmZvSXRlbT5AVVRDIDZQTTwvSW5mb0l0ZW0+XHJcbiAgICAgICAgICAgIDxJbmZvSXRlbT5UZWxlZ3JhbTogaHR0cHM6Ly90Lm1lL0RhQnVubnlORlQ8L0luZm9JdGVtPlxyXG4gICAgICAgICAgICA8SW5mb0l0ZW0+Q29udHJhY3QgQWRkcmVzczogVEJEPC9JbmZvSXRlbT5cclxuICAgICAgICAgIDwvSW5mb0xpc3Q+XHJcbiAgICAgICAgPC9JbmZvV3JhcD5cclxuICAgICAgPC9JbmZvU2lkZT5cclxuICAgIDwvQ2FsZW5kYXJCb3g+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDYWxlbmRhckJveE9uZTtcclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuXHJcbmltcG9ydCB7XHJcbiAgQ2FsZW5kYXJCb3gsXHJcbiAgRGF0ZXNTaWRlLFxyXG4gIERhdGVUZXh0LFxyXG4gIExpbmVEb3duLFxyXG4gIEluZm9TaWRlLFxyXG4gIEluZm9XcmFwLFxyXG4gIEhlYXZ5SW5mbyxcclxuICBJbmZvTGlzdCxcclxuICBJbmZvSXRlbSxcclxufSBmcm9tICcuL0NhbGVuZGFyU3R5bGUnO1xyXG5cclxuY29uc3QgQ2FsZW5kYXJCb3hUaHJlZSA9ICgpID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPENhbGVuZGFyQm94PlxyXG4gICAgICA8RGF0ZXNTaWRlPlxyXG4gICAgICAgIDxEYXRlVGV4dD4xMS8yMDIxPC9EYXRlVGV4dD5cclxuICAgICAgICA8TGluZURvd24gLz5cclxuICAgICAgPC9EYXRlc1NpZGU+XHJcbiAgICAgIDxJbmZvU2lkZT5cclxuICAgICAgICA8SW5mb1dyYXA+XHJcbiAgICAgICAgICA8SGVhdnlJbmZvPlByZS1zYWxlIDI8L0hlYXZ5SW5mbz5cclxuICAgICAgICAgIDxJbmZvTGlzdD5cclxuICAgICAgICAgICAgPEluZm9JdGVtPlVUQyA2UE0gQERhQnVubnlORlQuY29tPC9JbmZvSXRlbT5cclxuICAgICAgICAgICAgPEluZm9JdGVtPlN1cHBseTogMiwwMDA8L0luZm9JdGVtPlxyXG4gICAgICAgICAgPC9JbmZvTGlzdD5cclxuICAgICAgICA8L0luZm9XcmFwPlxyXG4gICAgICA8L0luZm9TaWRlPlxyXG4gICAgPC9DYWxlbmRhckJveD5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENhbGVuZGFyQm94VGhyZWU7XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcblxyXG5pbXBvcnQge1xyXG4gIENhbGVuZGFyQm94LFxyXG4gIERhdGVzU2lkZSxcclxuICBEYXRlVGV4dCxcclxuICBMaW5lRG93bixcclxuICBJbmZvU2lkZSxcclxuICBJbmZvV3JhcCxcclxuICBIZWF2eUluZm8sXHJcbiAgSW5mb0xpc3QsXHJcbiAgSW5mb0l0ZW0sXHJcbn0gZnJvbSAnLi9DYWxlbmRhclN0eWxlJztcclxuXHJcbmNvbnN0IENhbGVuZGFyQm94VHdvID0gKCkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8Q2FsZW5kYXJCb3g+XHJcbiAgICAgIDxEYXRlc1NpZGU+XHJcbiAgICAgICAgPERhdGVUZXh0PjExLzIwMjE8L0RhdGVUZXh0PlxyXG4gICAgICAgIDxMaW5lRG93biAvPlxyXG4gICAgICA8L0RhdGVzU2lkZT5cclxuICAgICAgPEluZm9TaWRlPlxyXG4gICAgICAgIDxJbmZvV3JhcD5cclxuICAgICAgICAgIDxIZWF2eUluZm8+UHJlLXNhbGUgMTwvSGVhdnlJbmZvPlxyXG4gICAgICAgICAgPEluZm9MaXN0PlxyXG4gICAgICAgICAgICA8SW5mb0l0ZW0+VVRDIDZQTSBARGFCdW5ueU5GVC5jb208L0luZm9JdGVtPlxyXG4gICAgICAgICAgICA8SW5mb0l0ZW0+U3VwcGx5OiAxLDAwMCA8L0luZm9JdGVtPlxyXG4gICAgICBcclxuICAgICAgICAgIDwvSW5mb0xpc3Q+XHJcbiAgICAgICAgICA8SGVhdnlJbmZvPiREYSBCdW5ueSBORlQgRVJDLTIwIFRva2VuIG9uIFVuaXN3YXA8L0hlYXZ5SW5mbz5cclxuICAgICAgICA8L0luZm9XcmFwPlxyXG4gICAgICA8L0luZm9TaWRlPlxyXG4gICAgPC9DYWxlbmRhckJveD5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENhbGVuZGFyQm94VHdvO1xyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcclxuaW1wb3J0IGZvbnRzIGZyb20gJy4uLy4uLy4uL3N0eWxlcy90eXBvZ3JhcGh5JztcclxuXHJcbmV4cG9ydCBjb25zdCBDYWxlbmRhckJveCA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgbWFyZ2luLXRvcDogNC4zNzVyZW07XHJcbiAgbWFyZ2luLWJvdHRvbTogNC4wNjI1cmVtO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTEwMHB4KSB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG1hcmdpbi10b3A6IDYuMzc1cmVtO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDk2cHg7XHJcbiAgICBtYXJnaW4tdG9wOiA0OHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBEYXRlc1NpZGUgPSBzdHlsZWQuZGl2YFxyXG4gIGZsZXgtYmFzaXM6IDEwJTtcclxuICBwYWRkaW5nLXJpZ2h0OiA0LjM3NXJlbTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBwYWRkaW5nLXRvcDogMzBweDtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDExMDBweCkge1xyXG4gICAgZmxleC1iYXNpczogdW5zZXQ7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAwO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IHVuc2V0O1xyXG4gICAgYWxpZ24taXRlbXM6IHVuc2V0O1xyXG4gICAgcGFkZGluZy10b3A6IDA7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIGJvcmRlci1sZWZ0OiA3cHggZGFzaGVkICNmZmY7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBoZWlnaHQ6IGNhbGMoMTAwJSArIDM1cHgpO1xyXG4gICAgbGVmdDogMDtcclxuICAgIHRvcDogMDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgYm9yZGVyLWxlZnQ6IDRweCBkYXNoZWQgI2ZmZjtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgRGF0ZVRleHQgPSBzdHlsZWQucGBcclxuICBmb250LXdlaWdodDogNzAwO1xyXG4gIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzE5MjAuZm9udFNpemV9O1xyXG4gIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQ0MC53MTkyMC5oZWlnaHR9O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzE2NjAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxNjYwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzE0NDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxNDQwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMTAwcHgpIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRvcDogLTM1cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDE1cHg7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIDo6YWZ0ZXIge1xyXG4gICAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgIGxlZnQ6IC0xNHB4O1xyXG4gICAgICB0b3A6IDE0cHg7XHJcbiAgICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc3NjguZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc3NjguaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc1MDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc1MDAuaGVpZ2h0fTtcclxuICAgIDo6YWZ0ZXIge1xyXG4gICAgICBsZWZ0OiAtMTBweDtcclxuICAgICAgdG9wOiAxMHB4O1xyXG4gICAgICB3aWR0aDogMTRweDtcclxuICAgICAgaGVpZ2h0OiAxNHB4O1xyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBMaW5lRG93biA9IHN0eWxlZC5kaXZgXHJcbiAgYm9yZGVyLXJpZ2h0OiA3cHggZGFzaGVkICMwMDAwMDA7XHJcbiAgZmxleDogMTtcclxuICBtYXJnaW4tdG9wOiAxLjVyZW07XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDExMDBweCkge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSW5mb1NpZGUgPSBzdHlsZWQuZGl2YFxyXG4gIGZsZXgtYmFzaXM6IDc5JTtcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTEwMHB4KSB7XHJcbiAgICBmbGV4LWJhc2lzOiAxMDAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDQ4cHg7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAgMjRweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRvcDogLTFyZW07XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEluZm9XcmFwID0gc3R5bGVkLmRpdmBcclxuICBiYWNrZ3JvdW5kOiAjRkZCOUI5O1xyXG4gIGJvcmRlcjogM3B4IHNvbGlkICMwMDAwMDA7XHJcbiAgYm94LXNoYWRvdzowIDhweCAwMCAjMDAwMDAwO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgcGFkZGluZzogMzBweCAyLjgxMjVyZW07XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDExMDBweCkge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdG9wOiAzMHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIZWF2eUluZm8gPSBzdHlsZWQuaDNgXHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxOTIwLmhlaWdodH07XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTY2MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzE2NjAuaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTQ0MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzE0NDAuaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc3NjguZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc3NjguaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc1MDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc1MDAuaGVpZ2h0fTtcclxuICB9XHJcbiAgJiY6bm90KDpmaXJzdC1vZi10eXBlKSB7XHJcbiAgICBtYXJnaW4tdG9wOiA0MHB4O1xyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDE2cHg7XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IExpZ2h0SW5mbyA9IHN0eWxlZC5wYFxyXG4gIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE5MjAuZm9udFNpemV9O1xyXG4gIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53MTkyMC5oZWlnaHR9O1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNjYwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53MTY2MC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNDQwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53MTQ0MC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzc2OC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzc2OC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzUwMC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzUwMC5oZWlnaHR9O1xyXG4gICAgd29yZC1icmVhazogYnJlYWstYWxsO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBJbmZvTGlzdCA9IHN0eWxlZC51bGBcclxuICBwYWRkaW5nOiAwIDQwcHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBwYWRkaW5nOiAwICAyNHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIHBhZGRpbmc6IDAgMTZweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSW5mb0l0ZW0gPSBzdHlsZWQubGlgXHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxOTIwLmhlaWdodH07XHJcbiAgd29yZC1icmVhazogYnJlYWstYWxsO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE2NjAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxNjYwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE0NDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxNDQwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NzY4LmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53NzY4LmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53NTAwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53NTAwLmhlaWdodH07XHJcbiAgICB3b3JkLWJyZWFrOiBicmVhay1hbGw7XHJcbiAgfVxyXG5gOyIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xyXG5pbXBvcnQgQ2FsZW5kYXJCb3hPbmUgZnJvbSAnLi9DYWxlbmRhckJveE9uZSc7XHJcbmltcG9ydCBDYWxlbmRhckJveFR3byBmcm9tICcuL0NhbGVuZGFyQm94VHdvJztcclxuaW1wb3J0IENhbGVuZGFyQm94Rm91ciBmcm9tICcuL0NhbGVuZGFyQm94Rm91cic7XHJcbmltcG9ydCBDYWxlbmRhckJveFRocmVlIGZyb20gJy4vQ2FsZW5kYXJCb3hUaHJlZSc7XHJcbmltcG9ydCB7IFdheXBvaW50IH0gZnJvbSAncmVhY3Qtd2F5cG9pbnQnO1xyXG5pbXBvcnQgZm9udHMgZnJvbSAnLi4vLi4vLi4vc3R5bGVzL3R5cG9ncmFwaHknO1xyXG5cclxuY29uc3QgU2VjdGlvbiA9IHN0eWxlZC5zZWN0aW9uYFxyXG4gIGJhY2tncm91bmQtY29sb3I6ICNGRjcyNzI7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHBhZGRpbmc6IDE1cmVtIDAgNHJlbSAwO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBwYWRkaW5nOiAyMHJlbSAwIDRyZW0gMDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMDAwcHgpIHtcclxuICAgIHBhZGRpbmc6IDI1cmVtIDAgNHJlbSAwO1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBwYWRkaW5nOiAxNXJlbSAwIDRyZW0gMDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1NTBweCkge1xyXG4gICAgcGFkZGluZy1ib3R0b206IDE2cHg7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNDAwcHgpIHtcclxuICAgIHBhZGRpbmc6IDEwcmVtIDAgNHJlbSAwO1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IElubmVyV3JhcCA9IHN0eWxlZC5kaXZgXHJcbiAgbWF4LXdpZHRoOiAxMTAwcHg7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5gO1xyXG5cclxuY29uc3QgUm9ja2V0QnVubnkgPSBzdHlsZWQuZGl2PHsgcm9ja2V0T25TY3JlZW46IGJvb2xlYW4gfT5gXHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgdG9wOiAtMzByZW07XHJcbiAgaGVpZ2h0OiAyMi41cmVtO1xyXG4gIHdpZHRoOiAxMjUlO1xyXG4gIHJpZ2h0OiAkeyh7IHJvY2tldE9uU2NyZWVuIH0pID0+IHJvY2tldE9uU2NyZWVuID8gJy0xMi41JScgOiAnIDIwMHZ3J307XHJcbiAgdHJhbnNpdGlvbjogcmlnaHQgLjdzIGVhc2Utb3V0O1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICB3aWR0aDogMTYwMHB4O1xyXG4gICAgdG9wOiAtMzVyZW07XHJcbiAgICByaWdodDogJHsoeyByb2NrZXRPblNjcmVlbiB9KSA9PiByb2NrZXRPblNjcmVlbiA/ICctNTBweCcgOiAnIDIwMHZ3J307XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTIwMHB4KSB7XHJcbiAgICB0b3A6IC0zMHJlbTtcclxuICAgIHdpZHRoOiAxMzIwcHg7XHJcbiAgICByaWdodDogJHsoeyByb2NrZXRPblNjcmVlbiB9KSA9PiByb2NrZXRPblNjcmVlbiA/ICcwJyA6ICcgMjAwdncnfTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMDAwcHgpIHtcclxuICAgIHdpZHRoOiAxMDUweDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgdG9wOiAtMjNyZW07XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogODAwcHgpIHtcclxuICAgIHdpZHRoOiA4ODBweDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA2MDBweCkge1xyXG4gICAgdG9wOiAtMThyZW07XHJcbiAgICB3aWR0aDogNjYwcHg7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNDAwcHgpIHtcclxuICAgIHRvcDogLTExcmVtO1xyXG4gICAgd2lkdGg6IDQ0MHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEJ1bm55SW1hZ2UgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiAxO1xyXG4gIHJpZ2h0OiAwcHg7XHJcbiAgYm90dG9tOiAtMzEwcHg7XHJcbiAgd2lkdGg6IDQ2MHB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIHJpZ2h0OiAtNHJlbTtcclxuICAgIGJvdHRvbTogLTE1cmVtO1xyXG4gICAgd2lkdGg6IDQyMHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTE3MHB4KSB7XHJcbiAgICByaWdodDogNTAlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDUwJSk7XHJcbiAgICBib3R0b206IC0xMy4zNzVyZW07XHJcbiAgICB3aWR0aDogNDUwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgcmlnaHQ6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCg1MCUpO1xyXG4gICAgYm90dG9tOiAtMTMuMzc1cmVtO1xyXG4gICAgd2lkdGg6IDM1MHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGJvdHRvbTogLTYuMzc1cmVtO1xyXG4gICAgd2lkdGg6IDIxMHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEFjdGl2YXRpb25zQm94ID0gc3R5bGVkLmRpdmBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkZGMzg3O1xyXG4gIGJveC1zaGFkb3c6ICAyNHB4IDEuNzVyZW0wMCAjMDAwMDAwO1xyXG4gIGJvcmRlcjogN3B4IHNvbGlkICMwMDAwMDA7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgcGFkZGluZy10b3A6IDVyZW07XHJcbiAgbWFyZ2luOiAwIDgwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTAuOTM3NXJlbTtcclxuICBib3gtc2hhZG93OiAxMnB4IDEycHggMHB4IDBweCAjMDAwMDAwO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICBwYWRkaW5nLXRvcDogNDBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBtYXJnaW46IDAgMjBweDtcclxuICAgIHBhZGRpbmctdG9wOiA0MHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IFZlY3RvcldyYXAgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBsZWZ0OiA1MCU7XHJcbiAgdG9wOiAtNy41cmVtO1xyXG4gIGhlaWdodDogMTEuMjVyZW07XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEwMDBweCkge1xyXG4gICAgdG9wOiAtOHJlbTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICB0b3A6IC03cmVtO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIHRvcDogLTU2cHg7XHJcbiAgfVxyXG4gIHN2ZyB7XHJcbiAgICBoZWlnaHQ6IDguMjVyZW07XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTAwMHB4KSB7XHJcbiAgICAgIGhlaWdodDogOXJlbTtcclxuICAgIH1cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgICBoZWlnaHQ6IDEyOHB4O1xyXG4gICAgfVxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICAgIGhlaWdodDogNjBweDtcclxuICAgIH1cclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBBY3RpdmF0aW9uVGl0bGUgPSBzdHlsZWQuaDNgXHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxOTIwLmhlaWdodH07XHJcbiAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTY2MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzE2NjAuaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTQ0MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzE0NDAuaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc3NjguZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc3NjguaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc1MDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc1MDAuaGVpZ2h0fTtcclxuICAgIG1hcmdpbi10b3A6IDEycHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQWN0aXZhdGlvbkxpc3QgPSBzdHlsZWQudWxgXHJcbiAgcGFkZGluZzogNHJlbSA4MHB4IDguMTI1cmVtIDgwcHg7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjYwcHgpIHtcclxuICAgIHBhZGRpbmc6IDNyZW0gODBweCA4cmVtIDYwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMTcwcHgpIHtcclxuICAgIHBhZGRpbmc6IDUuNjI1cmVtIDgwcHggMThyZW0gODBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBwYWRkaW5nOiAzMnB4IDI1cHggMTFyZW0gMjVweDtcclxuICAgIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgcGFkZGluZzogMzJweCAyNXB4IDkuNXJlbSAyNXB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEFjdGl2YXRpb25JdGVtID0gc3R5bGVkLmxpYFxyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxOTIwLmhlaWdodH07XHJcbiAgbWFyZ2luLWJvdHRvbTogMThweDtcclxuICBjb2xvcjogIzAwMDtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2NjBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTY2MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzE2NjAuaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTQ0MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzE0NDAuaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc3NjguZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0Lnc3NjguaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc1MDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0Lnc1MDAuaGVpZ2h0fTtcclxuICAgIG1hcmdpbi1ib3R0b206IDdweDtcclxuICB9XHJcblxyXG4gICYmOmxhc3Qtb2YtdHlwZSB7XHJcbiAgICB3aWR0aDogNzAlO1xyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDExNzBweCkge1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHNwYW4ge1xyXG4gICAgY29sb3I6I0JFNkRGRjtcclxuICAgIG1hcmdpbi1yaWdodDogMTJweDtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBDYWxlbmRhclRpdGxlID0gc3R5bGVkLmgzYFxyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxOTIwLmhlaWdodH07XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLncxNjYwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQ0MC53MTY2MC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLncxNDQwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQ0MC53MTQ0MC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzc2OC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzc2OC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzUwMC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250NDAudzUwMC5oZWlnaHR9O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IENhbGVuZGFyVGl0bGVXcmFwID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZmxleDogMTtcclxuICBtYXJnaW46IDEwLjkzNzVyZW0gMCA0LjM3NXJlbSAwO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMTAwcHgpIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBtYXJnaW46IDgwcHggMCAwIDA7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQ2FsZW5kYXJUaXRsZVNoYWRvdyA9IHN0eWxlZC5oM2BcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAuMjVyZW07XHJcbiAgbGVmdDogLjI1cmVtO1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQ0MC53MTkyMC5mb250U2l6ZX07XHJcbiAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxOTIwLmhlaWdodH07XHJcbiAgY29sb3I6ICMwMDA7XHJcbiAgei1pbmRleDogMDtcclxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLncxNjYwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQ0MC53MTY2MC5oZWlnaHR9O1xyXG4gICAgdG9wOiAuMTVyZW07XHJcbiAgICBsZWZ0OiAuMTVyZW07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250NDAudzE0NDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLncxNDQwLmhlaWdodH07XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMTAwcHgpIHtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWChjYWxjKC01MCUgKyAuMTVyZW0pKTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc3NjguZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc3NjguaGVpZ2h0fTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDQwLnc1MDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDQwLnc1MDAuaGVpZ2h0fTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWChjYWxjKC01MCUgKyAuMTVyZW0pKTtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBDYWxlbmRhckxpbWl0ID0gc3R5bGVkLmRpdmBcclxuICBtYXgtd2lkdGg6IDk4MHB4O1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG4gIHBhZGRpbmc6IDAgIDI0cHg7XHJcbmA7XHJcblxyXG5jb25zdCBUb3BWZWN0b3IgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzdmcgd2lkdGg9XCI0MTdcIiBoZWlnaHQ9XCIxODBcIiB2aWV3Qm94PVwiMCAwIDQxNyAxODBcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBmaWxsUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgIGNsaXBSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgICAgZD1cIk0wIDE4MEg0MTYuNjA2VjEzNy45OTZDNDE2LjYwNiAxMjYuMDM2IDQwNi43OTEgMTE2LjE4MyAzOTQuODIyIDExNi4xODNIMjM3LjQ5NlY5Ni4yNDY0QzI1MS44NiA4Ni42ODEyIDI2MS4xNjYgNzAuNzIzNCAyNjEuMTY2IDUyLjM4OTZDMjYxLjE2NiAyMy4zOTY5XHJcbiAgICAgICAgICAyMzcuNzY5IDAgMjA4Ljc4MSAwQzE3OS44MDIgMCAxNTYuMTI3IDIzLjM5NjkgMTU2LjEyNyA1Mi4zODk2QzE1Ni4xMjcgNzAuNzIzNCAxNjUuNjk3IDg2LjY3NjQgMTc5Ljc5NyA5Ni4yNDY0VjExNi4xODNIMjEuNzk0QzkuODI5MjQgMTE2LjE4MyAwIDEyNi4wMzYgMFxyXG4gICAgICAgICAgMTM3Ljk5NlYxODBaXCJcclxuICAgICAgICBmaWxsPVwiYmxhY2tcIiAvPlxyXG4gICAgPC9zdmc+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCBjb250ZW50ID0gW1xyXG4gIHsgcGVyY2VudDogJzEwJScsIHRleHQ6ICdQYXkgYmFjayBvdXIgdGVhbSBhbmQgc2VuZCBEYSBCdW5uaWVzIHNvbWUgcGl6emEuJyB9LFxyXG4gIHsgcGVyY2VudDogJzIwJScsIHRleHQ6ICdBaXJkcm9wIGdpdmVhd2F5IEVSQzIwIHRva2VuIGZvciB0b3AgaG9sZGVycyAmIEhPREwgcmFsbHkgZXZlbnQgYW5ub3VuY2VtZW50LicgfSxcclxuICB7IHBlcmNlbnQ6ICc0MCUnLCB0ZXh0OiAnUmVsZWFzZSA1MCBzcGVjaWFsIEhhdW50ZWQgQnVubmllcyAoSGFsbG93ZWVuIGVkaXRpb24pLicgfSxcclxuICB7IHBlcmNlbnQ6ICc3MCUnLCB0ZXh0OiAnQW5ub3VuY2VtZW50IG9mIGdlbmVyYXRpb24gMiBhbmQgYnJlZWRpbmcgZGV0YWlscyBvbiBEYSBCdW5ueSBORlQgRGlzY29yZC4nIH0sXHJcbiAgeyBwZXJjZW50OiAnODAlJywgdGV4dDogJ0FjdGl2YXRlIG91ciBwcmVtaWVyZSAtIERhIEJ1bm55IFJhZGlvIENoYW5uZWwgLSBvbiBZb3VUdWJlIGFuZCBTcG90aWZ5LicgfSxcclxuICB7IHBlcmNlbnQ6ICc5MCUnLCB0ZXh0OiAnRXhjbHVzaXZlIG1lbWJlciBhY2Nlc3MgdG8gRGEgQnVubnkgbGltaXRlZCBlZGl0aW9uIGRpZ2l0YWwgbWVyY2hhbmRpc2UgbWludGluZy4gRGEgQnVubnkgWCBOSUZUSSBTdHVkaW9zIGNvbGxhYm9yYXRpb24uIERldGFpbHMgdG8gYmUgcmVsZWFzZWQgaW4gRGlzY29yZC4nIH0sXHJcbiAgeyBwZXJjZW50OiAnMTAwJScsIHRleHQ6ICdXZSBsYW1ibyEgQW5ub3VuY2VtZW50IG9mIGdsb2JhbCBjZWxlYnJhdGlvbiBldmVudHMgJiByYWxseSBvbiBjaGFpbi4gR2l2ZWF3YXkgZm9yIGFsbCBORlQgaG9sZGVycy4nIH1cclxuXTtcclxuXHJcbmNvbnN0IFJvYWRtYXAgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3JvY2tldE9uU2NyZWVuLCBzZXRSb2NrZXRPblNjcmVlbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IHJlc2l6ZUV2ZW50SGFuZGxlID0gKCkgPT4ge1xyXG4gICAgY29uc3Qgd2luZG93V2lkdGggPSB3aW5kb3cuaW5uZXJXaWR0aDtcclxuICAgIHN3aXRjaCAodHJ1ZSkge1xyXG4gICAgICBjYXNlIHdpbmRvd1dpZHRoID4gMTY2MDpcclxuXHJcbiAgICAgICAgLyogaWYgKHJvY2tldE9uU2NyZWVuKSB7XHJcbiAgICAgICAgICBzZXRQb3NpdGlvblkoLTEyLjUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRDYWxjUG9zaXRpb24oLTEyLjUpO1xyXG4gICAgICAgIH0gKi9cclxuICAgICAgICBicmVhaztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICAvKiBpZiAocm9ja2V0T25TY3JlZW4pIHtcclxuICAgICAgICAgIHNldFBvc2l0aW9uWSgtMjUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRDYWxjUG9zaXRpb24oLTI1KTtcclxuICAgICAgICB9ICovXHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHJlc2l6ZUV2ZW50SGFuZGxlKCk7XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgcmVzaXplRXZlbnRIYW5kbGUpO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHJlc2l6ZUV2ZW50SGFuZGxlKTtcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCByb2NrZXRBcHBlYXJzID0gKCkgPT4ge1xyXG4gICAgc2V0Um9ja2V0T25TY3JlZW4odHJ1ZSk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNlY3Rpb24+XHJcbiAgICAgIDxJbm5lcldyYXAgaWQ9XCJyb2FkbWFwXCI+XHJcbiAgICAgICAgPFJvY2tldEJ1bm55IHJvY2tldE9uU2NyZWVuPXtyb2NrZXRPblNjcmVlbn0+XHJcbiAgICAgICAgICA8V2F5cG9pbnRcclxuICAgICAgICAgICAgb25FbnRlcj17cm9ja2V0QXBwZWFyc31cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgICAgd2lkdGg9ezIyMjh9XHJcbiAgICAgICAgICAgIGhlaWdodD17NjA3fVxyXG4gICAgICAgICAgICBzcmM9XCIvaW1nL3JvY2tldF9idW5ueS5wbmdcIlxyXG4gICAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L1JvY2tldEJ1bm55PlxyXG4gICAgICAgIDxBY3RpdmF0aW9uc0JveD5cclxuICAgICAgICAgIDxWZWN0b3JXcmFwPlxyXG4gICAgICAgICAgICA8VG9wVmVjdG9yIC8+XHJcbiAgICAgICAgICA8L1ZlY3RvcldyYXA+XHJcbiAgICAgICAgICA8QWN0aXZhdGlvblRpdGxlPlJvYWRtYXAgQWN0aXZhdGlvbnM8L0FjdGl2YXRpb25UaXRsZT5cclxuICAgICAgICAgIDxBY3RpdmF0aW9uTGlzdD5cclxuICAgICAgICAgICAge2NvbnRlbnQubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8QWN0aXZhdGlvbkl0ZW0ga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtLnBlcmNlbnR9IDwvc3Bhbj57aXRlbS50ZXh0fVxyXG4gICAgICAgICAgICAgICAgPC9BY3RpdmF0aW9uSXRlbT5cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9BY3RpdmF0aW9uTGlzdD5cclxuICAgICAgICAgIDxCdW5ueUltYWdlPlxyXG4gICAgICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgICAgICB3aWR0aD17NjUwfVxyXG4gICAgICAgICAgICAgIGhlaWdodD17ODA5fVxyXG4gICAgICAgICAgICAgIHNyYz1cIi9pbWcvYnVubnk0LnBuZ1wiXHJcbiAgICAgICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvQnVubnlJbWFnZT5cclxuICAgICAgICA8L0FjdGl2YXRpb25zQm94PlxyXG4gICAgICAgIDxDYWxlbmRhckxpbWl0PlxyXG4gICAgICAgICAgPENhbGVuZGFyVGl0bGVXcmFwPlxyXG4gICAgICAgICAgICA8Q2FsZW5kYXJUaXRsZT5cclxuICAgICAgICAgICAgICBFdmVudCBDYWxlbmRhclxyXG4gICAgICAgICAgICA8L0NhbGVuZGFyVGl0bGU+XHJcbiAgICAgICAgICAgIDxDYWxlbmRhclRpdGxlU2hhZG93PlxyXG4gICAgICAgICAgICAgIEV2ZW50IENhbGVuZGFyXHJcbiAgICAgICAgICAgIDwvQ2FsZW5kYXJUaXRsZVNoYWRvdz5cclxuICAgICAgICAgIDwvQ2FsZW5kYXJUaXRsZVdyYXA+XHJcbiAgICAgICAgICA8Q2FsZW5kYXJCb3hPbmUgLz5cclxuICAgICAgICAgIDxDYWxlbmRhckJveFR3byAvPlxyXG4gICAgICAgICAgPENhbGVuZGFyQm94VGhyZWUgLz5cclxuICAgICAgICAgIDxDYWxlbmRhckJveEZvdXIgLz5cclxuICAgICAgICA8L0NhbGVuZGFyTGltaXQ+XHJcbiAgICAgIDwvSW5uZXJXcmFwPlxyXG4gICAgPC9TZWN0aW9uID5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJvYWRtYXA7XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xyXG5pbXBvcnQgQ2Fycm90SGVhZGVyIGZyb20gJy4uL1NoYXJlZC9DYXJyb3RIZWFkZXIvQ2Fycm90SGVhZGVyJztcclxuaW1wb3J0IGZvbnRzIGZyb20gJy4uLy4uL3N0eWxlcy90eXBvZ3JhcGh5JztcclxuXHJcbmNvbnN0IFNlY3Rpb24gPSBzdHlsZWQuc2VjdGlvbmBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmU2MGFlO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuYDtcclxuXHJcbmNvbnN0IEhlYWRlcldyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbmA7XHJcblxyXG5jb25zdCBJbm5lcldyYXAgPSBzdHlsZWQuZGl2YFxyXG4gIHBhZGRpbmctdG9wOiAxMHJlbTtcclxuICBwYWRkaW5nLWJvdHRvbTogMjAuOTM3NXJlbTtcclxuICBtYXgtd2lkdGg6IDkwcmVtO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBAbWVkaWEgKG1heC13aWR0aDogOTcwcHgpIHtcclxuICAgIHBhZGRpbmctYm90dG9tOiAwO1xyXG4gICAgcGFkZGluZy10b3A6IDEwcmVtO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIHBhZGRpbmctdG9wOiA1cmVtO1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IFBhcmFncmFwaCA9IHN0eWxlZC5wYFxyXG4gIG1hcmdpbi10b3A6IDgwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxOTIwLmZvbnRTaXplfTtcclxuICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzE5MjAuaGVpZ2h0fTtcclxuICBwYWRkaW5nLWxlZnQ6IDEyLjUlO1xyXG4gIHBhZGRpbmctcmlnaHQ6IDM1JTtcclxuICB6LWluZGV4OiAxO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTY2MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNjYwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53MTY2MC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTQ0MHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNDQwLmZvbnRTaXplfTtcclxuICAgIGxpbmUtaGVpZ2h0OiAke2ZvbnRzLmZvbnQyNC53MTQ0MC5oZWlnaHR9O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTI1MHB4KSB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDcuNSU7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAzNy41JTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDk3MHB4KSB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IEJ1bm55SW1hZ2UgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiAxO1xyXG4gIHJpZ2h0OiAtMTAwcHg7XHJcbiAgYm90dG9tOiAtLjUyNXJlbTtcclxuICBtYXgtd2lkdGg6IDYyMnB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNDQwcHgpIHtcclxuICAgIHJpZ2h0OiAwO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogOTcwcHgpIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGxlZnQ6IDY1JTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcclxuICAgIHBhZGRpbmctdG9wOiAzNXB4O1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDQ1MHB4KSB7XHJcbiAgICBtYXJnaW4tdG9wOiAzMHB4O1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgcGFkZGluZzogMCAxcmVtO1xyXG4gIH1cclxuXHJcbmA7XHJcblxyXG5jb25zdCBCdWJibGVzSW1hZ2UgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgYm90dG9tOiAtMTBweDtcclxuICB3aWR0aDogMTAwJTtcclxuICBpbWcge1xyXG4gICAgd2lkdGg6IDEwMHZ3O1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgbWF4LWhlaWdodDogMzVyZW07XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgV2hhdERhID0gKCkgPT4ge1xyXG5cclxuICBjb25zdCBbcmVzaXplRmFjdG9yLCBzZXRSZXNpemVGYWN0b3JdID0gdXNlU3RhdGUoMSk7XHJcblxyXG4gIGNvbnN0IHJlc2l6ZUV2ZW50SGFuZGxlID0gKCkgPT4ge1xyXG4gICAgY29uc3Qgd2luZG93V2lkdGggPSB3aW5kb3cuaW5uZXJXaWR0aDtcclxuICAgIHN3aXRjaCAodHJ1ZSkge1xyXG4gICAgICBjYXNlIHdpbmRvd1dpZHRoID4gMTY2MDpcclxuICAgICAgICBzZXRSZXNpemVGYWN0b3IoMS4yNSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2Ugd2luZG93V2lkdGggPiAxMjAwOlxyXG4gICAgICAgIHNldFJlc2l6ZUZhY3RvcigxLjQ1KTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICBzZXRSZXNpemVGYWN0b3IoMS41NSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHJlc2l6ZUV2ZW50SGFuZGxlKCk7XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgcmVzaXplRXZlbnRIYW5kbGUpO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHJlc2l6ZUV2ZW50SGFuZGxlKTtcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNlY3Rpb24+XHJcbiAgICAgIDxJbm5lcldyYXAgaWQ9XCJhYm91dFwiPlxyXG4gICAgICAgIDxIZWFkZXJXcmFwcGVyPlxyXG4gICAgICAgICAgPENhcnJvdEhlYWRlciBiZ0NvbG9yPVwiIzg3RUVGNFwiIHBhZGRpbmc9XCIxLjU2MjVyZW0gNjRweCAyNXB4IDk2cHhcIj5cclxuICAgICAgICAgICAgV2hhdCBEYSBCdW5ueT9cclxuICAgICAgICAgIDwvQ2Fycm90SGVhZGVyPlxyXG4gICAgICAgIDwvSGVhZGVyV3JhcHBlcj5cclxuICAgICAgICA8UGFyYWdyYXBoPlxyXG4gICAgICAgICAgRGEgQnVubnkgaXMgYSB0cmliZSBvZiA4LDAwMCBwcm9ncmFtbWF0aWNhbGx5IGdlbmVyYXRlZCBORlQgYnVubmllcyB0aGF0IHJlc2lkZSBpbiB0aGUgRXRoZXJldW0gYmxvY2tjaGFpbi5cclxuICAgICAgICAgIEdlbmVyYXRpb24gMSB3YXMgaW5jdWJhdGVkIGZyb20gYSByYW5kb21pemVkIGNvbWJpbmF0aW9uIG9mIG1vcmUgdGhhbiAyMDAgdW5pcXVlIHRyYWl0cywgb3V0IG9mIDQsMzIwLDAwMCB0b3RhbFxyXG4gICAgICAgICAgcG9zc2liaWxpdGllcy4gRWFjaCBidW5ueSBoYXMgYSB1bmlxdWUgY2hhcmFjdGVyIGFuZCBhcHBlYXJhbmNlIHdoaWNoIG1ha2VzIGhpbS9oZXIg4oCcRGHigJ0gQnVubnkuLi4uXHJcbiAgICAgICAgPC9QYXJhZ3JhcGg+XHJcbiAgICAgICAgPEJ1bm55SW1hZ2U+XHJcbiAgICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgICAgd2lkdGg9ezYyMiAvIHJlc2l6ZUZhY3Rvcn1cclxuICAgICAgICAgICAgaGVpZ2h0PXs2MjIgLyByZXNpemVGYWN0b3J9XHJcbiAgICAgICAgICAgIHNyYz1cIi9pbWcvYnVubnkyLnBuZ1wiXHJcbiAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvQnVubnlJbWFnZT5cclxuICAgICAgPC9Jbm5lcldyYXA+XHJcbiAgICAgIDxCdWJibGVzSW1hZ2U+XHJcbiAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICB3aWR0aD17MTQ0MH1cclxuICAgICAgICAgIGhlaWdodD17NjExfVxyXG4gICAgICAgICAgc3JjPVwiL2ltZy9idWJibGVzX2JsdWUucG5nXCJcclxuICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9CdWJibGVzSW1hZ2U+XHJcbiAgICA8L1NlY3Rpb24+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBXaGF0RGE7IiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcbmltcG9ydCBmb250cyBmcm9tICcuLi8uLi8uLi9zdHlsZXMvdHlwb2dyYXBoeSc7XHJcblxyXG50eXBlIENhcnJvdFR5cGUgPSB7XHJcbiAgY2hpbGRyZW46IGFueTtcclxuICBwYWRkaW5nOiBzdHJpbmc7XHJcbiAgYmdDb2xvcjogc3RyaW5nO1xyXG59XHJcblxyXG5jb25zdCBXcmFwID0gc3R5bGVkLmRpdjx7IHBhZGRpbmc6IHN0cmluZzsgYmdDb2xvcjogc3RyaW5nOyB9PmBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAke3Byb3BzID0+IHByb3BzLmJnQ29sb3J9O1xyXG4gIHBhZGRpbmc6ICR7cHJvcHMgPT4gcHJvcHMucGFkZGluZ307XHJcbiAgd2lkdGg6IG1heC1jb250ZW50O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBoZWlnaHQ6IDUuNjI1cmVtO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBib3JkZXI6IDNweCBzb2xpZCAjMDAwMDAwO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgYm94LXNoYWRvdzowIDhweCAwIDAgIzAwMDAwMDtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICBwYWRkaW5nOiAxNnB4IDMycHg7XHJcbiAgICBoZWlnaHQ6IHVuc2V0O1xyXG4gICAgbWluLXdpZHRoOiAgMjQwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgQ2Fycm90V3JhcCA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGxlZnQ6IC0xLjU2MjVyZW07XHJcbiAgYm90dG9tOiAtMC45Mzc1cmVtO1xyXG4gIHotaW5kZXg6IDE7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgd2lkdGg6IDU2cHg7XHJcbiAgICBoZWlnaHQ6IDc0cHg7XHJcbiAgICBib3R0b206IDByZW07XHJcbiAgICBsZWZ0OiAtMXJlbTtcclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBQYXJhZ3JhcGggPSBzdHlsZWQucGBcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxOTIwLmZvbnRTaXplfTtcclxuICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzE5MjAuaGVpZ2h0fTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDE2MDBweCkge1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTY2MC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzE2NjAuaGVpZ2h0fTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxNjAwcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE0NDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0LncxNDQwLmhlaWdodH07XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzc2OC5mb250U2l6ZX07XHJcbiAgICBsaW5lLWhlaWdodDogJHtmb250cy5mb250MjQudzc2OC5oZWlnaHR9O1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0Lnc1MDAuZm9udFNpemV9O1xyXG4gICAgbGluZS1oZWlnaHQ6ICR7Zm9udHMuZm9udDI0Lnc1MDAuaGVpZ2h0fTtcclxuICB9XHJcbmA7XHJcblxyXG5cclxuY29uc3QgQ2Fycm90SGVhZGVyID0gKHsgY2hpbGRyZW4sIGJnQ29sb3IsIHBhZGRpbmcgfTogQ2Fycm90VHlwZSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8V3JhcCBiZ0NvbG9yPXtiZ0NvbG9yfSBwYWRkaW5nPXtwYWRkaW5nfT5cclxuICAgICAgPENhcnJvdFdyYXA+XHJcbiAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICB3aWR0aD17MTI0fVxyXG4gICAgICAgICAgaGVpZ2h0PXsxNjN9XHJcbiAgICAgICAgICBzcmM9XCIvaW1nL2NhcnJvdC5wbmdcIlxyXG4gICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L0NhcnJvdFdyYXA+XHJcbiAgICAgIDxQYXJhZ3JhcGg+XHJcbiAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICA8L1BhcmFncmFwaD5cclxuICAgIDwvV3JhcD5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENhcnJvdEhlYWRlcjtcclxuIiwiaW1wb3J0IFJlYWN0LCB7IFJlYWN0RWxlbWVudCB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBOZXh0UGFnZSB9IGZyb20gJ25leHQnXHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge1xyXG4gIG9uQ29ubmVjdFdhbGxldDogYW55XHJcbiAgYWRkcmVzczogc3RyaW5nXHJcbiAgYmFsYW5jZTogbnVtYmVyXHJcbiAgbmV0d29yazogc3RyaW5nXHJcbn1cclxuXHJcbi8vIGNvbnN0IE15ZGl2ID0gc3R5bGVkLmRpdmBcclxuLy8gICAvKiBwb3NpdGlvbjogYWJzb2x1dGU7ICovXHJcbi8vICAgd2lkdGg6IDE1MHB4O1xyXG4vLyAgIGhlaWdodDogNDBweDtcclxuLy8gICBsZWZ0OiAwcHg7XHJcbi8vICAgdG9wOiAwcHg7XHJcbi8vICAgYmFja2dyb3VuZDogI2ZmZmZmZjtcclxuLy8gICBib3JkZXI6IDJweCBzb2xpZCAjMDAwMDAwO1xyXG4vLyAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbi8vICAgYm9yZGVyLXJhZGl1czogMzkuNXB4O1xyXG4vLyAgIHBhZGRpbmc6IDAgMTNweDtcclxuLy8gICBkaXNwbGF5OiBmbGV4O1xyXG4vLyAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbi8vICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbi8vICAgY3Vyc29yOiBwb2ludGVyO1xyXG4vLyBgXHJcblxyXG5jb25zdCBNeWRpdiA9IHN0eWxlZC5kaXZgXHJcbiAgLyogcG9zaXRpb246IGFic29sdXRlOyAqL1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICB3aWR0aDogMTUwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG4gIGxlZnQ6IDBweDtcclxuICB0b3A6IDBweDtcclxuICBiYWNrZ3JvdW5kOiAjZmZmZmZmO1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICMwMDAwMDA7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBib3JkZXItcmFkaXVzOiAzOS41cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2U7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogbWVkaXVtO1xyXG5gXHJcblxyXG5jb25zdCBTbWFsbGIgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtc2l6ZTogc21hbGw7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgaGVpZ2h0OiAxNXB4O1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG5gXHJcbmNvbnN0IFNtYWxscyA9IHN0eWxlZC5kaXZgXHJcbiAgZm9udC1zaXplOiB4LXNtYWxsO1xyXG5gXHJcblxyXG5jb25zdCBDb25uZWN0QnV0dG9uOiBOZXh0UGFnZTxQcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICAvL3tvbkNvbm5lY3RXYWxsZXQsIGFkZHJlc3MsIGJhbGFuY2UsIG5ldHdvcmt9XHJcbiAgY29uc3Qge29uQ29ubmVjdFdhbGxldCwgYWRkcmVzcywgYmFsYW5jZSwgbmV0d29ya30gPSBwcm9wcztcclxuICBcclxuICBjb25zdCBNeWRpdiA9IHN0eWxlZC5kaXZgXHJcbiAgICAvKiBwb3NpdGlvbjogYWJzb2x1dGU7ICovXHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiBtZWRpdW07XHJcbiAgICB3aWR0aDogMTUwcHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBsZWZ0OiAwcHg7XHJcbiAgICB0b3A6IDBweDtcclxuICAgIGJhY2tncm91bmQ6ICNGRkZGRkY7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjMDAwMDAwO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDM5LjVweDtcclxuICAgIC8qIHBhZGRpbmc6IGF1dG8gYXV0bzsgKi9cclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2U7XHJcbiAgICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBcclxuICBgO1xyXG5cclxuICBjb25zdCBzaG9ydEFkZHJlc3MgPSAoYWRkcmVzczogc3RyaW5nKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICBhZGRyZXNzLnN1YnN0cmluZygwLCAxMCkgK1xyXG4gICAgICAnLi4uJyArXHJcbiAgICAgIGFkZHJlc3Muc3Vic3RyaW5nKGFkZHJlc3MubGVuZ3RoIC0gNCwgYWRkcmVzcy5sZW5ndGgpXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE15ZGl2IG9uQ2xpY2s9eyhlKSA9PiBvbkNvbm5lY3RXYWxsZXQoZSl9PlxyXG4gICAgICB7YWRkcmVzcyA/IChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPFNtYWxsYj5cclxuICAgICAgICAgICAge2JhbGFuY2VcclxuICAgICAgICAgICAgICA/IE51bWJlcihiYWxhbmNlKS50b0ZpeGVkKDQpICsgJyBFVEgnXHJcbiAgICAgICAgICAgICAgOiBTdHJpbmcoYmFsYW5jZSkgPT09ICcwJ1xyXG4gICAgICAgICAgICAgID8gJzAgRVRIJ1xyXG4gICAgICAgICAgICAgIDogJyd9XHJcbiAgICAgICAgICA8L1NtYWxsYj5cclxuICAgICAgICAgIDxTbWFsbHM+e2FkZHJlc3MgPyBzaG9ydEFkZHJlc3MoYWRkcmVzcykgOiAnQ29ubmVjdCBXYWxsZXQnfTwvU21hbGxzPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXY+IENvbm5lY3QgV2FsbGV0IDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9NeWRpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbm5lY3RCdXR0b25cclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5pbXBvcnQgeyBNb2JpbGVMaW5rVHlwZSB9IGZyb20gJy4vTmF2VHlwZXMnO1xyXG5cclxuaW1wb3J0IHtcclxuICBMaW5rV3JhcCxcclxuICBDYXJyb3RXcmFwLFxyXG4gIE1vYmlsZUxpbmtUZXh0LFxyXG59IGZyb20gJy4vTmF2U3R5bGUnO1xyXG5cclxuY29uc3QgTW9iaWxlTGluayA9ICh7IGhyZWYsIGNoaWxkcmVuLCB0b2dnbGVOYXZNb2JpbGUsIGhhbmRsZUNsaWNrLCBhbmltYXRpb25UaW1lb3V0IH06IE1vYmlsZUxpbmtUeXBlKSA9PiB7XHJcbiAgY29uc3QgbW9iaWxlVG91Y2ggPSAoKSA9PiB7XHJcbiAgICB0b2dnbGVOYXZNb2JpbGUoKTtcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBoYW5kbGVDbGljayhocmVmKTtcclxuICAgIH0sIGFuaW1hdGlvblRpbWVvdXQpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxMaW5rV3JhcD5cclxuICAgICAgPENhcnJvdFdyYXA+XHJcbiAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICB3aWR0aD17Mjh9XHJcbiAgICAgICAgICBoZWlnaHQ9ezM5fVxyXG4gICAgICAgICAgbGF5b3V0PVwiZml4ZWRcIlxyXG4gICAgICAgICAgc3JjPVwiL2ltZy9jYXJyb3QucG5nXCJcclxuICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9DYXJyb3RXcmFwPlxyXG4gICAgICA8TW9iaWxlTGlua1RleHQgb25DbGljaz17bW9iaWxlVG91Y2h9PlxyXG4gICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgPC9Nb2JpbGVMaW5rVGV4dD5cclxuICAgIDwvTGlua1dyYXA+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNb2JpbGVMaW5rO1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5pbXBvcnQgeyBEaXNjb3JkLCBUd2l0dGVyLCBUZWxlZ3JhbSwgTWVkaXVtIH0gZnJvbSAnLi4vLi4vLi4vaWNvbnMvSWNvbnMnO1xyXG5pbXBvcnQgeyBESVNDT1JEX0xJTkssIFRXSVRURVJfTElOSywgTUVESVVNX0xJTkssIFRFTEVfTElOSyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL0xpbmtzJztcclxuY29uc3QgYW5pbWF0aW9uVGltZW91dCA9IDQwMDtcclxuaW1wb3J0IEhhbWJ1cmd1ZXJMaW5lIGZyb20gJy4vSGFtYnVyZ3VlckxpbmUnO1xyXG5pbXBvcnQgYWRqdXN0U2Nyb2xsIGZyb20gJy4vYWRqdXN0U2Nyb2xsJztcclxuaW1wb3J0IHsgSWNvbkxpbmsgfSBmcm9tICcuLi8uLi8uLi9pY29ucy9pY29uJztcclxuXHJcbmltcG9ydCB7XHJcbiAgTmF2LFxyXG4gIE5hdkxpbmssXHJcbiAgR3JvdXAsXHJcbiAgTG9nbyxcclxuICBIYW1idXJndWVyLFxyXG4gIE5hdk1vYmlsZSxcclxuICBCdWJibGVzSW1hZ2UsXHJcbiAgTW9iaWxlSW5uZXIsXHJcbiAgU29jTGlua3MsXHJcbn0gZnJvbSAnLi9OYXZTdHlsZSc7XHJcblxyXG5pbXBvcnQgeyBEZXNrdG9wTGlua1R5cGUsIE1vYmlsZUxpbmtUeXBlLCBTZWN0aW9ucyB9IGZyb20gJy4vTmF2VHlwZXMnO1xyXG5pbXBvcnQgTW9iaWxlTGluayBmcm9tICcuL01vYmlsZUxpbmsnO1xyXG5pbXBvcnQgQ29ubmVjdEJ1dHRvbiBmcm9tICcuLi9Db25uZWN0QnV0dG9uL0Nvbm5lY3RCdXR0b24nO1xyXG5pbXBvcnQgeyBSZWFjdENoaWxkIH0gZnJvbSAnaG9pc3Qtbm9uLXJlYWN0LXN0YXRpY3Mvbm9kZV9tb2R1bGVzL0B0eXBlcy9yZWFjdCc7XHJcblxyXG5cclxuY29uc3QgTmF2QmFyID0gKHByb3BzOiBhbnkpID0+IHtcclxuICBjb25zdCBbbmF2TW9iaWxlUG9zaXRpb24sIHNldE5hdk1vYmlsZVBvc2l0aW9uXSA9IHVzZVN0YXRlKFwiMTAwJVwiKTtcclxuICBjb25zdCBbaXNNb2JpbGVOYXZPcGVuLCBzZXRJc01vYmlsZU5hdk9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IHtvbkNvbm5lY3RXYWxsZXQsIC4uLnVzZXJEYXRhIH0gPSBwcm9wcztcclxuICAvLyBjb25zb2xlLmxvZyh1c2VyRGF0YSk7XHJcblxyXG4gIC8vdGhlIHBhZ2UgaGFzIHRvbyBtYW55IGl0ZW5zIGFuZCB0aGlzIHN1cHBvcnRzIHRoZSBzY3JvbGwgbmF2aWdhdGlvbiBvbiBldmVyeSBjbGlja1xyXG4gIGNvbnN0IFtwb3NpdGlvbkZpeCwgc2V0UG9zaXRpb25GaXhdID0gdXNlU3RhdGUoe1xyXG4gICAgYWJvdXQ6IDAsXHJcbiAgICByYWJiaXQ6IDAsXHJcbiAgICByb2FkbWFwOiAwLFxyXG4gICAgZmFxOiAwLFxyXG4gIH0pO1xyXG5cclxuICAvL3RoZSBzdXBwb3J0IGZ1bmN0aW9uIHRoYXQgYWRqdXN0IGV2ZXJ5IGZpeCBkdWUgdGhlIHNjcmVlbiB3aWR0aFxyXG4gIGNvbnN0IHJlc2l6ZUV2ZW50SGFuZGxlID0gKCkgPT4ge1xyXG4gICAgYWRqdXN0U2Nyb2xsKHNldFBvc2l0aW9uRml4LCB3aW5kb3cuaW5uZXJXaWR0aCk7XHJcbiAgfTtcclxuXHJcbiAgLy9vbmx5IG1vbml0b3JzIHRoZSBzY3JlZW4gd2lkdGggdG8gYWRqdXN0IGV2ZXJ5IGZpeFxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICByZXNpemVFdmVudEhhbmRsZSgpO1xyXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHJlc2l6ZUV2ZW50SGFuZGxlKTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdyZXNpemUnLCByZXNpemVFdmVudEhhbmRsZSk7XHJcbiAgICB9O1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy9yZXNwb25zaWJsZSB0byBzaG93IGFuZCBoaWRlIHRoZSBtb2JpbGUgbWVudVxyXG4gIGNvbnN0IHRvZ2dsZU5hdk1vYmlsZSA9ICgpID0+IHtcclxuICAgIHNldElzTW9iaWxlTmF2T3BlbighaXNNb2JpbGVOYXZPcGVuKTtcclxuICAgIHNldE5hdk1vYmlsZVBvc2l0aW9uKGlzTW9iaWxlTmF2T3BlbiA/IFwiMTAwJVwiIDogXCIwXCIpO1xyXG4gIH1cclxuXHJcbiAgLy9oYW5kbGVzIGJvdGggdGhlIG1vYmlsZSBhbmQgZGVza29wIGxpbmsgY2xpY2tcclxuICBjb25zdCBoYW5kbGVDbGljayA9IChocmVmOiBTZWN0aW9ucykgPT4ge1xyXG4gICAgY29uc3QgZ2V0SHJlZiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGhyZWYpIGFzIEhUTUxFbGVtZW50O1xyXG4gICAgY29uc3QgdmFsdWVPZkZpeCA9IHBvc2l0aW9uRml4W2hyZWZdO1xyXG4gICAgd2luZG93LnNjcm9sbEJ5KHtcclxuICAgICAgdG9wOiBnZXRIcmVmLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLnRvcCArIHZhbHVlT2ZGaXgsXHJcbiAgICAgIGJlaGF2aW9yOiAnc21vb3RoJ1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBjb25zdCBEZXNrdG9wTGluayA9ICh7IGhyZWYsIGNoaWxkcmVuIH06IERlc2t0b3BMaW5rVHlwZSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPE5hdkxpbms+XHJcbiAgICAgICAgPGEgb25DbGljaz17KCkgPT4gaGFuZGxlQ2xpY2soaHJlZil9PntjaGlsZHJlbn08L2E+XHJcbiAgICAgIDwvTmF2TGluaz5cclxuICAgIClcclxuICB9XHJcblxyXG4gIGNvbnN0IE1vYmlsZUxpbmtQcmVwID0gKHsgaHJlZiwgY2hpbGRyZW4gfTp7aHJlZjogU2VjdGlvbnM7IGNoaWxkcmVuOiBSZWFjdENoaWxkIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxNb2JpbGVMaW5rXHJcbiAgICAgICAgdG9nZ2xlTmF2TW9iaWxlPXt0b2dnbGVOYXZNb2JpbGV9XHJcbiAgICAgICAgaGFuZGxlQ2xpY2s9e2hhbmRsZUNsaWNrfVxyXG4gICAgICAgIGFuaW1hdGlvblRpbWVvdXQ9e2FuaW1hdGlvblRpbWVvdXR9XHJcbiAgICAgICAgaHJlZj17aHJlZn0+XHJcbiAgICAgICAgeyBjaGlsZHJlbiB9XHJcbiAgICAgIDwvTW9iaWxlTGluaz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE5hdj5cclxuICBcclxuICAgICAgPEdyb3VwPlxyXG4gICAgICA8TG9nbz5cclxuICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgIHdpZHRoPXsyMTd9XHJcbiAgICAgICAgICBoZWlnaHQ9ezkyfVxyXG4gICAgICAgICAgc3JjPVwiL2ltZy9pY29uLW1haW4ucG5nXCJcclxuICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9Mb2dvPlxyXG4gICAgICAgIHsvKiA8RGVza3RvcExpbmsgaHJlZj1cImFib3V0XCI+QWJvdXQ8L0Rlc2t0b3BMaW5rPiAqL31cclxuICAgICAgICB7LyogPERlc2t0b3BMaW5rIGhyZWY9XCJyYWJiaXRcIj5Eb3duIHRoZSBSYWJiaXQgSG9sZTwvRGVza3RvcExpbms+XHJcbiAgICAgICAgPERlc2t0b3BMaW5rIGhyZWY9XCJyb2FkbWFwXCI+Um9hZG1hcDwvRGVza3RvcExpbms+ICovfVxyXG4gICAgIFxyXG4gIFxyXG4gICAgICA8L0dyb3VwPlxyXG4gICAgICA8R3JvdXA+XHJcbiAgICAgIDxJY29uTGluayBocmVmPXtESVNDT1JEX0xJTkt9PlxyXG4gICAgICAgICAgPERpc2NvcmQgLz5cclxuICAgICAgICA8L0ljb25MaW5rPlxyXG4gICAgICAgIDxJY29uTGluayBocmVmPXtUV0lUVEVSX0xJTkt9PlxyXG4gICAgICAgICAgPFR3aXR0ZXIgLz5cclxuICAgICAgICA8L0ljb25MaW5rPlxyXG4gICAgICAgIDxJY29uTGluayBocmVmPXtURUxFX0xJTkt9PlxyXG4gICAgICAgICAgPFRlbGVncmFtIC8+XHJcbiAgICAgICAgPC9JY29uTGluaz5cclxuICAgICAgICA8Q29ubmVjdEJ1dHRvbiB7Li4ucHJvcHN9Lz5cclxuICAgICAgPC9Hcm91cD5cclxuICAgICAgey8qIDxIYW1idXJndWVyIGlzT3Blbj17aXNNb2JpbGVOYXZPcGVufSBvbkNsaWNrPXt0b2dnbGVOYXZNb2JpbGV9IGFuaW1hdGlvblRpbWVvdXQ9e2FuaW1hdGlvblRpbWVvdXR9PlxyXG4gICAgICAgIDxIYW1idXJndWVyTGluZSAvPlxyXG4gICAgICAgIDxIYW1idXJndWVyTGluZSAvPlxyXG4gICAgICAgIDxIYW1idXJndWVyTGluZSAvPlxyXG4gICAgICA8L0hhbWJ1cmd1ZXI+XHJcbiAgICAgIDxOYXZNb2JpbGUgbGVmdD17bmF2TW9iaWxlUG9zaXRpb259PlxyXG4gICAgICAgIDxNb2JpbGVJbm5lcj5cclxuICAgICAgICAgIDxNb2JpbGVMaW5rUHJlcCBocmVmPVwiYWJvdXRcIj5BYm91dDwvTW9iaWxlTGlua1ByZXA+XHJcbiAgICAgICAgICA8TW9iaWxlTGlua1ByZXAgaHJlZj1cInJhYmJpdFwiPkRvd24gdGhlIFJhYmJpdCBIb2xlPC9Nb2JpbGVMaW5rUHJlcD5cclxuICAgICAgICAgIDxNb2JpbGVMaW5rUHJlcCBocmVmPVwicm9hZG1hcFwiPlJvYWRtYXA8L01vYmlsZUxpbmtQcmVwPlxyXG4gICAgICAgICAgPE1vYmlsZUxpbmtQcmVwIGhyZWY9XCJmYXFcIj5GQVE8L01vYmlsZUxpbmtQcmVwPlxyXG4gICAgICAgICAgPEJ1YmJsZXNJbWFnZT5cclxuICAgICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgICAgd2lkdGg9ezc1MH1cclxuICAgICAgICAgICAgICBoZWlnaHQ9ezM3OH1cclxuICAgICAgICAgICAgICBzcmM9XCIvaW1nL2J1YmJsZXNfcHVycGxlLnBuZ1wiXHJcbiAgICAgICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvQnViYmxlc0ltYWdlPlxyXG4gICAgICAgIDwvTW9iaWxlSW5uZXI+XHJcbiAgICAgIDwvTmF2TW9iaWxlPiAqL31cclxuICAgIDwvTmF2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTmF2QmFyOyIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCBmb250cyBmcm9tIFwiLi4vLi4vLi4vc3R5bGVzL3R5cG9ncmFwaHlcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBOYXYgPSBzdHlsZWQuZGl2YFxyXG4gIHBhZGRpbmc6IDIwcHggOTVweCAxMHB4IDE2NXB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIHotaW5kZXg6IDEwO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM1ZGYyYmM7XHJcbiAgQG1lZGlhIChtYXgtaGVpZ2h0OiA5MDBweCkgYW5kIChtaW4td2lkdGg6IDEwMDFweCkge1xyXG4gICAgcGFkZGluZy10b3A6IDE2cHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTZweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEzMDBweCkge1xyXG4gICAgcGFkZGluZzogMzVweCA0OHB4IDM1cHggNDhweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEwMDBweCkge1xyXG4gICAgcGFkZGluZzogMTVweCA0OHB4IDE1cHggNDhweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU1MHB4KSB7XHJcbiAgICBwYWRkaW5nOiAyNnB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBOYXZMaW5rID0gc3R5bGVkLmRpdmBcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYSB7XHJcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgZm9udC1zaXplOiAke2ZvbnRzLmZvbnQyNC53MTkyMC5mb250U2l6ZX07XHJcbiAgICBmb250LWZhbWlseTonc3BhY2UgZ3JvdGVzayc7XHJcbiAgICBtYXJnaW46MCAzMHB4O1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgIHRyYW5zaXRpb246IHRleHQtc2hhZG93IDAuM3MgZWFzZS1pbi1vdXQ7XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTYwMHB4KSB7XHJcbiAgICAgIGZvbnQtc2l6ZTogJHtmb250cy5mb250MjQudzE2NjAuZm9udFNpemV9O1xyXG4gICAgfVxyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDE0NDBweCkge1xyXG4gICAgICBmb250LXNpemU6ICR7Zm9udHMuZm9udDI0LncxNDQwLmZvbnRTaXplfTtcclxuICAgIH1cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxMzAwcHgpIHtcclxuICAgICAgcGFkZGluZzogMzVweCA0OHB4IDM1cHggNDhweDtcclxuICAgICAgbWFyZ2luOiAwIDE2cHg7XHJcbiAgICB9XHJcbiAgICAmOmhvdmVye1xyXG4gICAgICAgIHRleHQtc2hhZG93OiAwIDI1cHggMjVweCByZ2JhKDAsMCwwLDAuMyk7XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG5cclxuXHJcbmV4cG9ydCBjb25zdCBHcm91cCA9IHN0eWxlZC5kaXZgXHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDEwMDBweCkge1xyXG5cclxuICAgIH1cclxuICAgIHN2Z3tcclxuICAgICAgICBtYXJnaW46IDAgMTBweDtcclxuICAgIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBMb2dvID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBibG9jaztcclxuICB6LWluZGV4OiAxMDAxO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMDAwcHgpIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyMHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC1oZWlnaHQ6IDkwMHB4KSBhbmQgKG1pbi13aWR0aDogMTAwMXB4KSB7XHJcbiAgICB3aWR0aDogMTgwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1NTBweCkge1xyXG4gICAgaW1nIHtcclxuICAgICAgd2lkdGg6IDI0MHB4O1xyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIYW1idXJndWVyID0gc3R5bGVkLmRpdjx7IGlzT3BlbjogYm9vbGVhbjsgYW5pbWF0aW9uVGltZW91dDogbnVtYmVyIH0+YFxyXG4gIGRpc3BsYXk6IG5vbmU7XHJcbiAgei1pbmRleDogMTAyO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB0b3A6IC0xNXB4O1xyXG5cclxuICBzcGFuIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIGhlaWdodDogOHB4O1xyXG4gICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtICR7KHsgYW5pbWF0aW9uVGltZW91dCB9KSA9PiBhbmltYXRpb25UaW1lb3V0fW1zIGVhc2Utb3V0O1xyXG4gICAgc3ZnIHtcclxuICAgICAgaGVpZ2h0OiA0cHg7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzcGFuOm50aC1jaGlsZCgxKSB7XHJcbiAgICB0cmFuc2Zvcm06ICR7KHsgaXNPcGVuIH0pID0+IGlzT3BlbiA/ICdyb3RhdGUoNDVkZWcpIHRyYW5zbGF0ZSgxMnB4LDBweCknIDogJ3JvdGF0ZSgwKSAgdHJhbnNsYXRlKDAsIDApJ307XHJcbiAgfVxyXG5cclxuICBzcGFuOm50aC1jaGlsZCgyKSB7XHJcbiAgICB2aXNpYmlsaXR5OiAkeyh7IGlzT3BlbiB9KSA9PiBpc09wZW4gPyAnaGlkZGVuJyA6ICdzaG93J307XHJcbiAgfVxyXG5cclxuICBzcGFuOm50aC1jaGlsZCgzKSB7XHJcbiAgICB0cmFuc2Zvcm06ICR7KHsgaXNPcGVuIH0pID0+IGlzT3BlbiA/ICdyb3RhdGUoLTQ1ZGVnKSB0cmFuc2xhdGUoLTFweCwtMTFweCknIDogJ3JvdGF0ZSgwKSAgdHJhbnNsYXRlKDAsIDApJ307XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTAwMHB4KSB7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBOYXZNb2JpbGUgPSBzdHlsZWQuZGl2PHsgbGVmdDogc3RyaW5nIH0+YFxyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmQ3NGM7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBtaW4taGVpZ2h0OiAxMDB2aDtcclxuICBtaW4td2lkdGg6IDEwMHZ3O1xyXG4gIGxlZnQ6ICR7cHJvcHMgPT4gcHJvcHMubGVmdH07XHJcbiAgdG9wOiAwO1xyXG4gIHRyYW5zaXRpb246IGFsbCAuNnMgZWFzZS1pbi1vdXQ7XHJcbiAgei1pbmRleDogMTAxO1xyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEJ1YmJsZXNJbWFnZSA9IHN0eWxlZC5kaXZgXHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDA7XHJcbiAgYm90dG9tOiAtOHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGltZyB7XHJcbiAgICB3aWR0aDogMTAwdnc7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IExpbmtXcmFwID0gc3R5bGVkLmFgXHJcbiAgbWFyZ2luLWJvdHRvbTogNzBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDE7XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgTW9iaWxlSW5uZXIgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IENhcnJvdFdyYXAgPSBzdHlsZWQuZGl2YFxyXG4gIG1hcmdpbi1yaWdodDogMTBweDtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBNb2JpbGVMaW5rVGV4dCA9IHN0eWxlZC5zcGFuYFxyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGxpbmUtaGVpZ2h0OiAyM3B4O1xyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNvY0xpbmtzID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjpmaXhlZDtcclxuICBtYXJnaW46IDEwMHB4IDE4MHB4IDAgMDtcclxuICByaWdodDowO1xyXG5gIiwiY29uc3QgYWRqdXN0U2Nyb2xsID0gKHNldFBvc2l0aW9uRml4OiBhbnksIHdpZHRoOiBudW1iZXIpID0+IHtcclxuICBpZiAod2lkdGggPj0gMTkyMCkge1xyXG4gICAgc2V0UG9zaXRpb25GaXgoe1xyXG4gICAgICBhYm91dDogMTIwLFxyXG4gICAgICByYWJiaXQ6IDIwMCxcclxuICAgICAgcm9hZG1hcDogLTQwMCxcclxuICAgICAgZmFxOiAwLFxyXG4gICAgfSk7XHJcbiAgICByZXR1cm5cclxuICB9XHJcbiAgaWYgKHdpZHRoID49IDE2MDApIHtcclxuICAgIHNldFBvc2l0aW9uRml4KHtcclxuICAgICAgYWJvdXQ6IDEzMCxcclxuICAgICAgcmFiYml0OiAxMDAsXHJcbiAgICAgIHJvYWRtYXA6IC00MDAsXHJcbiAgICAgIGZhcTogMCxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuXHJcbiAgfVxyXG4gIGlmICh3aWR0aCA+PSAxNDQwKSB7XHJcbiAgICBzZXRQb3NpdGlvbkZpeCh7XHJcbiAgICAgIGFib3V0OiAxMzAsXHJcbiAgICAgIHJhYmJpdDogMTAwLFxyXG4gICAgICByb2FkbWFwOiAtNDAwLFxyXG4gICAgICBmYXE6IDAsXHJcbiAgICB9KTtcclxuICAgIHJldHVyblxyXG4gIH1cclxuICBpZiAod2lkdGggPj0gMTIwMCkge1xyXG4gICAgc2V0UG9zaXRpb25GaXgoe1xyXG4gICAgICBhYm91dDogMTIwLFxyXG4gICAgICByYWJiaXQ6IDIwLFxyXG4gICAgICByb2FkbWFwOiAtNDAwLFxyXG4gICAgICBmYXE6IDAsXHJcbiAgICB9KTtcclxuICAgIHJldHVyblxyXG4gIH1cclxuICBpZiAod2lkdGggPj0gNzY4KSB7XHJcbiAgICBzZXRQb3NpdGlvbkZpeCh7XHJcbiAgICAgIGFib3V0OiAtNTAsXHJcbiAgICAgIHJhYmJpdDogLTIwLFxyXG4gICAgICByb2FkbWFwOiAtNDAwLFxyXG4gICAgICBmYXE6IC0xODAsXHJcbiAgICB9KTtcclxuICAgIHJldHVyblxyXG4gIH1cclxuICBpZiAod2lkdGggPj0gNTAwKSB7XHJcbiAgICBzZXRQb3NpdGlvbkZpeCh7XHJcbiAgICAgIGFib3V0OiAtNTAsXHJcbiAgICAgIHJhYmJpdDogLTIwLFxyXG4gICAgICByb2FkbWFwOiAtMzIwLFxyXG4gICAgICBmYXE6IC0xNjAsXHJcbiAgICB9KTtcclxuICAgIHJldHVyblxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgYWRqdXN0U2Nyb2xsO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuZXhwb3J0IGNvbnN0IERpc2NvcmQgPSAocHJvcHMpID0+IHtcclxuICAgIGNvbnN0IHsgd2lkdGggPSA2MCwgaGVpZ2h0ID0gNDUsIGZpbGwgfSA9IHByb3BzO1xyXG4gICAgcmV0dXJuIChcclxuPHN2ZyBoZWlnaHQ9e3dpZHRofSB3aWR0aD17aGVpZ2h0fSB2aWV3Qm94PVwiLTI2LjI1IC01MCAyMjcuNSAzMDBcIj48cGF0aCBkPVwiTTY5LjQgODMuOWMtNS43IDAtMTAuMiA1LTEwLjIgMTEuMXM0LjYgMTEuMSAxMC4yIDExLjFjNS43IDAgMTAuMi01IDEwLjItMTEuMS4xLTYuMS00LjUtMTEuMS0xMC4yLTExLjF6bTM2LjUgMGMtNS43IDAtMTAuMiA1LTEwLjIgMTEuMXM0LjYgMTEuMSAxMC4yIDExLjFjNS43IDAgMTAuMi01IDEwLjItMTEuMXMtNC41LTExLjEtMTAuMi0xMS4xelwiLz48cGF0aCBkPVwiTTE1NC41IDBoLTEzNEM5LjIgMCAwIDkuMiAwIDIwLjZ2MTM1LjJjMCAxMS40IDkuMiAyMC42IDIwLjUgMjAuNmgxMTMuNGwtNS4zLTE4LjUgMTIuOCAxMS45IDEyLjEgMTEuMiAyMS41IDE5VjIwLjZDMTc1IDkuMiAxNjUuOCAwIDE1NC41IDB6bS0zOC42IDEzMC42cy0zLjYtNC4zLTYuNi04LjFjMTMuMS0zLjcgMTguMS0xMS45IDE4LjEtMTEuOS00LjEgMi43LTggNC42LTExLjUgNS45LTUgMi4xLTkuOCAzLjUtMTQuNSA0LjMtOS42IDEuOC0xOC40IDEuMy0yNS45LS4xLTUuNy0xLjEtMTAuNi0yLjctMTQuNy00LjMtMi4zLS45LTQuOC0yLTcuMy0zLjQtLjMtLjItLjYtLjMtLjktLjUtLjItLjEtLjMtLjItLjQtLjMtMS44LTEtMi44LTEuNy0yLjgtMS43czQuOCA4IDE3LjUgMTEuOGMtMyAzLjgtNi43IDguMy02LjcgOC4zLTIyLjEtLjctMzAuNS0xNS4yLTMwLjUtMTUuMiAwLTMyLjIgMTQuNC01OC4zIDE0LjQtNTguMyAxNC40LTEwLjggMjguMS0xMC41IDI4LjEtMTAuNWwxIDEuMmMtMTggNS4yLTI2LjMgMTMuMS0yNi4zIDEzLjFzMi4yLTEuMiA1LjktMi45YzEwLjctNC43IDE5LjItNiAyMi43LTYuMy42LS4xIDEuMS0uMiAxLjctLjIgNi4xLS44IDEzLTEgMjAuMi0uMiA5LjUgMS4xIDE5LjcgMy45IDMwLjEgOS42IDAgMC03LjktNy41LTI0LjktMTIuN2wxLjQtMS42czEzLjctLjMgMjguMSAxMC41YzAgMCAxNC40IDI2LjEgMTQuNCA1OC4zIDAgMC04LjUgMTQuNS0zMC42IDE1LjJ6XCIvPjwvc3ZnPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgVGVsZWdyYW0gPSAocHJvcHMpID0+IHtcclxuICAgIGNvbnN0IHsgIHdpZHRoID0gNjAsIGhlaWdodCA9IDQ1LCBmaWxsIH0gPSBwcm9wcztcclxuICAgIHJldHVybiAoXHJcbjxzdmcgaGVpZ2h0PXt3aWR0aH0gd2lkdGg9e2hlaWdodH0gdmlld0JveD1cIi0zNiAtNjAgMzEyIDM2MFwiPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBncmFkaWVudFVuaXRzPVwidXNlclNwYWNlT25Vc2VcIiB5Mj1cIjE4MFwiIHkxPVwiNDAuMDA4XCIgeDI9XCIxMDAuMDFcIiB4MT1cIjE2MC4wMVwiIGlkPVwiYVwiPjxzdG9wIG9mZnNldD1cIjBcIiBzdG9wLWNvbG9yPVwiIzQyNGQ1OFwiLz48c3RvcCBvZmZzZXQ9XCIxXCIgc3RvcC1jb2xvcj1cIiMyNzJhMmZcIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PGNpcmNsZSBjeD1cIjEyMFwiIGN5PVwiMTIwXCIgcj1cIjEyMFwiIGZpbGw9XCJ1cmwoI2EpXCIvPjxwYXRoIGZpbGw9XCIjZmZmXCIgZD1cIk00OS45NDIgMTE4Ljk2bDgwLjgxLTMzLjI5NWM3Ljk3Ny0zLjQ2OCAzNS4wMy0xNC41NjYgMzUuMDMtMTQuNTY2czEyLjQ4Ni00Ljg1NSAxMS40NDUgNi45MzZjLS4zNDcgNC44NTUtMy4xMiAyMS44NS01Ljg5NiA0MC4yM2wtOC42NyA1NC40NXMtLjY5NCA3Ljk3Ny02LjYgOS4zNjRjLTUuOTA2IDEuMzg3LTE1LjYwNy00Ljg1NS0xNy4zNC02LjI0My0xLjM4Ny0xLjA0LTI2LjAxMi0xNi42NDctMzUuMDMtMjQuMjc3LTIuNDI4LTIuMDgtNS4yMDItNi4yNDMuMzQ3LTExLjA5OCAxMi40ODYtMTEuNDQ1IDI3LjQtMjUuNjY1IDM2LjQxNi0zNC42ODIgNC4xNjItNC4xNjIgOC4zMjQtMTMuODczLTkuMDE3LTIuMDhsLTQ4LjkwMiAzMi45NDhzLTUuNTUgMy40NjgtMTUuOTU0LjM0Ny0yMi41NDMtNy4yODMtMjIuNTQzLTcuMjgzLTguMzI0LTUuMjAyIDUuODk2LTEwLjc1elwiLz48L3N2Zz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IFR3aXR0ZXIgPSAocHJvcHMpID0+IHtcclxuICAgIGNvbnN0IHsgIHdpZHRoID0gNjAsIGhlaWdodCA9IDQ1LCBmaWxsIH0gPSBwcm9wcztcclxuICAgIHJldHVybiAoXHJcbjxzdmcgaGVpZ2h0PXt3aWR0aH0gd2lkdGg9e2hlaWdodH12aWV3Qm94PVwiLTQ0LjcwMDYgLTYwLjU0Nzc1IDM4Ny40MDUyIDM2My4yODY1XCI+PHBhdGggZmlsbD1cIiNub25lXCIgZD1cIk05My43MTkgMjQyLjE5YzExMi40NiAwIDE3My45Ni05My4xNjggMTczLjk2LTE3My45NiAwLTIuNjQ2LS4wNTQtNS4yOC0uMTczLTcuOTAzYTEyNC4zMzggMTI0LjMzOCAwIDAwMzAuNDk4LTMxLjY2Yy0xMC45NTUgNC44Ny0yMi43NDQgOC4xNDgtMzUuMTEgOS42MjYgMTIuNjIyLTcuNTcgMjIuMzEzLTE5LjU0MyAyNi44ODUtMzMuODE3YTEyMi42MiAxMjIuNjIgMCAwMS0zOC44MjQgMTQuODQxQzIzOS43OTggNy40MzMgMjIzLjkxNSAwIDIwNi4zMjYgMGMtMzMuNzY0IDAtNjEuMTQ0IDI3LjM4MS02MS4xNDQgNjEuMTMyIDAgNC43OTguNTM3IDkuNDY1IDEuNTg2IDEzLjk0MS01MC44MTUtMi41NTctOTUuODc0LTI2Ljg4Ni0xMjYuMDMtNjMuODhhNjAuOTc3IDYwLjk3NyAwIDAwLTguMjc5IDMwLjczYzAgMjEuMjEyIDEwLjc5NCAzOS45MzggMjcuMjA4IDUwLjg5M2E2MC42ODUgNjAuNjg1IDAgMDEtMjcuNjktNy42NDdjLS4wMDkuMjU3LS4wMDkuNTA3LS4wMDkuNzgxIDAgMjkuNjEgMjEuMDc1IDU0LjMzMiA0OS4wNTEgNTkuOTM0YTYxLjIxOCA2MS4yMTggMCAwMS0xNi4xMjIgMi4xNTIgNjAuODQgNjAuODQgMCAwMS0xMS40OTEtMS4xMDNjNy43ODQgMjQuMjkzIDMwLjM1NSA0MS45NzEgNTcuMTE1IDQyLjQ2NS0yMC45MjYgMTYuNDAyLTQ3LjI4NyAyNi4xNzEtNzUuOTM3IDI2LjE3MS00LjkyOSAwLTkuNzk4LS4yOC0xNC41ODQtLjg0NiAyNy4wNTkgMTcuMzQ0IDU5LjE4OSAyNy40NjQgOTMuNzIyIDI3LjQ2NFwiLz48L3N2Zz5cclxuXHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBNZWRpdW0gPSAocHJvcHMpID0+IHtcclxuICAgIGNvbnN0IHsgd2lkdGggPSAyNSwgaGVpZ2h0ID0gMjUsIGZpbGwgfSA9IHByb3BzO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8c3ZnIHdpZHRoPXt3aWR0aH0gaGVpZ2h0PXt3aWR0aH0gdmlld0JveD17YDAgMCAke3dpZHRofSAke2hlaWdodH1gfSBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cclxuICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgIGQ9XCJNMTIgMC41QzUuMzczMjEgMC41IDAgNS44NzMyMSAwIDEyLjVDMCAxOS4xMjY4IDUuMzczMjEgMjQuNSAxMiAyNC41QzE4LjYyNjggMjQuNSAyNCAxOS4xMjY4IDI0IDEyLjVDMjQgNS44NzMyMSAxOC42MjY4IDAuNSAxMlxyXG4gICAgICAgICAgICAwLjVaTTE4Ljg1NzEgNy4yOTU1NEwxNy43NjQzIDguMzQyODZDMTcuNjY3OSA4LjQxNTE4IDE3LjYyMjMgOC41MzMwNCAxNy42NDExIDguNjQ4MjFWMTYuMzU0NUMxNy42MjIzIDE2LjQ3MjMgMTcuNjY3OSAxNi41OTAyXHJcbiAgICAgICAgICAgIDE3Ljc2NDMgMTYuNjU5OEwxOC44MzU3IDE3LjcwNzFWMTcuOTQwMkgxMy40NTcxVjE3LjcxNzlMMTQuNTYzNCAxNi42NDM4QzE0LjY3MzIgMTYuNTMzOSAxNC42NzMyIDE2LjUwMTggMTQuNjczMiAxNi4zMzg0VjEwLjEwMjdMMTEuNTkyOVxyXG4gICAgICAgICAgICAxNy45MTM0SDExLjE3NzdMNy41OTM3NSAxMC4xMDI3VjE1LjMzOTNDNy41NjE2MSAxNS41NTg5IDcuNjM5MjkgMTUuNzgxMyA3Ljc5NDY0IDE1LjkzOTNMOS4yMzU3MSAxNy42ODNWMTcuOTE2MUg1LjE0Mjg2VjE3LjY4M0w2LjU4MzkzXHJcbiAgICAgICAgICAgIDE1LjkzOTNDNi42NTk4NSAxNS44NjA5IDYuNzE2MzYgMTUuNzY1NyA2Ljc0ODkyIDE1LjY2MTVDNi43ODE0OCAxNS41NTc0IDYuNzg5MTkgMTUuNDQ3IDYuNzcxNDMgMTUuMzM5M1Y5LjI4NTcxQzYuNzkwMTggOS4xMTY5NiA2LjcyNTg5XHJcbiAgICAgICAgICAgIDguOTUzNTcgNi41OTczMiA4LjgzODM5TDUuMzE2OTYgNy4yOTU1NFY3LjA2MjVIOS4yOTQ2NEwxMi4zNjQzIDEzLjc5OTFMMTUuMDY3IDcuMDY3ODZIMTguODU3MVY3LjI5NTU0WlwiXHJcbiAgICAgICAgICAgICAgICBmaWxsPVwiYmxhY2tcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgIDwvc3ZnPlxyXG4gICAgKVxyXG59XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCBmb250cyBmcm9tIFwiLi4vLi4vc3JjL3N0eWxlcy90eXBvZ3JhcGh5XCI7XHJcblxyXG5leHBvcnQgY29uc3QgSWNvbkxpbmsgPSBzdHlsZWQuYWBcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG4gIHRyYW5zaXRpb246IHRleHQtc2hhZG93IDAuM3MgZWFzZS1pbi1vdXQ7XHJcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEzMDBweCkge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEycHg7XHJcbiAgfVxyXG4gICY6aG92ZXJ7XHJcbiAgICAgIHRleHQtc2hhZG93OiAwIDI1cHggMjVweCByZ2JhKDAsMCwwLDAuMyk7XHJcbiAgfVxyXG5gOyIsImV4cG9ydCBjb25zdCBESVNDT1JEX0xJTksgPSAnaHR0cHM6Ly9kaXNjb3JkLmdnL3EyTWRNdGhGMnonO1xyXG5leHBvcnQgY29uc3QgVFdJVFRFUl9MSU5LID0gXCJodHRwczovL3R3aXR0ZXIuY29tL0RhQnVubnlORlRcIjtcclxuZXhwb3J0IGNvbnN0IFRFTEVfTElOSyA9IFwiaHR0cHM6Ly90Lm1lL0RhQnVubnlORlRcIjtcclxuZXhwb3J0IGNvbnN0IE1FRElVTV9MSU5LID0gXCJodHRwczovL21lZGl1bS5jb20vQGRhYnVubnluZnRcIjtcclxuIiwiZXhwb3J0IGNvbnN0IGZvbnRzID0ge1xyXG4gIGZvbnQ0MDoge1xyXG4gICAgdzE5MjA6IHtcclxuICAgICAgZm9udFNpemU6IFwiMjJweFwiLFxyXG4gICAgICBoZWlnaHQ6IFwiMzBweFwiLFxyXG4gICAgfSxcclxuICAgIHcxNjYwOiB7XHJcbiAgICAgIGZvbnRTaXplOiBcIjIycHhcIixcclxuICAgICAgaGVpZ2h0OiBcIjI4cHhcIixcclxuICAgIH0sXHJcbiAgICB3MTQ0MDoge1xyXG4gICAgICBmb250U2l6ZTogXCIyMnB4XCIsXHJcbiAgICAgIGhlaWdodDogXCIyOHB4XCIsXHJcbiAgICB9LFxyXG4gICAgdzc2ODoge1xyXG4gICAgICBmb250U2l6ZTogXCIxOHB4XCIsXHJcbiAgICAgIGhlaWdodDogXCIyNHB4XCIsXHJcbiAgICB9LFxyXG4gICAgdzUwMDoge1xyXG4gICAgICBmb250U2l6ZTogXCIxNnB4XCIsXHJcbiAgICAgIGhlaWdodDogXCIyMHB4XCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAgZm9udDI0OiB7XHJcbiAgICB3MTkyMDoge1xyXG4gICAgICBmb250U2l6ZTogXCIyMHB4XCIsXHJcbiAgICAgIGhlaWdodDogXCIyNnB4XCIsXHJcbiAgICB9LFxyXG4gICAgdzE2NjA6IHtcclxuICAgICAgZm9udFNpemU6IFwiMThweFwiLFxyXG4gICAgICBoZWlnaHQ6IFwiMjRweFwiLFxyXG4gICAgfSxcclxuICAgIHcxNDQwOiB7XHJcbiAgICAgIGZvbnRTaXplOiBcIjE4cHhcIixcclxuICAgICAgaGVpZ2h0OiBcIjI0cHhcIixcclxuICAgIH0sXHJcbiAgICB3NzY4OiB7XHJcbiAgICAgIGZvbnRTaXplOiBcIjE2cHhcIixcclxuICAgICAgaGVpZ2h0OiBcIjIwcHhcIixcclxuICAgIH0sXHJcbiAgICB3NTAwOiB7XHJcbiAgICAgIGZvbnRTaXplOiBcIjE0cHhcIixcclxuICAgICAgaGVpZ2h0OiBcIjE4cHhcIixcclxuICAgIH0sXHJcbiAgfSxcclxuICBmb250MjA6IHtcclxuICAgIHcxOTIwOiB7XHJcbiAgICAgIGZvbnRTaXplOiBcIjE2cHhcIixcclxuICAgICAgaGVpZ2h0OiBcIjIwcHhcIixcclxuICAgIH0sXHJcbiAgICB3MTY2MDoge1xyXG4gICAgICBmb250U2l6ZTogXCIxNnB4XCIsXHJcbiAgICAgIGhlaWdodDogXCIyMHB4XCIsXHJcbiAgICB9LFxyXG4gICAgdzE0NDA6IHtcclxuICAgICAgZm9udFNpemU6IFwiMTZweFwiLFxyXG4gICAgICBoZWlnaHQ6IFwiMjBweFwiLFxyXG4gICAgfSxcclxuICAgIHc3Njg6IHtcclxuICAgICAgZm9udFNpemU6IFwiMTZweFwiLFxyXG4gICAgICBoZWlnaHQ6IFwiMjBweFwiLFxyXG4gICAgfSxcclxuICAgIHc1MDA6IHtcclxuICAgICAgZm9udFNpemU6IFwiMTRweFwiLFxyXG4gICAgICBoZWlnaHQ6IFwiMThweFwiLFxyXG4gICAgfSxcclxuICB9LFxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmb250czsiLCJleHBvcnQgZW51bSBDT05ORUNUX1NUQVRVUyB7XHJcbiAgICBDT05ORUNULFxyXG4gICAgQ09OTkVDVEVELFxyXG4gICAgQ09OTkVDVElORyxcclxuICB9XHJcblxyXG5leHBvcnQgZW51bSBTQUxFX1NUQVRVUyB7XHJcbiAgICBPRkZTQUxFLFxyXG4gICAgT05TQUxFLFxyXG4gICAgU09MRE9VVCxcclxuICB9IiwiZXhwb3J0IGNvbnN0IERJU0NPUkRfTElOSyA9ICdodHRwczovL2Rpc2NvcmQuZ2cvcTJNZE10aEYyeic7XHJcbmV4cG9ydCBjb25zdCBUV0lUVEVSX0xJTksgPSBcImh0dHBzOi8vdHdpdHRlci5jb20vRGFCdW5ueU5GVFwiO1xyXG5leHBvcnQgY29uc3QgVEVMRV9MSU5LID0gXCJodHRwczovL3QubWUvRGFCdW5ueU5GVFwiO1xyXG5leHBvcnQgY29uc3QgTUVESVVNX0xJTksgPSBcImh0dHBzOi8vbWVkaXVtLmNvbS9AZGFidW5ueW5mdFwiO1xyXG4iLCIvLyBleHBvcnQgY29uc3QgbmZ0YWRkcmVzcyA9IFwiMHhhM2UxMTZCMGJDODY4OUI5MUUxMjQ2NzM2OGEzNkEzMEU4ODAzNDE3XCI7XHJcbmV4cG9ydCBjb25zdCBuZnRhZGRyZXNzID0gXCIweEI1MzUwRTU2MTAzNjBmOWRhRTViMjU0M0RBMzdENDkzY0I4ZjgyYjNcIjtcclxuZXhwb3J0IGNvbnN0IHNlcnZlclVybCA9IFwiXCI7XHJcbmV4cG9ydCBjb25zdCBqd3RUb2tlbiA9XCJcIjtcclxuIiwiaW1wb3J0IHsgZXRoZXJzIH0gZnJvbSBcImV0aGVyc1wiO1xyXG4vLyBpbXBvcnQge2RhYnVubnluZnRBYml9IGZyb20gXCIuL2RhYnVubnktbmZ0XCI7XHJcbmltcG9ydCBkYWJ1bm55bmZ0IGZyb20gXCIuL0RhQnVubnkuanNvblwiO1xyXG5cclxuaW1wb3J0IHsgbmZ0YWRkcmVzcyB9IGZyb20gXCIuL2NvbmZpZ1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldE5GVENvbnRyYWN0ID0gKHByb3ZpZGVyKSA9PiB7XHJcbiAgcmV0dXJuIG5ldyBldGhlcnMuQ29udHJhY3QobmZ0YWRkcmVzcywgZGFidW5ueW5mdC5hYmksIHByb3ZpZGVyKTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBnZXRORlRBZGRyZXNzID0gKCkgPT4ge1xyXG4gIHJldHVybiBuZnRhZGRyZXNzO1xyXG59O1xyXG5cclxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2Rpc3QvY2xpZW50L2ltYWdlJylcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9kaXN0L2NsaWVudC9saW5rJylcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBldGhlcnNwcm9qZWN0L3Byb3ZpZGVyc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAd2FsbGV0Y29ubmVjdC93ZWIzLXByb3ZpZGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImV0aGVyc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2VydmVyL2Rlbm9ybWFsaXplLXBhZ2UtcGF0aC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2VydmVyL2ltYWdlLWNvbmZpZy5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9oZWFkLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9zaGFyZWQvbGliL2kxOG4vbm9ybWFsaXplLWxvY2FsZS1wYXRoLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9zaGFyZWQvbGliL21pdHQuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyLWNvbnRleHQuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL2dldC1hc3NldC1wYXRoLWZyb20tcm91dGUuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL2lzLWR5bmFtaWMuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3BhcnNlLXJlbGF0aXZlLXVybC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcXVlcnlzdHJpbmcuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3JvdXRlLW1hdGNoZXIuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3JvdXRlLXJlZ2V4LmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9zaGFyZWQvbGliL3RvLWJhc2UtNjQuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvdXRpbHMuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9oZWFkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LWlzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LXN3aXBlYWJsZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC13YXlwb2ludFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3R5bGVkLWNvbXBvbmVudHNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwidmFsaWRhdG9yXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIndlYjNtb2RhbFwiKTsiLCIvKiAoaWdub3JlZCkgKi8iXSwibmFtZXMiOlsiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJleHBvcnRzIiwidmFsdWUiLCJkZWZhdWx0IiwiSW1hZ2UxIiwiX3JlYWN0IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJfaGVhZCIsIl90b0Jhc2U2NCIsIl9pbWFnZUNvbmZpZyIsIl91c2VJbnRlcnNlY3Rpb24iLCJfZGVmaW5lUHJvcGVydHkiLCJvYmoiLCJrZXkiLCJlbnVtZXJhYmxlIiwiY29uZmlndXJhYmxlIiwid3JpdGFibGUiLCJfX2VzTW9kdWxlIiwiX29iamVjdFNwcmVhZCIsInRhcmdldCIsImkiLCJhcmd1bWVudHMiLCJsZW5ndGgiLCJzb3VyY2UiLCJvd25LZXlzIiwia2V5cyIsImdldE93blByb3BlcnR5U3ltYm9scyIsImNvbmNhdCIsImZpbHRlciIsInN5bSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsImZvckVhY2giLCJfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMiLCJleGNsdWRlZCIsIl9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlIiwic291cmNlU3ltYm9sS2V5cyIsImluZGV4T2YiLCJwcm90b3R5cGUiLCJwcm9wZXJ0eUlzRW51bWVyYWJsZSIsImNhbGwiLCJzb3VyY2VLZXlzIiwibG9hZGVkSW1hZ2VVUkxzIiwiU2V0IiwiZ2xvYmFsIiwiX19ORVhUX0lNQUdFX0lNUE9SVEVEIiwiVkFMSURfTE9BRElOR19WQUxVRVMiLCJ1bmRlZmluZWQiLCJsb2FkZXJzIiwiTWFwIiwiZGVmYXVsdExvYWRlciIsImltZ2l4TG9hZGVyIiwiY2xvdWRpbmFyeUxvYWRlciIsImFrYW1haUxvYWRlciIsImN1c3RvbUxvYWRlciIsIlZBTElEX0xBWU9VVF9WQUxVRVMiLCJpc1N0YXRpY1JlcXVpcmUiLCJzcmMiLCJpc1N0YXRpY0ltYWdlRGF0YSIsImlzU3RhdGljSW1wb3J0IiwiZGV2aWNlU2l6ZXMiLCJjb25maWdEZXZpY2VTaXplcyIsImltYWdlU2l6ZXMiLCJjb25maWdJbWFnZVNpemVzIiwibG9hZGVyIiwiY29uZmlnTG9hZGVyIiwicGF0aCIsImNvbmZpZ1BhdGgiLCJkb21haW5zIiwiY29uZmlnRG9tYWlucyIsInByb2Nlc3MiLCJlbnYiLCJfX05FWFRfSU1BR0VfT1BUUyIsImltYWdlQ29uZmlnRGVmYXVsdCIsImFsbFNpemVzIiwic29ydCIsImEiLCJiIiwiZ2V0V2lkdGhzIiwid2lkdGgiLCJsYXlvdXQiLCJzaXplcyIsInZpZXdwb3J0V2lkdGhSZSIsInBlcmNlbnRTaXplcyIsIm1hdGNoIiwiZXhlYyIsInB1c2giLCJwYXJzZUludCIsInNtYWxsZXN0UmF0aW8iLCJNYXRoIiwibWluIiwid2lkdGhzIiwicyIsImtpbmQiLCJtYXAiLCJ3IiwiZmluZCIsInAiLCJnZW5lcmF0ZUltZ0F0dHJzIiwidW5vcHRpbWl6ZWQiLCJxdWFsaXR5Iiwic3JjU2V0IiwibGFzdCIsImpvaW4iLCJnZXRJbnQiLCJ4IiwiZGVmYXVsdEltYWdlTG9hZGVyIiwibG9hZGVyUHJvcHMiLCJsb2FkIiwiZ2V0Iiwicm9vdCIsIkVycm9yIiwiVkFMSURfTE9BREVSUyIsImhhbmRsZUxvYWRpbmciLCJpbWciLCJwbGFjZWhvbGRlciIsIm9uTG9hZGluZ0NvbXBsZXRlIiwiaGFuZGxlTG9hZCIsInN0YXJ0c1dpdGgiLCJkZWNvZGUiLCJQcm9taXNlIiwicmVzb2x2ZSIsImNhdGNoIiwidGhlbiIsInN0eWxlIiwiYmFja2dyb3VuZFNpemUiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJhZGQiLCJuYXR1cmFsV2lkdGgiLCJuYXR1cmFsSGVpZ2h0IiwicmVmIiwicGFyZW50RWxlbWVudCIsInBhcmVudCIsImdldENvbXB1dGVkU3R5bGUiLCJkaXNwbGF5IiwiY29uc29sZSIsIndhcm4iLCJwb3NpdGlvbiIsImNvbXBsZXRlIiwib25sb2FkIiwiX3BhcmFtIiwicHJpb3JpdHkiLCJsb2FkaW5nIiwibGF6eUJvdW5kYXJ5IiwiY2xhc3NOYW1lIiwiaGVpZ2h0Iiwib2JqZWN0Rml0Iiwib2JqZWN0UG9zaXRpb24iLCJibHVyRGF0YVVSTCIsImFsbCIsInJlc3QiLCJzdGF0aWNTcmMiLCJzdGF0aWNJbWFnZURhdGEiLCJKU09OIiwic3RyaW5naWZ5Iiwid2lkdGhJbnQiLCJoZWlnaHRJbnQiLCJxdWFsaXR5SW50IiwiaXNMYXp5IiwiaGFzIiwiaW5jbHVkZXMiLCJTdHJpbmciLCJpc05hTiIsIlZBTElEX0JMVVJfRVhUIiwicmFuZCIsImZsb29yIiwicmFuZG9tIiwidG9TdHJpbmciLCJzZXRSZWYiLCJpc0ludGVyc2VjdGVkIiwidXNlSW50ZXJzZWN0aW9uIiwicm9vdE1hcmdpbiIsImRpc2FibGVkIiwiaXNWaXNpYmxlIiwid3JhcHBlclN0eWxlIiwic2l6ZXJTdHlsZSIsInNpemVyU3ZnIiwiaW1nU3R5bGUiLCJ0b3AiLCJsZWZ0IiwiYm90dG9tIiwicmlnaHQiLCJib3hTaXppbmciLCJwYWRkaW5nIiwiYm9yZGVyIiwibWFyZ2luIiwibWluV2lkdGgiLCJtYXhXaWR0aCIsIm1pbkhlaWdodCIsIm1heEhlaWdodCIsImJsdXJTdHlsZSIsImJhY2tncm91bmRQb3NpdGlvbiIsIm92ZXJmbG93IiwicXVvdGllbnQiLCJwYWRkaW5nVG9wIiwiaW1nQXR0cmlidXRlcyIsInNyY1N0cmluZyIsImNyZWF0ZUVsZW1lbnQiLCJhbHQiLCJ0b0Jhc2U2NCIsImFzc2lnbiIsImRlY29kaW5nIiwicmVsIiwiYXMiLCJocmVmIiwiaW1hZ2VzcmNzZXQiLCJpbWFnZXNpemVzIiwibm9ybWFsaXplU3JjIiwic2xpY2UiLCJ1cmwiLCJVUkwiLCJwYXJhbXMiLCJzZWFyY2hQYXJhbXMiLCJzZXQiLCJwYXJhbXNTdHJpbmciLCJtaXNzaW5nVmFsdWVzIiwicGFyc2VkU3JjIiwiZXJyIiwiZXJyb3IiLCJob3N0bmFtZSIsImVuY29kZVVSSUNvbXBvbmVudCIsIl9yb3V0ZXIiLCJfcm91dGVyMSIsInByZWZldGNoZWQiLCJwcmVmZXRjaCIsInJvdXRlciIsIm9wdGlvbnMiLCJpc0xvY2FsVVJMIiwiY3VyTG9jYWxlIiwibG9jYWxlIiwiaXNNb2RpZmllZEV2ZW50IiwiZXZlbnQiLCJjdXJyZW50VGFyZ2V0IiwibWV0YUtleSIsImN0cmxLZXkiLCJzaGlmdEtleSIsImFsdEtleSIsIm5hdGl2ZUV2ZW50Iiwid2hpY2giLCJsaW5rQ2xpY2tlZCIsImUiLCJyZXBsYWNlIiwic2hhbGxvdyIsInNjcm9sbCIsIm5vZGVOYW1lIiwicHJldmVudERlZmF1bHQiLCJMaW5rIiwicHJvcHMiLCJjcmVhdGVQcm9wRXJyb3IiLCJhcmdzIiwiZXhwZWN0ZWQiLCJhY3R1YWwiLCJyZXF1aXJlZFByb3BzR3VhcmQiLCJyZXF1aXJlZFByb3BzIiwiXyIsIm9wdGlvbmFsUHJvcHNHdWFyZCIsInBhc3NIcmVmIiwib3B0aW9uYWxQcm9wcyIsInZhbFR5cGUiLCJoYXNXYXJuZWQiLCJ1c2VSZWYiLCJjdXJyZW50IiwidXNlUm91dGVyIiwidXNlTWVtbyIsInJlc29sdmVkSHJlZiIsInJlc29sdmVkQXMiLCJyZXNvbHZlSHJlZiIsImNoaWxkcmVuIiwiY2hpbGQiLCJDaGlsZHJlbiIsIm9ubHkiLCJjaGlsZFJlZiIsInNldEludGVyc2VjdGlvblJlZiIsInVzZUNhbGxiYWNrIiwiZWwiLCJ1c2VFZmZlY3QiLCJzaG91bGRQcmVmZXRjaCIsImlzUHJlZmV0Y2hlZCIsImNoaWxkUHJvcHMiLCJvbkNsaWNrIiwiZGVmYXVsdFByZXZlbnRlZCIsIm9uTW91c2VFbnRlciIsInR5cGUiLCJsb2NhbGVEb21haW4iLCJpc0xvY2FsZURvbWFpbiIsImdldERvbWFpbkxvY2FsZSIsImxvY2FsZXMiLCJkb21haW5Mb2NhbGVzIiwiYWRkQmFzZVBhdGgiLCJhZGRMb2NhbGUiLCJkZWZhdWx0TG9jYWxlIiwiY2xvbmVFbGVtZW50IiwiX2RlZmF1bHQiLCJyZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCIsIm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoIiwiZW5kc1dpdGgiLCJfX05FWFRfVFJBSUxJTkdfU0xBU0giLCJ0ZXN0IiwicmVxdWVzdElkbGVDYWxsYmFjayIsImNhbmNlbElkbGVDYWxsYmFjayIsInNlbGYiLCJiaW5kIiwid2luZG93IiwiY2IiLCJzdGFydCIsIkRhdGUiLCJub3ciLCJzZXRUaW1lb3V0IiwiZGlkVGltZW91dCIsInRpbWVSZW1haW5pbmciLCJtYXgiLCJpZCIsImNsZWFyVGltZW91dCIsIm1hcmtBc3NldEVycm9yIiwiaXNBc3NldEVycm9yIiwiZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCIsImNyZWF0ZVJvdXRlTG9hZGVyIiwiX2dldEFzc2V0UGF0aEZyb21Sb3V0ZSIsIl9yZXF1ZXN0SWRsZUNhbGxiYWNrIiwiTVNfTUFYX0lETEVfREVMQVkiLCJ3aXRoRnV0dXJlIiwiZ2VuZXJhdG9yIiwiZW50cnkiLCJmdXR1cmUiLCJyZXNvbHZlciIsInByb20iLCJoYXNQcmVmZXRjaCIsImxpbmsiLCJkb2N1bWVudCIsIk1TSW5wdXRNZXRob2RDb250ZXh0IiwiZG9jdW1lbnRNb2RlIiwicmVsTGlzdCIsInN1cHBvcnRzIiwiY2FuUHJlZmV0Y2giLCJwcmVmZXRjaFZpYURvbSIsInJlcyIsInJlaiIsInF1ZXJ5U2VsZWN0b3IiLCJjcm9zc09yaWdpbiIsIl9fTkVYVF9DUk9TU19PUklHSU4iLCJvbmVycm9yIiwiaGVhZCIsImFwcGVuZENoaWxkIiwiQVNTRVRfTE9BRF9FUlJPUiIsIlN5bWJvbCIsImFwcGVuZFNjcmlwdCIsInNjcmlwdCIsInJlamVjdCIsImJvZHkiLCJkZXZCdWlsZFByb21pc2UiLCJyZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0IiwibXMiLCJjYW5jZWxsZWQiLCJyIiwiX19CVUlMRF9NQU5JRkVTVCIsIm9uQnVpbGRNYW5pZmVzdCIsIl9fQlVJTERfTUFOSUZFU1RfQ0IiLCJnZXRGaWxlc0ZvclJvdXRlIiwiYXNzZXRQcmVmaXgiLCJyb3V0ZSIsInNjcmlwdHMiLCJlbmNvZGVVUkkiLCJjc3MiLCJtYW5pZmVzdCIsImFsbEZpbGVzIiwidiIsImVudHJ5cG9pbnRzIiwibG9hZGVkU2NyaXB0cyIsInN0eWxlU2hlZXRzIiwicm91dGVzIiwibWF5YmVFeGVjdXRlU2NyaXB0IiwiZmV0Y2hTdHlsZVNoZWV0IiwiZmV0Y2giLCJvayIsInRleHQiLCJjb250ZW50Iiwid2hlbkVudHJ5cG9pbnQiLCJvbkVudHJ5cG9pbnQiLCJleGVjdXRlIiwiZm4iLCJjb21wb25lbnQiLCJpbnB1dCIsIm9sZCIsImxvYWRSb3V0ZSIsInJvdXRlRmlsZXNQcm9taXNlIiwiZW50cnlwb2ludCIsInN0eWxlcyIsImZpbmFsbHkiLCJjbiIsIm5hdmlnYXRvciIsImNvbm5lY3Rpb24iLCJzYXZlRGF0YSIsImVmZmVjdGl2ZVR5cGUiLCJvdXRwdXQiLCJfd2l0aFJvdXRlciIsImNyZWF0ZVJvdXRlciIsIm1ha2VQdWJsaWNSb3V0ZXJJbnN0YW5jZSIsIl9yb3V0ZXJDb250ZXh0Iiwic2luZ2xldG9uUm91dGVyIiwicmVhZHlDYWxsYmFja3MiLCJyZWFkeSIsInVybFByb3BlcnR5RmllbGRzIiwicm91dGVyRXZlbnRzIiwiY29yZU1ldGhvZEZpZWxkcyIsImV2ZW50cyIsImZpZWxkIiwiZ2V0Um91dGVyIiwib24iLCJldmVudEZpZWxkIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzdWJzdHJpbmciLCJfc2luZ2xldG9uUm91dGVyIiwibWVzc2FnZSIsInN0YWNrIiwidXNlQ29udGV4dCIsIlJvdXRlckNvbnRleHQiLCJpbnN0YW5jZSIsInByb3BlcnR5IiwiQXJyYXkiLCJpc0FycmF5IiwiaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIiLCJJbnRlcnNlY3Rpb25PYnNlcnZlciIsImlzRGlzYWJsZWQiLCJ1bm9ic2VydmUiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsInVzZVN0YXRlIiwidGFnTmFtZSIsIm9ic2VydmUiLCJpZGxlQ2FsbGJhY2siLCJlbGVtZW50IiwiY2FsbGJhY2siLCJvYnNlcnZlciIsImVsZW1lbnRzIiwiY3JlYXRlT2JzZXJ2ZXIiLCJkZWxldGUiLCJzaXplIiwiZGlzY29ubmVjdCIsIm9ic2VydmVycyIsImVudHJpZXMiLCJpc0ludGVyc2VjdGluZyIsImludGVyc2VjdGlvblJhdGlvIiwid2l0aFJvdXRlciIsIkNvbXBvc2VkQ29tcG9uZW50IiwiV2l0aFJvdXRlcldyYXBwZXIiLCJnZXRJbml0aWFsUHJvcHMiLCJvcmlnR2V0SW5pdGlhbFByb3BzIiwibmFtZSIsImRpc3BsYXlOYW1lIiwiZGVsTG9jYWxlIiwiaGFzQmFzZVBhdGgiLCJkZWxCYXNlUGF0aCIsImludGVycG9sYXRlQXMiLCJfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCIsIl9yb3V0ZUxvYWRlciIsIl9kZW5vcm1hbGl6ZVBhZ2VQYXRoIiwiX25vcm1hbGl6ZUxvY2FsZVBhdGgiLCJfbWl0dCIsIl91dGlscyIsIl9pc0R5bmFtaWMiLCJfcGFyc2VSZWxhdGl2ZVVybCIsIl9xdWVyeXN0cmluZyIsIl9yZXNvbHZlUmV3cml0ZXMiLCJfcm91dGVNYXRjaGVyIiwiX3JvdXRlUmVnZXgiLCJkZXRlY3REb21haW5Mb2NhbGUiLCJfX05FWFRfSTE4Tl9TVVBQT1JUIiwiYmFzZVBhdGgiLCJfX05FWFRfUk9VVEVSX0JBU0VQQVRIIiwiYnVpbGRDYW5jZWxsYXRpb25FcnJvciIsImFkZFBhdGhQcmVmaXgiLCJwcmVmaXgiLCJwYXRoTm9RdWVyeUhhc2giLCJub3JtYWxpemVMb2NhbGVQYXRoIiwiZGV0ZWN0ZWRMb2NhbGUiLCJkZXRlY3RlZERvbWFpbiIsImh0dHAiLCJkb21haW4iLCJwYXRobmFtZSIsInBhdGhMb3dlciIsInRvTG93ZXJDYXNlIiwibG9jYWxlTG93ZXIiLCJzdWJzdHIiLCJxdWVyeUluZGV4IiwiaGFzaEluZGV4IiwibG9jYXRpb25PcmlnaW4iLCJnZXRMb2NhdGlvbk9yaWdpbiIsInJlc29sdmVkIiwib3JpZ2luIiwiYXNQYXRobmFtZSIsInF1ZXJ5IiwiaW50ZXJwb2xhdGVkUm91dGUiLCJkeW5hbWljUmVnZXgiLCJnZXRSb3V0ZVJlZ2V4IiwiZHluYW1pY0dyb3VwcyIsImdyb3VwcyIsImR5bmFtaWNNYXRjaGVzIiwiZ2V0Um91dGVNYXRjaGVyIiwiZXZlcnkiLCJwYXJhbSIsInJlcGVhdCIsIm9wdGlvbmFsIiwicmVwbGFjZWQiLCJzZWdtZW50IiwicmVzdWx0Iiwib21pdFBhcm1zRnJvbVF1ZXJ5IiwiZmlsdGVyZWRRdWVyeSIsInJlc29sdmVBcyIsImJhc2UiLCJ1cmxBc1N0cmluZyIsImZvcm1hdFdpdGhWYWxpZGF0aW9uIiwidXJsUHJvdG9NYXRjaCIsInVybEFzU3RyaW5nTm9Qcm90byIsInVybFBhcnRzIiwic3BsaXQiLCJub3JtYWxpemVkVXJsIiwibm9ybWFsaXplUmVwZWF0ZWRTbGFzaGVzIiwiYXNQYXRoIiwiZmluYWxVcmwiLCJpbnRlcnBvbGF0ZWRBcyIsImlzRHluYW1pY1JvdXRlIiwic2VhcmNoUGFyYW1zVG9VcmxRdWVyeSIsImhhc2giLCJzdHJpcE9yaWdpbiIsInByZXBhcmVVcmxBcyIsImhyZWZIYWRPcmlnaW4iLCJhc0hhZE9yaWdpbiIsInByZXBhcmVkVXJsIiwicHJlcGFyZWRBcyIsInJlc29sdmVEeW5hbWljUm91dGUiLCJwYWdlcyIsImNsZWFuUGF0aG5hbWUiLCJkZW5vcm1hbGl6ZVBhZ2VQYXRoIiwic29tZSIsInBhZ2UiLCJyZSIsIm1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uIiwiX19ORVhUX1NDUk9MTF9SRVNUT1JBVElPTiIsImhpc3RvcnkiLCJzZXNzaW9uU3RvcmFnZSIsInNldEl0ZW0iLCJyZW1vdmVJdGVtIiwibiIsIlNTR19EQVRBX05PVF9GT1VORCIsImZldGNoUmV0cnkiLCJhdHRlbXB0cyIsImNyZWRlbnRpYWxzIiwic3RhdHVzIiwianNvbiIsImRhdGEiLCJub3RGb3VuZCIsImZldGNoTmV4dERhdGEiLCJkYXRhSHJlZiIsImlzU2VydmVyUmVuZGVyIiwiUm91dGVyIiwiY29uc3RydWN0b3IiLCJwYXRobmFtZTEiLCJxdWVyeTEiLCJhczEiLCJpbml0aWFsUHJvcHMiLCJwYWdlTG9hZGVyIiwiQXBwIiwid3JhcEFwcCIsIkNvbXBvbmVudCIsIkNvbXBvbmVudDEiLCJlcnIxIiwic3Vic2NyaXB0aW9uIiwiaXNGYWxsYmFjayIsImlzUHJldmlldyIsInNkYyIsInNkciIsIl9pZHgiLCJvblBvcFN0YXRlIiwic3RhdGUiLCJjaGFuZ2VTdGF0ZSIsImdldFVSTCIsIl9fTiIsImZvcmNlZFNjcm9sbCIsImlkeCIsInBhZ2VYT2Zmc2V0IiwieSIsInBhZ2VZT2Zmc2V0IiwiZ2V0SXRlbSIsInBhcnNlIiwicGFyc2VSZWxhdGl2ZVVybCIsImlzU3NyIiwiX2JwcyIsImNoYW5nZSIsIl9zaGFsbG93IiwiY29tcG9uZW50cyIsImluaXRpYWwiLCJfX05fU1NHIiwiX19OX1NTUCIsImF1dG9FeHBvcnREeW5hbWljIiwiX19ORVhUX0RBVEFfXyIsImF1dG9FeHBvcnQiLCJzdWIiLCJjbGMiLCJfd3JhcEFwcCIsImlzUmVhZHkiLCJnc3NwIiwiZ2lwIiwiYXBwR2lwIiwiZ3NwIiwibG9jYXRpb24iLCJzZWFyY2giLCJfX05FWFRfSEFTX1JFV1JJVEVTIiwiX3Nob3VsZFJlc29sdmVIcmVmIiwiYWRkRXZlbnRMaXN0ZW5lciIsInNjcm9sbFJlc3RvcmF0aW9uIiwicmVsb2FkIiwiYmFjayIsIm1ldGhvZCIsInNob3VsZFJlc29sdmVIcmVmIiwiX2giLCJwcmV2TG9jYWxlIiwicGFyc2VkQXMiLCJsb2NhbGVQYXRoUmVzdWx0IiwiZGlkTmF2aWdhdGUiLCJhc05vQmFzZVBhdGgiLCJTVCIsInBlcmZvcm1hbmNlIiwibWFyayIsInJvdXRlUHJvcHMiLCJfaW5GbGlnaHRSb3V0ZSIsImFib3J0Q29tcG9uZW50TG9hZCIsImNsZWFuZWRBcyIsImxvY2FsZUNoYW5nZSIsIm9ubHlBSGFzaENoYW5nZSIsImVtaXQiLCJzY3JvbGxUb0hhc2giLCJub3RpZnkiLCJwYXJzZWQiLCJyZXdyaXRlcyIsImdldFBhZ2VMaXN0IiwiX19yZXdyaXRlcyIsInVybElzTmV3IiwicmV3cml0ZXNSZXN1bHQiLCJtYXRjaGVkUGFnZSIsInJvdXRlUmVnZXgiLCJyb3V0ZU1hdGNoIiwic2hvdWxkSW50ZXJwb2xhdGUiLCJtaXNzaW5nUGFyYW1zIiwicmVmMSIsInJvdXRlSW5mbyIsImdldFJvdXRlSW5mbyIsInBhZ2VQcm9wcyIsIl9fTl9SRURJUkVDVCIsImRlc3RpbmF0aW9uIiwicGFyc2VkSHJlZiIsIm5ld1VybCIsIm5ld0FzIiwiX19OX1BSRVZJRVciLCJub3RGb3VuZFJvdXRlIiwiZmV0Y2hDb21wb25lbnQiLCJhcHBDb21wIiwibmV4dCIsImlzUHJlcmVuZGVyZWQiLCJzdGF0dXNDb2RlIiwiaXNWYWxpZFNoYWxsb3dSb3V0ZSIsIl9zY3JvbGwiLCJzaG91bGRTY3JvbGwiLCJyZXNldFNjcm9sbCIsImRvY3VtZW50RWxlbWVudCIsImxhbmciLCJoYW5kbGVSb3V0ZUluZm9FcnJvciIsImxvYWRFcnJvckZhaWwiLCJnaXBFcnIiLCJyb3V0ZUluZm9FcnIiLCJleGlzdGluZ1JvdXRlSW5mbyIsImNhY2hlZFJvdXRlSW5mbyIsIm1vZCIsImlzVmFsaWRFbGVtZW50VHlwZSIsImdldERhdGFIcmVmIiwiX2dldERhdGEiLCJfZ2V0U3RhdGljRGF0YSIsIl9nZXRTZXJ2ZXJEYXRhIiwiZXJyMiIsImJlZm9yZVBvcFN0YXRlIiwib2xkVXJsTm9IYXNoIiwib2xkSGFzaCIsIm5ld1VybE5vSGFzaCIsIm5ld0hhc2giLCJzY3JvbGxUbyIsImlkRWwiLCJnZXRFbGVtZW50QnlJZCIsInNjcm9sbEludG9WaWV3IiwibmFtZUVsIiwiZ2V0RWxlbWVudHNCeU5hbWUiLCJwYXRobmFtZTIiLCJfaXNTc2ciLCJpc1NzZyIsImNhbmNlbCIsImNvbXBvbmVudFJlc3VsdCIsImxvYWRQYWdlIiwiY2FjaGVLZXkiLCJyZXNvdXJjZUtleSIsImN0eCIsIkFwcDEiLCJBcHBUcmVlIiwibG9hZEdldEluaXRpYWxQcm9wcyIsIlJlYWN0Iiwic3R5bGVkIiwiSGVhZCIsIkZhcSIsIkhlcm8iLCJOYXZCYXIiLCJXaGF0RGEiLCJDb21tdW5pdHkiLCJGb290ZXIiLCJSb2FkbWFwIiwiRXZvbHV0aW9uIiwiRWdncyIsIkJ1bm5pZXNDYXJvdXNlbCIsIldlYjNQcm92aWRlciIsImV0aGVycyIsIldlYjNNb2RhbCIsIldhbGxldENvbm5lY3RQcm92aWRlciIsImdldE5GVEFkZHJlc3MiLCJnZXRORlRDb250cmFjdCIsIkxhbmRpbmdXcmFwIiwibWFpbiIsIkRhQnVubnlfTkZUX0FkZHJlc3MiLCJORVhUX1BVQkxJQ19EQUJVTk5ZX05GVENPTlRSQUNUX0FERFJFU1MiLCJJTkZVUkFfSUQiLCJORVhUX1BVQkxJQ19JTkZVUkFfQVBJX0tFWV8xIiwiSG9tZSIsIm5ldHdvcmtOYW1lIiwic2V0TmV0d29ya05hbWUiLCJwcm92aWRlciIsInNldFByb3ZpZGVyIiwidXNlckJhbGFuY2UiLCJzZXRVc2VyQmFsYW5jZSIsImFkZHJlc3MiLCJzZXRBZGRyZXNzIiwidXNlckRhdGEiLCJzZXRVc2VyRGF0YSIsImJhbGFuY2UiLCJuZXR3b3JrIiwic2V0TWVzc2FnZSIsInByb3ZpZGVyT3B0aW9ucyIsIndhbGxldGNvbm5lY3QiLCJwYWNrYWdlIiwiaW5mdXJhSWQiLCJhc3NldERhdGEiLCJidXllckFkZHJlc3MiLCJub3JtYWxUb2tlbklkcyIsInJhcmVUb2tlbklkcyIsInRvdGFsUHJpY2VQYWlkIiwiZW1haWxJZCIsInN1YnNjcmliZVN0YXR1cyIsInB1cmNoYXNlZFRpbWVTdGFtcCIsIm9uTWludFRva2VuIiwidG9rZW5Db3VudCIsImlzUmFyaXR5IiwidG9rZW5QcmljZSIsImxvZyIsInNpZ25lciIsImdldFNpZ25lciIsImFjY291bnRBZGRyZXNzIiwiZ2V0QWRkcmVzcyIsIm5mdENvbnRyYWN0IiwicHJpY2UiLCJ1dGlscyIsInBhcnNlRXRoZXIiLCJyZWNlaXB0IiwibWludCIsInR4Iiwid2FpdCIsInRva2VuSWRzIiwiTnVtYmVyIiwicmVzcG9uc2UiLCJlcnJNZXNzIiwiYWxlcnQiLCJvbkNvbm5lY3RXYWxsZXQiLCJ3ZWIzTW9kYWwiLCJjYWNoZVByb3ZpZGVyIiwiY2xlYXJDYWNoZWRQcm92aWRlciIsIndlYjNwcm92aWRlciIsImNvbm5lY3QiLCJuZXR3b3JrZGF0YSIsImdldE5ldHdvcmsiLCJiYWwiLCJmb3JtYXRFdGhlciIsImdldEJhbGFuY2UiLCJJbWFnZSIsInVzZVN3aXBlYWJsZSIsImZvbnRzIiwiaGlzdG9yeUl0ZW1zIiwiaW1hZ2UiLCJTZWN0aW9uV3JhcCIsInNlY3Rpb24iLCJJdGVtV3JhcCIsImRpdiIsIkJsb2NrIiwiUGFyYWdyYXBoIiwiZm9udDI0IiwidzE0NDAiLCJmb250U2l6ZSIsInc3NjgiLCJ3NTAwIiwiSXRlbSIsInByZXNzSG9sZCIsImNsaWNrZWQiLCJjb3VudCIsImRpcmVjdGlvbiIsInNpemVTbGlkZXIiLCJpdGVtIiwiZXhwYW5zaW9uUmF0ZSIsImV2IiwidHJhbnNmb3JtIiwibW92ZW1lbnRYIiwib25lRWxlbWVudFdpZHRoIiwiZmlyc3RDaGlsZCIsIm9mZnNldFdpZHRoIiwibnVtYmVyT2ZFbGVtZW50IiwibmV4dFBvc2l0aW9uIiwiaW5uZXJXaWR0aCIsInByZXZpb3VzUG9zaXRpb24iLCJ0cmFuc2l0aW9uIiwic2V0VmFyaWFibGVzIiwiY3VycmVudFBvc2l0aW9uIiwiaGFuZGxlcnMiLCJvblN3aXBpbmciLCJkZWx0YVgiLCJkaXIiLCJzcGVlZCIsInNpZ24iLCJvblN3aXBlZExlZnQiLCJvblN3aXBlZFJpZ2h0IiwiZGVsdGEiLCJwcmV2ZW50RGVmYXVsdFRvdWNobW92ZUV2ZW50IiwidHJhY2tUb3VjaCIsIlNlY3Rpb24iLCJJbm5lcldyYXAiLCJUaXRsZVRvcCIsImgyIiwiZm9udDQwIiwidzE5MjAiLCJ3MTY2MCIsIlRpdGxlIiwiUG9zaXRpb24iLCJJbWFnZVdyYXAiLCJJbWFnZUJveCIsIkJ1bm55Qm94IiwiQnViYmxlc0ltYWdlIiwiQnVubnkiLCJ0aXRsZSIsIkNhcnJvdEhlYWRlciIsIkhlYWRlcldyYXAiLCJFZ2dzSW1hZ2VzIiwiRWdnc0xpc3QiLCJ1bCIsIkJhY2tncm91bmQiLCJCYWNrZ3JvdW5kTW9iaWxlIiwiQmFja2dyb3VuZE1vYmlsZVNtYWxsIiwiVG9wSW1hZ2UiLCJMaXN0SXRlbSIsImxpIiwiaDMiLCJUZXh0IiwiZm9udDIwIiwiQnViYmxlSW1hZ2UiLCJFZ2dMaXN0T3V0ZXJXcmFwIiwiRWdnc0luZm9MaXN0IiwiRWdnc0luZm8iLCJFZ2dJbWFnZVdyYXAiLCJFZ2dzRGF0YSIsIkVnZ3NIZWFkZXJEZXRhaWxzIiwibGlzdEhlaWdodCIsInNldExpc3RIZWlnaHQiLCJyZXNpemVFdmVudEhhbmRsZSIsImVnZ0ltYWdlIiwiZ2V0RWxlbWVudHNCeVRhZ05hbWUiLCJpbWFnZUhlaWdodCIsIm9mZnNldEhlaWdodCIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJCYWNrSW5EYXlzIiwiQ29udGVudEltYWdlIiwiQ29udGVudFRleHQiLCJDb250ZW50V3JhcCIsIkJhY2tJbkRheXNUZXh0IiwiVGhyZWVCdW5uaWVzIiwiVGhyZWVCdW5uaWVzVGV4dCIsIkFudE1pbmVyIiwiQW50TWluZXJUZXh0IiwiQ29udGVudERlc2t0b3AiLCJCbG9ja1RleHQiLCJCbG9ja1dyYXAiLCJDb250ZW50TW9iaWxlIiwiQm90dG9tVGV4dCIsIkZ1bm55QnVubmllc0ltYWdlIiwiaXNNb2JpbGUiLCJzZXRJc01vYmlsZSIsIklubmVyTGltaXQiLCJRdWVzdGlvbldyYXAiLCJUZXh0SGVhZGVyIiwiVGV4dEhlYWRlckZpcnN0IiwiTGlzdCIsIkRyb3BEb3duIiwiZXhwYW5kZWQiLCJDbGlja1Nob3ciLCJBcnJvdyIsInNldEV4cGFuZGVkIiwidG9nZ2xlU2hvdyIsIm5mdGFkZHJlc3MiLCJ2YWxpZGF0b3IiLCJESVNDT1JEX0xJTksiLCJCdW5ueUltYWdlIiwiTGFuZHNjYXBlSW1hZ2UiLCJTbWFydENvbnRyYWN0V3JhcCIsIlNtYXJ0TGVmdCIsIlRleHRUb3AiLCJUZXh0TWlkZGxlIiwiVG9rZW5Cb3R0b20iLCJTbWFydFJpZ2h0IiwiVGV4dFJpZ2h0IiwiTGlua3MiLCJDb3B5cmlnaHQiLCJFbWFpbFN1YnNjcmliZSIsIkN1c3RvbUlucHV0VGV4dCIsIkN1c3RvbUlucHV0QnRuIiwiRGlzcGxheU1lc3NhZ2UiLCJMb2FkZXIiLCJlbWFpbCIsInNldEVtYWlsIiwib25FbWFpbFN1YnNjcmliZUhhbmRsZSIsImlzRW1haWwiLCJlbWFpbERhdGEiLCJ1c2VyQWRkcmVzcyIsIkNPTk5FQ1RfU1RBVFVTIiwiU0FMRV9TVEFUVVMiLCJDdGFCdXR0b24iLCJGaXJzdExheWVyIiwiU2Vjb25kTGF5ZXIiLCJCdXR0b25UZXh0IiwiQnV0dG9uVGV4dENsaWNrIiwiTGVmdENvcm5lclNWRyIsIlJpZ2h0Q29ybmVyU1ZHIiwiTGVmdENvcm5lciIsIlJpZ2h0Q29ybmVyIiwiQ29ubmVjdEJ1dHRvbiIsImNvbm5lY3RTdGF0dXMiLCJzYWxlU3RhdHVzIiwic2V0U2hvd01pbnRCb3giLCJPRkZTQUxFIiwiT05TQUxFIiwiQ09OTkVDVCIsIk1pbnRCdXR0b24iLCJCYW5uZXJJbWFnZSIsIkpvaW5Cb3hEZXNrdG9wIiwiSm9pbkJveE1vYmlsZSIsIkpvaW5DdGEiLCJNaW50Qm94IiwiTWludFRvcCIsIk1pbnRNaWRkbGUiLCJDbG9zZSIsIlJhcml0eSIsIkxpbWl0Iiwib25SYXJpdHlQcmljZUNsaWNrZWQiLCJ0YWJpbmRleCIsInJlc2l6ZUZhY3RvciIsInNldFJlc2l6ZUZhY3RvciIsImJ1bm55Q291bnQiLCJzZXRCdW5ueUNvdW50Iiwic2hvd01pbnRCb3giLCJzZXRJc1Jhcml0eSIsIm1pbnRCdG5UZXh0Iiwic2V0TWludEJ0blRleHQiLCJvbk1pbnRUb2tlbjEiLCJpbm5lclRleHQiLCJ3aW5kb3dXaWR0aCIsImFtb3VudENoYW5nZSIsImFtb3VudCIsIkNhbGVuZGFyQm94IiwiRGF0ZXNTaWRlIiwiRGF0ZVRleHQiLCJMaW5lRG93biIsIkluZm9TaWRlIiwiSW5mb1dyYXAiLCJIZWF2eUluZm8iLCJJbmZvTGlzdCIsIkluZm9JdGVtIiwiQ2FsZW5kYXJCb3hGb3VyIiwiTGlnaHRJbmZvIiwiQ2FsZW5kYXJCb3hPbmUiLCJDYWxlbmRhckJveFRocmVlIiwiQ2FsZW5kYXJCb3hUd28iLCJXYXlwb2ludCIsIlJvY2tldEJ1bm55Iiwicm9ja2V0T25TY3JlZW4iLCJBY3RpdmF0aW9uc0JveCIsIlZlY3RvcldyYXAiLCJBY3RpdmF0aW9uVGl0bGUiLCJBY3RpdmF0aW9uTGlzdCIsIkFjdGl2YXRpb25JdGVtIiwiQ2FsZW5kYXJUaXRsZSIsIkNhbGVuZGFyVGl0bGVXcmFwIiwiQ2FsZW5kYXJUaXRsZVNoYWRvdyIsIkNhbGVuZGFyTGltaXQiLCJUb3BWZWN0b3IiLCJwZXJjZW50Iiwic2V0Um9ja2V0T25TY3JlZW4iLCJyb2NrZXRBcHBlYXJzIiwiaW5kZXgiLCJIZWFkZXJXcmFwcGVyIiwiV3JhcCIsImJnQ29sb3IiLCJDYXJyb3RXcmFwIiwiTXlkaXYiLCJTbWFsbGIiLCJTbWFsbHMiLCJzaG9ydEFkZHJlc3MiLCJ0b0ZpeGVkIiwiTGlua1dyYXAiLCJNb2JpbGVMaW5rVGV4dCIsIk1vYmlsZUxpbmsiLCJ0b2dnbGVOYXZNb2JpbGUiLCJoYW5kbGVDbGljayIsImFuaW1hdGlvblRpbWVvdXQiLCJtb2JpbGVUb3VjaCIsIkRpc2NvcmQiLCJUd2l0dGVyIiwiVGVsZWdyYW0iLCJUV0lUVEVSX0xJTksiLCJURUxFX0xJTksiLCJhZGp1c3RTY3JvbGwiLCJJY29uTGluayIsIk5hdiIsIk5hdkxpbmsiLCJHcm91cCIsIkxvZ28iLCJuYXZNb2JpbGVQb3NpdGlvbiIsInNldE5hdk1vYmlsZVBvc2l0aW9uIiwiaXNNb2JpbGVOYXZPcGVuIiwic2V0SXNNb2JpbGVOYXZPcGVuIiwicG9zaXRpb25GaXgiLCJzZXRQb3NpdGlvbkZpeCIsImFib3V0IiwicmFiYml0Iiwicm9hZG1hcCIsImZhcSIsImdldEhyZWYiLCJ2YWx1ZU9mRml4Iiwic2Nyb2xsQnkiLCJnZXRCb3VuZGluZ0NsaWVudFJlY3QiLCJiZWhhdmlvciIsIkRlc2t0b3BMaW5rIiwiTW9iaWxlTGlua1ByZXAiLCJIYW1idXJndWVyIiwiaXNPcGVuIiwiTmF2TW9iaWxlIiwiTW9iaWxlSW5uZXIiLCJzcGFuIiwiU29jTGlua3MiLCJmaWxsIiwiTWVkaXVtIiwiTUVESVVNX0xJTksiLCJzZXJ2ZXJVcmwiLCJqd3RUb2tlbiIsImRhYnVubnluZnQiLCJDb250cmFjdCIsImFiaSJdLCJzb3VyY2VSb290IjoiIn0=