// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const { ethers } = require("hardhat");

async function main() {

  //baseURI and not revealed uri
  let baseURI = "https://gateway.pinata.cloud/ipfs/QmYJfBnWNVjYR2gayhRZucjScnTg1D9h6wqpPotr2qd7N4/";
  let notRevealedUri = "https://gateway.pinata.cloud/ipfs/QmSXTv28979BJUVX41368hp42xx2JeJaRkx3D9NtTBeLqe";
  
  // We get the contract to deploy
  const accts = await ethers.getSigners();
  accts.forEach( acct => {
    console.log('Account address: ', acct.address);
  })

  //Get NFTContract
  const NFTContract1 = await ethers.getContractFactory('AAA')
  //deploy nft
  const nftDeployed1 = await NFTContract1.deploy(accts[0].address, accts[1].address, accts[2].address);
  await nftDeployed1.deployed();
  console.log('NFT Contract deployed to address:', nftDeployed1.address)
  console.log("NTF owner: ", await nftDeployed1.owner());
 
  //Get SinglePriceNFTcontract
  const NFTContract2 = await ethers.getContractFactory('SinglePriceNFTcontract')
  //deploy nft
  const nftDeployed2 = await NFTContract2.deploy(accts[0].address, accts[1].address, accts[2].address);
  await nftDeployed2.deployed();
  console.log('NFT Contract deployed to address:', nftDeployed2.address)
  console.log("NTF owner: ", await nftDeployed2.owner());
  
  //set not revealed URI
  // await nftDeployed.setNotRevealedURI(notRevealedUri);
  // console.log("Not revealed URI set to - ", await nftDeployed.notRevealedUri());

  //set baseURI of the nft
  await nftDeployed1.setBaseURI(notRevealedUri);
  let baseURI1 = await nftDeployed1.getBaseURI();
  console.log("baseURI set to - ", baseURI1);

  // let tokenId;

  // // mint one nft
  // let tx = await nftDeployed.mint(2,
  //   {value: ethers.utils.parseEther('0.1'), gasLimit: 300000});
  // const receipt = await tx.wait();
  // // console.log('receipt: ', receipt);
  // for (const event of receipt.events) {
  //   if (event.event !== 'Transfer') {
  //     console.log('ignoring unknown event type ', event.event)
  //     continue
  //   }
  //   tokenId = event.args.tokenId.toString()
  //   console.log("TokenId fetched - ", tokenId);
  // }
  // console.log('1 - tokenURI of tokenID: ', tokenId, await nftDeployed.tokenURI(tokenId));

  
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
