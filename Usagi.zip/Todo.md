## TODO: 

## Notes
For emails to work
- SET admin emailId and password at /util/auth.config

## DONE
2. Hide and show mint box from Hero.tsx file.
3. remove all bunny names
4. contract with only one price

## git
$ git fetch origin main //merge main branch to current branch

## COMMANDS

## Deployed Contract Address
NFT Contract address:   0xa3e116B0bC8689B91E12467368a36A30E8803417
NTF owner:              0xda210a5DF6985380DeE4990C914744e54E771Ad6

## compile
$ npx hardhat compile

## Deploy
$ npx hardhat run scripts/deploy.js --network mainnet
$ npx hardhat run scripts/deploy.js --network rinkeby

## Verify Network
$ npx hardhat verify 0xa3e116B0bC8689B91E12467368a36A30E8803417 '0xda210a5DF6985380DeE4990C914744e54E771Ad6' '0xda210a5DF6985380DeE4990C914744e54E771Ad6' '0xda21D8719698b6aaB21c3ACe883f6dD6C7690aC3' '0x361381fBA49814e5A652422D8B9481143e7D6397' --network rinkeby 

$ npx hardhat verify 0x4DD3A47C4D45E5F38d2e9D766ABD678199af1476 '0xda210a5DF6985380DeE4990C914744e54E771Ad6' '0xda210a5DF6985380DeE4990C914744e54E771Ad6' '0xda21D8719698b6aaB21c3ACe883f6dD6C7690aC3' '0x361381fBA49814e5A652422D8B9481143e7D6397' --network rinkeby 
$ npx hardhat verify --network mainnet  0xcontract_address 

## Test
$ npx hardhat test test/dabunnynft-test.js 
$ npx hardhat test test/dabunnynft-test.js --network rinkeby 

## Local testing
$ npx hardhat test --network hardhat test/dabunnynft-test.js


## notes
1. Max total Supply = total minted nfts 

NFT References
https://etherscan.io/token/0x1dc5d3b2162f9500d7ddec14eb0ba9ccb43bc20c
https://etherscan.io/address/0xfd3c3717164831916e6d2d7cdde9904dd793ec84#code