import React from 'react'

function Loader(props: any) {
  return <div>Loading...</div>
}

export default Loader
