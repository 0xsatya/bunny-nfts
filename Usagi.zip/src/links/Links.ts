export const DISCORD_LINK = 'https://discord.gg/q2MdMthF2z';
export const TWITTER_LINK = "https://twitter.com/DaBunnyNFT";
export const TELE_LINK = "https://t.me/DaBunnyNFT";
export const MEDIUM_LINK = "https://medium.com/@dabunnynft";
