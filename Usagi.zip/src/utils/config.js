// export const nftaddress = "0xa3e116B0bC8689B91E12467368a36A30E8803417";
export const nftaddress = "0xB5350E5610360f9daE5b2543DA37D493cB8f82b3";
export const serverUrl = "";
export const jwtToken ="";
