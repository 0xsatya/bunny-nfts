export enum CONNECT_STATUS {
    CONNECT,
    CONNECTED,
    CONNECTING,
  }

export enum SALE_STATUS {
    OFFSALE,
    ONSALE,
    SOLDOUT,
  }